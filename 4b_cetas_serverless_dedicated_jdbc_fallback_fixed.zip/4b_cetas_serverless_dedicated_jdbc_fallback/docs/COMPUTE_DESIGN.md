# Compute design — 4B — serverless CETAS + dedicated JDBC fallback

## Intended nightly flow

`Refresh complete → serverless plan/CETAS → dedicated DBR 18.x JDBC fallback only when required → serverless Delta publish → final summary`

| Stage | Compute | Purpose |
|---|---|---|
| Plan / Synapse checks | Serverless | Uses `mssql-python` for command-capable T-SQL connection |
| CETAS | Serverless Databricks task; CETAS executes in Synapse | Issues CETAS DDL through `mssql-python` |
| JDBC fallback | Dedicated DBR 18.x job cluster | Spark JDBC bulk read for only `FALLBACK_REQUIRED` tables |
| Delta publish | Serverless | Publishes all `VALIDATED` CETAS/JDBC stages independently |
| Finalize | Serverless | Final success/failure/fallback summary |

The dedicated `bridge` cluster exists only for the exceptional JDBC fallback task; successful CETAS tables never use it.

## Why CETAS can be serverless

CETAS itself always executes inside the Synapse dedicated SQL pool. The Databricks task only submits and monitors the T-SQL command. On serverless, this package uses Microsoft's `mssql-python` DB-API driver because Spark Connect intentionally has no JVM gateway. This avoids relying on an undocumented attempt to execute DDL through a read-only remote-query pattern.

## Static-source assumption

The upstream tables refresh once per night and are immutable after the COMPLETE signal. Extraction does not start before that signal. Per-table failures do not block unrelated `VALIDATED` tables from publication.
