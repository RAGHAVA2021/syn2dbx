# Package guide — 4B — serverless CETAS + dedicated JDBC fallback

**Package:** `4b_cetas_serverless_dedicated_jdbc_fallback.zip`

**Nightly flow:** `Refresh complete → serverless plan/CETAS → dedicated DBR 18.x JDBC fallback only when required → serverless Delta publish → final summary`

The dedicated `bridge` cluster exists only for the exceptional JDBC fallback task; successful CETAS tables never use it.

---

# 4B compute-variant addendum

The base guide remains valid for contracts, control tables and recovery semantics. The nightly task chain in **this ZIP** is:

`00_plan.py` (serverless) → `10_extract_validate_batch.py` (serverless CETAS + validation) → `20_dedicated_jdbc_fallback.py` (dedicated cluster only for FALLBACK_REQUIRED) → `30_publish_batch.py` (serverless) → `90_finalize.py` (serverless).

`10_process_batch.py` is retained as the original reference implementation and for regression tests; `databricks.yml` does not schedule it in this variant.

See `COMPUTE_DESIGN.md` for prerequisites and the compute boundary.

---

# Package guide: Synapse to Databricks full refresh (v2.6.5)

This is the navigation guide for the shipped files. Read [DESIGN.md](DESIGN.md)
for the detailed safety decisions, [CODE_STRUCTURE.md](CODE_STRUCTURE.md) for
module dependencies and call sequences, [DATA_DICTIONARY.md](DATA_DICTIONARY.md)
for control-table columns and identifiers, and [RUNBOOK.md](RUNBOOK.md) for exact
setup, deployment, recovery, and rollback commands. File roles below describe the
package as delivered, including the optional manifest and upstream table modes.

## 1. What the package does

Each Sydney business date, an upstream completion signal certifies that the
Synapse source set is ready. The Databricks job plans enabled mappings, exports
each source through CETAS (with a bounded JDBC fallback for eligible failures),
validates the staged Parquet, and atomically overwrites each Unity Catalog Delta
target. A table failure is logged without stopping unrelated tables. After the
last batch, finalize records the run result and POSTs one complete summary to
an operator-owned HTTPS workflow. That workflow formats and delivers the email.

```mermaid
flowchart TD
  U["Upstream completion and counts"] --> P["00_plan: validate and batch"]
  P --> B["10_process_batch: each table"]
  B --> S["CETAS or JDBC → ADLS Parquet"]
  S --> V["Validate → UC Delta overwrite"]
  B --> L["UC table_log"]
  V --> L
  L --> F["90_finalize: count outcomes"]
  F --> R["UC run_log"]
  F --> N["HTTPS summary → operator email"]
```

The three notebooks are ordered by `databricks.yml`. The Python modules in
`src/bridge` implement reusable logic; notebooks supply Spark, Synapse, storage,
secrets, and job parameters. The `sql`, `tools`, and `infra` folders prepare the
environment; they do not run once per table each night.

### How the folders relate

```mermaid
flowchart LR
  CFG["config/<br/>settings + examples"] -->|input| TOOLS["tools/<br/>generate_inventory, render_uc_setup"]
  TOOLS -->|inventory.json| CFG
  TOOLS -->|uc_setup.sql| UC[("Unity Catalog<br/>control + target tables")]
  SQLS["sql/synapse/"] -->|one-time objects, grants| SYN[("Synapse pool")]
  SQLU["sql/unity_catalog/"] -->|upgrades only| UC
  INFRA["infra/"] -->|lifecycle rule| ADLS[("ADLS staging")]
  GH[".github/workflows/"] -->|prepare_deploy + bundle deploy| YML
  YML["databricks.yml"] -->|defines jobs that run| NB["src/notebooks/"]
  NB -->|imports| BR["src/bridge/"]
  CFG -->|deployed inventory.json| NB
  BR --> SYN
  BR --> ADLS
  BR --> UC
  TESTS["tests/"] -->|verify| BR
  TESTS -->|verify| TOOLS
  DOCS["docs/ + README + AGENTS"] -.->|describe| BR
```

| Folder | Role | When it is used | Depends on / feeds |
|---|---|---|---|
| `config/` | The contract: which tables, where, and how | Setup; read by every job run | Filled by operator and `tools/`; read by notebooks and `tools/render_uc_setup.py` |
| `tools/` | Generators run from a workstation | Setup and when tables change | Reads `config/` and the Synapse catalog; writes `inventory.json` and UC setup SQL |
| `sql/synapse/` | Pool-side objects and permissions | One-time setup | Creates what `src/bridge/synapse.py` uses (schemas, scoped credential, external data source, Parquet file format, job user and grants) |
| `sql/unity_catalog/` | Control-table upgrades | Only when upgrading an older installation | Must match `tools/render_uc_setup.py` and `src/bridge/control.py` columns |
| `infra/` | Storage retention and identity notes | One-time setup | Cleans the ADLS staging folders written by the job |
| `.github/workflows/` | CI/CD | Every pull request and merge | Runs `tests/`, `tools/prepare_deploy.py` and `databricks bundle deploy` |
| `databricks.yml` | Job definitions | Deployment | Runs the notebooks with parameters, cluster, schedule, retries |
| `src/notebooks/` | Job entry points | Every run | Import `src/bridge`; hold Spark, `dbutils` and secret handles |
| `src/bridge/` | All logic and decisions | Every run | Used by notebooks, `tools/` and `tests/` |
| `tests/` | Local verification | Every change | Tests `src/bridge`, `tools/`, `databricks.yml` and `AGENTS.md` |
| `docs/` | Human documentation | Reading | Describes all of the above |

Module-level dependencies, the notebook-to-module map and call sequences are in
[CODE_STRUCTURE.md](CODE_STRUCTURE.md).

## 2. Folder and file inventory

### Root

| File | Purpose and main input → output |
|---|---|
| `FIRST_READ_ME.md` | Reading order by role, where to find specific answers, which documents to publish to Confluence. |
| `README.md` | Entry point, package overview, compact tree, quick start, test command. |
| `AGENTS.md` | Design invariants, architecture ownership, constraints, status vocabulary and change guidance for maintainers. |
| `CHANGELOG.md` | Versioned changes and upgrade actions. |
| `databricks.yml` | Asset Bundle definition. Cluster, schedule, parameters, ACLs, task graph and retries → nightly, acceptance, rollback, and maintenance jobs. |
| `requirements-dev.txt` | Local development and test dependencies; the job runtime is governed separately by the Databricks cluster. |
| `.github/workflows/ci-cd.yml` | GitHub Actions: tests on pull requests; on merge to `main`, deploy to dev, then prod after approval; manual per-environment deploy. |
| `.github/workflows/bundle-deploy.yml` | Reusable deploy of one environment: checks variables, selects inventory, GitHub OIDC → Azure login, `bundle validate` and `bundle deploy`. |
| `.gitignore` | Excludes build output, Databricks state, Spark local files and Python caches from Git. Review sensitive generated inventory/settings before committing; this file does not exclude them. |

### `config/`: contract and example data

| File | Purpose and main input → output |
|---|---|
| `settings.example.json` | Copy to `settings.json`; supply Synapse, manifest, staging, control, execution, governance and summary-webhook secret settings → input to inventory generation. |
| `inventory.example.json` | Two-table example of the complete validated inventory, including mapping schemas and notification settings → reference for the deployed `inventory.json`. |
| `row_counts.example.csv` | Example upstream row-count manifest fields → reference for the upstream pipeline's daily CSV. |

`config/settings.json` and `config/inventory.json` are **generated or filled in
locally** and are not shipped in the archive. With GitHub deployment, each
environment's reviewed inventory is committed as `config/inventory.dev.json` or
`config/inventory.prod.json`; `tools/prepare_deploy.py` copies the right one to
`config/inventory.json` during the deploy. The notebooks load the deployed
`inventory.json`; they do not read `settings.example.json` at runtime. The
upstream produces its own real manifest CSV and `_SUCCESS` marker if configured
for manifest completion.

### `src/bridge/`: implementation used by notebooks

| File | Purpose and main input → output |
|---|---|
| `__init__.py` | Marks the Python package. |
| `contract.py` | Validates inventory and identifiers; maps Synapse column types; builds safe export SQL and target names. Inventory/mapping → validated contract and SQL. |
| `manifest.py` | Validates manifest settings and the completion marker; parses and checks upstream CSV rows. Storage contents → business date, sequence and expected counts. |
| `synapse.py` | Obtains credentials, connects to Synapse, checks staging objects, reads source metadata/counts, issues CETAS, and classifies SQL errors. Mapping/settings → source information and exported files. |
| `planning.py` | Business-date cutoff, batch packing, status sets, Delta-history decisions, retry classification and run totals. Plan/history → batch IDs or outcome decisions. |
| `process.py` | Per-table state machine and batch loop. Calls the injected platform operations, logs statuses and keeps tables independent. Plan/mapping → table outcomes. |
| `loader.py` | Spark JDBC fallback staging, Parquet reading and validation, target overwrite, history inspection and restore. Stage/source → verified UC Delta publication. |
| `control.py` | Append-only UC table and run logs, plan reads/writes, latest outcomes and summary queries. Events → `table_log`, `run_log`, `plan`. |
| `notification.py` | Creates the complete summary payload; reads an HTTPS URL from Databricks secrets; POSTs JSON with a stable notification ID. Final outcomes → operator workflow request. |

### `src/notebooks/`: Databricks job entry points

| File | Purpose and main input → output |
|---|---|
| `_bootstrap.py` | Shared `%run` imports, UTC Spark settings, widget helper and fixed inventory path → initialized modules/settings. |
| `00_plan.py` | Checks Synapse staging, finds today's completed upstream, reads counts and schemas, packs batches → UC `plan`, run log and task value `batch_ids`. |
| `10_process_batch.py` | Loads a batch and wires real Spark/Synapse/storage operations into `process_batch` → per-table log events and target commits; raises after processing for transient failures eligible for the one task retry. |
| `90_finalize.py` | Runs after all process tasks (`ALL_DONE`); tallies statuses/deadline/fallbacks, writes `FINISHED*`, sends the complete webhook summary and applies the job's failure policy → run log, notification and final verdict. |
| `acceptance_checks.py` | One-time workspace/runtime acceptance tests for Delta transactions, history, grants, restore and governance → go-live evidence, not production table data. |
| `rollback.py` | Restricted operator tool: one target and a reviewed earlier version/date → guarded Delta restore. |
| `maintenance.py` | Weekly control retention, optional VACUUM and orphan CETAS definition cleanup → smaller logs and tidy Synapse metadata. ADLS files follow the lifecycle policy. |

### `sql/synapse/`: pool setup and security review

| File | Purpose and main input → output |
|---|---|
| `03_review_credential_scope.sql` | Read-only listing of credential, external data source and grant reach → administrator's permission review; run before granting export rights. |
| `01_export_setup.sql` | Reviewed one-time Synapse schemas, external staging setup and CETAS grants → pool objects only where missing. Replace placeholders first. |
| `02_upstream_control.sql` | Optional completion table and upstream INSERT example → `bridge_upstream.upstream_run` when `completion_source=synapse_table`. Manifest mode uses its CSV and marker instead. |

### `sql/unity_catalog/`: upgrades of existing installations

| File | Purpose and main input → output |
|---|---|
| `upgrade_1.2_to_1.3.sql` | Adds method/error/duration log columns and refreshes views. |
| `upgrade_1.3_to_1.4.sql` | Adds count source and planned expected-count/schema fields; refreshes views. |
| `upgrade_2.4_to_2.5.sql` | Adds `commit_utc` to table logs and refreshes views. |

New installations use rendered setup SQL and **do not** run historic upgrade
scripts. Existing installations run only the needed upgrades, in version
order, before deploying code that writes the new columns.

### `tools/`, `infra/`, `docs/` and `tests/`

| File or folder | Purpose and main input → output |
|---|---|
| `tools/generate_inventory.py` | `settings.json` + Synapse catalog (optional size profile) → reviewed `config/inventory.json`; rejects unsupported columns. |
| `tools/prepare_deploy.py` | Environment name → checks the bundle target host, validates `config/inventory.<env>.json`, copies it to `config/inventory.json`. Used by the GitHub deploy workflow. |
| `tools/render_uc_setup.py` | Validated inventory + job principal and optional consumer group → `build/uc_setup.sql` for UC control and target tables/grants. |
| `infra/adls_lifecycle_policy.json` | Template for aging out staged ADLS files → storage account lifecycle rule after placeholders are set. |
| `infra/README.md` | Storage retention and identity/access setup notes. |
| `docs/DESIGN.md` | Architecture, table flow, safety and retry decisions. |
| `docs/CODE_STRUCTURE.md` | Layers, jobs and tasks, module dependency graph, notebook-to-module map, plan/table/finalize call sequences, test coverage map. |
| `docs/DATA_DICTIONARY.md` | Columns of `plan`, `table_log`, `run_log` and views; `run_log` events; ID and path formats; target metadata columns and Delta `userMetadata`; summary webhook payload. |
| `docs/RUNBOOK.md` | Exact setup, deployment, daily monitoring, recovery and rollback instructions. |
| `docs/RELEASE_VALIDATION.md` | Go-live acceptance checklist and environment-specific checks. |
| `docs/V22_REVIEW_RESOLUTION.md` | Historical v2.2 review findings and resolutions. |
| `docs/PACKAGE_GUIDE.md` | This inventory and execution map. |
| `tests/conftest.py` | Shared fixtures and Python import paths. |
| `tests/test_contract.py` | Inventory, type conversion and SQL safety tests. |
| `tests/test_manifest.py` | Manifest parsing and trust rules. |
| `tests/test_synapse_checks.py` | Synapse staging verification and error classification. |
| `tests/test_planning.py` | Batching, cutoff, history and summary rules. |
| `tests/test_process.py` | Per-table and batch paths with simulated platform operations. |
| `tests/test_loader_spark.py` | Real local Spark Parquet and conversion tests; optional Spark dependency. |
| `tests/test_jdbc_derby.py` | Local Derby JDBC round trips without a live Synapse pool. |
| `tests/test_notification.py` | Complete-summary payload, optional failure delivery and safe error reporting. |
| `tests/test_tools.py` | Inventory/setup generators and bundle structure. |
| `tests/test_deploy.py` | Inventory selection, pause-status variables, sync excludes and workflow structure. |
| `tests/test_agents_doc.py` | Checks that architecture claims in `AGENTS.md` remain grounded in files/code. |
| `tests/test_v20_regressions.py` | Publication safety regressions found in v1.9 review. |
| `tests/test_v23_regressions.py` | Operational regressions found in v2.2 review. |
| `tests/test_v24_regressions.py` | Recovery, missing stage and JDBC route regressions. |
| `tests/test_v25_regressions.py` | Cross-run restore, manifest, cutoff and Spark-free regressions. |
| `tests/test_v251_regressions.py` | Live-clock cutoff regression. |
| `tests/test_v26_recovery.py` | Sydney recovery and publication-margin behaviour. |
| `tests/test_v262_regressions.py` | Runtime 18 review regressions. |
| `tests/test_v263_regressions.py` | Repair-run ownership, UC grants, governance exemptions and finalize retry. |

## 3. Execution order and what moves between stages

### One-time setup (administrator/operator)

1. Review the Synapse credential scope with `03_review_credential_scope.sql`.
   Confirm existing access; run `01_export_setup.sql` only for missing objects.
   Use `02_upstream_control.sql` only for Synapse-table completion.
2. Apply the reviewed ADLS lifecycle policy and provide the upstream completion
   contract: manifest CSV plus `_SUCCESS`, or the completed Synapse row.
3. Fill `config/settings.json` from its example. Store the notification workflow
   URL in a Databricks secret and configure its scope/key in settings.
4. Run `tools/generate_inventory.py` to produce `config/inventory.json`. Review
   enabled/mandatory flags, column types, schemas and source mappings.
5. Run `tools/render_uc_setup.py` with the reviewed inventory; execute its SQL
   as an authorized UC administrator. Existing installations may first need
   the ordered UC upgrade scripts above.
6. Deploy the Asset Bundle (for a new installation, follow RUNBOOK "Fresh
   installation with GitHub (dev, then prod)"), by hand or through GitHub Actions (merge to `main`
   → dev, approval → prod). Run the acceptance job and a trial load on the
   actual dedicated cluster. Validate the notification receiver and its email.
   Then unpause the nightly schedule through the pause-status bundle variables. Commands and approvals are in RUNBOOK.

### Every automatic nightly run

| Order | Component | Consumes | Produces |
|---|---|---|---|
| 1 | Upstream | Completed nightly Synapse rebuild | Matching business date/sequence; completion marker or row, optionally per-table counts. |
| 2 | `00_plan.py` | Inventory, completion signal, Synapse staging/catalog | UC plan, source schema hashes, batch IDs, 07:00 Sydney cutoff. |
| 3 | `10_process_batch.py` per batch | Planned mappings, target history, Synapse, staging | Per-table CETAS or JDBC files, validated candidate, Delta commit, append-only status events. |
| 4 | Batch retry (if needed) | Transient failures in that batch | Another attempt for those mappings only; terminal/success statuses stay recorded. |
| 5 | `90_finalize.py` | Every planned mapping and its latest run outcome | UC `FINISHED`/`FINISHED_WITH_FAILURES`, structured HTTPS summary, final job verdict. |

The summary includes `NOT_STARTED` or cutoff-skipped mappings as failures.
Successful target writes survive unrelated table failures. The Databricks
on-failure email is an additional system alert when the job fails; the summary
endpoint is responsible for the table counts and IDs on *every completed run*.
If planning fails before a plan exists, there can be no table summary and the
system failure alert is used. Endpoint deduplication by `notification_id` is
necessary for delivery ambiguity or a manual Repair run.

### Morning investigation and same-day recovery

1. Read the summary email and inspect `table_log` for each failed mapping's
   `detail` and the earlier CETAS/JDBC events.
2. Correct the cause. A Databricks Repair run of the existing job retains its
   original 07:00 cutoff. From 07:00 to before 11:00 Sydney time, start a new
   targeted run using today's `business_date` and `only_mappings=<ids>`.
3. The targeted run rechecks each target's history and source release. A target
   already published for that release is verified and normally avoids a second
   export. Corrected upstream data requires a new, higher sequence.
4. The targeted run sends its own summary after its selected mappings finish.
   No new recovery run begins at or after 11:00; with the default five-minute
   safety margin, a new export must begin before approximately 10:55.

## 4. Boundaries and references

Local tests check code paths but cannot prove actual CETAS encodings, dedicated
cluster behaviour, UC permissions, HTTPS delivery or the production deadline.
Use [RELEASE_VALIDATION.md](RELEASE_VALIDATION.md) and the acceptance job for
those checks. For exact status meanings and operator commands, use
[RUNBOOK.md](RUNBOOK.md). For the governing invariants, use [AGENTS.md](../AGENTS.md).

### Suggested reading order

| Reader | Read |
|---|---|
| New to the package | `README.md` → this guide → `DESIGN.md` sections 1–2 |
| Operator | This guide section 3 → `RUNBOOK.md` → `DATA_DICTIONARY.md` |
| Developer / maintainer | `DESIGN.md` → `CODE_STRUCTURE.md` → `AGENTS.md` → `DATA_DICTIONARY.md` |
| Go-live approver | `DESIGN.md` sections 6–8 → `RELEASE_VALIDATION.md` |
