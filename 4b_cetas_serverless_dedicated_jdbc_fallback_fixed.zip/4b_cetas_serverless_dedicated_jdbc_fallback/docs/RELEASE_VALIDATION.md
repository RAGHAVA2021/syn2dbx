# Release validation — compute-corrected 4A/4B variant

Local validation performed after the compute split correction:

- `PYTHONPATH=src pytest -q`: **362 passed, 2 skipped**.
- `python -m compileall -q src`: **passed**.
- `databricks.yml` parses successfully and compute-placement regression tests assert the intended serverless/dedicated boundaries.
- Actual serverless-to-Synapse network reachability, `mssql-python` package installation, Synapse permissions, CETAS execution, UC-JDBC connectivity (4A), dedicated Spark-JDBC connectivity (4B), and Delta acceptance behavior must be proven in the real DEV workspace before PROD.

Do not treat local tests as proof of cloud networking or permissions. Run `databricks bundle validate -t dev`, deploy to DEV, and execute the acceptance job plus representative CETAS-success and forced-fallback tables.
