# FIRST READ — 4B — serverless CETAS + dedicated JDBC fallback

This ZIP is **4b_cetas_serverless_dedicated_jdbc_fallback.zip**.

**Nightly flow:** `Refresh complete → serverless plan/CETAS → dedicated DBR 18.x JDBC fallback only when required → serverless Delta publish → final summary`

The dedicated `bridge` cluster exists only for the exceptional JDBC fallback task; successful CETAS tables never use it.

Start with `docs/PACKAGE_GUIDE.md`, then `docs/COMPUTE_DESIGN.md`, `docs/DESIGN.md`, and `docs/RUNBOOK.md`. Keep the nightly schedule PAUSED until DEV connectivity, permissions, CETAS, fallback, publish and notification acceptance tests pass.
