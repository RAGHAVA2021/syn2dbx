"""Behavioural checks for 4B: the serverless CETAS task must never run JDBC itself.

CETAS-class failures and historical-timestamp reroutes are logged as
FALLBACK_REQUIRED so the dedicated `bridge` cluster task performs the JDBC read.
"""
import json
from pathlib import Path

from bridge import contract, planning, process
from test_process import NOW, CodedError, FakeOps, ctx, m  # noqa: F401 (fixtures)

ROOT = Path(__file__).resolve().parents[1]


def _defer(ctx):
    ctx.settings["execution"]["defer_jdbc_fallback"] = True
    return ctx


def test_defer_flag_is_a_known_execution_setting(inventory):
    assert contract.DEFAULT_EXECUTION["defer_jdbc_fallback"] is False
    cfg = json.loads((ROOT / "config" / "settings.example.json").read_text())
    assert contract.execution(cfg, "defer_jdbc_fallback") is True


def test_cetas_task_enables_deferral():
    nb = (ROOT / "src" / "notebooks" / "10_extract_validate_batch.py").read_text()
    assert 'settings["execution"]["defer_jdbc_fallback"] = True' in nb


def test_cetas_failure_is_deferred_not_read_on_serverless(ctx, m):
    ops = FakeOps(m, export_raises=CodedError(105019))
    status = process.process_table(_defer(ctx), m, ops, now=NOW)
    assert status == "FALLBACK_REQUIRED"
    assert "jdbc" not in ops.calls and "overwrite" not in ops.calls
    assert not any(e["status"] == "FALLBACK_STARTED" for e in ops.logs)
    assert ops.logs[-1]["method"] == "JDBC" and ops.logs[-1]["error_code"] == 105019


def test_historical_timestamp_is_deferred_not_read_on_serverless(ctx, m):
    class Ancient(FakeOps):
        def validate_and_convert(self, df, mapping, business_date, release, reject_ancient_timestamps=False):
            if reject_ancient_timestamps:
                raise contract.AncientCetasTimestamp("FAILED_CONTRACT", "historical INT96")
            return super().validate_and_convert(df, mapping, business_date, release)

    ops = Ancient(m)
    assert process.process_table(_defer(ctx), m, ops, now=NOW) == "FALLBACK_REQUIRED"
    assert "jdbc" not in ops.calls and "overwrite" not in ops.calls


def test_without_deferral_inline_fallback_is_unchanged(ctx, m):
    ctx.settings["execution"]["defer_jdbc_fallback"] = False
    ops = FakeOps(m, export_raises=CodedError(105019))
    process.process_table(ctx, m, ops, now=NOW)
    assert "jdbc" in ops.calls


def test_fallback_required_is_in_flight_for_planning():
    assert "FALLBACK_REQUIRED" in planning.IN_FLIGHT
    assert "FALLBACK_REQUIRED" not in planning.TERMINAL
