from pathlib import Path
import json
import yaml

ROOT = Path(__file__).resolve().parents[1]


def test_4b_serverless_cetas_and_dedicated_jdbc_split():
    bundle = yaml.safe_load((ROOT / 'databricks.yml').read_text())
    job = bundle['resources']['jobs']['nightly_full_refresh']
    tasks = {t['task_key']: t for t in job['tasks']}
    assert 'job_cluster_key' not in tasks['plan']
    assert 'job_cluster_key' not in tasks['process']['for_each_task']['task']
    assert tasks['plan']['environment_key'] == 'serverless_sql'
    assert tasks['process']['for_each_task']['task']['environment_key'] == 'serverless_sql'
    fb = tasks['dedicated_jdbc_fallback']['for_each_task']['task']
    assert fb['job_cluster_key'] == 'bridge'
    assert tasks['dedicated_jdbc_fallback']['run_if'] == 'ALL_DONE'
    assert tasks['publish']['depends_on'] == [{'task_key': 'dedicated_jdbc_fallback'}]
    assert 'job_cluster_key' not in tasks['publish']['for_each_task']['task']


def test_4b_cetas_command_path_has_serverless_dbapi_support():
    code = (ROOT / 'src' / 'bridge' / 'synapse.py').read_text()
    assert 'def _serverless_dbapi_connection' in code
    assert 'import mssql_python' in code


def test_4b_deferred_fallback_is_enabled():
    cfg = json.loads((ROOT / 'config' / 'settings.example.json').read_text())
    assert cfg['execution']['defer_jdbc_fallback'] is True


def test_4b_dedicated_fallback_uses_spark_jdbc():
    nb = (ROOT / 'src' / 'notebooks' / '20_dedicated_jdbc_fallback.py').read_text()
    assert 'loader.jdbc_export' in nb
    assert 'synapse.partition_bounds' in nb
    assert 'dedicated-cluster JDBC fallback started' in nb
