# Changelog — 4B — serverless CETAS + dedicated JDBC fallback

## 2.6.6
## 2026-09-27 deferred-fallback fix

- Fixed: the serverless CETAS task ran the JDBC fallback inline, so the dedicated `bridge` task never received work. CETAS-class failures and historical-timestamp reroutes now log `FALLBACK_REQUIRED` and stop; the dedicated cluster performs the JDBC read.
- `contract.py`: added `execution.defer_jdbc_fallback` (default false) and its validation; the example setting no longer raises `KeyError`.
- `process.py`: added `DeferredFallback` and the two defer branches.
- `planning.py`: `FALLBACK_REQUIRED` is now in-flight, not unknown.
- `10_extract_validate_batch.py`: enables deferral for the serverless CETAS task.
- `AGENTS.md`: corrected the compute boundary and status table.
- Added `tests/test_4b_deferred_fallback.py` (behavioural; fails on 2.6.5).

## 2.6.5
## 2026-09-27 compute correction

- Corrected the package so CETAS command/control actually runs from a **serverless Databricks task**.
- Added serverless command SQL support through `mssql-python==1.15.0`; no Spark JVM gateway is required for CETAS.
- Kept per-table deferred fallback and independent publication (`ALL_DONE`).
- Updated tests, package names and compute documentation to match the executable bundle.
- The dedicated `bridge` cluster exists only for the exceptional JDBC fallback task; successful CETAS tables never use it.
