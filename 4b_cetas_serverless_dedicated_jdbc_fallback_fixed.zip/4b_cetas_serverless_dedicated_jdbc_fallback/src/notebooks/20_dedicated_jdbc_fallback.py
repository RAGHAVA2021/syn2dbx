# Databricks notebook source
# MAGIC %md
# MAGIC # 20 · Dedicated JDBC fallback
# MAGIC Runs only for mappings whose **serverless CETAS** phase logged `FALLBACK_REQUIRED`.
# MAGIC The task itself runs on the dedicated DBR 18.x job cluster and uses Spark JDBC to
# MAGIC stage Parquet, validate it, and log `VALIDATED`. Successful CETAS tables are untouched.

# COMMAND ----------
# MAGIC %run ./_bootstrap

# COMMAND ----------
import json
from datetime import timezone
from contextlib import contextmanager

settings = load_settings()
job_run_id = widget("job_run_id")
batch_id = int(widget("batch_id"))
plan = control.read_plan(spark, settings, job_run_id, batch_id)
if not plan:
    raise RuntimeError(f"No plan rows for job run {job_run_id}, batch {batch_id}")
first = plan[0]
release = first["release_id"]
latest = control.latest_status(spark, settings, release, job_run_id)
by_id = {m["mapping_id"]: m for m in settings["mappings"]}
plan_by_id = {p["mapping_id"]: p for p in plan}
required = [mid for mid in plan_by_id if latest.get(mid) == "FALLBACK_REQUIRED"]
if not required:
    print("No FALLBACK_REQUIRED mappings in this batch.")
    dbutils.notebook.exit("{}")

get_props = synapse.credentials_provider(settings, dbutils)
jdbc_url = synapse.jdbc_url(settings)
results, failures = {}, []
for mid in required:
    m = by_id[mid]
    pinfo = plan_by_id[mid]
    attempt = process.new_attempt_id()
    ctx = process.Context(settings=settings, release=release, sequence=int(first["upstream_sequence"]),
                          business_date=str(first["business_date"]), job_run_id=job_run_id,
                          cutoff_utc=first["cutoff_utc"].replace(tzinfo=timezone.utc))
    rel = process.fallback_location(process.stage_location(ctx, m, attempt))
    stage_path = f"{settings['staging']['root']}/{rel}"
    base = dict(release_id=release, job_run_id=job_run_id, mapping_id=mid,
                target=contract.fq_target(m).replace("`", ""), mandatory=bool(m.get("mandatory", False)),
                attempt_id=attempt, stage_path=stage_path, method="JDBC")
    try:
        control.log_table(spark, settings, **base, status="FALLBACK_STARTED",
                          detail="dedicated-cluster JDBC fallback started")
        with synapse.connect(spark, settings, get_props) as conn:
            bounds = synapse.partition_bounds(conn, m, contract.execution(settings, "export_timeout_seconds"))
        col = contract.partition_column(m)
        loader.jdbc_export(spark, jdbc_url, contract.jdbc_query(m), get_props(), stage_path,
                           fetch_size=contract.execution(settings, "jdbc_fetch_size"),
                           timeout=contract.execution(settings, "export_timeout_seconds"),
                           bounds=bounds, partition_column=col["name"] if col else None,
                           num_partitions=contract.execution(settings, "jdbc_num_partitions"),
                           driver=synapse.DRIVER)
        names = [f.name.rstrip("/") for f in dbutils.fs.ls(stage_path)]
        raw = loader.read_export(spark, stage_path, m, lambda _: names, require_success=True)
        _, rows = loader.validate_and_convert(raw, m, str(first["business_date"]), release)
        expected = pinfo["expected_rows"]
        count_source = "manifest" if expected is not None else "none"
        if m.get("verify_source_count", True) and expected is not None and int(expected) != int(rows):
            with synapse.connect(spark, settings, get_props) as conn:
                actual = synapse.count_rows(conn, m, contract.execution(settings, "export_timeout_seconds"))
            if int(actual) != int(rows):
                raise RuntimeError(f"fallback row mismatch: manifest={expected}, staged={rows}, Synapse={actual}")
            expected, count_source = int(actual), "synapse_after_manifest_mismatch"
        if rows == 0 and not m.get("allow_empty", False):
            raise RuntimeError("fallback export has 0 rows and allow_empty is false")
        control.log_table(spark, settings, **base, status="VALIDATED",
                          source_rows=int(expected) if expected is not None else None,
                          parquet_rows=int(rows), count_source=count_source,
                          detail="dedicated JDBC fallback staged and validated")
        results[mid] = "VALIDATED"
    except Exception as exc:
        control.log_table(spark, settings, **base, status="FALLBACK_REQUIRED",
                          detail=f"dedicated JDBC fallback attempt failed: {type(exc).__name__}: {exc}")
        results[mid] = "FALLBACK_REQUIRED"
        failures.append(mid)

print(json.dumps(results, indent=2, sort_keys=True))
if failures:
    raise RuntimeError(f"Dedicated JDBC fallback failed for: {sorted(failures)}")
