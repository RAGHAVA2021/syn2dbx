# Databricks notebook source
# MAGIC %md
# MAGIC # Acceptance checks — run once per workspace before go-live
# MAGIC Proves on your runtime the Delta behaviour this design depends on. It uses a
# MAGIC scratch table in `scratch_schema` and drops it at the end.
# MAGIC
# MAGIC 1. `INSERT OVERWRITE` honours the SQL idempotent-write settings
# MAGIC    (`txnAppId`/`txnVersion`): same version again is skipped, a lower version is
# MAGIC    skipped, a higher version is applied.
# MAGIC 2. `userMetadata` and `numOutputRows` appear in `DESCRIBE HISTORY`.
# MAGIC 3. `INSERT OVERWRITE` keeps an actual SELECT grant and table properties.
# MAGIC 4. `RESTORE` works and does not look like a published night.
# MAGIC 5. A later untagged data write invalidates an old publication.
# MAGIC 6. Empty and partitioned overwrites replace all rows and expose metrics.
# MAGIC 7. An actual OPTIMIZE history entry does not invalidate a publication.
# MAGIC 8. `loader.history` exposes each commit's time in UTC (the deadline check uses it).
# MAGIC 9. Writes go through the production `loader.overwrite`, and a static full overwrite is
# MAGIC    not recorded as `isDynamicPartitionOverwrite` even with a dynamic session default.
# MAGIC 10. The runtime is 17+ and the governance preflight (`SHOW EFFECTIVE POLICIES`,
# MAGIC    `DESCRIBE ... AS JSON`) runs on a plain target; any inherited ABAC policy is listed.
# MAGIC 11. A missing staging folder and a missing manifest/marker are classified as missing,
# MAGIC    not as errors (the plan's wait loop and stage reuse depend on this).
# MAGIC
# MAGIC Rerun this job after any Runtime 18 release-note entry lists behavioural changes:
# MAGIC `18.x` clusters pick up dated updates on every restart.
# MAGIC
# MAGIC Every check raises on failure. Run it on the actual production runtime.
# MAGIC A plain scratch table does not prove writes on targets with row filters or
# MAGIC masks; those need a separate protected-table trial before go-live.

# COMMAND ----------

# MAGIC %run ./_bootstrap

# COMMAND ----------

import uuid

from bridge import manifest

settings = load_settings()
runtime = spark.conf.get(loader.RUNTIME_VERSION_CONF, None)
print(f"runtime: {runtime}")
if contract.runtime_major(runtime) is None or contract.runtime_major(runtime) < contract.MIN_GOVERNANCE_RUNTIME_MAJOR:
    raise AssertionError(f"ACCEPTANCE FAILED: runtime {runtime!r} is below Databricks Runtime "
                         f"{contract.MIN_GOVERNANCE_RUNTIME_MAJOR}; the job pins 18.x-scala2.13")
scratch = widget("scratch_schema")  # catalog.schema the job identity may create tables in
grant_principal = widget("grant_principal")
if not grant_principal or "`" in grant_principal or "\n" in grant_principal:
    raise ValueError("grant_principal must be an existing group with no backticks or newlines")
if spark.conf.get("spark.sql.parquet.datetimeRebaseModeInRead") != "CORRECTED" or \
        spark.conf.get("spark.sql.parquet.int96RebaseModeInRead") != "CORRECTED":
    raise AssertionError("Parquet calendar rebase settings must be CORRECTED")
cat, sch = scratch.split(".")
t = f"{contract.q_spark(cat)}.{contract.q_spark(sch)}.`bridge_acceptance_txn`"
spark.sql(f"DROP TABLE IF EXISTS {t}")
spark.sql(f"CREATE TABLE {t} (id INT, _bridge_business_date DATE, _bridge_release_id STRING) TBLPROPERTIES "
          "('delta.deletedFileRetentionDuration'='interval 7 days', "
          "'delta.autoOptimize.autoCompact'='false')")
spark.sql(f"GRANT SELECT ON TABLE {t} TO `{grant_principal}`")
def select_grant():
    return any(str(r["principal"]) == grant_principal and str(r["actionType"]).upper() == "SELECT"
               for r in spark.sql(f"SHOW GRANTS ON TABLE {t}").collect())
assert select_grant(), "scratch SELECT grant did not take effect"
props_before = {r["key"]: r["value"] for r in spark.sql(f"SHOW TBLPROPERTIES {t}").collect()}
scratch_mapping = {"mapping_id": "acceptance", "target_catalog": cat, "target_schema": sch,
                   "target_table": "bridge_acceptance_txn", "columns": [{"name": "id", "sql_type": "int"}]}


def write(version, n, release, many_files=False):
    df = spark.range(n).selectExpr("CAST(id AS INT) AS id",
        "DATE '2026-01-01' AS _bridge_business_date", "'acceptance' AS _bridge_release_id")
    if many_files:
        df = df.repartition(8)
    loader.overwrite(spark, scratch_mapping, df, version,
        planning.user_metadata(release, version, "2026-01-01", "acceptance", "0", "a"))


def hist():
    return [{"version": int(r["version"]), "operation": r["operation"], "userMetadata": r["userMetadata"],
             "operationParameters": dict(r["operationParameters"] or {}),
             "operationMetrics": dict(r["operationMetrics"] or {})}
            for r in spark.sql(f"DESCRIBE HISTORY {t}").collect()]


def check(cond, msg):
    if not cond:
        raise AssertionError("ACCEPTANCE FAILED: " + msg)
    print("ok -", msg)


write(10, 5, "r10")
check(spark.table(t).count() == 5, "first overwrite applied")
v1 = hist()[0]["version"]
check(planning.verify_after_write(hist(), "r10", 10, 5)[0] == "PUBLISHED", "history has userMetadata + numOutputRows")
committed = planning.commit_utc(loader.history(spark, scratch_mapping, 50), v1)
check(committed is not None and abs((planning.utcnow().replace(tzinfo=None) - committed).total_seconds()) < 3600,
      "loader.history exposes the commit time in UTC (used by the finalize deadline check)")

write(10, 7, "r10-retry")
check(hist()[0]["version"] == v1 and spark.table(t).count() == 5, "same txnVersion is skipped (retry is a no-op)")

write(9, 3, "r9")
check(hist()[0]["version"] == v1 and spark.table(t).count() == 5, "lower txnVersion is skipped (old night blocked)")
check(planning.verify_after_write(hist(), "r9", 9, 3)[0] == "SUPERSEDED", "skipped old write classified SUPERSEDED")

write(11, 8, "r11", many_files=True)
check(spark.table(t).count() == 8, "higher txnVersion is applied")
spark.sql(f"OPTIMIZE {t}")
check(hist()[0]["operation"] == "OPTIMIZE" and planning.precheck(hist(), 11, "2026-01-01") == "ALREADY_CURRENT",
      "OPTIMIZE history does not invalidate the published version")

props_after = {r["key"]: r["value"] for r in spark.sql(f"SHOW TBLPROPERTIES {t}").collect()}
check(props_after.get("delta.deletedFileRetentionDuration") == props_before.get("delta.deletedFileRetentionDuration"),
      "INSERT OVERWRITE keeps table properties")
check(select_grant(), "INSERT OVERWRITE keeps SELECT grant")

spark.sql(f"ALTER TABLE {t} SET TBLPROPERTIES ('bridge.acceptance'='checked')")
check(planning.precheck(hist(), 11, "2026-01-01") == "ALREADY_CURRENT",
      "SET TBLPROPERTIES does not invalidate a verified data publication")
spark.sql(f"ALTER TABLE {t} UNSET TBLPROPERTIES ('bridge.acceptance')")
check(planning.precheck(hist(), 11, "2026-01-01") == "ALREADY_CURRENT",
      "UNSET TBLPROPERTIES does not invalidate a verified data publication")
spark.sql(f"VACUUM {t}")
check(planning.precheck(hist(), 11, "2026-01-01") == "ALREADY_CURRENT",
      "the runtime's VACUUM operations do not invalidate a verified publication")

spark.sql(f"INSERT OVERWRITE TABLE {t} (id) SELECT id FROM range(2)")
check(planning.precheck(hist(), 11) == "FAILED_VERIFY",
      "an untagged overwrite cannot be reported as an already current release")

restore_md = planning.restore_metadata("r11", v1 + 1, v1, "acceptance")
loader.restore(spark, {"target_catalog": cat, "target_schema": sch, "target_table": "bridge_acceptance_txn"},
               v1, restore_md)
check(spark.table(t).count() == 5, "RESTORE works")
check(hist()[0]["operation"] == "RESTORE" and hist()[0]["userMetadata"] == restore_md,
      "RESTORE history has the metadata required by automatic verification")
check(planning.latest_bridge_commit(hist())[1]["release_id"] == "r11", "restore commit is not mistaken for a publish")
restored_version = hist()[0]["version"]
write(11, 3, "r11-retry-after-restore")
check(hist()[0]["version"] == restored_version and spark.table(t).count() == 5,
      "a RESTORE does not erase the idempotency guard for the old txnVersion")
write(12, 4, "r12-after-restore")
check(spark.table(t).count() == 4, "a higher txnVersion can publish after RESTORE")
write(13, 0, "r13-empty")
check(spark.table(t).count() == 0 and planning.verify_after_write(hist(), "r13-empty", 13, 0)[0] == "PUBLISHED",
      "empty overwrite records numOutputRows=0")

p = f"{contract.q_spark(cat)}.{contract.q_spark(sch)}.`bridge_acceptance_partitioned`"
spark.sql(f"DROP TABLE IF EXISTS {p}")
spark.sql(f"CREATE TABLE {p} (id INT, part INT, _bridge_business_date DATE, "
          "_bridge_release_id STRING) USING DELTA PARTITIONED BY (part)")
spark.sql(f"INSERT INTO {p} (id, part) VALUES (1, 1), (2, 2)")
partition_mapping = {"mapping_id": "acceptance_partitioned", "target_catalog": cat, "target_schema": sch,
                     "target_table": "bridge_acceptance_partitioned",
                     "columns": [{"name": "id", "sql_type": "int"}, {"name": "part", "sql_type": "int"}]}
partition_data = spark.range(1).selectExpr("CAST(3 AS INT) AS id", "CAST(3 AS INT) AS part",
    "DATE '2026-01-01' AS _bridge_business_date", "'acceptance' AS _bridge_release_id")
prior_mode = spark.conf.get("spark.sql.sources.partitionOverwriteMode", None)
spark.conf.set("spark.sql.sources.partitionOverwriteMode", "dynamic")
try:
    loader.overwrite(spark, partition_mapping, partition_data, 14,
        planning.user_metadata("r14", 14, "2026-01-01", "acceptance_partitioned", "0", "a"))
    check(spark.conf.get("spark.sql.sources.partitionOverwriteMode") == "dynamic",
          "overwrite restores the prior partition mode")
finally:
    if prior_mode is None:
        spark.conf.unset("spark.sql.sources.partitionOverwriteMode")
    else:
        spark.conf.set("spark.sql.sources.partitionOverwriteMode", prior_mode)
check([(r['id'], r['part']) for r in spark.table(p).collect()] == [(3, 3)],
      "static partitioned overwrite removes rows in old partitions")
p_hist = loader.history(spark, partition_mapping, 50)
check(not planning.dynamic_partition_overwrite(p_hist[0]),
      "the bridge overwrite is not recorded as isDynamicPartitionOverwrite")
check(planning.verify_after_write(p_hist, "r14", 14, 1)[0] == "PUBLISHED",
      "a static partitioned publish verifies as PUBLISHED")
spark.sql(f"DROP TABLE {p}")

# ---- governance preflight on a plain target -------------------------------------------
loader.check_target_schema(spark, scratch_mapping)
try:
    exempted = loader.check_target_governance(spark, scratch_mapping, settings)
except contract.ContractError as e:
    raise AssertionError(
        "ACCEPTANCE FAILED: the governance preflight blocks a plain scratch table in "
        f"{scratch}: {e}. Inherited ABAC policies would block every bridge target in the same "
        "catalog/schema. Review each with DESCRIBE POLICY; list only those whose EXCEPT clause names the "
        "job and rollback identities in governance.exempt_abac_policies, each as {catalog, schema?, table?, "
        "name} of the securable the policy is defined on") from e
print(f"ok - governance preflight runs on this runtime (reviewed exemptions applied: {exempted or 'none'})")

# ---- missing paths are classified as missing (plan wait loop, stage reuse) ------------
def missing_error(action, path):
    try:
        action(path)
    except Exception as e:  # noqa: BLE001 - classified below
        return e
    raise AssertionError(f"ACCEPTANCE FAILED: {path} unexpectedly exists")

probe_id = uuid.uuid4().hex
st = settings["staging"]
missing_stage = f"{st['root']}/{st['prefix']}/_acceptance_missing_{probe_id}/"
check(manifest.is_missing_path_error(missing_error(dbutils.fs.ls, missing_stage)),
      "a missing staging folder is recognized as missing (dbutils.fs.ls)")
if manifest.enabled(settings):
    missing_csv = manifest.path_for(settings, "2099-12-31")
    check(manifest.is_missing_path_error(missing_error(dbutils.fs.ls, missing_csv)),
          "a missing manifest CSV is recognized as missing (dbutils.fs.ls)")
    marker = manifest.marker_path(settings, "2099-12-31")
    if marker:
        check(manifest.is_missing_path_error(missing_error(lambda x: dbutils.fs.head(x, 1024), marker)),
              "a missing completion marker is recognized as missing (dbutils.fs.head)")

spark.sql(f"DROP TABLE {t}")
print("\nALL ACCEPTANCE CHECKS PASSED")
print("Also check: governance preflight rejects filtered or masked targets before extraction.")
