# 4B — serverless CETAS + dedicated JDBC fallback

Production-oriented Synapse dedicated SQL pool → ADLS Gen2 → Unity Catalog managed Delta full-refresh package for static nightly source tables.

## Compute split

| Stage | Compute | Purpose |
|---|---|---|
| Plan / Synapse checks | Serverless | Uses `mssql-python` for command-capable T-SQL connection |
| CETAS | Serverless Databricks task; CETAS executes in Synapse | Issues CETAS DDL through `mssql-python` |
| JDBC fallback | Dedicated DBR 18.x job cluster | Spark JDBC bulk read for only `FALLBACK_REQUIRED` tables |
| Delta publish | Serverless | Publishes all `VALIDATED` CETAS/JDBC stages independently |
| Finalize | Serverless | Final success/failure/fallback summary |

**Flow:** `Refresh complete → serverless plan/CETAS → dedicated DBR 18.x JDBC fallback only when required → serverless Delta publish → final summary`

The dedicated `bridge` cluster exists only for the exceptional JDBC fallback task; successful CETAS tables never use it.

## Important prerequisites

- Unity Catalog enabled workspace and serverless jobs available.
- Serverless network connectivity to the Synapse SQL endpoint and ADLS.
- `mssql-python==1.15.0` is installed by the job environment for serverless command/control SQL.
- The run identity has the required Synapse CETAS permissions and storage access.
- Upstream COMPLETE/manifest signal is authoritative; source tables remain static after it.
- Recovery cutoff remains 11:00 Australia/Sydney; do not rerun the previous night after the cutoff.

See `docs/PACKAGE_GUIDE.md` and `docs/COMPUTE_DESIGN.md` for file-by-file and compute details.
