import copy
import json
from pathlib import Path
import sys

import pytest

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"python"))
from bridge_run import config, projection
from bridge_run import size_class


ORIGINAL=json.loads((Path(__file__).resolve().parents[1]/"config.example.json").read_text())
for item in ORIGINAL["mappings"]:
    item["target_catalog"]="example_catalog"
ORIGINAL["control_catalog"]="example_catalog"


def write(tmp_path,doc):
    p=tmp_path/"config.json";p.write_text(json.dumps(doc));return p


def test_valid_reviewed_contract(tmp_path):
    doc=copy.deepcopy(ORIGINAL)
    config(write(tmp_path,doc))
    assert projection(doc["mappings"][0]) == "[customer_id] AS [customer_id], [name] AS [name]"


def test_optional_member_cannot_move_pointer(tmp_path):
    doc=copy.deepcopy(ORIGINAL)
    doc["mappings"][1]["mandatory"]=False
    with pytest.raises(RuntimeError,match="Optional pointer member"):
        config(write(tmp_path,doc))


def test_duplicate_target_case_insensitive(tmp_path):
    doc=copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["columns"][1]["target"]="CUSTOMER_ID"
    with pytest.raises(RuntimeError,match="Duplicate/missing columns"):
        config(write(tmp_path,doc))


def test_unreviewed_expression_cannot_be_injected(tmp_path):
    doc=copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["columns"][0]["source"]="id]; DROP TABLE t;--"
    with pytest.raises(RuntimeError,match="Unsafe SQL identifier"):
        config(write(tmp_path,doc))


def test_missing_retention_property(tmp_path):
    doc=copy.deepcopy(ORIGINAL)
    del doc["mappings"][1]["physical_properties"]["delta.deletedFileRetentionDuration"]
    with pytest.raises(RuntimeError,match="Missing governed property"):
        config(write(tmp_path,doc))


def test_profile_classification_uses_rows_columns_or_storage():
    limits={"medium_rows":100,"large_rows":1000,"medium_bytes":10000,
            "large_bytes":100000,"medium_columns":10,"large_columns":50}
    assert size_class(2,2,40,limits)=="SMALL"
    assert size_class(101,2,40,limits)=="MEDIUM"
    assert size_class(2,51,40,limits)=="LARGE"
    assert size_class(2,2,100001,limits)=="LARGE"


def test_profiled_inventory_rejects_missing_or_mismatched_profile(tmp_path):
    doc=copy.deepcopy(ORIGINAL)
    doc["require_profiles"]=True
    with pytest.raises(RuntimeError,match="Missing/stale profile"):
        config(write(tmp_path,doc))
    doc["mappings"][0]["size_class"]="SMALL"
    doc["mappings"][0]["source_profile"]={"profiled_at_utc":"2026-09-22T00:00:00Z",
        "estimated_rows":1,"physical_used_bytes":128,"column_count":99,
        "source_schema_version":doc["mappings"][0]["source_schema_version"]}
    with pytest.raises(RuntimeError,match="Missing/stale profile"):
        config(write(tmp_path,doc))
