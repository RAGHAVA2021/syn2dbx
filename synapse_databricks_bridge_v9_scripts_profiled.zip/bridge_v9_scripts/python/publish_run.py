"""Publish a READY bridge run only after recorded fence, policy and consumer gates.

Never rerun a PUBLISHING run blindly: reconcile its Databricks history first.
"""
import argparse
import json
import re
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from bridge_run import config, db, fetchone, need, notebook_job, update_run


def publish_group(cfg, ev, run_id, run, by_id, group_id, members):
    # Distinct independent tables and pointer groups own distinct target keys.
    # Each worker has its own Azure SQL connection and publisher Job invocation.
    with db("BRIDGE_CONTROL_ODBC") as control:
        strategy = members[0]["strategy"]
        if strategy == "REPLACE_TABLE":
            for m in members:
                target = ".".join(m[k] for k in ("target_catalog","target_schema","target_table"))
                key = "table:"+target
                state = fetchone(control,"SELECT published_release_id,high_water_sequence,control_version "
                                 "FROM bridge.target_state WHERE target_key=?", key)
                need(state and int(ev["upstream_sequence"]) > state[1], f"Stale target: {key}")
                mapping = {**m,"candidate_table":f"candidate_{m['mapping_id'].replace('-', '_')}_"
                           f"{run_id.replace('-', '_')}_a1",
                           "source_rows":by_id[m["mapping_id"]][2],"generation_id":run[1]}
                payload = {"strategy":strategy,"mapping":mapping,"release_id":run[3],
                           "upstream_sequence":ev["upstream_sequence"]}
                result = notebook_job(cfg["publisher_job_id"],payload)
                need(result.get("release_id") == run[3] and result.get("rows") == mapping["source_rows"],
                     f"Publisher output mismatch: {key}")
                cursor = control.cursor()
                cursor.execute("UPDATE bridge.target_state SET previous_release_id=published_release_id, "
                               "published_release_id=?,published_sequence=?,high_water_sequence=?, "
                               "control_version=control_version+1 WHERE target_key=? AND control_version=? "
                               "AND high_water_sequence=?",run[3],ev["upstream_sequence"],
                               ev["upstream_sequence"],key,state[2],state[1])
                need(cursor.rowcount==1,"Control state conflict after Delta commit; freeze target")
                control.commit()
        else:
            key = "group:"+group_id
            state = fetchone(control,"SELECT published_release_id,high_water_sequence,control_version "
                             "FROM bridge.target_state WHERE target_key=?",key)
            need(state and state[0] and int(ev["upstream_sequence"]) > state[1], "Missing/stale group control")
            expected = {m["mapping_id"] for m in members}
            known = {r[0] for r in control.cursor().execute(
                "SELECT mapping_id FROM bridge.group_members WHERE inventory_version=? AND group_id=? "
                "AND enabled=1 AND mandatory=1 AND strategy='RELEASE_POINTER'",cfg["inventory_version"],group_id)}
            need(expected == known, f"Group membership mismatch: {group_id}")
            payload = {"strategy":strategy,"group_id":group_id,"members":[
                {**m,"source_rows":by_id[m["mapping_id"]][2]} for m in members],
                "release_id":run[3],"generation_id":run[1],"bridge_run_id":run_id,
                "group_contract_version":members[0]["group_contract_version"],
                "upstream_sequence":ev["upstream_sequence"],"expected_current_release":state[0],
                "expected_version":state[2],"control_catalog":cfg["control_catalog"],
                "control_schema":cfg["control_schema"]}
            result = notebook_job(cfg["pointer_job_id"],payload)
            need(result.get("release_id")==run[3],"Pointer outcome ambiguous")
            cursor = control.cursor()
            cursor.execute("UPDATE bridge.target_state SET previous_release_id=published_release_id, "
                           "published_release_id=?,published_sequence=?,high_water_sequence=?, "
                           "control_version=control_version+1 WHERE target_key=? AND control_version=? "
                           "AND high_water_sequence=?",run[3],ev["upstream_sequence"],
                           ev["upstream_sequence"],key,state[2],state[1])
            need(cursor.rowcount==1,"Pointer committed but Azure SQL state diverged; freeze group")
            control.commit()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--bridge-run-id", required=True)
    parser.add_argument("--evidence", required=True, help="Recorded results from independent gate jobs")
    a = parser.parse_args()
    cfg = config(a.config)
    ev = json.loads(Path(a.evidence).read_text())
    need(ev.get("bridge_run_id") == a.bridge_run_id, "Evidence for different run")
    for gate in ("fence_clean", "source_smoke_check", "audit_health", "policy_readiness",
                 "restricted_identity_tests", "consumer_contract_tests"):
        need(ev.get(gate) is True and ev.get(gate+"_evidence_uri"), f"Missing evidence: {gate}")
    with db("BRIDGE_CONTROL_ODBC") as control:
        run = fetchone(control, "SELECT upstream_run_id,generation_id,inventory_version,release_id,status,upstream_sequence "
                       "FROM bridge.runs WHERE bridge_run_id=?", a.bridge_run_id)
        need(run and run[4] == "READY" and run[2] == cfg["inventory_version"], "Run not READY/inventory changed")
        need(ev.get("release_id") == run[3] and ev.get("generation_id") == run[1], "Evidence release/generation mismatch")
        need(ev.get("upstream_sequence") == run[5], "Evidence source sequence mismatch")
        attempts = control.cursor().execute("SELECT mapping_id,status,source_rows,parquet_rows,delta_rows "
                                             "FROM bridge.object_attempts WHERE bridge_run_id=?",a.bridge_run_id).fetchall()
        by_id = {r[0]:r for r in attempts}
        need(len(by_id) == len(attempts) == len(cfg["mappings"]), "Run has missing/duplicate attempt")
        for m in cfg["mappings"]:
            r = by_id[m["mapping_id"]]
            need(r[1] == "READY" and r[2] == r[3] == r[4], f"Member not reconciled: {m['mapping_id']}")
        update_run(control, a.bridge_run_id, "READY", "PUBLISHING")
        try:
            groups = {}
            for m in cfg["mappings"]:
                groups.setdefault(m["group_id"], []).append(m)
            failures=[]
            with ThreadPoolExecutor(max_workers=cfg.get("max_publisher_workers",1)) as pool:
                futures={pool.submit(publish_group,cfg,ev,a.bridge_run_id,run,by_id,group_id,members):group_id
                         for group_id,members in groups.items()}
                for future in as_completed(futures):
                    try: future.result()
                    except Exception as exc: failures.append((futures[future],exc))
            need(not failures, f"{len(failures)} publication group(s) failed; first: {failures[0] if failures else ''}")
            update_run(control,a.bridge_run_id,"PUBLISHING","PUBLISHED")
        except Exception:
            control.rollback()
            # PUBLISHING intentionally remains in place. A Delta commit might
            # have succeeded; an operator must inspect actual history first.
            raise
    print(json.dumps({"bridge_run_id":a.bridge_run_id,"status":"PUBLISHED"}))


if __name__ == "__main__":
    main()
