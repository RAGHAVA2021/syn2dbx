"""Run a closed Synapse generation through CETAS/ADF and two Databricks jobs.

The Azure SQL, Synapse, ADF and Databricks connections are separate identities.
See README for the required fail-closed preflight and job configuration.
"""
import argparse
import base64
import json
import os
import re
import sys
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed, wait, FIRST_COMPLETED
from datetime import date, datetime, timedelta, timezone
from pathlib import Path

import pyodbc
import requests
from azure.identity import DefaultAzureCredential
from azure.storage.blob import BlobServiceClient
from databricks.sdk import WorkspaceClient


ID = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
KEY = re.compile(r"^[A-Za-z0-9_\-]{1,128}$")
RESERVED = {"release_id","mapping_object_id","source_generation_id","bridge_run_id",
            "upstream_run_id","upstream_sequence","business_date","load_attempt","group_contract_version"}


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def ident(value):
    need(bool(ID.fullmatch(value)), f"Unsafe SQL identifier: {value!r}")
    return f"[{value}]"


def size_class(rows, columns, used_bytes, limits):
    if rows >= limits["large_rows"] or used_bytes >= limits["large_bytes"] or columns >= limits["large_columns"]:
        return "LARGE"
    if rows >= limits["medium_rows"] or used_bytes >= limits["medium_bytes"] or columns >= limits["medium_columns"]:
        return "MEDIUM"
    return "SMALL"


def config(path):
    doc = json.loads(Path(path).read_text())
    need(doc["inventory_version"] and doc["source_set_id"], "Missing inventory/source set")
    for k in ("control_catalog","control_schema"):
        ident(doc[k])
    mappings = doc["mappings"]
    need(mappings, "At least one mapping is required")
    for name, default in (("max_extraction_workers", 4), ("max_loader_workers", 1),
                          ("max_publisher_workers", 1)):
        n = doc.get(name, default)
        need(type(n) is int and 1 <= n <= 32, f"Invalid {name}")
    class_limits = doc.get("extraction_class_limits", {"SMALL": 4, "MEDIUM": 2, "LARGE": 1})
    need(set(class_limits) == {"SMALL", "MEDIUM", "LARGE"} and
         all(type(x) is int and 1 <= x <= 32 for x in class_limits.values()),
         "Invalid extraction_class_limits")
    thresholds = doc.get("profile_thresholds", {})
    required_thresholds = ("medium_rows", "large_rows", "medium_bytes", "large_bytes",
                           "medium_columns", "large_columns")
    if thresholds:
        need(all(type(thresholds.get(k)) is int and thresholds[k] > 0 for k in required_thresholds)
             and thresholds["medium_rows"] < thresholds["large_rows"]
             and thresholds["medium_bytes"] < thresholds["large_bytes"]
             and thresholds["medium_columns"] < thresholds["large_columns"],
             "Invalid profile_thresholds")
    ids, targets, sources = set(), set(), set()
    for m in mappings:
        for k in ("mapping_id", "group_id"):
            need(bool(KEY.fullmatch(m[k])), f"Invalid {k}: {m[k]}")
        need(m["strategy"] in ("REPLACE_TABLE", "RELEASE_POINTER"), "Invalid strategy")
        need(m["method"] in ("CETAS", "COPY_ACTIVITY"), "Invalid route")
        if doc.get("require_profiles"):
            prof = m.get("source_profile", {})
            need(m.get("size_class") in class_limits and
                 prof.get("source_schema_version") == m["source_schema_version"] and
                 type(prof.get("estimated_rows")) is int and prof["estimated_rows"] >= 0 and
                 type(prof.get("physical_used_bytes")) is int and prof["physical_used_bytes"] >= 0 and
                 prof.get("column_count") == len(m["columns"]) and
                 bool(prof.get("profiled_at_utc")),
                 f"Missing/stale profile: {m['mapping_id']}")
            need(bool(thresholds) and m["size_class"] == size_class(
                 prof["estimated_rows"], prof["column_count"], prof["physical_used_bytes"], thresholds),
                 f"Profile class differs from thresholds: {m['mapping_id']}")
        need(m["mandatory"] or m["strategy"] == "REPLACE_TABLE", "Optional pointer member")
        need(m.get("allow_empty") is False, "Empty-result publication requires a separate zero-row release manifest; not implemented here")
        need(m["mapping_id"] not in ids, "Duplicate mapping")
        ids.add(m["mapping_id"])
        src = (m["source_schema"].lower(), m["source_view"].lower())
        tgt = tuple(m[k].lower() for k in ("target_catalog", "target_schema", "target_table"))
        need(src not in sources and tgt not in targets, "Duplicate source or target")
        sources.add(src); targets.add(tgt)
        for k in ("source_schema", "source_view", "target_catalog", "target_schema", "target_table",
                  "candidate_schema", "physical_schema"):
            ident(m[k])
        columns = m["columns"]
        need(columns and len({c["target"].lower() for c in columns}) == len(columns), "Duplicate/missing columns")
        need(not ({c["target"].lower() for c in columns} & RESERVED), "Target column clashes with bridge metadata")
        role = "consumer_properties" if m["strategy"] == "REPLACE_TABLE" else "physical_properties"
        props = m[role]
        for required in ("delta.deletedFileRetentionDuration","delta.logRetentionDuration",
                         "delta.setTransactionRetentionDuration"):
            need(required in props, f"Missing governed property: {required}")
        for c in columns:
            ident(c["source"]); ident(c["target"])
            need(c.get("conversion", "DIRECT") in ("DIRECT", "GUID_TEXT"), "Unsupported source conversion")
            need(c["target_type"] in ("string", "boolean", "int", "bigint", "double", "date", "timestamp", "timestamp_ntz") or
                 bool(re.fullmatch(r"decimal\(\d{1,2},\d{1,2}\)", c["target_type"])), "Unsupported target type")
    groups = {}
    for m in mappings:
        groups.setdefault(m["group_id"], set()).add(m["strategy"])
    need(all(len(x) == 1 for x in groups.values()), "Mixed publication strategies in a group")
    for group_id in groups:
        versions = {m["group_contract_version"] for m in mappings if m["group_id"]==group_id}
        need(len(versions)==1, f"Mixed group-contract versions: {group_id}")
    return doc


def db(var, autocommit=False):
    # Supply complete ODBC connection strings through the named secret store at runtime.
    # Control and CETAS identities must differ. No connection strings are logged.
    return pyodbc.connect(os.environ[var], autocommit=autocommit, timeout=45)


def fetchone(conn, sql, *params):
    return conn.cursor().execute(sql, *params).fetchone()


def projection(m):
    result = []
    for c in m["columns"]:
        src = ident(c["source"])
        expr = f"CONVERT(varchar(36), {src})" if c.get("conversion") == "GUID_TEXT" else src
        result.append(f"{expr} AS {ident(c['target'])}")
    return ", ".join(result)


def require_empty_adls(root, relative):
    match = re.fullmatch(r"abfss://([^@/]+)@([A-Za-z0-9]+)\.dfs\.core\.windows\.net",root.rstrip("/"))
    need(match,"Staging root must be the container-level ADLS URI")
    container, account = match.groups()
    client = BlobServiceClient(f"https://{account}.blob.core.windows.net", DefaultAzureCredential())
    found = next(iter(client.get_container_client(container).list_blobs(name_starts_with=relative)),None)
    need(found is None, f"Attempt prefix is not empty: {relative}")


def update_run(conn, run_id, prior, next_state):
    cur = conn.cursor()
    cur.execute("UPDATE bridge.runs SET status=?, updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND status=?",
                next_state, run_id, prior)
    need(cur.rowcount == 1, f"Run state changed concurrently: {prior} -> {next_state}")
    conn.commit()


def notebook_job(job_id, payload):
    client = WorkspaceClient()
    encoded = base64.b64encode(json.dumps(payload, separators=(",", ":")).encode()).decode()
    need(len(encoded) < 9000, "Job parameter too large: store the approved contract in a restricted control location")
    started = client.jobs.run_now(job_id=int(job_id), notebook_params={"payload_b64": encoded})
    run_id = started.run_id
    need(run_id is not None, "No Databricks run ID")
    deadline = time.monotonic() + 7200
    while time.monotonic() < deadline:
        run = client.jobs.get_run(run_id=run_id)
        state = run.state
        if state and state.life_cycle_state and state.life_cycle_state.value in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
            need(state.result_state and state.result_state.value == "SUCCESS", f"Job failed: {run_id}: {state}")
            task_id = run.tasks[0].run_id if run.tasks else run_id
            output = client.jobs.get_run_output(run_id=task_id)
            value = output.notebook_output.result if output.notebook_output else None
            need(value, f"No notebook output from {task_id}")
            return json.loads(value)
        time.sleep(10)
    raise TimeoutError(f"Databricks run {run_id} not terminal; inspect it before retrying")


def copy_activity(doc, m, payload):
    adf = doc["adf"]
    base = (f"https://management.azure.com/subscriptions/{adf['subscription_id']}"
            f"/resourceGroups/{adf['resource_group']}/providers/Microsoft.DataFactory"
            f"/factories/{adf['factory']}")
    token = DefaultAzureCredential().get_token("https://management.azure.com/.default").token
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    url = f"{base}/pipelines/{adf['copy_pipeline']}/createRun?api-version=2018-06-01"
    p = {"mapping_id":m["mapping_id"],"bridge_run_id":payload["bridge_run_id"],
         "release_id":payload["release_id"],"generation_id":payload["generation_id"],
         "sourceSchema":m["source_schema"],"sourceView":m["source_view"],
         "projection":projection(m),"relativePath":payload["relative_path"]}
    response = requests.post(url, json=p, headers=headers, timeout=60); response.raise_for_status()
    activity_id = response.json()["runId"]
    deadline = time.monotonic() + 7200
    while time.monotonic() < deadline:
        response = requests.get(f"{base}/pipelineruns/{activity_id}?api-version=2018-06-01",
                                headers=headers, timeout=60); response.raise_for_status()
        status = response.json()["status"]
        if status in ("Succeeded", "Failed", "Cancelled"):
            need(status == "Succeeded", f"ADF run {activity_id} ended {status}")
            now = datetime.now(timezone.utc)
            start = (now - timedelta(days=1)).isoformat()
            end = (now + timedelta(hours=1)).isoformat()
            metrics_url = (f"{base}/pipelineruns/{activity_id}/queryActivityruns?api-version=2018-06-01")
            metrics = requests.post(metrics_url, json={"lastUpdatedAfter":start,"lastUpdatedBefore":end},
                                    headers=headers, timeout=60)
            metrics.raise_for_status()
            activities = metrics.json().get("value", [])
            need(len(activities) == 1 and activities[0]["status"] == "Succeeded", "Copy activity evidence missing")
            output = activities[0].get("output", {})
            need(output.get("rowsRead") == output.get("rowsCopied"), "ADF rows read/copied differ")
            need(not output.get("rowsSkipped", 0), "ADF skipped rows")
            return activity_id
        time.sleep(10)
    raise TimeoutError(f"ADF run {activity_id} indeterminate; inspect before retrying")


def cetas(m, relative_path):
    name = "x_" + uuid.uuid4().hex[:24]
    source = f"{ident(m['source_schema'])}.{ident(m['source_view'])}"
    statement = (f"CREATE EXTERNAL TABLE bridge_meta.{ident(name)} WITH "
                 f"(LOCATION = '{relative_path}', DATA_SOURCE = bridge_stage, FILE_FORMAT = bridge_parquet) "
                 f"AS SELECT {projection(m)} FROM {source}")
    with db("BRIDGE_CETAS_ODBC", autocommit=True) as conn:
        try:
            conn.cursor().execute(statement)
        finally:
            # Dropping external-table metadata does not delete the Parquet files.
            conn.cursor().execute(f"IF OBJECT_ID('bridge_meta.{name}') IS NOT NULL "
                                  f"DROP EXTERNAL TABLE bridge_meta.{ident(name)}")
    return name


def fence(conn, doc, generation, run_id):
    row = fetchone(conn, "SELECT state,generation_id,bridge_owner,expires_utc FROM bridge.source_fence WHERE source_set_id=?",
                   doc["source_set_id"])
    need(row and row[0] == "BRIDGE_HELD" and row[1] == generation and row[2] == run_id,
         "Source fence not held by this run/generation")
    need(row[3] is not None, "Fence expiry must be configured")
    now = fetchone(conn, "SELECT SYSUTCDATETIME()")[0]
    need(row[3] > now + timedelta(minutes=int(doc.get("minimum_fence_margin_minutes",30))),
         "Insufficient source-fence time remaining")


def extract_one(cfg, args, run_id, release, rows, m):
    with db("BRIDGE_CONTROL_ODBC") as control:
        fence(control, cfg, args.generation_id, run_id)
        relative = f"bridge/parquet-stage/{args.business_date}/{run_id}/{m['mapping_id']}/attempt-001/"
        full = cfg["staging_abfss_root"].rstrip("/") + "/" + relative
        require_empty_adls(cfg["staging_abfss_root"],relative)
        item = {**m, "bridge_run_id": run_id, "release_id": release,
                "generation_id": args.generation_id, "upstream_run_id": args.upstream_run_id,
                "upstream_sequence": args.sequence, "business_date": str(args.business_date),
                "source_rows": rows[m["mapping_id"]], "leaf_path": full,
                "relative_path": relative, "attempt": 1,
                "delta_write_sequence": args.sequence,
                "inventory_version": cfg["inventory_version"],
                "control_catalog": cfg["control_catalog"], "control_schema": cfg["control_schema"]}
        control.cursor().execute("INSERT bridge.object_attempts(bridge_run_id,mapping_id,attempt,method,status,leaf_path,source_rows) "
                                 "VALUES (?,?,1,?,'EXTRACTING',?,?)", run_id,m["mapping_id"],m["method"],full,rows[m["mapping_id"]])
        control.commit()
        try:
            request_id = cetas(m, relative) if m["method"] == "CETAS" else copy_activity(cfg,m,item)
            cur=control.cursor()
            cur.execute("UPDATE bridge.object_attempts SET status='EXTRACTED',source_request_id=? "
                        "WHERE bridge_run_id=? AND mapping_id=? AND attempt=1 AND status='EXTRACTING'",
                        request_id,run_id,m["mapping_id"])
            need(cur.rowcount==1,"Extraction attempt changed concurrently")
            control.commit()
        except Exception as exc:
            control.rollback()
            control.cursor().execute("UPDATE bridge.object_attempts SET status='FAILED',error_text=? "
                                     "WHERE bridge_run_id=? AND mapping_id=? AND attempt=1",str(exc)[:2000],run_id,m["mapping_id"])
            control.commit()
            raise
        return item


def load_one(cfg, run_id, item):
    result = notebook_job(cfg["loader_job_id"], item)
    need(result["source_rows"] == result["parquet_rows"] == result["delta_rows"] == item["source_rows"],
         f"Three-way count mismatch: {item['mapping_id']}")
    with db("BRIDGE_CONTROL_ODBC") as control:
        cur = control.cursor()
        cur.execute("UPDATE bridge.object_attempts SET status='READY',parquet_rows=?,delta_rows=? "
                    "WHERE bridge_run_id=? AND mapping_id=? AND attempt=1 AND status='EXTRACTED'",
                    result["parquet_rows"], result["delta_rows"], run_id, item["mapping_id"])
        need(cur.rowcount == 1, f"Load state conflict: {item['mapping_id']}")
        control.commit()
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--upstream-run-id", required=True)
    parser.add_argument("--generation-id", required=True)
    parser.add_argument("--sequence", required=True, type=int)
    parser.add_argument("--business-date", required=True, type=date.fromisoformat)
    parser.add_argument("--bridge-run-id", required=True,
                        help="Existing approved BRIDGE_HELD owner. Use same ID for retries/recovery.")
    args = parser.parse_args()
    cfg = config(args.config)
    need(bool(KEY.fullmatch(args.bridge_run_id)), "Unsafe bridge ID")
    run_id = args.bridge_run_id
    release = "rel_" + run_id
    with db("BRIDGE_CONTROL_ODBC") as control, db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
        fence(control, cfg, args.generation_id, run_id)
        audit = fetchone(syn, "SELECT COUNT_BIG(*), MAX(upstream_sequence) FROM bridge_meta.upstream_run "
                         "WHERE upstream_run_id=? AND source_generation_id=? AND status='COMPLETE' AND write_closed=1",
                         args.upstream_run_id, args.generation_id)
        need(audit and audit[0] == 1 and audit[1] == args.sequence, "Upstream run missing/duplicate/unclosed")
        rows = {}
        for m in cfg["mappings"]:
            from source_metadata import schema_hash
            need(schema_hash(syn,m["source_schema"],m["source_view"])==m["source_schema_version"],
                 f"Current presentation schema drift: {m['mapping_id']}")
            r = fetchone(syn, "SELECT COUNT_BIG(*),MAX(row_count),MIN(row_count) FROM bridge_meta.upstream_object "
                         "WHERE upstream_run_id=? AND mapping_id=? AND status='COMPLETE' AND source_schema_version=?",
                         args.upstream_run_id, m["mapping_id"], m["source_schema_version"])
            need(r and r[0] == 1 and r[1] == r[2], f"Missing/duplicate source audit: {m['mapping_id']}")
            rows[m["mapping_id"]] = int(r[1])
        existing = fetchone(control, "SELECT status FROM bridge.runs WHERE bridge_run_id=?", run_id)
        need(not existing, "Run already exists: recover it using its durable state, never rerun blindly")
        seeded={r[0]:(r[1],r[2],r[3]) for r in control.cursor().execute(
            "SELECT mapping_id,group_id,mandatory,strategy FROM bridge.group_members "
            "WHERE inventory_version=? AND enabled=1",cfg["inventory_version"])}
        actual={m["mapping_id"]:(m["group_id"],m["mandatory"],m["strategy"]) for m in cfg["mappings"]}
        need(actual==seeded,"Immutable enabled inventory does not match seeded control members")
        for m in cfg["mappings"]:
            key = "group:" + m["group_id"] if m["strategy"] == "RELEASE_POINTER" else "table:" + ".".join(m[k] for k in ("target_catalog", "target_schema", "target_table"))
            state = fetchone(control, "SELECT high_water_sequence FROM bridge.target_state WHERE target_key=?", key)
            need(state and args.sequence > state[0], f"Missing/stale high-water state: {key}")
        control.cursor().execute("INSERT bridge.runs(bridge_run_id,upstream_run_id,generation_id,upstream_sequence,"
                                 "business_date,inventory_version,release_id,status) "
                                 "VALUES (?,?,?,?,?,?,?,'CREATED')", run_id, args.upstream_run_id,
                                 args.generation_id, args.sequence, args.business_date,
                                 cfg["inventory_version"], release)
        control.commit()
        try:
            update_run(control, run_id, "CREATED", "EXTRACTING")
            objects, errors = [], []
            workers=int(cfg.get("max_extraction_workers",4))
            need(1<=workers<=32,"Invalid extraction concurrency")
            limits=cfg.get("extraction_class_limits", {"SMALL":4,"MEDIUM":2,"LARGE":1})
            # Start the largest objects first to reduce the end-of-window tail.
            pending=sorted(cfg["mappings"], key=lambda m:m.get("source_profile",{}).get("physical_used_bytes",0), reverse=True)
            active={}
            by_class={k:0 for k in limits}
            with ThreadPoolExecutor(max_workers=workers) as pool:
                while pending or active:
                    while len(active)<workers:
                        pos=next((i for i,m in enumerate(pending)
                                  if by_class[m.get("size_class","MEDIUM")] < limits[m.get("size_class","MEDIUM")]),None)
                        if pos is None: break
                        m=pending.pop(pos)
                        cls=m.get("size_class","MEDIUM")
                        future=pool.submit(extract_one,cfg,args,run_id,release,rows,m)
                        active[future]=cls
                        by_class[cls]+=1
                    if not active:
                        raise RuntimeError("No extraction capacity for pending mappings")
                    completed,_=wait(active,return_when=FIRST_COMPLETED)
                    for future in completed:
                        by_class[active.pop(future)]-=1
                        try: objects.append(future.result())
                        except Exception as exc: errors.append(exc)
            if errors: raise RuntimeError(f"{len(errors)} extraction(s) failed; first: {errors[0]}")
            update_run(control, run_id, "EXTRACTING", "EXTRACTED")
            # The source fence is not released by this script: the independent fence
            # detectors and source smoke check in v9 must complete before its release.
            # Loading retained immutable Parquet can proceed with the fence held.
            update_run(control, run_id, "EXTRACTED", "LOADING")
            load_errors=[]
            with ThreadPoolExecutor(max_workers=cfg.get("max_loader_workers",1)) as pool:
                futures=[pool.submit(load_one,cfg,run_id,item) for item in objects]
                for future in as_completed(futures):
                    try: future.result()
                    except Exception as exc: load_errors.append(exc)
            if load_errors:
                raise RuntimeError(f"{len(load_errors)} load(s) failed; first: {load_errors[0]}")
            update_run(control, run_id, "LOADING", "READY")
            # Deliberate stop: policy and consumer gates are held by the separate publisher.
            print(json.dumps({"bridge_run_id":run_id,"release_id":release,"status":"READY",
                              "next":"Run publish.py only after fence/policy/consumer evidence is recorded"}))
        except Exception:
            control.rollback()
            control.cursor().execute("UPDATE bridge.runs SET status='FAILED',updated_utc=SYSUTCDATETIME() "
                                     "WHERE bridge_run_id=? AND status IN ('EXTRACTING','EXTRACTED','LOADING')",run_id)
            control.commit()
            raise


if __name__ == "__main__":
    main()
