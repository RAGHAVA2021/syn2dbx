"""Render initial Azure SQL member/state seeds and Unity Catalog pointer/view SQL.

Run only on a new inventory wave. Review both outputs before executing.
"""
import argparse
from pathlib import Path
from bridge_run import config


def quoted(s):
    return "`"+s+"`"


def lit(s):
    if "'" in str(s): raise ValueError("Invalid literal")
    return "'"+str(s)+"'"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--output-dir", required=True)
    a = p.parse_args()
    doc = config(a.config)
    dest = Path(a.output_dir); dest.mkdir(parents=True, exist_ok=True)
    azure = ["-- Run against Azure SQL. Review state before executing; one inventory version only."]
    uc = ["-- Run against a Unity Catalog SQL warehouse as deployment identity.",
          f"CREATE SCHEMA IF NOT EXISTS {quoted(doc['control_catalog'])}.{quoted(doc['control_schema'])};",
          f"CREATE TABLE IF NOT EXISTS {quoted(doc['control_catalog'])}.{quoted(doc['control_schema'])}.published_groups (",
          " group_id STRING, published_release_id STRING, published_sequence BIGINT,",
          " high_water_sequence BIGINT, previous_release_id STRING,",
          " control_version BIGINT, published_at TIMESTAMP) USING DELTA;" ]
    groups={}
    for m in doc["mappings"]:
        azure.append("INSERT bridge.group_members(inventory_version,group_id,mapping_id,enabled,mandatory,strategy) "
                     f"VALUES ({lit(doc['inventory_version'])},{lit(m['group_id'])},{lit(m['mapping_id'])},"
                     f"1,{1 if m['mandatory'] else 0},{lit(m['strategy'])});")
        key = ("group:"+m["group_id"] if m["strategy"]=="RELEASE_POINTER" else
               "table:"+".".join(m[k] for k in ("target_catalog","target_schema","target_table")))
        groups.setdefault(key, []).append(m)
        for s in ("candidate_schema","physical_schema","target_schema"):
            uc.append(f"CREATE SCHEMA IF NOT EXISTS {quoted(m['target_catalog'])}.{quoted(m[s])};")
    for key, members in groups.items():
        azure.append("INSERT bridge.target_state(target_key,published_release_id,published_sequence,high_water_sequence) "
                     f"VALUES ({lit(key)},'NONE',-1,-1);")
        if members[0]["strategy"]!="RELEASE_POINTER": continue
        group=members[0]["group_id"]
        uc.append(f"INSERT INTO {quoted(doc['control_catalog'])}.{quoted(doc['control_schema'])}.published_groups "
                  "(group_id,published_release_id,published_sequence,high_water_sequence,previous_release_id,control_version,published_at) "
                  f"VALUES ({lit(group)},'NONE',-1,-1,NULL,0,current_timestamp());")
        for m in members:
            table=f"{quoted(m['target_catalog'])}.{quoted(m['physical_schema'])}.{quoted(m['target_table']+'_snapshots')}"
            view=f"{quoted(m['target_catalog'])}.{quoted(m['target_schema'])}.{quoted(m['target_table'])}"
            selected=", ".join(quoted(c["target"]) for c in m["columns"])
            uc.append("-- Confirm governed row filters/masks on PHYSICAL table and grant users only the VIEW.\n"
                      f"CREATE VIEW {view} AS SELECT {selected} FROM {table} WHERE release_id = "
                      f"(SELECT published_release_id FROM {quoted(doc['control_catalog'])}.{quoted(doc['control_schema'])}.published_groups "
                      f"WHERE group_id={lit(group)});" )
    (dest/"azure_sql_seed.sql").write_text("\n".join(azure)+"\n")
    (dest/"unity_catalog_setup.sql").write_text("\n".join(dict.fromkeys(uc))+"\n")
    print(dest)


if __name__=="__main__": main()
