"""Explicit source writer and bridge fence transitions for existing orchestration.

The upstream scheduler MUST call write-start before any governed table DML,
write-close after all audit rows commit, then bridge-hold. All other writer
identities must be constrained to the same entry point.
"""
import argparse
import json
from bridge_run import config, db, need

NEXT = {"write-start":("AVAILABLE","WRITE_ACTIVE"),
        "write-close":("WRITE_ACTIVE","CLOSED"),
        "bridge-hold":("CLOSED","BRIDGE_HELD"),
        "bridge-release":("BRIDGE_HELD","AVAILABLE")}


def main():
    p=argparse.ArgumentParser()
    p.add_argument("action", choices=NEXT)
    p.add_argument("--source-set",required=True)
    p.add_argument("--generation",required=True)
    p.add_argument("--actor",required=True,
                   help="Writer run ID on start/close; bridge run ID on hold/release")
    p.add_argument("--expiry-utc",help="UTC ISO time; required except release")
    p.add_argument("--evidence",help="JSON evidence for release; all gate checks must pass")
    p.add_argument("--config",help="Required for bridge-hold source-audit preflight")
    p.add_argument("--upstream-run-id",help="Required for bridge-hold source-audit preflight")
    a=p.parse_args()
    prior,nxt=NEXT[a.action]
    if a.action != "bridge-release": need(a.expiry_utc,"Fence needs a bounded expiry")
    if a.action == "bridge-release":
        need(a.evidence,"Bridge release needs independent detector evidence")
        data=json.loads(open(a.evidence,encoding="utf-8").read())
        for field in ("all_source_requests_terminal","no_source_retry_needed","audit_healthy",
                      "no_fence_violation","smoke_check_passed"):
            need(data.get(field) is True and data.get(field+"_evidence_uri"),f"Missing {field}")
        need(data.get("source_generation_id")==a.generation,"Wrong generation in evidence")
    if a.action == "bridge-hold":
        need(a.config and a.upstream_run_id,"Hold requires inventory and upstream run ID")
        cfg=config(a.config)
        need(cfg["source_set_id"]==a.source_set,"Wrong source set")
        with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
            run=syn.cursor().execute("SELECT count_big(*) FROM bridge_meta.upstream_run WHERE "
                                     "upstream_run_id=? AND source_generation_id=? AND status='COMPLETE' "
                                     "AND write_closed=1",a.upstream_run_id,a.generation).fetchone()
            need(run and run[0]==1,"Upstream generation not uniquely closed")
            for m in cfg["mappings"]:
                obj=syn.cursor().execute("SELECT count_big(*) FROM bridge_meta.upstream_object WHERE "
                                         "upstream_run_id=? AND mapping_id=? AND source_schema_version=? "
                                         "AND status='COMPLETE'",a.upstream_run_id,m["mapping_id"],
                                         m["source_schema_version"]).fetchone()
                need(obj and obj[0]==1,f"Incomplete upstream member: {m['mapping_id']}")
    with db("BRIDGE_CONTROL_ODBC") as conn:
        row=conn.cursor().execute("SELECT state,generation_id,writer_owner,bridge_owner,control_version "
                                  "FROM bridge.source_fence WHERE source_set_id=?",a.source_set).fetchone()
        need(row and row[0]==prior,"Fence changed; stop")
        if prior not in ("AVAILABLE",): need(row[1]==a.generation,"Generation changed")
        if prior=="WRITE_ACTIVE": need(row[2]==a.actor,"Wrong writer")
        if prior=="BRIDGE_HELD": need(row[3]==a.actor,"Wrong bridge owner")
        conn.cursor().execute("EXEC bridge.transition_fence @source_set_id=?,@expected_state=?,"
                              "@next_state=?,@expected_version=?,@generation_id=?,@actor=?,@expiry_utc=?",
                              a.source_set,prior,nxt,row[4],a.generation,a.actor,a.expiry_utc)
        conn.commit()
    print(json.dumps({"source_set":a.source_set,"generation":a.generation,"state":nxt}))


if __name__=="__main__":main()
