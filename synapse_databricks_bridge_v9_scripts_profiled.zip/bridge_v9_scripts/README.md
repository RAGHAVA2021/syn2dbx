# Synapse to Databricks bridge: v9 executable reference

This package accompanies `syn_views_2_dbx_tbl_v9.md`. It is parameterised code, **not a completed deployment for the actual estate**. It cannot be run unchanged: the sample has fictitious names and the real mappings, identities, network, table contracts, security policies, ADF linked services and Databricks jobs have not been supplied.

## Scope and current limits

The supplied code implements the core full-load path: a governed source fence, upstream view audit, CETAS or ADF Copy to unique ADLS attempt paths, a three-way row count, Delta candidate or multi-release physical writes, independent table replacement and an atomic group pointer. It refuses unsafe identifiers, duplicate mappings, optional pointer members, schema drift, stale publication and repeated run IDs. It does not silently retry failed or ambiguous operations.

Several v9 production controls need environment-specific implementations before any production run: source writer inventory and removal of bypass writes; audit-stream/fence-violation detectors; table-level mask/ABAC inventory and restricted-identity policy tests; consumer contracts and streaming/CDF tests; source/Delta business-total checks; recovery of ambiguous commits; cleanup and rollback automation; case-specific `time`/timestamp/ancient-date conversion; large-object chunking; and monitoring/on-call integration. The evidence file is a record of those external tests, not a way to bypass them. For any mapping requiring those features, extend and validate the code before enabling it. **Do not use this package alone to declare v9 fully implemented.**

Only direct named source columns and a controlled GUID-to-text conversion are rendered for CETAS/Copy. There is no unrestricted SQL expression field. The basic Spark type conversion should be extended for specific source timestamp/decimal contracts after full-volume testing. The ADF route uses one unpartitioned Copy Activity; set additional source parallelism only after capacity testing. The Python bridge runs bounded concurrent extracts, serverless loads, and publications across disjoint target keys. Members within one publication group remain ordered. Benchmark the full 1,000-table path before declaring an overnight SLO.

## Files

| File | Execution context |
|---|---|
| `sql/01_azure_sql_control.sql` | Azure SQL control database administrator |
| `sql/02_synapse_setup.sql` | Existing Synapse dedicated SQL pool database administrator |
| `python/source_metadata.py` | Orchestration host: compute a reproducible source view schema hash |
| `python/profile_inventory.py` | Orchestration host: non-scanning dedicated-pool table profile, CSV review report and a new versioned config |
| `databricks/profile_inventory_pyspark.py` | Manually created Databricks classic cluster: Spark JDBC profile with the same report and versioned config in a UC volume |
| `python/generate_mappings.py` | Discover all source tables or views in a Synapse schema and generate a pinned mapping inventory |
| `databricks/generate_mappings_pyspark.py` | One-time PySpark notebook for the same discovery from Databricks into a Unity Catalog volume |
| `python/fence.py` | Existing upstream scheduler and bridge scheduler; distinct identities |
| `python/upstream_audit.py` | After existing Synapse materialisation, while upstream owns WRITE_ACTIVE |
| `python/render_setup.py` | Local generation of reviewed seed and UC setup SQL |
| `WHERE_TO_ENTER_VALUES.md` | Exact source, ADLS, target and serverless Job configuration fields |
| `python/deploy_adf.py` | Optional Copy route; deploy reviewed ADF objects using existing linked services |
| `python/bridge_run.py` | Control host; extraction and Databricks loading |
| `databricks/load_candidate.py` | Single-task Databricks Job run as loading principal |
| `databricks/publish.py` | Two single-task Jobs: Strategy A publisher and separate group-pointer principal |
| `python/publish_run.py` | Control host; conditional publication after independently recorded gates |

## Before the first run

1. Copy `config.example.json` to a private `config.json`, or use `python/generate_mappings.py` or `databricks/generate_mappings_pyspark.py` as documented in `WHERE_TO_ENTER_VALUES.md` to discover a large source schema. For physical source tables, run `databricks/profile_inventory_pyspark.py` on a manually created, Unity Catalog-enabled Databricks classic cluster. Set its input/output UC volume paths, dedicated-pool JDBC connection and new inventory version. Review the accompanying `.profile.csv` report and configured class thresholds. The orchestration-host `python/profile_inventory.py` remains an alternative, not a prerequisite. Seed **the new profile inventory version**, not the input version. Replace every `<...>` marker; review all mappings, source hashes, ordered column types and exceptions. Choose `REPLACE_TABLE` or `RELEASE_POINTER` by the v9 consistency review. All enabled pointer members must be mandatory and have the same `group_contract_version`. The example count and types are illustrations only.
2. Install Microsoft ODBC Driver 18 for SQL Server and `pip install -r requirements.txt`. Supply four secure ODBC connection strings via `BRIDGE_CONTROL_ODBC`, `BRIDGE_SYNAPSE_AUDIT_ODBC`, `BRIDGE_CETAS_ODBC`, and optionally the identity used for source writer procedures. Do not print them. The CETAS SQL login and source storage credential are different principals. The host identity also needs read/list access to the ADLS staging prefix to prove an attempt path is empty; the Databricks job reads through its UC external location. Configure Databricks unified authentication for the three job invocations. ADF API access uses `DefaultAzureCredential`.
3. Create Azure SQL tables and stored procedure; seed `bridge.source_fence` once. Create Synapse audit, credential, external data source and Parquet file format after the administrator provisions its database master key. Fill the ADLS account/container in the SQL script, then run it once. Grant stored-procedure execution to registered writer/bridge identities but no direct fence-table write privileges. Ensure all governed Synapse writers, including replays and support, acquire the same fence before modification.
4. For each source view, run `python python/source_metadata.py --schema presentation --view v_customer` and record the hash in the config. Recompute on any schema change. Keep a versioned, immutable copy of `config.json` per run. Precreate UC catalogs, schemas, staging external location, service principals and policy functions. Verify runtime and warehouse support for every write and policy inspection command. Grant the Strategy A publisher `MANAGE` on existing consumer tables, `CREATE TABLE` on their schema, plus `SELECT` on candidate tables. Grant the loader no `MANAGE` on consumer tables.
5. Run `python python/render_setup.py --config config.json --output-dir generated`. Review and execute `generated/azure_sql_seed.sql` in the control database. Run `generated/unity_catalog_setup.sql` on a Databricks SQL warehouse **after physical tables are created**: it inserts the `NONE` pointer and creates stable views. Do not grant users access to physical snapshot tables, unpublished candidates or the pointer control table. Apply and test either governed policies on physical tables or approved dynamic view SQL; the supplied generated views assume `PHYSICAL_TABLE_POLICY` and must not be used for groups requiring the other mode.
6. Follow `WHERE_TO_ENTER_VALUES.md` for the UC staging external location and three **Serverless** single-task notebook Jobs. Deploy `databricks/load_candidate.py` as a loader Job; deploy `databricks/publish.py` separately as an independent publisher Job and a group-pointer Job with their respective identities. Disable serverless automatic retries for publication tasks. Set the three job IDs in config. If using Copy, deploy the reviewed datasets and pipeline with `python python/deploy_adf.py --config config.json --synapse-linked-service ... --adls-linked-service ... --container ... --source-dummy-table ...`. The linked services must exist already, with correct network and secret access. Inspect pipeline metrics for skipped/truncated rows during the acceptance run.
7. Test the exact privilege, policy and staging access paths with the intended service principals. Benchmark the full-sized largest objects, CETAS/Copy mixture, Parquet scan, Delta write, publication and rollback. Set `max_extraction_workers`, `extraction_class_limits`, `max_loader_workers`, `max_publisher_workers` and `minimum_fence_margin_minutes` to measured values. Set the loader and publisher Jobs' **Maximum concurrent runs** to at least their respective worker limits; verify workspace/serverless quotas separately. The base code uses one attempt per object and stops for operator reconciliation on failure. A partially published run stays `PUBLISHING` and requires target-by-target reconciliation.

### Profiling and workload classes

Both profilers use dedicated-pool distribution metadata. Their `estimated_rows` and `physical_used_bytes` are planning measurements, not a point-in-time source audit and **not predicted Parquet output bytes**. Replicated tables are counted once for estimated logical rows, but physical bytes include replicated copies. Index maintenance affects the accuracy of DMV counts. The report includes source schema/table, estimated rows, actual source column count, physical GiB, distribution, and SMALL/MEDIUM/LARGE classification. Limits are initial *examples* (`profile_thresholds`); set them from measured execution time and source queue pressure. An object becomes the largest class triggered by its rows, physical size, or column count. The extract scheduler starts large objects early while respecting both the aggregate worker cap and each class cap. It does not use the profile count for reconciliation: the nightly upstream audit remains authoritative. Generate a fresh reviewed inventory when table shape or workload characteristics change. Views without a directly profiled materialised table require a separate approved size measurement; the profilers deliberately stop.

## Nightly command order

All identifiers below are examples. The **same generation** is used from upstream materialisation through the source read. An existing upstream scheduler invokes these as job steps; no secret or manual GUI action is required once the identities and external gates are implemented.

```bash
python python/fence.py write-start --source-set synapse_materialised --generation GEN_20260922_01 --actor SYN_20260922_01 --expiry-utc 2026-09-22T08:00:00
# Run the existing Synapse transformation/materialisation job here.
python python/upstream_audit.py --config config.json --upstream-run-id SYN_20260922_01 --generation-id GEN_20260922_01 --writer-owner SYN_20260922_01 --sequence 2026092201 --business-date 2026-09-22
python python/fence.py write-close --source-set synapse_materialised --generation GEN_20260922_01 --actor SYN_20260922_01 --expiry-utc 2026-09-22T08:00:00
python python/fence.py bridge-hold --config config.json --upstream-run-id SYN_20260922_01 --source-set synapse_materialised --generation GEN_20260922_01 --actor BRG_20260922_01 --expiry-utc 2026-09-22T08:00:00
python python/bridge_run.py --config config.json --upstream-run-id SYN_20260922_01 --generation-id GEN_20260922_01 --sequence 2026092201 --business-date 2026-09-22 --bridge-run-id BRG_20260922_01
# Produce real audit/monitoring/source-smoke evidence and inspect every source request.
python python/fence.py bridge-release --source-set synapse_materialised --generation GEN_20260922_01 --actor BRG_20260922_01 --evidence fence_evidence.json
# Run policy/consumer/readiness tests with the correct restricted identities.
python python/publish_run.py --config config.json --bridge-run-id BRG_20260922_01 --evidence publication_evidence.json
```

The `fence_evidence.json` must contain `source_generation_id`, and each of `all_source_requests_terminal`, `no_source_retry_needed`, `audit_healthy`, `no_fence_violation`, `smoke_check_passed` set to `true`, with a separate `<field>_evidence_uri` for each. The publication evidence must contain `bridge_run_id`, `release_id`, `generation_id`, integer `upstream_sequence`, and `fence_clean`, `source_smoke_check`, `audit_health`, `policy_readiness`, `restricted_identity_tests`, `consumer_contract_tests`, each with a `<field>_evidence_uri`. An external evidence producer must generate them from actual platform records; a hand-written `true` file provides no assurance.

The first loading run creates physical snapshot tables, after which the UC setup SQL can create their stable views. Do not publish a pointer group until all its enabled physical slices, control row, policies and consumer views exist. For subsequent runs, an existing group pointer row is required. Source fence expiry, lost ADF/Databricks acknowledgement or a run left in `PUBLISHING` requires inspecting source request IDs, exact ADLS paths, Delta history and both control stores before any new attempt. Do not rerun the CLI with the same run ID hoping it will repair the state.

## Validation performed locally

`python -m compileall -q python databricks tests`; `python -m json.tool config.example.json`; `pytest -q`. These check syntax and a few fail-closed contract invariants. They do not run against Azure or prove permissions, policy visibility, lake storage semantics, performance or rollback. Run the deployment acceptance evidence from v9 in the actual workspaces.

## Product references

- [Synapse CETAS syntax and permissions](https://learn.microsoft.com/en-us/sql/t-sql/statements/create-external-table-as-select-transact-sql)
- [ADF pipeline createRun](https://learn.microsoft.com/en-us/rest/api/datafactory/pipelines/create-run)
- [ADF Copy from Synapse dedicated SQL pool](https://learn.microsoft.com/en-us/azure/data-factory/connector-azure-sql-data-warehouse)
- [Databricks SDK for Python](https://learn.microsoft.com/en-us/azure/databricks/dev-tools/sdk-python)
- [Databricks table replacement privileges](https://learn.microsoft.com/en-us/azure/databricks/tables/tables-concepts)
- [Delta idempotent writes](https://learn.microsoft.com/en-us/azure/databricks/structured-streaming/delta-lake)
