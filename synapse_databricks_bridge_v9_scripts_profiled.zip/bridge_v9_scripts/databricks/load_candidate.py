# Databricks notebook source
"""Single-task Lakeflow Job, Run as the unprivileged loading service principal.
Notebook parameter: payload_b64. The job must have UC READ FILES on staging.
"""
import base64
import json
import re
from pyspark.sql import functions as F

dbutils.widgets.text("payload_b64", "")
p = json.loads(base64.b64decode(dbutils.widgets.get("payload_b64")).decode())
assert re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", p["target_catalog"])
assert re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", p["target_schema"])
assert re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", p["target_table"])
assert re.fullmatch(r"[A-Za-z0-9_\-]+", p["mapping_id"])
assert p["leaf_path"].startswith("abfss://") and "/bridge/parquet-stage/" in p["leaf_path"]


def q(s):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", s):
        raise ValueError("Unsafe identifier")
    return f"`{s}`"


def quoted(name):
    return ".".join(q(x) for x in name.split("."))


def assert_count(actual, expected, what):
    if actual != expected:
        raise ValueError(f"{what}: expected {expected}, observed {actual}")


# Read only the exact immutable attempt path. A count can skip column decoding;
# the subsequent write of all projected fields is the all-column decode action.
raw = (spark.read.option("ignoreCorruptFiles", "false")
       .option("ignoreMissingFiles", "false").parquet(p["leaf_path"]))
names = [f.name for f in raw.schema.fields]
expected = [c["target"] for c in p["columns"]]
if names != expected or len({n.lower() for n in names}) != len(names):
    raise ValueError(f"Parquet columns/order differ: {names} != {expected}")
for field, contract in zip(raw.schema.fields, p["columns"]):
    if field.dataType.simpleString() != contract["source_spark_type"]:
        raise ValueError(f"Physical/logical type drift in {field.name}: {field.dataType}")
parquet_rows = raw.count()
assert_count(parquet_rows, int(p["source_rows"]), "Source-to-Parquet count")
if parquet_rows == 0 and not p["allow_empty"]:
    raise ValueError("Unapproved empty result")

metadata = {
    "release_id":p["release_id"], "mapping_object_id":p["mapping_id"],
    "source_generation_id":p["generation_id"], "bridge_run_id":p["bridge_run_id"],
    "upstream_run_id":p["upstream_run_id"], "upstream_sequence":str(p["upstream_sequence"]),
    "business_date":p["business_date"], "load_attempt":str(p["attempt"]),
    "group_contract_version":p.get("group_contract_version", "")
}

converted = raw.select(*[F.col(q(c["target"])).cast(c["target_type"]).alias(c["target"])
                         for c in p["columns"]])
# A non-null input becoming NULL is rejected even if the ambient ANSI setting differs.
# With ANSI enabled, invalid casts also fail at the action below.
bad = raw.select(*[
    F.sum(F.when(F.col(q(c["target"])).isNotNull() &
                 F.col(q(c["target"])).cast(c["target_type"]).isNull(), 1).otherwise(0)).alias(c["target"])
    for c in p["columns"]]).first()
if bad and any(x for x in bad):
    raise ValueError(f"Conversion lost non-null values: {bad}")
for k,v in metadata.items():
    converted = converted.withColumn(k, F.lit(v))

catalog, schema = q(p["target_catalog"]), q(p["target_schema"])
if p["strategy"] == "REPLACE_TABLE":
    table_name = f"candidate_{p['mapping_id'].replace('-', '_')}_{p['bridge_run_id'].replace('-', '_')}_a{p['attempt']}"
    target = f"{catalog}.{q(p['candidate_schema'])}.{q(table_name)}"
else:
    target = f"{catalog}.{q(p['physical_schema'])}.{q(p['target_table'] + '_snapshots')}"

columns_sql = ", ".join(f"{q(c['target'])} {c['target_type'].upper()}" for c in p["columns"])
metadata_sql = ", ".join(f"{q(k)} STRING" for k in metadata)
props = p["consumer_properties"] if p["strategy"] == "REPLACE_TABLE" else p["physical_properties"]
if any(not re.fullmatch(r"[A-Za-z][A-Za-z0-9._]*",k) or "'" in str(v) for k,v in props.items()):
    raise ValueError("Unsafe property contract")
properties = ", ".join(f"'{k}'='{v}'" for k,v in sorted(props.items()))
# The consumer/pointer schemas and storage locations are provisioned in advance.
spark.sql(f"CREATE TABLE IF NOT EXISTS {target} ({columns_sql}, {metadata_sql}) USING DELTA "
          f"TBLPROPERTIES ({properties})")

where = (f"release_id = '{p['release_id']}' AND mapping_object_id = '{p['mapping_id']}' "
         f"AND bridge_run_id = '{p['bridge_run_id']}'")
prior = spark.sql(f"SELECT count(*) AS n FROM {target} WHERE {where}").first().n
if prior:
    assert_count(prior, parquet_rows, "Previously committed slice")
else:
    app_id = f"bridge:{p['mapping_id']}:{p['release_id']}"
    version = int(p["delta_write_sequence"])
    if version < 0: raise ValueError("Negative Delta transaction version")
    (converted.write.format("delta").mode("append")
        .option("txnAppId", app_id).option("txnVersion", version)
        .option("userMetadata", json.dumps(metadata, sort_keys=True)).saveAsTable(target))

delta_rows = spark.sql(f"SELECT count(*) AS n FROM {target} WHERE {where}").first().n
assert_count(delta_rows, parquet_rows, "Parquet-to-Delta count")
attempts = spark.sql(f"SELECT count(DISTINCT load_attempt) AS n FROM {target} WHERE {where}").first().n
assert_count(attempts, 1 if delta_rows else 0, "Mixed load attempts")
result = {"source_rows":int(p["source_rows"]), "parquet_rows":parquet_rows,
          "delta_rows":delta_rows, "target":target, "release_id":p["release_id"]}
dbutils.notebook.exit(json.dumps(result))
