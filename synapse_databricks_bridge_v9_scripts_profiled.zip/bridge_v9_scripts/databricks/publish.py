# Databricks notebook source
"""Single-task publication Job. Run as the restricted Strategy A publisher.

For pointer groups, a separate pointer publisher can run this job with MODIFY
on the UC control table; it does not need MANAGE on consumer tables.
"""
import base64
import json
import re

dbutils.widgets.text("payload_b64", "")
p = json.loads(base64.b64decode(dbutils.widgets.get("payload_b64")).decode())


def quote(s):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", s):
        raise ValueError("Unsafe identifier")
    return f"`{s}`"


def literal(s):
    if not re.fullmatch(r"[A-Za-z0-9_\-]+", str(s)):
        raise ValueError("Unsafe release, group or run ID")
    return f"'{s}'"


def table(c, s, t):
    return f"{quote(c)}.{quote(s)}.{quote(t)}"


def single(sql):
    result = spark.sql(sql).collect()
    if len(result) != 1:
        raise ValueError(f"Expected one row, found {len(result)}")
    return result[0]


expected = int(p["upstream_sequence"])
release = literal(p["release_id"])

if p["strategy"] == "REPLACE_TABLE":
    m = p["mapping"]
    target = table(m["target_catalog"],m["target_schema"],m["target_table"])
    candidate = table(m["target_catalog"],m["candidate_schema"],m["candidate_table"])
    count = single(f"SELECT count(*) n, count(DISTINCT source_generation_id) g "
                   f"FROM {candidate} WHERE release_id = {release}")
    if count.n != int(m["source_rows"]) or count.g != (1 if count.n else 0):
        raise ValueError("Candidate not ready or not from one generation")
    observed = single(f"SELECT DISTINCT source_generation_id FROM {candidate} "
                      f"WHERE release_id={release}") if count.n else None
    if observed and observed[0] != m["generation_id"]:
        raise ValueError("Wrong source generation")
    # Policy readiness is a separate mandatory gate: this job is invoked only
    # after approved policy snapshots and restricted-user tests have been stored.
    # Properties are explicit; a previous consumer property's persistence is
    # never assumed. The deploying team must populate this complete contract.
    props = m["consumer_properties"]
    required = ("delta.deletedFileRetentionDuration","delta.logRetentionDuration")
    if not all(x in props for x in required):
        raise ValueError("Missing governed retention property")
    def kv(k,v):
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9._]*",k) or "'" in str(v):
            raise ValueError("Unsafe property")
        return f"'{k}'='{v}'"
    properties = ", ".join(kv(k,v) for k,v in sorted(props.items()))
    columns = ", ".join(quote(c["target"]) for c in m["columns"])
    metadata = ", ".join(quote(x) for x in ("release_id","mapping_object_id","source_generation_id",
                         "bridge_run_id","upstream_run_id","upstream_sequence","business_date","load_attempt",
                         "group_contract_version"))
    # Unique writer lease and expected high-water check are held by the
    # orchestrator. Query the candidate exactly; do not use SELECT *.
    spark.sql(f"CREATE OR REPLACE TABLE {target} USING DELTA TBLPROPERTIES ({properties}) "
              f"AS SELECT {columns}, {metadata} FROM {candidate} WHERE release_id={release}")
    post = single(f"SELECT count(*) n, min(release_id) a, max(release_id) b FROM {target}")
    if post.n != count.n or post.a != p["release_id"] or post.b != p["release_id"]:
        raise ValueError("Published table validation failed; freeze target and recover")
    actual = {r.key:r.value for r in spark.sql(f"SHOW TBLPROPERTIES {target}").collect()}
    if any(actual.get(k) != str(v) for k,v in props.items()):
        raise ValueError("Governed table properties differ after REPLACE")
    dbutils.notebook.exit(json.dumps({"target":target,"release_id":p["release_id"],"rows":post.n}))

elif p["strategy"] == "RELEASE_POINTER":
    control = table(p["control_catalog"],p["control_schema"],"published_groups")
    group = literal(p["group_id"])
    members = p["members"]
    if not members or any(not m["mandatory"] for m in members):
        raise ValueError("Every enabled member must be mandatory")
    if len({m["mapping_id"] for m in members}) != len(members):
        raise ValueError("Duplicate group member")
    for m in members:
        physical = table(m["target_catalog"],m["physical_schema"],m["target_table"] + "_snapshots")
        mapping_id = literal(m["mapping_id"])
        row = single(f"SELECT count(*) n, count(DISTINCT source_generation_id) g, "
                     f"count(DISTINCT bridge_run_id) b, count(DISTINCT group_contract_version) c "
                     f"FROM {physical} WHERE release_id={release} AND mapping_object_id={mapping_id}")
        if (row.n != int(m["source_rows"]) or
            (row.g,row.b,row.c) != ((1,1,1) if row.n else (0,0,0))):
            raise ValueError(f"Unready group member: {m['mapping_id']}")
        if row.n:
            tags = single(f"SELECT min(source_generation_id) g, min(bridge_run_id) b, "
                          f"min(group_contract_version) c FROM {physical} "
                          f"WHERE release_id={release} AND mapping_object_id={mapping_id}")
            if (tags.g,tags.b,tags.c) != (p["generation_id"],p["bridge_run_id"],p["group_contract_version"]):
                raise ValueError("Group member from wrong generation/run/contract")
    old = single(f"SELECT published_release_id,high_water_sequence,control_version "
                 f"FROM {control} WHERE group_id={group}")
    if old.high_water_sequence >= expected:
        raise ValueError("Candidate is stale versus publication high-water")
    if old.published_release_id != p["expected_current_release"] or old.control_version != p["expected_version"]:
        raise ValueError("Publication pointer changed during readiness")
    spark.sql(f"UPDATE {control} SET previous_release_id=published_release_id, "
              f"published_release_id={release}, published_sequence={expected}, "
              f"high_water_sequence={expected},control_version=control_version+1, "
              f"published_at=current_timestamp() WHERE group_id={group} "
              f"AND control_version={int(p['expected_version'])} "
              f"AND published_release_id={literal(p['expected_current_release'])} "
              f"AND high_water_sequence={old.high_water_sequence}")
    new = single(f"SELECT published_release_id,control_version FROM {control} WHERE group_id={group}")
    if new.published_release_id != p["release_id"] or new.control_version != old.control_version+1:
        raise ValueError("Pointer update not proven; inspect Delta history before retry")
    dbutils.notebook.exit(json.dumps({"group_id":p["group_id"],"release_id":p["release_id"]}))
else:
    raise ValueError("Unsupported publication strategy")
