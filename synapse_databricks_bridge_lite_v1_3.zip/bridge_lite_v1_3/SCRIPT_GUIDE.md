# Script guide: what each script does, in the order you use it

The package copies Synapse dedicated-pool tables or views into Unity Catalog Delta tables once a day. Every script belongs to one of these phases:

| Phase | When | Steps |
|---|---|---|
| **I** Inventory | Once per inventory wave | I1–I3 |
| **S** Setup | Once, plus S2 for each new wave | S1–S3 |
| **N** Nightly | Every day, as one chained job (see `DESIGN.md`) | N1–N4 |
| **M** Maintenance | For example weekly | M1 |
| **R** Recovery | Only after a failure | R1–R3 |

"Control host" means the machine or job runner that runs the Python scripts. It holds the ODBC connection strings in environment variables.

---

## Phase I: build the inventory

### I1 `python/generate_mappings.py` (or `databricks/generate_mappings_pyspark.py`)

**Purpose:** discover every table or view in one Synapse schema and write a config with one mapping per object. Each mapping gets:

- all columns, in source order;
- the supported type conversions;
- a schema hash;
- a consumer table name.

If any column has a type that needs human review, nothing is written. The problem objects are listed in `*.exceptions.json` instead.

- **Runs on:** the control host (ODBC, `BRIDGE_SYNAPSE_AUDIT_ODBC`) or a Databricks cluster (JDBC, writes to a UC volume).
- **Writes:** a new config file (never overwrites) plus the exceptions report.
- **Next:** review the config, then fill in the staging root and the job IDs.

### I2 `python/profile_inventory.py` (or `databricks/profile_inventory_pyspark.py`) — optional

**Purpose:** classify each table as SMALL, MEDIUM or LARGE. The classification uses estimated rows, physical bytes and column count, all read from dedicated-pool DMVs without scanning data.

The nightly run starts the largest tables first and limits concurrent extracts per class. The script writes a **new inventory version** plus a `.profile.csv` report. Without profiling, every mapping is scheduled as MEDIUM.

### I3 `python/source_metadata.py`

**Purpose:** print the schema hash of one source object (`--schema`, `--view`). Use it when you add or edit a mapping by hand. It is also the library that `upstream_audit.py` and `bridge_run.py` use to detect schema drift.

---

## Phase S: set up the platform

### S1 SQL scripts

| Script | Where | Creates |
|---|---|---|
| `sql/01_azure_sql_control.sql` | Azure SQL control database | `bridge.runs`, `bridge.object_attempts`, `bridge.target_state`, `bridge.recovery_events` |
| `sql/02_synapse_setup.sql` | Synapse dedicated pool | `bridge_meta` schema, managed-identity credential, ADLS external data source, Parquet file format, `upstream_run`/`upstream_object` audit tables |

### S2 `python/render_setup.py`

**Purpose:** turn the config into two idempotent SQL files:

- `azure_sql_seed.sql` adds one `bridge.target_state` row per consumer table. Run it in the control database.
- `unity_catalog_setup.sql` creates the candidate and consumer schemas. Run it on a SQL warehouse.

Rerun both for every new inventory wave. Existing publication state is never reset.

### S3 Databricks jobs

Import the notebooks and create one **serverless, single-task** job for each. Each job has its own Run-as identity and the notebook parameters `manifest_path` and `manifest_sha256`. Put the job IDs in the config.

| Notebook | Job | Config key |
|---|---|---|
| `databricks/load_candidate.py` | Loader | `loader_job_id` |
| `databricks/publish.py` | Publisher | `publisher_job_id` |
| `databricks/retire_releases.py` | Retention | `retention_job_id` |

`WHERE_TO_ENTER_VALUES.md` lists the grants and job settings.

---

## Phase N: the nightly chain

### N1 Your existing Synapse refresh

This stays unchanged. It must finish before N2 starts, and it must not run again until N3 has finished.

### N2 `python/upstream_audit.py`

**Purpose:** record, for this refresh, every mapped object's row count and schema hash. It also records the refresh's business date and an increasing sequence number.

These counts are what the Parquet files and Delta tables must match later. The script refuses:

- a duplicate refresh ID;
- schema drift;
- a sequence that is not higher than the last one.

`--sequence` defaults to the previous sequence plus one.

### N3 `python/bridge_run.py` (runs `databricks/load_candidate.py`)

**Purpose:** extract every mapping with CETAS to Parquet and load it into an attempt-specific Delta candidate table. Each table passes a three-way row-count check: audit = Parquet = Delta.

1. **Pre-checks:**
   - the refresh is audited and is still the newest one;
   - the schema hashes match the config;
   - every consumer table is seeded, and this refresh is newer than what it holds;
   - no other open run exists for this refresh.
2. **Extract:** CETAS writes to a fresh, empty `…/attempt-NNN/` folder, largest tables first, within the worker and class limits. The "still the newest refresh" check is repeated after every read. An audited zero-row object skips CETAS and is loaded from its reviewed schema.
3. **Load:** the loader job checks the Parquet column names, order, types and row count, then writes the candidate table idempotently.
4. The run ends `READY`, even if some mappings were excluded in partial mode. The output lists ready and excluded IDs. **It changes nothing that consumers see.**

The run holds a lease with a heartbeat. After a failure, use `--resume` (step R1).

`--bridge-run-id` accepts letters, digits, `_` and `-`, **1 to 124 characters**, because the derived release ID `rel_<run>` must fit a 128-character column.

### N4 `python/publish_run.py` (runs `databricks/publish.py`)

**Purpose:** replace each consumer table from its candidate with one atomic `CREATE OR REPLACE TABLE`, then verify the row count, release ID and table properties.

Before touching a table, the run takes that table's publication claim in Azure SQL, so two runs can never replace the same table at once. A table that already holds a newer release is reported as `superseded-by-newer` and left alone. With excluded mappings, only READY tables publish and the run ends `PARTIALLY_PUBLISHED`; otherwise it ends `PUBLISHED`.

---

## Phase M: maintenance

### M1 `python/retire_releases.py` (runs `databricks/retire_releases.py`)

**Purpose:** stop old candidate tables and Parquet files from accumulating.

- For each table it always keeps the published release, the previous release (for rollback) and any `--keep-release`.
- Candidate tables are dropped, and with `--delete-staging` the exact recorded Parquet attempt folders are deleted, once the retention window has passed:
  - `retention_days_published` (default 7) for published releases;
  - `retention_days_unpublished` (default 30) for everything else, including failed and abandoned attempts.
- It is a dry run unless you pass `--execute`. The Databricks job re-reads each consumer table and never drops the candidate it currently holds.

---

## Phase R: recovery

### R1 `python/bridge_run.py … --resume`

Continues a FAILED or crashed run with the same `--upstream-run-id` and `--bridge-run-id`:

- READY tables are kept.
- EXTRACTED tables are reloaded from their retained Parquet.
- Failed extractions get the next attempt folder, up to `max_attempts`.

A run whose lease is still live cannot be taken over until `takeover_after_minutes` after its last heartbeat.

If the previous process died while a read or load was in flight, `--resume` marks that attempt `INDETERMINATE` and stops. Resolve it with R3, then resume again.

If a newer refresh has been audited since the run started, re-extraction is refused. Abandon the run with R3 `abandon-run` and start a new run for the new refresh.

### R2 `python/publish_run.py … --resume`

Continues a run left in PUBLISHING. Each remaining table's actual Delta state is inspected first:

- **The Delta table already holds this release** (the Azure SQL update was lost): the table is reconciled, not republished.
- **The Delta table still holds the release Azure SQL records as published:** the table is published.
- **Anything else:** that table stops for operator review.

If a publisher job's outcome is unknown, the run keeps its lease. Resolve it with R3 `resolve-publication` first.

### R3 `python/recovery.py`

| Command | Use when | Needs |
|---|---|---|
| `resolve-attempt` | An attempt is `INDETERMINATE` (a CETAS read or loader job whose outcome is unknown) | Evidence that the stored external ID is terminal (`phase` SOURCE or LOADER) |
| `resolve-publication` | A publisher job's outcome is unknown | Evidence that the stored publisher run is terminal and the old orchestrator stopped |
| `abandon-publication` | A table's publication must be given up, including a claim made before job submission | `--config`; evidence that the orchestrator stopped and Delta was inspected, plus terminal external ID or proof no job was submitted |
| `abandon-publishing-run` | A PUBLISHING run has no outstanding target claims | `--config`; stopped orchestrator and released/expired lease |
| `abandon-run` | An unpublished run can no longer finish, e.g. a newer refresh replaced its source data or it reached `max_attempts` | No evidence; refused while any read or load may still be running, or while another process holds a live lease |

Every action is written to `bridge.recovery_events`. Evidence formats are in `README.md`.

---

## How the pieces connect

```text
generate_mappings ─► (profile_inventory) ─► config.json (reviewed, versioned)
sql/01 + sql/02 ─► render_setup ─► control seed + UC schemas ─► three Databricks jobs

nightly (one chain, concurrency 1):
  [your refresh] ─► upstream_audit ─► bridge_run ──(loader job)──► READY ─► publish_run ──(publisher job)──► PUBLISHED

periodic: retire_releases ──(retention job)
recovery: bridge_run --resume · publish_run --resume · recovery.py
```
