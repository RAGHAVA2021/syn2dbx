"""Step S2 (SCRIPT_GUIDE.md): render the Azure SQL seed and Unity Catalog setup SQL.

Safe to run for every inventory wave: every statement is idempotent and existing
publication state is never reset.

  azure_sql_seed.sql       one bridge.target_state row per consumer table
  unity_catalog_setup.sql  the candidate and consumer schemas
"""
import argparse
from pathlib import Path

from bridge_run import config, ident, target_key


def q(s):
    ident(s)
    return "`" + s + "`"


def lit(s):
    if "'" in str(s):
        raise ValueError("Invalid literal")
    return "'" + str(s) + "'"


def render(doc):
    azure = ["-- Run against the Azure SQL control database. Idempotent: safe to re-run and safe for later waves.",
             "SET XACT_ABORT ON;", "BEGIN TRANSACTION;"]
    uc = ["-- Run on a Unity Catalog SQL warehouse as the deployment identity. Idempotent."]
    for m in doc["mappings"]:
        key = lit(target_key(m))
        azure.append(f"IF NOT EXISTS (SELECT 1 FROM bridge.target_state WHERE target_key={key}) "
                     "INSERT bridge.target_state(target_key,published_release_id,published_sequence,high_water_sequence) "
                     f"VALUES ({key},'NONE',-1,-1);")
        for s in ("candidate_schema", "target_schema"):
            uc.append(f"CREATE SCHEMA IF NOT EXISTS {q(m['target_catalog'])}.{q(m[s])};")
    azure.append("COMMIT;")
    return "\n".join(azure) + "\n", "\n".join(dict.fromkeys(uc)) + "\n"


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--output-dir", required=True)
    a = p.parse_args()
    azure, uc = render(config(a.config))
    dest = Path(a.output_dir)
    dest.mkdir(parents=True, exist_ok=True)
    (dest / "azure_sql_seed.sql").write_text(azure)
    (dest / "unity_catalog_setup.sql").write_text(uc)
    print(dest)


if __name__ == "__main__":
    main()
