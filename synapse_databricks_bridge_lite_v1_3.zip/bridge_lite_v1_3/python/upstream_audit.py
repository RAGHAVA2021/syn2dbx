"""Step N2 (SCRIPT_GUIDE.md): record the row count and schema of every mapped source after the daily refresh.

Run it as the step immediately after the refresh, in the same pipeline, and before
bridge_run.py. These counts are what the extract, the Parquet files and the Delta
candidates must all match. The run is written in one transaction: either every mapping
is recorded or none is.
"""
import argparse
import json
from datetime import date

from bridge_run import KEY, cetas_error_is_terminal, config, db, ident, need
from source_metadata import schema_hash


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--upstream-run-id", required=True, help="Unique ID of this refresh, e.g. SYN_20260922")
    p.add_argument("--business-date", required=True, type=date.fromisoformat)
    p.add_argument("--sequence", type=int,
                   help="Increasing number of this refresh; default is the latest recorded sequence + 1")
    a = p.parse_args()
    need(bool(KEY.fullmatch(a.upstream_run_id)), "Unsafe upstream run ID (1..128 letters, digits, '_' or '-')")
    d = config(a.config)
    with db("BRIDGE_SYNAPSE_AUDIT_ODBC", autocommit=True) as syn:
        prior = syn.cursor().execute("SELECT count_big(*) FROM bridge_meta.upstream_run WHERE upstream_run_id=?",
                                     a.upstream_run_id).fetchone()[0]
        need(prior == 0, "Upstream run audit already exists; use a new upstream run ID")
        # Sequences drive the publication high-water mark; a reused or lower sequence would only
        # be rejected much later, after a full extraction.
        latest = syn.cursor().execute("SELECT MAX(upstream_sequence) FROM bridge_meta.upstream_run").fetchone()[0]
        sequence = a.sequence if a.sequence is not None else (0 if latest is None else int(latest)) + 1
        need(latest is None or sequence > int(latest),
             f"Sequence {sequence} must be greater than the latest recorded sequence {latest}")
        observations = []
        for m in d["mappings"]:
            try:
                actual = schema_hash(syn, m["source_schema"], m["source_view"])
                need(actual == m["source_schema_version"], f"Schema drift: {m['mapping_id']}")
                query = f"SELECT count_big(*) FROM {ident(m['source_schema'])}.{ident(m['source_view'])}"
                n = int(syn.cursor().execute(query).fetchone()[0])
                observations.append((m, "COMPLETE", n, None))
            except Exception as exc:
                # Connection loss, timeout or an unclassified driver failure is
                # not evidence that this source alone is bad; stop the entire audit.
                local_drift = isinstance(exc, (RuntimeError, ValueError))
                if not d.get("allow_partial_release", False) or not (local_drift or cetas_error_is_terminal(exc)):
                    raise
                observations.append((m, "EXCLUDED", 0, f"{type(exc).__name__}: {exc}"[:1000]))
    with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
        try:
            for m, status, n, error in observations:
                syn.cursor().execute("INSERT bridge_meta.upstream_object(upstream_run_id,mapping_id,"
                                     "source_schema_version,status,row_count,error_text,refresh_completed_utc) "
                                     "VALUES (?,?,?,?,?,?,SYSUTCDATETIME())",
                                     a.upstream_run_id, m["mapping_id"], m["source_schema_version"], status, n, error)
            syn.cursor().execute("INSERT bridge_meta.upstream_run(upstream_run_id,upstream_sequence,business_date,"
                                 "status,completed_utc) VALUES (?,?,?,'COMPLETE',SYSUTCDATETIME())",
                                 a.upstream_run_id, sequence, a.business_date)
            syn.commit()
        except Exception:
            syn.rollback()
            raise
    print(json.dumps({"upstream_run_id": a.upstream_run_id, "sequence": sequence,
                      "complete": sum(x[1] == "COMPLETE" for x in observations),
                      "excluded": [x[0]["mapping_id"] for x in observations if x[1] == "EXCLUDED"]}))


if __name__ == "__main__":
    main()
