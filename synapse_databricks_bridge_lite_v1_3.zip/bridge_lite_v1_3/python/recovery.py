"""Step R3 (SCRIPT_GUIDE.md): audited recovery for stuck attempts, publications and runs.

This command never infers that an external operation stopped. For resolve-attempt,
resolve-publication and abandon-publication an operator or monitor must inspect the
stored external run ID and supply evidence. abandon-run needs no evidence because it
refuses any run that may still have external work in flight.

  resolve-attempt      INDETERMINATE attempt -> retryable, after terminal evidence
  resolve-publication  unknown publisher -> resumable, after terminal evidence
  abandon-publication  release a publication claim, after terminal evidence and a Delta check
  abandon-run          give up an unpublished run (e.g. a newer refresh replaced its source data)
"""
import argparse
import json
from pathlib import Path

from bridge_run import config, db, need

UNRESOLVED = ("RUNNING", "UNKNOWN")
ABANDONABLE_RUNS = ("EXTRACTING", "EXTRACTED", "LOADING", "READY", "FAILED")


def evidence(path, required):
    doc = json.loads(Path(path).read_text())
    for field in required:
        need(doc.get(field) is True, f"Evidence must set {field}=true")
    need(isinstance(doc.get("evidence_uri"), str) and doc["evidence_uri"], "Evidence URI is required")
    return doc


def resolve_databricks_external_id(stored_id, ev):
    """Validate loader/publisher evidence and return the authoritative Databricks run ID.

    The orchestrator stores the job's idempotency token ("token:<token>") before run-now and the
    numeric run ID only after Databricks answers. If that answer was lost, the stored value is the
    token. Evidence may then either repeat the stored token as external_run_id (no run was found
    for it), or give the matching idempotency_token together with the actual run ID found for it,
    which is recorded in place of the token.
    """
    need(stored_id, "No stored Databricks run identifier")
    stored_id = str(stored_id)
    supplied = ev.get("external_run_id")
    if stored_id.startswith("token:"):
        if supplied == stored_id:
            return stored_id
        token = str(ev.get("idempotency_token") or "")
        need(token and "token:" + token.removeprefix("token:") == stored_id,
             "Evidence idempotency_token differs from the stored submission token")
        need(isinstance(supplied, str) and supplied.strip() and not supplied.startswith("token:"),
             "Evidence must provide the actual Databricks external_run_id found for the token")
        return supplied
    need(supplied == stored_id, "Evidence external run ID differs")
    return stored_id


def resolve_attempt(a):
    ev = evidence(a.evidence, ("external_terminal", "safe_to_retry"))
    need(ev.get("phase") in ("SOURCE", "LOADER"), "Evidence phase must be SOURCE or LOADER")
    with db("BRIDGE_CONTROL_ODBC") as conn:
        cur = conn.cursor()
        row = cur.execute(
            "SELECT a.status,a.source_request_id,a.loader_run_id,r.status,a.source_operation_state,"
            "a.loader_operation_state FROM bridge.object_attempts a WITH (UPDLOCK,HOLDLOCK) "
            "JOIN bridge.runs r ON r.bridge_run_id=a.bridge_run_id WHERE a.bridge_run_id=? AND a.mapping_id=? "
            "AND a.attempt=?", a.bridge_run_id, a.mapping_id, a.attempt).fetchone()
        need(row, "Unknown attempt")
        need(row[0] == "INDETERMINATE" and row[3] == "FAILED", "Attempt/run is not awaiting recovery")
        source = ev["phase"] == "SOURCE"
        # The evidence must be about the operation that is actually unresolved. Proving an
        # already-terminal operation terminal would otherwise release the lease while the
        # other (source or loader) operation may still be running.
        phase_state, other_state = (row[4], row[5]) if source else (row[5], row[4])
        other_phase = "LOADER" if source else "SOURCE"
        need(phase_state in UNRESOLVED,
             f"The {ev['phase']} operation is not unresolved (state {phase_state}); "
             "supply evidence for the operation that is RUNNING/UNKNOWN")
        need(other_state not in UNRESOLVED,
             f"The {other_phase} operation is also unresolved (state {other_state}); resolve it first")
        if source:
            need(row[1] and ev.get("external_run_id") == row[1], "Evidence external run ID differs")
            resolved_id = row[1]
        else:
            resolved_id = resolve_databricks_external_id(row[2], ev)
        next_status = "FAILED" if source else "EXTRACTED"
        state_col = "source_operation_state" if source else "loader_operation_state"
        id_col = "source_request_id" if source else "loader_run_id"
        cur.execute(f"UPDATE bridge.object_attempts SET status=?,{id_col}=?,{state_col}='VERIFIED_TERMINAL',"
                    "error_text=?,updated_utc=SYSUTCDATETIME() "
                    "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status='INDETERMINATE'",
                    next_status, resolved_id, ("Recovered after terminal evidence: " + a.reason)[:2000],
                    a.bridge_run_id, a.mapping_id, a.attempt)
        need(cur.rowcount == 1, "Attempt changed concurrently")
        remaining = cur.execute("SELECT count(*) FROM bridge.object_attempts WHERE bridge_run_id=? "
                                "AND status='INDETERMINATE'", a.bridge_run_id).fetchone()[0]
        if remaining == 0:
            cur.execute("UPDATE bridge.runs SET orchestrator_token=NULL,updated_utc=SYSUTCDATETIME() "
                        "WHERE bridge_run_id=? AND status='FAILED'", a.bridge_run_id)
        cur.execute("INSERT bridge.recovery_events(action,bridge_run_id,mapping_id,attempt,external_run_id,actor,"
                    "evidence_uri,reason) VALUES ('RESOLVE_ATTEMPT',?,?,?,?,?,?,?)",
                    a.bridge_run_id, a.mapping_id, a.attempt, resolved_id, a.actor, ev["evidence_uri"], a.reason)
        conn.commit()


def resolve_publication(a):
    """Record proof that an unknown mutating publisher is terminal, preserving its ID.

    The explicit orchestrator_stopped assertion prevents an operator from clearing the
    lease while the original publisher orchestration is still actively heartbeating.
    Once every unknown publisher owned by the run is resolved, resume may proceed
    immediately and will inspect Delta before deciding whether to reconcile or publish.
    """
    ev = evidence(a.evidence, ("external_terminal", "safe_to_resume", "orchestrator_stopped"))
    with db("BRIDGE_CONTROL_ODBC") as conn:
        cur = conn.cursor()
        target = cur.execute(
            "SELECT publish_owner,publish_external_run_id,publish_operation_state "
            "FROM bridge.target_state WITH (UPDLOCK,HOLDLOCK) WHERE target_key=?", a.target_key).fetchone()
        run = cur.execute("SELECT status FROM bridge.runs WITH (UPDLOCK,HOLDLOCK) WHERE bridge_run_id=?",
                          a.bridge_run_id).fetchone()
        need(target and run and target[0] == a.bridge_run_id and run[0] == "PUBLISHING",
             "Run does not own an unresolved publication claim")
        need(target[2] in UNRESOLVED, "Publisher operation is not awaiting recovery")
        resolved_id = resolve_databricks_external_id(target[1], ev)
        cur.execute("UPDATE bridge.target_state SET publish_external_run_id=?,publish_operation_state='VERIFIED_TERMINAL' "
                    "WHERE target_key=? AND publish_owner=? AND publish_external_run_id=? "
                    "AND publish_operation_state IN ('RUNNING','UNKNOWN')",
                    resolved_id, a.target_key, a.bridge_run_id, target[1])
        need(cur.rowcount == 1, "Publication claim changed concurrently")
        unresolved = cur.execute(
            "SELECT count(*) FROM bridge.target_state WHERE publish_owner=? "
            "AND publish_operation_state IN ('RUNNING','UNKNOWN')", a.bridge_run_id).fetchone()[0]
        if unresolved == 0:
            cur.execute("UPDATE bridge.runs SET orchestrator_token=NULL,updated_utc=SYSUTCDATETIME() "
                        "WHERE bridge_run_id=? AND status='PUBLISHING'", a.bridge_run_id)
        cur.execute("INSERT bridge.recovery_events(action,bridge_run_id,target_key,external_run_id,actor,evidence_uri,"
                    "reason) VALUES ('RESOLVE_PUBLICATION',?,?,?,?,?,?)", a.bridge_run_id, a.target_key,
                    resolved_id, a.actor, ev["evidence_uri"], a.reason)
        conn.commit()


def abandon_publication(a):
    ev = evidence(a.evidence, ("delta_state_verified", "safe_to_abandon", "orchestrator_stopped"))
    takeover = config(a.config).get("takeover_after_minutes", 150)
    with db("BRIDGE_CONTROL_ODBC") as conn:
        cur = conn.cursor()
        target = cur.execute("SELECT publish_owner,publish_external_run_id,publish_operation_state FROM bridge.target_state "
                             "WITH (UPDLOCK,HOLDLOCK) WHERE target_key=?", a.target_key).fetchone()
        run = cur.execute("SELECT status, CASE WHEN orchestrator_token IS NULL OR heartbeat_utc IS NULL "
                          "OR heartbeat_utc < DATEADD(minute, -?, SYSUTCDATETIME()) THEN 1 ELSE 0 END "
                          "FROM bridge.runs WITH (UPDLOCK,HOLDLOCK) WHERE bridge_run_id=?",
                          takeover, a.bridge_run_id).fetchone()
        need(target and run and target[0] == a.bridge_run_id and run[0] == "PUBLISHING",
             "Run does not own an active publication claim")
        need(run[1] == 1, f"Run holds a live lease; stop it and wait {takeover} minutes")
        if target[1] is None:
            # The claim is written before notebook_job starts. A missing ID is safe to
            # abandon only if its pre-submission state is still NULL and the original
            # orchestrator is known stopped; no external mutation was submitted.
            need(target[2] is None and ev.get("no_external_submission") is True,
                 "Missing publisher ID requires no_external_submission=true and no operation state")
            resolved_id = None
        else:
            need(ev.get("external_terminal") is True, "Evidence must set external_terminal=true")
            resolved_id = resolve_databricks_external_id(target[1], ev)
        cur.execute("UPDATE bridge.target_state SET publish_owner=NULL,publish_token=NULL,publish_claimed_utc=NULL,"
                    "publish_external_run_id=?,publish_operation_state='ABANDONED' WHERE target_key=? AND publish_owner=?",
                    resolved_id, a.target_key, a.bridge_run_id)
        need(cur.rowcount == 1, "Publication claim changed concurrently")
        remaining = cur.execute("SELECT count(*) FROM bridge.target_state WHERE publish_owner=?",
                                a.bridge_run_id).fetchone()[0]
        if remaining == 0:
            cur.execute("UPDATE bridge.runs SET status='PUBLICATION_ABANDONED',orchestrator_token=NULL,"
                        "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND status='PUBLISHING'", a.bridge_run_id)
        cur.execute("INSERT bridge.recovery_events(action,bridge_run_id,target_key,external_run_id,actor,evidence_uri,"
                    "reason) VALUES ('ABANDON_PUBLICATION',?,?,?,?,?,?)", a.bridge_run_id, a.target_key,
                    resolved_id, a.actor, ev["evidence_uri"], a.reason)
        conn.commit()


def abandon_publishing_run(a):
    """Finish an orphaned PUBLISHING run when it has no outstanding target claims."""
    ev = evidence(a.evidence, ("orchestrator_stopped", "safe_to_abandon"))
    takeover = config(a.config).get("takeover_after_minutes", 150)
    with db("BRIDGE_CONTROL_ODBC") as conn:
        cur = conn.cursor()
        run = cur.execute("SELECT status FROM bridge.runs WITH (UPDLOCK,HOLDLOCK) WHERE bridge_run_id=?",
                          a.bridge_run_id).fetchone()
        need(run and run[0] == "PUBLISHING", "Run is not awaiting publication recovery")
        owned = cur.execute("SELECT count(*) FROM bridge.target_state WITH (UPDLOCK,HOLDLOCK) "
                            "WHERE publish_owner=?", a.bridge_run_id).fetchone()[0]
        need(owned == 0, "Run still owns publication claims; resolve or abandon each target first")
        cur.execute("UPDATE bridge.runs SET status='PUBLICATION_ABANDONED',orchestrator_token=NULL,"
                    "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND status='PUBLISHING' "
                    "AND (orchestrator_token IS NULL OR heartbeat_utc IS NULL "
                    "OR heartbeat_utc < DATEADD(minute, -?, SYSUTCDATETIME()))",
                    a.bridge_run_id, takeover)
        need(cur.rowcount == 1, f"Run holds a live lease; stop the orchestrator and wait {takeover} minutes")
        cur.execute("INSERT bridge.recovery_events(action,bridge_run_id,actor,evidence_uri,reason) "
                    "VALUES ('ABANDON_PUBLISHING_RUN',?,?,?,?)",
                    a.bridge_run_id, a.actor, ev["evidence_uri"], a.reason)
        conn.commit()


def abandon_run(a):
    """Give up an unpublished run so a new run can take its place and retention can clean it up.

    Refused while any source read or loader of the run may still be running (resolve those
    with resolve-attempt first) and while another orchestrator holds a live lease on the run.
    """
    takeover = config(a.config).get("takeover_after_minutes", 150)
    with db("BRIDGE_CONTROL_ODBC") as conn:
        cur = conn.cursor()
        run = cur.execute("SELECT status FROM bridge.runs WITH (UPDLOCK,HOLDLOCK) WHERE bridge_run_id=?",
                          a.bridge_run_id).fetchone()
        need(run, "Unknown run")
        need(run[0] in ABANDONABLE_RUNS, f"Run status {run[0]} cannot be abandoned "
                                         "(a PUBLISHING run uses abandon-publication for each claimed target)")
        blockers = [f"{r[0]} attempt {r[1]}: {r[2]} (source {r[3]}, loader {r[4]})" for r in cur.execute(
            "SELECT mapping_id,attempt,status,source_operation_state,loader_operation_state "
            "FROM bridge.object_attempts WITH (UPDLOCK,HOLDLOCK) WHERE bridge_run_id=? AND (status='INDETERMINATE' "
            "OR source_operation_state IN ('RUNNING','UNKNOWN') OR loader_operation_state IN ('RUNNING','UNKNOWN'))",
            a.bridge_run_id).fetchall()]
        need(not blockers, "External work may still be running; resolve it with resolve-attempt first: "
                           + "; ".join(blockers))
        marks = ",".join("?" * len(ABANDONABLE_RUNS))
        cur.execute("UPDATE bridge.runs SET status='ABANDONED',orchestrator_token=NULL,updated_utc=SYSUTCDATETIME() "
                    f"WHERE bridge_run_id=? AND status IN ({marks}) AND (orchestrator_token IS NULL OR "
                    "heartbeat_utc IS NULL OR heartbeat_utc < DATEADD(minute, -?, SYSUTCDATETIME()))",
                    a.bridge_run_id, *ABANDONABLE_RUNS, takeover)
        need(cur.rowcount == 1, f"Run {a.bridge_run_id} holds a live orchestrator lease; stop that process or wait "
                                f"{takeover} minutes after its last heartbeat")
        cur.execute("UPDATE bridge.object_attempts SET status='ABANDONED',updated_utc=SYSUTCDATETIME(),"
                    "source_operation_state=CASE WHEN source_operation_state='PENDING' THEN 'NOT_STARTED' "
                    "ELSE source_operation_state END "
                    "WHERE bridge_run_id=? AND status IN ('EXTRACTING','EXTRACTED','LOADING','READY')",
                    a.bridge_run_id)
        cur.execute("INSERT bridge.recovery_events(action,bridge_run_id,actor,reason) VALUES ('ABANDON_RUN',?,?,?)",
                    a.bridge_run_id, a.actor, a.reason)
        conn.commit()


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="action", required=True)
    attempt = sub.add_parser("resolve-attempt")
    attempt.add_argument("--bridge-run-id", required=True); attempt.add_argument("--mapping-id", required=True)
    attempt.add_argument("--attempt", required=True, type=int)
    resolve_pub = sub.add_parser("resolve-publication")
    resolve_pub.add_argument("--bridge-run-id", required=True); resolve_pub.add_argument("--target-key", required=True)
    abandon_pub = sub.add_parser("abandon-publication")
    abandon_pub.add_argument("--bridge-run-id", required=True); abandon_pub.add_argument("--target-key", required=True)
    abandon_pub.add_argument("--config", required=True)
    abandon_publishing_parser = sub.add_parser("abandon-publishing-run")
    abandon_publishing_parser.add_argument("--bridge-run-id", required=True)
    abandon_publishing_parser.add_argument("--config", required=True)
    for command in (attempt, resolve_pub, abandon_pub, abandon_publishing_parser):
        command.add_argument("--evidence", required=True)
    run = sub.add_parser("abandon-run")
    run.add_argument("--bridge-run-id", required=True); run.add_argument("--config", required=True)
    for command in (attempt, resolve_pub, abandon_pub, abandon_publishing_parser, run):
        command.add_argument("--actor", required=True); command.add_argument("--reason", required=True)
    a = p.parse_args()
    need(len(a.reason) <= 1000, "Reason must be at most 1000 characters")
    {"resolve-attempt": resolve_attempt, "resolve-publication": resolve_publication,
     "abandon-publication": abandon_publication, "abandon-publishing-run": abandon_publishing_run,
     "abandon-run": abandon_run}[a.action](a)
    print(json.dumps({"action": a.action, "bridge_run_id": a.bridge_run_id, "status": "RECORDED"}))


if __name__ == "__main__":
    main()
