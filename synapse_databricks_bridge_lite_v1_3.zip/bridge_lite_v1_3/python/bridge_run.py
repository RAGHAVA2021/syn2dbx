"""Extract the audited Synapse objects with CETAS and load them into Delta candidate tables.

Step N3 of the nightly flow (see SCRIPT_GUIDE.md). Run it after the daily refresh and
upstream_audit.py have finished. The run is resumable with --resume: READY attempts are
kept, EXTRACTED/LOADING attempts are reloaded from their retained Parquet, and FAILED
extractions get a fresh attempt path. Every control write is conditional on an
orchestrator lease token, so a superseded process cannot change state after another
process has taken the run over.

Source consistency relies on scheduling: the daily refresh must not run while this
script reads Synapse (see DESIGN.md). As a backstop, a read is only accepted while the
audited refresh is still the newest one recorded in bridge_meta.upstream_run.
"""
import argparse
import hashlib
import json
import os
import re
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed, wait, FIRST_COMPLETED
from contextlib import contextmanager
from pathlib import Path


ID = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
KEY = re.compile(r"^[A-Za-z0-9_\-]{1,128}$")
BRIDGE_RUN_ID = re.compile(r"^[A-Za-z0-9_\-]{1,124}$")  # rel_ prefix must fit nvarchar(128)
METADATA_COLUMNS = ("release_id", "mapping_object_id", "bridge_run_id", "upstream_run_id",
                    "upstream_sequence", "business_date", "load_attempt")
RESERVED = set(METADATA_COLUMNS)
STAGE_PREFIX = "bridge/parquet-stage"
MANIFEST_PREFIX = STAGE_PREFIX + "/_manifests"
MAX_MANIFEST_BYTES = 8 * 1024 * 1024
JOB_TIMEOUT_SECONDS = 7200          # Databricks job and CETAS statement limit
CANCEL_WAIT_SECONDS = 900           # how long to wait for a cancelled run to become terminal
MIN_TAKEOVER_MINUTES = (JOB_TIMEOUT_SECONDS + CANCEL_WAIT_SECONDS + 59) // 60
RESUMABLE_EXTRACT_STATES = ("EXTRACTING", "EXTRACTED", "LOADING", "FAILED")
# Runs in these states are finished; any other run blocks a new run for the same upstream refresh.
FINISHED_RUN_STATES = ("PUBLISHED", "PARTIALLY_PUBLISHED", "PUBLICATION_ABANDONED", "ABANDONED")
REQUIRED_PROPERTIES = ("delta.deletedFileRetentionDuration", "delta.logRetentionDuration",
                       "delta.setTransactionRetentionDuration")
RUNTIME_KEYS = ("loader_job_id", "publisher_job_id", "retention_job_id", "max_extraction_workers",
                "extraction_class_limits", "max_loader_workers", "max_publisher_workers",
                "heartbeat_seconds", "retention_days_published", "retention_days_unpublished",
                "max_loader_retries_per_attempt")
# Settings of features this package does not implement. A config that still carries them was
# written for a different package; refuse it instead of silently ignoring part of it.
UNSUPPORTED_TOP = ("source_set_id", "control_catalog", "control_schema", "pointer_job_id",
                   "synapse_pipeline", "minimum_fence_margin_minutes")
UNSUPPORTED_MAPPING = ("strategy", "method", "group_id", "mandatory", "group_contract_version",
                       "physical_schema", "physical_properties", "allow_empty")


class Indeterminate(RuntimeError):
    """An external operation may still be running; its outcome is unknown."""


class PhaseError(RuntimeError):
    def __init__(self, message, errors):
        super().__init__(message)
        self.errors = errors


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def ident(value):
    need(isinstance(value, str) and bool(ID.fullmatch(value)), f"Unsafe SQL identifier: {value!r}")
    return f"[{value}]"


def size_class(rows, columns, used_bytes, limits):
    if rows >= limits["large_rows"] or used_bytes >= limits["large_bytes"] or columns >= limits["large_columns"]:
        return "LARGE"
    if rows >= limits["medium_rows"] or used_bytes >= limits["medium_bytes"] or columns >= limits["medium_columns"]:
        return "MEDIUM"
    return "SMALL"


THRESHOLD_KEYS = ("medium_rows", "large_rows", "medium_bytes", "large_bytes", "medium_columns", "large_columns")


def valid_thresholds(t):
    return (all(type(t.get(k)) is int and t[k] > 0 for k in THRESHOLD_KEYS)
            and t["medium_rows"] < t["large_rows"] and t["medium_bytes"] < t["large_bytes"]
            and t["medium_columns"] < t["large_columns"])


def valid_target_type(value):
    if value in ("string", "boolean", "int", "bigint", "double", "date", "timestamp", "timestamp_ntz"):
        return True
    match = re.fullmatch(r"decimal\((\d{1,2}),(\d{1,2})\)", str(value))
    return bool(match and 1 <= int(match.group(1)) <= 38 and 0 <= int(match.group(2)) <= int(match.group(1)))


def staging_parts(root):
    match = re.fullmatch(r"abfss://([^@/]+)@([A-Za-z0-9]+)\.dfs\.core\.windows\.net", str(root).rstrip("/"))
    need(match, "staging_abfss_root must be the container-level ADLS URI")
    return match.groups()


def candidate_table_name(mapping_id, run_id, attempt):
    """Collision-free candidate name: '-' and '_' IDs never map to the same table."""
    digest = hashlib.sha256(f"{mapping_id}\x1f{run_id}".encode()).hexdigest()[:16]
    readable = re.sub(r"[^A-Za-z0-9_]", "_", mapping_id)[:80]
    return f"candidate_{readable}_{digest}_a{int(attempt)}"


def attempt_relative_path(business_date, run_id, mapping_id, attempt):
    return f"{STAGE_PREFIX}/{business_date}/{run_id}/{mapping_id}/attempt-{int(attempt):03d}/"


def consumer_target(m):
    return ".".join(m[k] for k in ("target_catalog", "target_schema", "target_table"))


def delta_target(m, run_id, attempt):
    """Unquoted three-part candidate name the loader writes; stored in object_attempts.delta_target."""
    return f"{m['target_catalog']}.{m['candidate_schema']}.{candidate_table_name(m['mapping_id'], run_id, attempt)}"


def target_key(m):
    return "table:" + consumer_target(m)


def config(path):
    doc = json.loads(Path(path).read_text())
    need(isinstance(doc.get("inventory_version"), str) and bool(KEY.fullmatch(doc["inventory_version"])),
         "inventory_version must be 1..128 letters, digits, '_' or '-'")
    mappings = doc.get("mappings")
    need(mappings, "At least one mapping is required")
    unsupported = [k for k in UNSUPPORTED_TOP if k in doc] + sorted(
        {k for m in mappings for k in UNSUPPORTED_MAPPING if k in m})
    need(not unsupported, f"Unsupported config field(s) {unsupported}: this package publishes every mapping as an "
                          "independent CETAS table replacement. Regenerate the config with generate_mappings.py")
    for name, default, low, high in (("max_extraction_workers", 4, 1, 32), ("max_loader_workers", 1, 1, 32),
                                     ("max_publisher_workers", 1, 1, 32), ("max_attempts", 3, 1, 9),
                                     ("takeover_after_minutes", 150, MIN_TAKEOVER_MINUTES, 1440),
                                     ("heartbeat_seconds", 60, 10, 600),
                                     ("retention_days_published", 7, 0, 3650),
                                     ("retention_days_unpublished", 30, 0, 3650),
                                     ("max_loader_retries_per_attempt", 3, 1, 10)):
        n = doc.get(name, default)
        need(type(n) is int and low <= n <= high, f"Invalid {name}: must be an integer {low}..{high}")
    need(doc.get("heartbeat_seconds", 60) * 3 <= doc.get("takeover_after_minutes", 150) * 60,
         "takeover_after_minutes must cover at least three missed heartbeats")
    need(type(doc.get("allow_partial_release", False)) is bool, "allow_partial_release must be boolean")
    class_limits = doc.get("extraction_class_limits", {"SMALL": 4, "MEDIUM": 2, "LARGE": 1})
    need(set(class_limits) == {"SMALL", "MEDIUM", "LARGE"} and
         all(type(x) is int and 1 <= x <= 32 for x in class_limits.values()),
         "Invalid extraction_class_limits")
    thresholds = doc.get("profile_thresholds", {})
    if thresholds:
        need(valid_thresholds(thresholds), "Invalid profile_thresholds")
    ids, targets, sources, candidate_schemas = set(), set(), set(), set()
    for m in mappings:
        need(isinstance(m.get("mapping_id"), str) and bool(KEY.fullmatch(m["mapping_id"])),
             f"Invalid mapping_id: {m.get('mapping_id')}")
        need(isinstance(m.get("source_schema_version"), str) and 0 < len(m["source_schema_version"]) <= 128,
             f"Missing/invalid source_schema_version: {m['mapping_id']}")
        if "size_class" in m:
            need(m["size_class"] in class_limits, f"Unknown size_class: {m['mapping_id']}")
        if doc.get("require_profiles"):
            prof = m.get("source_profile", {})
            need(m.get("size_class") in class_limits and
                 prof.get("source_schema_version") == m["source_schema_version"] and
                 type(prof.get("estimated_rows")) is int and prof["estimated_rows"] >= 0 and
                 type(prof.get("physical_used_bytes")) is int and prof["physical_used_bytes"] >= 0 and
                 prof.get("mapped_column_count") == len(m["columns"]) and
                 type(prof.get("physical_column_count")) is int and prof["physical_column_count"] > 0 and
                 bool(prof.get("profiled_at_utc")),
                 f"Missing/stale profile: {m['mapping_id']}")
            need(bool(thresholds) and m["size_class"] == size_class(
                 prof["estimated_rows"], prof["physical_column_count"], prof["physical_used_bytes"], thresholds),
                 f"Profile class differs from thresholds: {m['mapping_id']}")
        need(m["mapping_id"] not in ids, f"Duplicate mapping: {m['mapping_id']}")
        ids.add(m["mapping_id"])
        for k in ("source_schema", "source_view", "target_catalog", "target_schema", "target_table",
                  "candidate_schema"):
            ident(m.get(k))
        src = (m["source_schema"].lower(), m["source_view"].lower())
        tgt = tuple(m[k].lower() for k in ("target_catalog", "target_schema", "target_table"))
        need(src not in sources and tgt not in targets, f"Duplicate source or target: {m['mapping_id']}")
        sources.add(src); targets.add(tgt)
        candidate_schemas.add((m["target_catalog"].lower(), m["candidate_schema"].lower()))
        need(("materialised_schema" in m) == ("materialised_table" in m),
             "materialised_schema and materialised_table must be given together")
        for k in ("materialised_schema", "materialised_table"):
            if k in m:
                ident(m[k])
        columns = m.get("columns")
        need(columns and len({c["target"].lower() for c in columns}) == len(columns), "Duplicate/missing columns")
        need(not ({c["target"].lower() for c in columns} & RESERVED), "Target column clashes with bridge metadata")
        props = m.get("consumer_properties")
        need(isinstance(props, dict), f"Missing consumer_properties: {m['mapping_id']}")
        for required in REQUIRED_PROPERTIES:
            need(required in props, f"Missing governed property: {required}")
        for k, v in props.items():
            need(isinstance(v, str) and "'" not in v and bool(re.fullmatch(r"[A-Za-z][A-Za-z0-9._]*", k)),
                 f"Delta property values must be quote-free strings exactly as Delta reports them: {k}")
        for c in columns:
            ident(c["source"]); ident(c["target"])
            need(isinstance(c.get("source_spark_type"), str) and c["source_spark_type"].strip(),
                 f"Missing source_spark_type: {m['mapping_id']}.{c.get('target', '?')}")
            need(c.get("conversion", "DIRECT") in ("DIRECT", "GUID_TEXT"), "Unsupported source conversion")
            need(valid_target_type(c["target_type"]), "Unsupported target type")
    for cat, sch, tab in targets:
        # Candidates are generated as candidate_<mapping>_<digest>_a<n> in candidate_schema.
        need(not ((cat, sch) in candidate_schemas and tab.startswith("candidate_")),
             f"{cat}.{sch}.{tab} uses the name space reserved for generated candidate tables")
    return doc


def config_sha256(cfg):
    """Pin the data contract while permitting operational fixes during recovery."""
    pinned = {k: v for k, v in cfg.items() if k not in RUNTIME_KEYS}
    canonical = json.dumps(pinned, sort_keys=True, separators=(",", ":"), ensure_ascii=True)
    return hashlib.sha256(canonical.encode("ascii")).hexdigest()


def require_jobs(cfg):
    for key in ("loader_job_id", "publisher_job_id"):
        need(type(cfg.get(key)) is int and cfg[key] > 0, f"{key} is not configured")


@contextmanager
def db(var, autocommit=False):
    """Open, yield and always close a connection. Nothing is committed implicitly."""
    import pyodbc
    # Supply complete ODBC connection strings through the secret store at runtime.
    # Control and CETAS identities must differ. No connection strings are logged.
    conn = pyodbc.connect(os.environ[var], autocommit=autocommit, timeout=45)
    try:
        yield conn
    except BaseException:
        if not autocommit:
            try:
                conn.rollback()
            except Exception:
                pass
        raise
    finally:
        conn.close()


def fetchone(conn, sql, *params):
    return conn.cursor().execute(sql, *params).fetchone()


# Every orchestrator write carries this predicate: a process whose lease was taken
# over can no longer change run or attempt state.
OWNED = "EXISTS (SELECT 1 FROM bridge.runs r WHERE r.bridge_run_id=? AND r.orchestrator_token=?)"


def claim_run(conn, run_id, allowed, next_status, takeover_minutes):
    """Take the run lease. Succeeds when nobody holds it or its heartbeat is stale."""
    token = uuid.uuid4().hex
    marks = ",".join("?" * len(allowed))
    cur = conn.cursor()
    cur.execute("UPDATE bridge.runs SET status=?, orchestrator_token=?, heartbeat_utc=SYSUTCDATETIME(), "
                "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? "
                f"AND status IN ({marks}) AND (orchestrator_token IS NULL OR heartbeat_utc IS NULL "
                "OR heartbeat_utc < DATEADD(minute, -?, SYSUTCDATETIME()))",
                next_status, token, run_id, *allowed, takeover_minutes)
    need(cur.rowcount == 1, "Run cannot be claimed: wrong status, or another orchestrator holds a live lease "
                            f"(wait {takeover_minutes} minutes after its last heartbeat)")
    conn.commit()
    return token


def update_run(conn, run_id, token, prior, next_state, release_lease=False):
    cur = conn.cursor()
    cur.execute("UPDATE bridge.runs SET status=?, updated_utc=SYSUTCDATETIME(), "
                "orchestrator_token=CASE WHEN ?=1 THEN NULL ELSE orchestrator_token END "
                "WHERE bridge_run_id=? AND status=? AND orchestrator_token=?",
                next_state, 1 if release_lease else 0, run_id, prior, token)
    need(cur.rowcount == 1, f"Run state or lease changed concurrently: {prior} -> {next_state}")
    conn.commit()


def is_indeterminate(exc):
    if isinstance(exc, (Indeterminate, KeyboardInterrupt, SystemExit)):
        return True
    return any(is_indeterminate(e) for e in getattr(exc, "errors", []))


class RunLease:
    """Background heartbeat; `check()` stops new external work once the lease is lost."""

    def __init__(self, run_id, token, seconds):
        self.run_id, self.token, self.seconds = run_id, token, seconds
        self.lost = False
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._beat, daemon=True)

    def __enter__(self):
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        self._thread.join(timeout=60)

    def _beat(self):
        misses = 0
        while not self._stop.wait(self.seconds):
            try:
                with db("BRIDGE_CONTROL_ODBC") as conn:
                    cur = conn.cursor()
                    cur.execute("UPDATE bridge.runs SET heartbeat_utc=SYSUTCDATETIME() "
                                "WHERE bridge_run_id=? AND orchestrator_token=?", self.run_id, self.token)
                    owned = cur.rowcount == 1
                    conn.commit()
                if not owned:
                    self.lost = True
                    return
                misses = 0
            except Exception as exc:
                misses += 1
                print(f"WARNING heartbeat failed ({misses}/3): {exc}", file=sys.stderr)
                if misses >= 3:
                    self.lost = True
                    return

    def check(self):
        need(not self.lost, "Run lease lost (taken over or heartbeat failing); stopping new work")


def container_client(root):
    from azure.identity import DefaultAzureCredential
    from azure.storage.blob import BlobServiceClient
    container, account = staging_parts(root)
    service = BlobServiceClient(f"https://{account}.blob.core.windows.net", DefaultAzureCredential())
    return service.get_container_client(container)


def require_empty_adls(root, relative):
    found = next(iter(container_client(root).list_blobs(name_starts_with=relative)), None)
    need(found is None, f"Attempt prefix is not empty: {relative}")


def write_manifest(cfg, run_id, payload):
    """Store a job payload as an immutable, hash-checked file under the staging location.

    Notebook parameters are limited to ~10 KB; wide tables exceed that.
    """
    data = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True, default=str).encode("ascii")
    need(len(data) <= MAX_MANIFEST_BYTES, "Job manifest exceeds 8 MB")
    relative = f"{MANIFEST_PREFIX}/{run_id}/{uuid.uuid4().hex}.json"
    container_client(cfg["staging_abfss_root"]).upload_blob(relative, data, overwrite=False)
    return cfg["staging_abfss_root"].rstrip("/") + "/" + relative, hashlib.sha256(data).hexdigest()


TERMINAL_JOB_STATES = ("TERMINATED", "SKIPPED", "INTERNAL_ERROR")


def notebook_job(cfg, job_id, payload, run_id, started_callback=None, terminal_callback=None):
    from databricks.sdk import WorkspaceClient
    need(int(job_id) > 0, "Databricks job ID is not configured")
    path, digest = write_manifest(cfg, run_id, payload)
    client = WorkspaceClient()
    # One token per invocation. Databricks returns the EXISTING run for a known token whatever its
    # state, so a token derived only from the payload would make every retry adopt the first
    # (possibly failed) run. The token is persisted before submission. If the submission outcome is
    # unknown, calling run-now again with the stored token returns the existing run if one was
    # created; if none was, that call STARTS it. It is not a read-only probe: check the job's run
    # list first, and re-submit with the token only when a run is actually wanted.
    idempotency_token = "bridge_" + hashlib.sha256(
        (json.dumps(payload, sort_keys=True, default=str) + "\x1f" + uuid.uuid4().hex)
        .encode("utf-8")).hexdigest()[:48]
    if started_callback:
        started_callback("token:" + idempotency_token)
    try:
        # notebook_params requires the job to define notebook widgets (task base parameters).
        started = client.jobs.run_now(job_id=int(job_id),
                                      notebook_params={"manifest_path": path, "manifest_sha256": digest},
                                      idempotency_token=idempotency_token)
    except Exception as exc:
        raise Indeterminate("Databricks submission outcome is unknown; inspect Jobs before recovery") from exc
    dbx_run = started.run_id
    if dbx_run is None:
        raise Indeterminate(f"Databricks accepted idempotency token {idempotency_token} but returned no run ID")
    try:
        if started_callback:
            started_callback(str(dbx_run))
    except Exception as exc:
        raise Indeterminate(f"Databricks run {dbx_run} started but its ID could not be persisted") from exc

    def terminal():
        run = client.jobs.get_run(run_id=dbx_run)
        state = run.state
        done = bool(state and state.life_cycle_state and state.life_cycle_state.value in TERMINAL_JOB_STATES)
        return done, run, state

    deadline = time.monotonic() + JOB_TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        try:
            done, run, state = terminal()
        except Exception as exc:
            raise Indeterminate(f"Databricks run {dbx_run} status is unknown after polling failed") from exc
        if done:
            if not (state.result_state and state.result_state.value == "SUCCESS"):
                if terminal_callback:
                    terminal_callback(str(dbx_run), "FAILED")
                raise RuntimeError(f"Job failed: {dbx_run}: {state}")
            task_id = run.tasks[0].run_id if run.tasks else dbx_run
            try:
                output = client.jobs.get_run_output(run_id=task_id)
                value = output.notebook_output.result if output.notebook_output else None
                need(value, f"No notebook output from {task_id}")
                result = json.loads(value)
                if terminal_callback:
                    terminal_callback(str(dbx_run), "SUCCEEDED")
                return result
            except Exception as exc:
                raise Indeterminate(f"Databricks run {dbx_run} terminated but its result is unknown") from exc
        time.sleep(10)
    # Cancel so the run cannot commit later while a resumed orchestrator acts.
    try:
        client.jobs.cancel_run(run_id=dbx_run)
    except Exception as exc:
        raise Indeterminate(f"Databricks run {dbx_run} timed out and cancellation was not submitted") from exc
    stop = time.monotonic() + CANCEL_WAIT_SECONDS
    while time.monotonic() < stop:
        try:
            stopped = terminal()[0]
        except Exception as exc:
            raise Indeterminate(f"Databricks run {dbx_run} cancellation outcome is unknown") from exc
        if stopped:
            if terminal_callback:
                terminal_callback(str(dbx_run), "CANCELLED")
            raise RuntimeError(f"Databricks run {dbx_run} timed out and was cancelled; it may have committed "
                               "before cancellation, which --resume reconciles")
        time.sleep(10)
    raise Indeterminate(f"Databricks run {dbx_run} timed out and did not stop after cancel; inspect it")


def projection(m):
    result = []
    for c in m["columns"]:
        src = ident(c["source"])
        expr = f"CONVERT(varchar(36), {src})" if c.get("conversion") == "GUID_TEXT" else src
        result.append(f"{expr} AS {ident(c['target'])}")
    return ", ".join(result)


# SQLSTATE classes that the server returns for a statement it has finished rejecting or
# rolling back (syntax/permission, data, constraint, transaction rollback, ...). Anything
# else - connection loss (08xxx), query timeout (HYT00/HYT01), cancel (HY008), a generic
# driver error (HY000), an interrupt or a non-ODBC exception - leaves the outcome unknown.
TERMINAL_SQLSTATE_CLASSES = ("21", "22", "23", "24", "25", "28", "3D", "3F", "40", "42", "44")


def cetas_error_is_terminal(exc):
    if not isinstance(exc, Exception) or not type(exc).__module__.startswith("pyodbc"):
        return False
    state = exc.args[0] if exc.args and isinstance(exc.args[0], str) else ""
    return len(state) == 5 and state[:2].upper() in TERMINAL_SQLSTATE_CLASSES


def cetas(m, relative_path, started_callback=None, terminal_callback=None):
    name = "x_" + uuid.uuid4().hex[:24]
    if started_callback:
        started_callback(name)
    source = f"{ident(m['source_schema'])}.{ident(m['source_view'])}"
    statement = (f"CREATE EXTERNAL TABLE bridge_meta.{ident(name)} WITH "
                 f"(LOCATION = '{relative_path}', DATA_SOURCE = bridge_stage, FILE_FORMAT = bridge_parquet) "
                 f"AS SELECT {projection(m)} FROM {source}")
    drop = f"IF OBJECT_ID(N'bridge_meta.{name}') IS NOT NULL DROP EXTERNAL TABLE bridge_meta.{ident(name)}"
    with db("BRIDGE_CETAS_ODBC", autocommit=True) as conn:
        conn.timeout = JOB_TIMEOUT_SECONDS

        def cleanup():
            # Dropping metadata never deletes the Parquet files. A cleanup failure is
            # reported but must never replace the original CETAS error.
            try:
                conn.cursor().execute(drop)
            except Exception as exc:
                print(f"WARNING CETAS metadata bridge_meta.{name} was not dropped: {exc}", file=sys.stderr)

        try:
            conn.cursor().execute(statement)
        except BaseException as exc:
            cleanup()
            if cetas_error_is_terminal(exc):
                # The server returned an error for the statement: it is not still running.
                if terminal_callback:
                    terminal_callback(name, "FAILED")
                raise RuntimeError(f"CETAS operation {name} failed: {exc}") from exc
            raise Indeterminate(f"CETAS operation {name} outcome is unknown; inspect Synapse requests and ADLS") from exc
        cleanup()
    if terminal_callback:
        terminal_callback(name, "SUCCEEDED")
    return name


def require_current_upstream(syn, sequence):
    """The audited refresh must still be the newest one recorded.

    A newer audited refresh means the source tables no longer hold the rows that were counted
    for this run, so reading them now would mix two days. This does not detect a refresh that is
    still in progress; the schedule must prevent that (DESIGN.md).
    """
    latest = fetchone(syn, "SELECT MAX(upstream_sequence) FROM bridge_meta.upstream_run WHERE status='COMPLETE'")
    newest = None if not latest or latest[0] is None else int(latest[0])
    need(newest == int(sequence),
         f"A newer refresh (sequence {newest}) has been audited since this run's refresh (sequence {sequence}); "
         "its source data is gone. Abandon this run (recovery.py abandon-run) and start a new one")


def build_item(cfg, ctx, m, attempt):
    relative = attempt_relative_path(ctx["business_date"], ctx["run_id"], m["mapping_id"], attempt)
    return {**m, "bridge_run_id": ctx["run_id"], "release_id": ctx["release"],
            "upstream_run_id": ctx["upstream_run_id"], "upstream_sequence": ctx["sequence"],
            "business_date": ctx["business_date"], "source_rows": ctx["rows"][m["mapping_id"]],
            "leaf_path": cfg["staging_abfss_root"].rstrip("/") + "/" + relative,
            "relative_path": relative, "attempt": attempt, "delta_write_sequence": ctx["sequence"],
            "candidate_table": candidate_table_name(m["mapping_id"], ctx["run_id"], attempt),
            "inventory_version": cfg["inventory_version"]}


def extract_one(cfg, ctx, lease, m, attempt):
    lease.check()
    run_id, token, mid = ctx["run_id"], ctx["token"], m["mapping_id"]
    item = build_item(cfg, ctx, m, attempt)
    with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
        require_current_upstream(syn, ctx["sequence"])
    # Short-lived control connections: extraction can take hours.
    with db("BRIDGE_CONTROL_ODBC") as control:
        require_empty_adls(cfg["staging_abfss_root"], item["relative_path"])
        cur = control.cursor()
        cur.execute("INSERT bridge.object_attempts(bridge_run_id,mapping_id,attempt,status,leaf_path,"
                    "source_rows,delta_target,target_key,consumer_target,source_operation_state,updated_utc) "
                    "SELECT ?,?,?,'EXTRACTING',?,?,?,?,?,'PENDING',SYSUTCDATETIME() WHERE " + OWNED,
                    run_id, mid, attempt, item["leaf_path"], item["source_rows"],
                    delta_target(m, run_id, attempt), target_key(m), consumer_target(m), run_id, token)
        need(cur.rowcount == 1, "Run lease lost before extraction")
        control.commit()
    if item["source_rows"] == 0:
        # CETAS may produce no readable Parquet files for an empty relation. The
        # audited zero rows and scheduler exclusion are the source contract here.
        with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
            require_current_upstream(syn, ctx["sequence"])
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            cur.execute("UPDATE bridge.object_attempts SET status='EXTRACTED',"
                        "source_operation_state='NOT_STARTED',updated_utc=SYSUTCDATETIME() "
                        "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                        "AND status='EXTRACTING' AND source_operation_state='PENDING' AND " + OWNED,
                        run_id, mid, attempt, run_id, token)
            need(cur.rowcount == 1, "Empty extraction attempt or lease changed concurrently")
            control.commit()
        return item
    try:
        def source_started(external_id):
            with db("BRIDGE_CONTROL_ODBC") as control:
                cur = control.cursor()
                cur.execute("UPDATE bridge.object_attempts SET source_request_id=?,source_operation_state='RUNNING',"
                            "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND "
                            + OWNED, external_id, run_id, mid, attempt, run_id, token)
                need(cur.rowcount == 1, "Could not persist external source operation ID")
                control.commit()

        def source_terminal(external_id, state):
            with db("BRIDGE_CONTROL_ODBC") as control:
                cur = control.cursor()
                cur.execute("UPDATE bridge.object_attempts SET source_operation_state=?,updated_utc=SYSUTCDATETIME() "
                            "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND source_request_id=? AND " + OWNED,
                            state, run_id, mid, attempt, external_id, run_id, token)
                need(cur.rowcount == 1, "Could not persist terminal source operation state")
                control.commit()

        request_id = cetas(m, item["relative_path"], source_started, source_terminal)
        with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
            # Still the newest refresh when the read finished; otherwise the files may mix two days.
            require_current_upstream(syn, ctx["sequence"])
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            cur.execute("UPDATE bridge.object_attempts SET status='EXTRACTED',source_request_id=?,source_operation_state='SUCCEEDED',"
                        "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                        "AND status='EXTRACTING' AND " + OWNED,
                        request_id, run_id, mid, attempt, run_id, token)
            need(cur.rowcount == 1, "Extraction attempt or lease changed concurrently")
            control.commit()
    except BaseException as exc:
        unknown = is_indeterminate(exc)
        try:
            with db("BRIDGE_CONTROL_ODBC") as control:
                # A stored PENDING state proves nothing was submitted (cetas() records RUNNING
                # before it submits), so the attempt is FAILED / NOT_STARTED even after an
                # interrupt. A read already recorded SUCCEEDED keeps that state on an ordinary
                # failure: the attempt failed afterwards, not the read. An unknown outcome records
                # UNKNOWN so recovery.py resolve-attempt can resolve it with SOURCE evidence.
                control.cursor().execute(
                    "UPDATE bridge.object_attempts SET "
                    "status=CASE WHEN source_operation_state='PENDING' THEN 'FAILED' ELSE ? END,"
                    "source_operation_state=CASE WHEN source_operation_state='PENDING' THEN 'NOT_STARTED' "
                    "WHEN ?=0 AND source_operation_state='SUCCEEDED' THEN 'SUCCEEDED' ELSE ? END,"
                    "error_text=?,updated_utc=SYSUTCDATETIME() "
                    "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status='EXTRACTING' AND " + OWNED,
                    "INDETERMINATE" if unknown else "FAILED", 1 if unknown else 0, "UNKNOWN" if unknown else "FAILED",
                    f"{type(exc).__name__}: {exc}"[:2000], run_id, mid, attempt, run_id, token)
                control.commit()
        except Exception as record_error:
            print(f"WARNING could not record failure for {mid}: {record_error}", file=sys.stderr)
        raise
    return item


def load_one(cfg, ctx, lease, item):
    lease.check()
    run_id, token, mid, attempt = ctx["run_id"], ctx["token"], item["mapping_id"], item["attempt"]
    with db("BRIDGE_CONTROL_ODBC") as control:
        cur = control.cursor()
        cur.execute("UPDATE bridge.object_attempts SET status='LOADING',loader_attempts=loader_attempts+1,"
                    "updated_utc=SYSUTCDATETIME() "
                    "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status IN ('EXTRACTED','LOADING') AND "
                    "loader_attempts<? AND " + OWNED, run_id, mid, attempt,
                    cfg.get("max_loader_retries_per_attempt", 3), run_id, token)
        need(cur.rowcount == 1, f"Load state conflict: {mid}")
        control.commit()

    def loader_started(external_id):
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            cur.execute("UPDATE bridge.object_attempts SET loader_run_id=?,loader_operation_state='RUNNING',"
                        "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND "
                        + OWNED, external_id, run_id, mid, attempt, run_id, token)
            need(cur.rowcount == 1, "Could not persist Databricks loader run ID")
            control.commit()

    def loader_terminal(external_id, state):
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            cur.execute("UPDATE bridge.object_attempts SET loader_operation_state=?,updated_utc=SYSUTCDATETIME() "
                        "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND loader_run_id=? AND " + OWNED,
                        state, run_id, mid, attempt, external_id, run_id, token)
            need(cur.rowcount == 1, "Could not persist terminal loader state")
            control.commit()

    try:
        result = notebook_job(cfg, cfg["loader_job_id"], item, run_id, loader_started, loader_terminal)
    except BaseException as exc:
        unknown = is_indeterminate(exc)
        try:
            with db("BRIDGE_CONTROL_ODBC") as control:
                control.cursor().execute(
                    "UPDATE bridge.object_attempts SET status=?,loader_operation_state=?,error_text=?,"
                    "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                    "AND status='LOADING' AND " + OWNED,
                    "INDETERMINATE" if unknown else "EXTRACTED", "UNKNOWN" if unknown else "FAILED",
                    f"{type(exc).__name__}: {exc}"[:2000], run_id, mid, attempt, run_id, token)
                control.commit()
        except Exception as record_error:
            print(f"WARNING could not record loader failure for {mid}: {record_error}", file=sys.stderr)
        raise
    expected_target = delta_target(item, run_id, attempt)
    try:
        need(isinstance(result, dict), f"Loader returned no result object: {mid}")
        need(result.get("source_rows") == result.get("parquet_rows") == result.get("delta_rows")
             == item["source_rows"], f"Three-way count mismatch: {mid}")
        need(result.get("target") == expected_target,
             f"Loader wrote {result.get('target')}, expected {expected_target}")
    except RuntimeError as exc:
        # The loader finished, but its result contradicts the orchestrator's expectation. Reloading
        # the same Parquet cannot change that, so the attempt is FAILED with loader state REJECTED
        # and --resume re-extracts it as a new attempt, bounded by max_attempts.
        try:
            with db("BRIDGE_CONTROL_ODBC") as control:
                control.cursor().execute(
                    "UPDATE bridge.object_attempts SET status='FAILED',loader_operation_state='REJECTED',"
                    "error_text=?,updated_utc=SYSUTCDATETIME() "
                    "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status='LOADING' AND " + OWNED,
                    f"Loader result rejected: {exc}"[:2000], run_id, mid, attempt, run_id, token)
                control.commit()
        except Exception as record_error:
            print(f"WARNING could not record loader result error for {mid}: {record_error}", file=sys.stderr)
        raise
    with db("BRIDGE_CONTROL_ODBC") as control:
        cur = control.cursor()
        cur.execute("UPDATE bridge.object_attempts SET status='READY',parquet_rows=?,delta_rows=?,"
                    "loader_operation_state='SUCCEEDED',"
                    "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                    "AND status='LOADING' AND " + OWNED,
                    result["parquet_rows"], result["delta_rows"], run_id, mid, attempt, run_id, token)
        need(cur.rowcount == 1, f"Load state conflict: {mid}")
        control.commit()
    return result


LATEST_ATTEMPTS = ("SELECT a.mapping_id,a.attempt,a.status,a.leaf_path,a.source_rows,a.parquet_rows,a.delta_rows,"
                   "a.delta_target,a.source_operation_state,a.loader_operation_state,a.loader_attempts FROM bridge.object_attempts a "
                   "WHERE a.bridge_run_id=? AND a.attempt=(SELECT MAX(b.attempt) FROM bridge.object_attempts b "
                   "WHERE b.bridge_run_id=a.bridge_run_id AND b.mapping_id=a.mapping_id)")


def run_extractions(cfg, ctx, lease, work):
    """Bounded, class-limited extraction; largest objects first."""
    workers = cfg.get("max_extraction_workers", 4)
    limits = cfg.get("extraction_class_limits", {"SMALL": 4, "MEDIUM": 2, "LARGE": 1})
    pending = sorted(work, key=lambda w: w[0].get("source_profile", {}).get("physical_used_bytes", 0), reverse=True)
    objects, errors, active = [], [], {}
    by_class = {k: 0 for k in limits}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        while pending or active:
            while len(active) < workers and not lease.lost:
                pos = next((i for i, (m, _) in enumerate(pending)
                            if by_class[m.get("size_class", "MEDIUM")] < limits[m.get("size_class", "MEDIUM")]), None)
                if pos is None:
                    break
                m, attempt = pending.pop(pos)
                cls = m.get("size_class", "MEDIUM")
                active[pool.submit(extract_one, cfg, ctx, lease, m, attempt)] = cls
                by_class[cls] += 1
            if not active:
                if lease.lost:
                    errors.append(RuntimeError("Run lease lost; unscheduled extractions skipped"))
                    break
                raise RuntimeError("No extraction capacity for pending mappings")
            completed, _ = wait(active, return_when=FIRST_COMPLETED)
            for future in completed:
                by_class[active.pop(future)] -= 1
                try:
                    objects.append(future.result())
                except BaseException as exc:
                    errors.append(exc)
    if errors and (not cfg.get("allow_partial_release") or any(is_indeterminate(e) for e in errors)):
        raise PhaseError(f"{len(errors)} extraction(s) failed; first: {errors[0]}", errors)
    for e in errors:
        print(f"EXCLUDED extraction: {e}", file=sys.stderr)
    return objects


def run_loads(cfg, ctx, lease, items):
    errors = []
    with ThreadPoolExecutor(max_workers=cfg.get("max_loader_workers", 1)) as pool:
        futures = [pool.submit(load_one, cfg, ctx, lease, item) for item in items]
        for future in as_completed(futures):
            try:
                future.result()
            except BaseException as exc:
                errors.append(exc)
    if errors and (not cfg.get("allow_partial_release") or any(is_indeterminate(e) for e in errors)):
        raise PhaseError(f"{len(errors)} load(s) failed; first: {errors[0]}", errors)
    for e in errors:
        print(f"EXCLUDED load: {e}", file=sys.stderr)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--upstream-run-id", required=True,
                        help="The refresh recorded by upstream_audit.py; its sequence and business date are used")
    parser.add_argument("--bridge-run-id", required=True, help="New unique run ID. Reuse the same ID with --resume.")
    parser.add_argument("--resume", action="store_true",
                        help="Continue an existing FAILED run, or take over an interrupted one after its lease expires")
    args = parser.parse_args()
    cfg = config(args.config)
    require_jobs(cfg)
    staging_parts(cfg["staging_abfss_root"])
    need(bool(BRIDGE_RUN_ID.fullmatch(args.bridge_run_id)), "Unsafe bridge run ID (1..124 characters)")
    run_id = args.bridge_run_id
    release = "rel_" + run_id

    with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
        audit = fetchone(syn, "SELECT COUNT_BIG(*), MAX(upstream_sequence), MAX(business_date) "
                              "FROM bridge_meta.upstream_run WHERE upstream_run_id=? AND status='COMPLETE'",
                         args.upstream_run_id)
    need(audit and audit[0] == 1,
         f"Upstream run {args.upstream_run_id} is missing or duplicated: run upstream_audit.py after the refresh")
    ctx = {"run_id": run_id, "release": release, "upstream_run_id": args.upstream_run_id,
           "sequence": int(audit[1]), "business_date": str(audit[2]), "rows": {}}
    by_id = {m["mapping_id"]: m for m in cfg["mappings"]}

    with db("BRIDGE_CONTROL_ODBC") as control:
        existing = fetchone(control, "SELECT upstream_run_id,inventory_version,release_id,status,config_sha256 FROM bridge.runs "
                                     "WHERE bridge_run_id=?", run_id)
        if args.resume:
            need(existing, "No run to resume")
            need(tuple(existing[:3]) == (args.upstream_run_id, cfg["inventory_version"], release),
                 "Resume arguments/config differ from the stored run")
            need(existing[4] == config_sha256(cfg), "Reviewed config changed since this run started")
            need(existing[3] in RESUMABLE_EXTRACT_STATES,
                 f"Run status {existing[3]} is not resumable here (READY/PUBLISHING runs belong to publish_run.py)")
            latest = {r[0]: r for r in control.cursor().execute(LATEST_ATTEMPTS, run_id).fetchall()}
        else:
            need(not existing, "Run already exists: continue it with --resume, never rerun blindly")
            marks = ",".join("?" * len(FINISHED_RUN_STATES))
            other = fetchone(control, "SELECT bridge_run_id,status FROM bridge.runs WHERE upstream_run_id=? "
                                      f"AND status NOT IN ({marks})", args.upstream_run_id, *FINISHED_RUN_STATES)
            need(not other, f"Run {other and other[0]} ({other and other[1]}) already exists for upstream run "
                            f"{args.upstream_run_id}: resume or publish it, or abandon it (recovery.py abandon-run)")
            latest = {}
        need(set(latest) <= set(by_id), "Run has attempts for mappings outside this inventory")
        for m in cfg["mappings"]:
            key = target_key(m)
            state = fetchone(control, "SELECT high_water_sequence FROM bridge.target_state WHERE target_key=?", key)
            need(state, f"Target not seeded: {key} (run render_setup.py and apply azure_sql_seed.sql)")
            need(ctx["sequence"] > state[0], f"Target {key} already holds sequence {state[0]}; "
                                             f"this refresh ({ctx['sequence']}) is not newer")

        # Plan: which mappings extract (and with which attempt) and which only reload.
        to_extract, to_load_attempts, orphaned = [], [], []
        for m in cfg["mappings"]:
            row = latest.get(m["mapping_id"])
            if row is None:
                to_extract.append((m, 1))
            elif row[2] == "READY":
                continue
            elif row[2] == "EXTRACTING" and row[8] != "PENDING":
                # A previous orchestrator stopped while a source read was (or may have been)
                # submitted. Never infer that it stopped: route it through audited recovery.
                orphaned.append((m["mapping_id"], row[1], "SOURCE"))
            elif row[2] == "LOADING" and row[9] in ("RUNNING", "UNKNOWN"):
                orphaned.append((m["mapping_id"], row[1], "LOADER"))
            elif row[2] in ("EXTRACTED", "LOADING") and row[10] >= cfg.get("max_loader_retries_per_attempt", 3):
                need(row[1] < cfg.get("max_attempts", 3), f"{m['mapping_id']} reached max_attempts")
                to_extract.append((m, row[1] + 1))
            elif row[2] in ("EXTRACTED", "LOADING"):
                to_load_attempts.append((m, row[1], row[3]))
            elif row[2] == "INDETERMINATE":
                raise RuntimeError(f"{m['mapping_id']} has an indeterminate external operation; verify the stored "
                                   "external run ID and resolve it with recovery.py before --resume")
            else:
                need(row[1] < cfg.get("max_attempts", 3), f"{m['mapping_id']} reached max_attempts ({row[1]})")
                to_extract.append((m, row[1] + 1))

        if orphaned:
            # Only reachable with --resume (a new run has no attempts). Take the lease, record the
            # orphaned operations as INDETERMINATE and stop; recovery.py resolves each one against
            # terminal evidence for its stored external ID.
            token = claim_run(control, run_id, RESUMABLE_EXTRACT_STATES, "EXTRACTING",
                              cfg.get("takeover_after_minutes", 150))
            cur = control.cursor()
            for mid, attempt, phase in orphaned:
                state_col = "source_operation_state" if phase == "SOURCE" else "loader_operation_state"
                cur.execute(f"UPDATE bridge.object_attempts SET status='INDETERMINATE',{state_col}='UNKNOWN',"
                            "error_text='Orchestrator stopped while this operation was in flight',"
                            "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                            "AND status IN ('EXTRACTING','LOADING') AND " + OWNED,
                            run_id, mid, attempt, run_id, token)
                need(cur.rowcount == 1, f"Attempt changed concurrently: {mid}")
            cur.execute("UPDATE bridge.runs SET status='FAILED',updated_utc=SYSUTCDATETIME() "
                        "WHERE bridge_run_id=? AND orchestrator_token=?", run_id, token)
            control.commit()
            raise RuntimeError("In-flight operation(s) from a stopped orchestrator are now INDETERMINATE: "
                               + ", ".join(f"{mid} attempt {n} ({phase})" for mid, n, phase in orphaned)
                               + ". Verify each stored external ID is terminal, run recovery.py "
                               "resolve-attempt, then --resume")

    with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
        from source_metadata import schema_hash
        if to_extract:
            # Only a source read needs the source to be unchanged; reloading retained Parquet does not.
            require_current_upstream(syn, ctx["sequence"])
        extracting = {m["mapping_id"] for m, _ in to_extract}
        for m in cfg["mappings"]:
            r = fetchone(syn, "SELECT COUNT_BIG(*),MAX(status),MAX(row_count),MIN(row_count) "
                         "FROM bridge_meta.upstream_object WHERE upstream_run_id=? AND mapping_id=? "
                         "AND source_schema_version=?",
                         args.upstream_run_id, m["mapping_id"], m["source_schema_version"])
            need(r and r[0] == 1 and r[1] in ("COMPLETE", "EXCLUDED") and r[2] == r[3],
                 f"Missing/duplicate source audit: {m['mapping_id']}")
            if r[1] == "EXCLUDED":
                need(cfg.get("allow_partial_release", False) and m["mapping_id"] not in latest,
                     f"Previously loaded mapping became excluded: {m['mapping_id']}")
                continue
            if m["mapping_id"] in extracting:
                need(schema_hash(syn, m["source_schema"], m["source_view"]) == m["source_schema_version"],
                     f"Current source schema drift: {m['mapping_id']}")
            ctx["rows"][m["mapping_id"]] = int(r[2])
    to_extract = [(m, n) for m, n in to_extract if m["mapping_id"] in ctx["rows"]]

    takeover = cfg.get("takeover_after_minutes", 150)
    with db("BRIDGE_CONTROL_ODBC") as control:
        if args.resume:
            token = claim_run(control, run_id, RESUMABLE_EXTRACT_STATES, "EXTRACTING", takeover)
            ctx["token"] = token
            cur = control.cursor()
            for m, attempt in to_extract:
                if attempt > 1:
                    # Only an attempt whose source operation was never submitted can still be
                    # EXTRACTING here (PENDING); anything submitted went through recovery above.
                    cur.execute("UPDATE bridge.object_attempts SET status='SUPERSEDED',"
                                "source_operation_state='NOT_STARTED',updated_utc=SYSUTCDATETIME(),"
                                "error_text=COALESCE(error_text,'Interrupted before submission; superseded on resume') "
                                "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status='EXTRACTING' "
                                "AND source_operation_state='PENDING' AND "
                                + OWNED, run_id, m["mapping_id"], attempt - 1, run_id, token)
                    cur.execute("UPDATE bridge.object_attempts SET status='SUPERSEDED',"
                                "error_text='Loader retry limit reached; next extraction attempt',"
                                "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                                "AND status IN ('EXTRACTED','LOADING') AND loader_attempts>=? AND " + OWNED,
                                run_id, m["mapping_id"], attempt - 1,
                                cfg.get("max_loader_retries_per_attempt", 3), run_id, token)
            control.commit()
        else:
            token = uuid.uuid4().hex
            ctx["token"] = token
            control.cursor().execute(
                "INSERT bridge.runs(bridge_run_id,upstream_run_id,upstream_sequence,business_date,"
                "inventory_version,config_sha256,release_id,status,orchestrator_token,heartbeat_utc) "
                "VALUES (?,?,?,?,?,?,?,'EXTRACTING',?,SYSUTCDATETIME())", run_id, args.upstream_run_id,
                ctx["sequence"], ctx["business_date"], cfg["inventory_version"], config_sha256(cfg), release, token)
            control.commit()

    for m, attempt, leaf in to_load_attempts:
        need(leaf == build_item(cfg, ctx, m, attempt)["leaf_path"], f"Stored leaf path differs: {m['mapping_id']}")

    try:
        with RunLease(run_id, token, cfg.get("heartbeat_seconds", 60)) as lease:
            items = [build_item(cfg, ctx, m, attempt) for m, attempt, _ in to_load_attempts]
            items += run_extractions(cfg, ctx, lease, to_extract)
            with db("BRIDGE_CONTROL_ODBC") as control:
                update_run(control, run_id, token, "EXTRACTING", "EXTRACTED")
                update_run(control, run_id, token, "EXTRACTED", "LOADING")
            run_loads(cfg, ctx, lease, items)
            lease.check()
            with db("BRIDGE_CONTROL_ODBC") as control:
                rows = control.cursor().execute(LATEST_ATTEMPTS, run_id).fetchall()
                ready = {r[0] for r in rows if r[2] == "READY"}
                excluded = {m["mapping_id"] for m in cfg["mappings"]} - ready
                need(not excluded or cfg.get("allow_partial_release", False),
                     "Not every mapping reached READY")
                need(not any(r[2] == "INDETERMINATE" or r[8] in ("RUNNING", "UNKNOWN")
                             or r[9] in ("RUNNING", "UNKNOWN") for r in rows),
                     "Unresolved external operation prevents partial release")
                update_run(control, run_id, token, "LOADING", "READY", release_lease=True)
        print(json.dumps({"bridge_run_id": run_id, "release_id": release, "status": "READY",
                          "ready": sorted(ready), "excluded": sorted(excluded),
                          "next": "publish_run.py --bridge-run-id " + run_id}))
    except BaseException as exc:
        keep = is_indeterminate(exc)
        try:
            with db("BRIDGE_CONTROL_ODBC") as control:
                # Keep the lease if work may still be running, so a resume must wait for it to expire.
                control.cursor().execute(
                    "UPDATE bridge.runs SET status='FAILED',updated_utc=SYSUTCDATETIME(),"
                    "orchestrator_token=CASE WHEN ?=1 THEN orchestrator_token ELSE NULL END "
                    "WHERE bridge_run_id=? AND orchestrator_token=? "
                    "AND status IN ('EXTRACTING','EXTRACTED','LOADING')", 1 if keep else 0, run_id, token)
                control.commit()
        except Exception as record_error:
            print(f"WARNING could not mark run FAILED: {record_error}", file=sys.stderr)
        raise


if __name__ == "__main__":
    main()
