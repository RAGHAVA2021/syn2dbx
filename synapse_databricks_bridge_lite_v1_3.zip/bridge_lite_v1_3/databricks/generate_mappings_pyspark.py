# Databricks notebook source
"""Step I1 alternative (SCRIPT_GUIDE.md): one-time Synapse metadata discovery on Databricks classic or serverless compute.

Upload the complete bridge_lite_v1_3 folder as Workspace files. Configure the
settings below, including either a UC JDBC connection or a raw Synapse JDBC URL.
The generator writes JSON to a Unity Catalog volume, not local driver storage.
"""
import json
import re
import sys
from collections import defaultdict
from pathlib import Path

# COMMAND ----------
# Change these values. PACKAGE_DIR must point to the extracted Workspace folder.
PACKAGE_DIR = "/Workspace/Shared/bridge_lite_v1_3"
OUTPUT = "/Volumes/analytics/bridge_config/files/config.generated.json"
SOURCE_SCHEMA = "presentation"
SOURCE_KIND = "table"  # "table" or "view"
SOURCE_PREFIX = ""      # e.g. "v_" for selected views
TARGET_CATALOG = "analytics"
TARGET_SCHEMA = "gold"
INVENTORY_VERSION = "wave_001_v1"

# Option 1: reuse an existing Unity Catalog JDBC connection. This is a preview feature
# (check your runtime and workspace previews); the connection must point to the dedicated
# SQL pool database and include `query` in its externalOptionsAllowList.
UC_JDBC_CONNECTION = ""  # e.g. "synapse_metadata"

# Option 2: use a JDBC URL on a classic cluster and credentials from secret scope.
# Ignored when UC_JDBC_CONNECTION is set. Never put a password in the URL.
JDBC_URL = "jdbc:sqlserver://<workspace>.sql.azuresynapse.net:1433;databaseName=<dedicated-pool>;encrypt=true;trustServerCertificate=false"
SECRET_SCOPE = "bridge"
USER_SECRET_KEY = "synapse-metadata-user"
PASSWORD_SECRET_KEY = "synapse-metadata-password"

# COMMAND ----------
sys.path.insert(0, str(Path(PACKAGE_DIR) / "python"))
from generate_mappings import make_mapping
from source_metadata import ident

for value in (SOURCE_SCHEMA, TARGET_CATALOG, TARGET_SCHEMA):
    ident(value)
if SOURCE_PREFIX:
    ident(SOURCE_PREFIX)
if SOURCE_KIND not in ("table", "view"):
    raise ValueError("SOURCE_KIND must be table or view")
if not re.fullmatch(r"[A-Za-z0-9_\-]+", INVENTORY_VERSION):
    raise ValueError("Invalid inventory version")
output = Path(OUTPUT)
if not str(output).startswith("/Volumes/") or output.suffix != ".json":
    raise ValueError("Write the config to an existing Unity Catalog volume as a .json file")
if output.exists():
    raise FileExistsError(f"Refusing to overwrite approved inventory: {output}")

# Catalog SQL queries only; no data from the 1,000 tables is transferred.
kind = "U" if SOURCE_KIND == "table" else "V"
metadata_sql = f"""
SELECT o.name AS object_name, c.name AS column_name, c.column_id,
       t.name AS sql_type, c.max_length, c.precision, c.scale, c.is_nullable
FROM sys.objects AS o
JOIN sys.schemas AS s ON o.schema_id = s.schema_id
JOIN sys.columns AS c ON c.object_id = o.object_id
JOIN sys.types AS t ON c.user_type_id = t.user_type_id
WHERE s.name = '{SOURCE_SCHEMA}' AND o.type = '{kind}'
"""
reader = spark.read.format("jdbc").option("query", metadata_sql)
if UC_JDBC_CONNECTION:
    reader = reader.option("databricks.connection", UC_JDBC_CONNECTION)
else:
    if "<" in JDBC_URL or ">" in JDBC_URL:
        raise ValueError("Fill JDBC_URL with the dedicated SQL pool endpoint and database")
    reader = (reader.option("url", JDBC_URL)
              .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
              .option("user", dbutils.secrets.get(SECRET_SCOPE, USER_SECRET_KEY))
              .option("password", dbutils.secrets.get(SECRET_SCOPE, PASSWORD_SECRET_KEY)))

by_object = defaultdict(list)
for r in reader.load().collect():
    if SOURCE_PREFIX and not r.object_name.startswith(SOURCE_PREFIX):
        continue
    by_object[r.object_name].append([
        r.column_name, int(r.column_id), r.sql_type, int(r.max_length),
        int(r.precision), int(r.scale), bool(r.is_nullable)])
if not by_object:
    raise ValueError("No visible matching Synapse objects; check schema, permissions and connection")

template = json.loads((Path(PACKAGE_DIR) / "config.example.json").read_text())
base = template["mappings"][0]
template["inventory_version"] = INVENTORY_VERSION
generated, errors, target_names = [], [], set()
for name in sorted(by_object):
    rows = sorted(by_object[name], key=lambda row: row[1])
    try:
        mapping = make_mapping(base, SOURCE_SCHEMA, name, TARGET_CATALOG,
                               TARGET_SCHEMA, SOURCE_PREFIX, rows, SOURCE_KIND)
        target_key = mapping["target_table"].lower()
        if target_key in target_names:
            raise ValueError("Case-insensitive target name collision")
        target_names.add(target_key)
        generated.append(mapping)
    except (ValueError, RuntimeError, KeyError) as exc:
        errors.append({"schema": SOURCE_SCHEMA, "object": name, "reason": str(exc)})

report = output.with_suffix(".exceptions.json")
report.parent.mkdir(parents=True, exist_ok=True)
report.write_text(json.dumps({"selected_objects": len(by_object), "generated": len(generated),
                              "exceptions": errors}, indent=2) + "\n")
if errors:
    raise ValueError(f"{len(errors)} object(s) need review; see {report}. No config written.")

template["mappings"] = generated
output.write_text(json.dumps(template, indent=2) + "\n")
print(f"Generated {len(generated)} mappings: {output}. Review, then run render_setup.py.")
print(f"Exception report: {report}")
