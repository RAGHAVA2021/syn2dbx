# Databricks notebook source
"""Publisher Job (step N4 in SCRIPT_GUIDE.md), Run as the publication principal.

Parameters: manifest_path, manifest_sha256.
mode PUBLISH atomically replaces the consumer table from its validated candidate with
CREATE OR REPLACE TABLE. mode INSPECT only reports the consumer table's current release,
so publish_run.py --resume can reconcile a commit whose Azure SQL update was lost.
"""
import hashlib
import json
import re

MANIFEST = re.compile(r"abfss://[^/]+/bridge/parquet-stage/_manifests/[A-Za-z0-9_\-]+/[0-9a-f]{32}\.json")
METADATA_COLUMNS = ("release_id", "mapping_object_id", "bridge_run_id", "upstream_run_id",
                    "upstream_sequence", "business_date", "load_attempt")
REQUIRED_PROPERTIES = ("delta.deletedFileRetentionDuration", "delta.logRetentionDuration",
                       "delta.setTransactionRetentionDuration")

dbutils.widgets.text("manifest_path", "")
dbutils.widgets.text("manifest_sha256", "")


def read_manifest():
    path, expected = dbutils.widgets.get("manifest_path"), dbutils.widgets.get("manifest_sha256")
    if not MANIFEST.fullmatch(path) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError("Invalid manifest parameters")
    text = spark.read.option("wholetext", "true").text(path).first()[0]
    if hashlib.sha256(text.encode("utf-8")).hexdigest() != expected:
        raise ValueError("Manifest hash mismatch")
    return json.loads(text)


def quote(s):
    if not isinstance(s, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", s):
        raise ValueError("Unsafe identifier")
    return f"`{s}`"


def literal(s):
    if not re.fullmatch(r"[A-Za-z0-9_\-]+", str(s)):
        raise ValueError("Unsafe release, mapping or run ID")
    return f"'{s}'"


def table(c, s, t):
    return f"{quote(c)}.{quote(s)}.{quote(t)}"


def single(sql):
    result = spark.sql(sql).collect()
    if len(result) != 1:
        raise ValueError(f"Expected one row, found {len(result)}")
    return result[0]


def kv(k, v):
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9._]*", k) or not isinstance(v, str) or "'" in v:
        raise ValueError("Unsafe property")
    return f"'{k}'='{v}'"


p = read_manifest()
mode = p.get("mode")
if mode not in ("PUBLISH", "INSPECT"):
    raise ValueError("Unsupported mode")
m = p["mapping"]
release = literal(p["release_id"])
target = table(m["target_catalog"], m["target_schema"], m["target_table"])

if mode == "INSPECT":
    raw = f"{m['target_catalog']}.{m['target_schema']}.{m['target_table']}"
    if not spark.catalog.tableExists(raw):
        dbutils.notebook.exit(json.dumps({"exists": False, "release_ids": [], "rows": 0}))
    if "release_id" not in [c.lower() for c in spark.table(target).columns]:
        dbutils.notebook.exit(json.dumps({"exists": True, "release_ids": None, "rows": None}))
    found = spark.sql(f"SELECT release_id, count(*) n FROM {target} GROUP BY release_id LIMIT 10").collect()
    if not found:
        properties = {r.key: r.value for r in spark.sql(f"SHOW TBLPROPERTIES {target}").collect()}
        if properties.get("bridge.row_count") == "0" and properties.get("bridge.release_id"):
            dbutils.notebook.exit(json.dumps({"exists": True,
                                              "release_ids": [properties["bridge.release_id"]], "rows": 0}))
    dbutils.notebook.exit(json.dumps({"exists": True, "release_ids": sorted(r.release_id for r in found),
                                      "rows": sum(r.n for r in found)}))

candidate = table(m["target_catalog"], m["candidate_schema"], m["candidate_table"])
where = (f"release_id = {release} AND mapping_object_id = {literal(m['mapping_id'])} "
         f"AND load_attempt = {literal(m['attempt'])}")
count = single(f"SELECT count(*) n, count(DISTINCT upstream_run_id) u, min(upstream_run_id) r "
               f"FROM {candidate} WHERE {where}")
expected_rows = int(m["source_rows"])
if count.n != expected_rows or (expected_rows > 0 and (count.u != 1 or count.r != m["upstream_run_id"])):
    raise ValueError("Candidate is not ready or is not from this upstream refresh")
# Properties are explicit and restated on every replacement.
props = m["consumer_properties"]
missing = [k for k in REQUIRED_PROPERTIES if k not in props]
if missing:
    raise ValueError(f"Missing governed retention properties: {missing}")
properties = ", ".join(kv(k, v) for k, v in sorted({**props,
    "bridge.release_id": p["release_id"], "bridge.load_attempt": str(m["attempt"]),
    "bridge.row_count": str(expected_rows)}.items()))
columns = ", ".join(quote(c["target"]) for c in m["columns"])
metadata = ", ".join(quote(x) for x in METADATA_COLUMNS)
spark.sql(f"CREATE OR REPLACE TABLE {target} USING DELTA TBLPROPERTIES ({properties}) "
          f"AS SELECT {columns}, {metadata} FROM {candidate} WHERE {where}")
post = single(f"SELECT count(*) n, min(release_id) a, max(release_id) b FROM {target}")
if post.n != count.n or (post.n > 0 and (post.a != p["release_id"] or post.b != p["release_id"])):
    raise ValueError("Published table validation failed; freeze target and recover")
actual = {r.key: r.value for r in spark.sql(f"SHOW TBLPROPERTIES {target}").collect()}
drift = {k: (v, actual.get(k)) for k, v in props.items() if actual.get(k) != v}
if drift:
    raise ValueError(f"Governed table properties differ after REPLACE: {drift}")
dbutils.notebook.exit(json.dumps({"target": target, "release_id": p["release_id"], "rows": post.n}))
