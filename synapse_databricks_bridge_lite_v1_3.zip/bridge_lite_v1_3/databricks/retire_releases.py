# Databricks notebook source
"""Retention Job (step M1 in SCRIPT_GUIDE.md), Run as the retention principal.

Needs ownership or MANAGE on candidate tables and SELECT on consumer tables. Parameters:
manifest_path, manifest_sha256 (written by python/retire_releases.py --execute).
The consumer table is re-read here and always wins: a candidate whose attempt is what the
consumer table currently holds is never dropped, even if the Azure SQL plan was stale.
"""
import hashlib
import json
import re

NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
MANIFEST = re.compile(r"abfss://[^/]+/bridge/parquet-stage/_manifests/[A-Za-z0-9_\-]+/[0-9a-f]{32}\.json")

dbutils.widgets.text("manifest_path", "")
dbutils.widgets.text("manifest_sha256", "")


def read_manifest():
    path, expected = dbutils.widgets.get("manifest_path"), dbutils.widgets.get("manifest_sha256")
    if not MANIFEST.fullmatch(path) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError("Invalid manifest parameters")
    text = spark.read.option("wholetext", "true").text(path).first()[0]
    if hashlib.sha256(text.encode("utf-8")).hexdigest() != expected:
        raise ValueError("Manifest hash mismatch")
    return json.loads(text)


def q(s):
    if not isinstance(s, str) or not NAME.fullmatch(s):
        raise ValueError("Unsafe identifier")
    return f"`{s}`"


p = read_manifest()
dropped, skipped = [], []

for d in p["drop_tables"]:
    if not d["table"].startswith("candidate_"):
        raise ValueError(f"Refusing to drop a non-candidate table: {d['table']}")
    target_raw = f"{d['target']['catalog']}.{d['target']['schema']}.{d['target']['table']}"
    if spark.catalog.tableExists(target_raw):
        target = ".".join(q(d["target"][k]) for k in ("catalog", "schema", "table"))
        columns = [c.lower() for c in spark.table(target).columns]
        if "release_id" in columns and "load_attempt" in columns:
            live = spark.sql(f"SELECT DISTINCT release_id, load_attempt FROM {target} LIMIT 5").collect()
            if any(r.release_id == d["release_id"] and r.load_attempt == str(d["attempt"]) for r in live):
                skipped.append({"table": d["table"], "reason": "attempt is live in the consumer table"})
                continue
            if not live:
                props = {r.key: r.value for r in spark.sql(f"SHOW TBLPROPERTIES {target}").collect()}
                if props.get("bridge.release_id") == d["release_id"] and props.get("bridge.load_attempt") == str(d["attempt"]):
                    skipped.append({"table": d["table"], "reason": "empty attempt is live in the consumer table"})
                    continue
    spark.sql(f"DROP TABLE IF EXISTS {q(d['catalog'])}.{q(d['schema'])}.{q(d['table'])}")
    dropped.append({"run_id": d["run_id"], "mapping_id": d["mapping_id"], "attempt": d["attempt"]})

dbutils.notebook.exit(json.dumps({"dropped": dropped, "skipped": skipped}))
