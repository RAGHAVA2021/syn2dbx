"""Static checks for scripts that cannot run outside Databricks or Azure."""
import ast
import re
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = sorted((ROOT / "databricks").glob("*.py")) + sorted((ROOT / "python").glob("*.py"))


@pytest.mark.parametrize("path", SCRIPTS, ids=lambda p: f"{p.parent.name}/{p.name}")
def test_no_top_level_function_is_rebound(path):
    """A module-level def later overwritten by an assignment breaks every later call."""
    tree = ast.parse(path.read_text())
    functions = {n.name for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    rebound = set()
    for node in tree.body:
        targets = node.targets if isinstance(node, ast.Assign) else [getattr(node, "target", None)]
        for t in targets:
            if isinstance(t, ast.Name) and t.id in functions:
                rebound.add(t.id)
    assert not rebound, f"{path.name} rebinds function(s) {sorted(rebound)}"


def test_notebook_package_dir_matches_package_folder():
    text = (ROOT / "databricks" / "generate_mappings_pyspark.py").read_text()
    assert f'PACKAGE_DIR = "/Workspace/Shared/{ROOT.name}"' in text
    assert ROOT.name in (ROOT / "WHERE_TO_ENTER_VALUES.md").read_text()


def test_loader_and_publisher_agree_on_metadata_columns():
    import sys
    sys.path.insert(0, str(ROOT / "python"))
    from bridge_run import METADATA_COLUMNS
    tree = ast.parse((ROOT / "databricks" / "publish.py").read_text())
    published = next(ast.literal_eval(n.value) for n in tree.body if isinstance(n, ast.Assign)
                     and any(getattr(t, "id", None) == "METADATA_COLUMNS" for t in n.targets))
    assert published == METADATA_COLUMNS
    loader = (ROOT / "databricks" / "load_candidate.py").read_text()
    assert re.findall(r'"(\w+)": ', loader[loader.index("metadata = {"):loader.index("}", loader.index("metadata = {"))]) \
        == list(METADATA_COLUMNS)


def test_loader_accepts_an_empty_attempt_and_rejects_mixed_nonempty_attempts():
    """Run the real notebook's attempt-count guard without importing Databricks."""
    tree = ast.parse((ROOT / "databricks" / "load_candidate.py").read_text())
    functions = {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
    scope = {}
    isolated = ast.Module(body=[functions["assert_count"], functions["assert_attempts"]], type_ignores=[])
    exec(compile(ast.fix_missing_locations(isolated), "load_candidate.py", "exec"), scope)
    scope["assert_attempts"](0, 0)
    scope["assert_attempts"](1, 3)
    with pytest.raises(ValueError, match="Mixed load attempts"):
        scope["assert_attempts"](0, 3)
    with pytest.raises(ValueError, match="Mixed load attempts"):
        scope["assert_attempts"](2, 3)


REMOVED = re.compile(r"fence|RELEASE_POINTER|COPY_ACTIVITY|published_groups|_snapshots|pointer_job|"
                     r"generation_id|write_closed|ABANDONED_GENERATION|group_members", re.IGNORECASE)


@pytest.mark.parametrize("path", SCRIPTS + sorted((ROOT / "sql").glob("*.sql")), ids=lambda p: p.name)
def test_code_has_no_references_to_removed_features(path):
    text = path.read_text()
    if path.name == "bridge_run.py":
        # The refusal list for configs written for other packages names removed settings on purpose.
        start = text.index("UNSUPPORTED_TOP = ")
        text = text[:start] + text[text.index(")", text.index("UNSUPPORTED_MAPPING = ")) + 1:]
    assert not REMOVED.findall(text), f"{path.name}: {sorted(set(REMOVED.findall(text)))}"
