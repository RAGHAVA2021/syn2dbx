"""Fail-closed configuration rules, naming, paths and external-call classification."""
import copy
import json
import sys
import types
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
from bridge_run import (attempt_relative_path, candidate_table_name, cetas_error_is_terminal, config,  # noqa: E402
                        delta_target, is_indeterminate, Indeterminate, PhaseError, notebook_job, projection,
                        size_class, target_key)
import generate_mappings  # noqa: E402
import render_setup  # noqa: E402

ORIGINAL = json.loads((ROOT / "config.example.json").read_text())
for item in ORIGINAL["mappings"]:
    item["target_catalog"] = "example_catalog"


def write(tmp_path, doc):
    p = tmp_path / "config.json"
    p.write_text(json.dumps(doc))
    return p


def test_example_config_is_valid(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    config(write(tmp_path, doc))
    assert projection(doc["mappings"][0]) == "[customer_id] AS [customer_id], [name] AS [name]"


@pytest.mark.parametrize("where,field,value", [
    ("top", "source_set_id", "synapse_materialised"),
    ("top", "pointer_job_id", 1),
    ("top", "synapse_pipeline", {}),
    ("mapping", "strategy", "RELEASE_POINTER"),
    ("mapping", "strategy", "REPLACE_TABLE"),
    ("mapping", "method", "CETAS"),
    ("mapping", "group_id", "g"),
    ("mapping", "allow_empty", False),
])
def test_fields_of_removed_features_are_refused(tmp_path, where, field, value):
    doc = copy.deepcopy(ORIGINAL)
    (doc if where == "top" else doc["mappings"][0])[field] = value
    with pytest.raises(RuntimeError, match="Unsupported config field"):
        config(write(tmp_path, doc))


def test_duplicate_target_column_case_insensitive(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["columns"][1]["target"] = "CUSTOMER_ID"
    with pytest.raises(RuntimeError, match="Duplicate/missing columns"):
        config(write(tmp_path, doc))


def test_duplicate_consumer_table_rejected(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][1]["target_table"] = "CUSTOMER"
    with pytest.raises(RuntimeError, match="Duplicate source or target"):
        config(write(tmp_path, doc))


def test_metadata_column_names_are_reserved(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["columns"][1]["target"] = "release_id"
    with pytest.raises(RuntimeError, match="clashes with bridge metadata"):
        config(write(tmp_path, doc))


def test_consumer_table_cannot_use_candidate_name_space(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["target_schema"] = "bridge_candidate"
    doc["mappings"][0]["target_table"] = "candidate_x"
    with pytest.raises(RuntimeError, match="reserved for generated candidate tables"):
        config(write(tmp_path, doc))


def test_unreviewed_expression_cannot_be_injected(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["columns"][0]["source"] = "id]; DROP TABLE t;--"
    with pytest.raises(RuntimeError, match="Unsafe SQL identifier"):
        config(write(tmp_path, doc))


def test_missing_retention_property(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    del doc["mappings"][0]["consumer_properties"]["delta.deletedFileRetentionDuration"]
    with pytest.raises(RuntimeError, match="Missing governed property"):
        config(write(tmp_path, doc))


def test_property_values_must_be_strings(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["consumer_properties"]["delta.enableChangeDataFeed"] = True
    with pytest.raises(RuntimeError, match="quote-free strings"):
        config(write(tmp_path, doc))


def test_profile_classification_uses_rows_columns_or_storage():
    limits = {"medium_rows": 100, "large_rows": 1000, "medium_bytes": 10000,
              "large_bytes": 100000, "medium_columns": 10, "large_columns": 50}
    assert size_class(2, 2, 40, limits) == "SMALL"
    assert size_class(101, 2, 40, limits) == "MEDIUM"
    assert size_class(2, 51, 40, limits) == "LARGE"
    assert size_class(2, 2, 100001, limits) == "LARGE"


def _profile(m, physical_columns=None):
    m["size_class"] = "SMALL"
    m["source_profile"] = {"profiled_at_utc": "2026-09-22T00:00:00Z", "estimated_rows": 1,
                           "physical_used_bytes": 128, "mapped_column_count": len(m["columns"]),
                           "physical_column_count": physical_columns or len(m["columns"]),
                           "source_schema_version": m["source_schema_version"]}


def test_profiled_inventory_rejects_missing_or_mismatched_profile(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["require_profiles"] = True
    with pytest.raises(RuntimeError, match="Missing/stale profile"):
        config(write(tmp_path, doc))
    for m in doc["mappings"]:
        _profile(m)
    doc["mappings"][0]["source_profile"]["mapped_column_count"] = 99
    with pytest.raises(RuntimeError, match="Missing/stale profile"):
        config(write(tmp_path, doc))


def test_profile_allows_materialised_table_with_more_columns_than_view(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["require_profiles"] = True
    for m in doc["mappings"]:
        _profile(m, physical_columns=len(m["columns"]) + 5)
    config(write(tmp_path, doc))


def test_unknown_size_class_rejected(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["size_class"] = "HUGE"
    with pytest.raises(RuntimeError, match="Unknown size_class"):
        config(write(tmp_path, doc))


def test_materialised_fields_must_be_paired(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    del doc["mappings"][0]["materialised_table"]
    with pytest.raises(RuntimeError, match="given together"):
        config(write(tmp_path, doc))


@pytest.mark.parametrize("field,value", [("max_attempts", 0), ("takeover_after_minutes", 5),
                                         ("takeover_after_minutes", 134), ("heartbeat_seconds", 5000)])
def test_invalid_resume_settings(tmp_path, field, value):
    doc = copy.deepcopy(ORIGINAL)
    doc[field] = value
    with pytest.raises(RuntimeError):
        config(write(tmp_path, doc))


@pytest.mark.parametrize("value", ["decimal(5,10)", "decimal(39,0)", "decimal(0,0)"])
def test_invalid_decimal_contracts_are_rejected(tmp_path, value):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["columns"][0]["target_type"] = value
    with pytest.raises(RuntimeError, match="Unsupported target type"):
        config(write(tmp_path, doc))


def test_missing_source_spark_type_fails_fast(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    del doc["mappings"][0]["columns"][0]["source_spark_type"]
    with pytest.raises(RuntimeError, match="Missing source_spark_type"):
        config(write(tmp_path, doc))


def test_missing_source_schema_version_fails_fast(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    del doc["mappings"][0]["source_schema_version"]
    with pytest.raises(RuntimeError, match="source_schema_version"):
        config(write(tmp_path, doc))


def test_candidate_names_do_not_collide():
    assert candidate_table_name("A-B", "run-1", 1) != candidate_table_name("A_B", "run_1", 1)
    assert candidate_table_name("A", "r", 1) != candidate_table_name("A", "r", 2)
    assert candidate_table_name("A", "r", 1) == candidate_table_name("A", "r", 1)
    assert len(candidate_table_name("X" * 128, "Y" * 128, 9)) < 128


def test_attempt_paths_and_targets():
    assert attempt_relative_path("2026-09-22", "BRG_1", "MAP_1", 2) == \
        "bridge/parquet-stage/2026-09-22/BRG_1/MAP_1/attempt-002/"
    m = copy.deepcopy(ORIGINAL["mappings"][0])
    assert delta_target(m, "BRG_1", 1).startswith("example_catalog.bridge_candidate.candidate_MAP_v_customer_")
    assert target_key(m) == "table:example_catalog.gold.customer"


def test_indeterminate_detection_through_phase_errors():
    assert is_indeterminate(PhaseError("x", [RuntimeError("a"), Indeterminate("b")]))
    assert not is_indeterminate(PhaseError("x", [RuntimeError("a")]))


def test_cetas_sqlstate_classification():
    Error = type("Error", (Exception,), {"__module__": "pyodbc"})
    assert cetas_error_is_terminal(Error("42000", "syntax"))
    assert cetas_error_is_terminal(Error("40001", "rolled back"))
    assert not cetas_error_is_terminal(Error("08S01", "link failure"))
    assert not cetas_error_is_terminal(Error("HYT00", "timeout"))
    assert not cetas_error_is_terminal(RuntimeError("42000"))


def test_databricks_poll_failure_after_submission_is_indeterminate(monkeypatch):
    import bridge_run
    monkeypatch.setattr(bridge_run, "write_manifest", lambda cfg, run, payload: ("abfss://manifest", "0" * 64))

    class Jobs:
        def run_now(self, **kw): return type("Started", (), {"run_id": 42})()
        def get_run(self, **kw): raise ConnectionError("poll failed")

    class Client:
        def __init__(self): self.jobs = Jobs()

    package = types.ModuleType("databricks")
    sdk = types.ModuleType("databricks.sdk")
    sdk.WorkspaceClient = Client
    monkeypatch.setitem(sys.modules, "databricks", package)
    monkeypatch.setitem(sys.modules, "databricks.sdk", sdk)
    seen = []
    with pytest.raises(Indeterminate, match="status is unknown"):
        notebook_job({}, 1, {"mode": "TEST"}, "BRG", seen.append)
    assert seen[0].startswith("token:bridge_") and seen[1] == "42"


def test_generated_mapping_is_accepted_by_config(tmp_path):
    rows = [["customer_id", 1, "bigint", 8, 19, 0, False], ["name", 2, "nvarchar", 200, 0, 0, True],
            ["created", 3, "date", 3, 10, 0, True], ["amount", 4, "decimal", 9, 18, 2, True]]
    base = copy.deepcopy(ORIGINAL["mappings"][0])
    m = generate_mappings.make_mapping(base, "presentation", "v_orders", "example_catalog", "gold", "v_", rows)
    assert m["target_table"] == "orders" and m["mapping_id"] == "MAP_v_orders"
    assert "materialised_table" not in m and "size_class" not in m
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"] = [m]
    config(write(tmp_path, doc))


def test_render_setup_is_idempotent_sql(tmp_path):
    doc = config(write(tmp_path, copy.deepcopy(ORIGINAL)))
    azure, uc = render_setup.render(doc)
    assert azure.count("IF NOT EXISTS (SELECT 1 FROM bridge.target_state") == 2
    assert "'table:example_catalog.gold.customer'" in azure
    assert "CREATE SCHEMA IF NOT EXISTS `example_catalog`.`bridge_candidate`;" in uc
    assert uc.count("`bridge_candidate`") == 1            # de-duplicated
