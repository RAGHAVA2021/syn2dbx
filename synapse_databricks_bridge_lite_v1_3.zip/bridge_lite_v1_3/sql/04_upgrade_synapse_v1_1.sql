-- Run in the dedicated Synapse SQL pool, after v1.1 refresh/bridge jobs finish.
ALTER TABLE bridge_meta.upstream_object ADD error_text varchar(1000) NULL;
