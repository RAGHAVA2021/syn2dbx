-- Step S1 (SCRIPT_GUIDE.md). Run once in a dedicated Azure SQL Database using an administrator identity.
-- Replace the grants at the end with your named orchestration identity.
IF SCHEMA_ID(N'bridge') IS NULL EXEC(N'CREATE SCHEMA bridge');
GO
CREATE TABLE bridge.runs (
 bridge_run_id nvarchar(128) NOT NULL PRIMARY KEY,
 upstream_run_id nvarchar(128) NOT NULL,
 upstream_sequence bigint NOT NULL, business_date date NOT NULL,
 inventory_version nvarchar(128) NOT NULL, config_sha256 char(64) NOT NULL,
 release_id nvarchar(128) NOT NULL UNIQUE,
 status varchar(24) NOT NULL CHECK(status IN ('EXTRACTING','EXTRACTED','LOADING','READY','PUBLISHING','PUBLISHED','PARTIALLY_PUBLISHED',
                                              'FAILED','PUBLICATION_ABANDONED','ABANDONED')),
 -- Orchestrator lease: every write by bridge_run.py/publish_run.py is conditional on the
 -- token; a process whose heartbeat is older than takeover_after_minutes can be taken over.
 orchestrator_token nvarchar(64) NULL,
 heartbeat_utc datetime2(3) NULL,
 created_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 updated_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
CREATE TABLE bridge.object_attempts (
 bridge_run_id nvarchar(128) NOT NULL REFERENCES bridge.runs(bridge_run_id),
 mapping_id nvarchar(128) NOT NULL, attempt int NOT NULL CHECK(attempt>0),
 status varchar(24) NOT NULL CHECK(status IN ('EXTRACTING','INDETERMINATE','EXTRACTED','LOADING','READY',
                                              'FAILED','SUPERSEDED','ABANDONED')),
 leaf_path nvarchar(1024) NOT NULL UNIQUE,
 source_request_id nvarchar(128) NULL, source_rows bigint NULL,
 parquet_rows bigint NULL, delta_rows bigint NULL,
 error_text nvarchar(2000) NULL,
 -- Recorded before any external work, so retention never depends on the current config.
 delta_target nvarchar(512) NOT NULL,
 target_key nvarchar(512) NOT NULL,
 consumer_target nvarchar(512) NOT NULL,
 source_operation_state varchar(24) NULL,
 loader_run_id nvarchar(128) NULL,
 loader_operation_state varchar(24) NULL,
 loader_attempts int NOT NULL DEFAULT 0,
 updated_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 retired_utc datetime2(3) NULL,
 staging_deleted_utc datetime2(3) NULL,
 PRIMARY KEY(bridge_run_id,mapping_id,attempt)
);
GO
CREATE TABLE bridge.target_state (
 target_key nvarchar(512) NOT NULL PRIMARY KEY,
 published_release_id nvarchar(128) NULL,
 published_sequence bigint NULL,
 high_water_sequence bigint NOT NULL DEFAULT -1,
 previous_release_id nvarchar(128) NULL,
 control_version bigint NOT NULL DEFAULT 0,
 -- Publication claim: only one bridge run may change a target's Delta state at a time.
 -- Cleared in the same update that records the publication; kept by the owning run if
 -- the outcome is unknown, so only that run's publish_run.py --resume can continue.
 publish_owner nvarchar(128) NULL,
 publish_token nvarchar(64) NULL,
 publish_claimed_utc datetime2(3) NULL,
 publish_external_run_id nvarchar(128) NULL,
 publish_operation_state varchar(24) NULL
);
GO
CREATE TABLE bridge.recovery_events (
 recovery_event_id bigint IDENTITY PRIMARY KEY,
 action varchar(32) NOT NULL,
 bridge_run_id nvarchar(128) NOT NULL,
 mapping_id nvarchar(128) NULL,
 attempt int NULL,
 target_key nvarchar(512) NULL,
 external_run_id nvarchar(128) NULL,
 actor nvarchar(128) NOT NULL,
 evidence_uri nvarchar(2048) NULL,       -- required for every action except ABANDON_RUN
 reason nvarchar(1000) NOT NULL,
 at_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
-- The orchestration identity needs SELECT, INSERT and UPDATE on these four tables.
-- GRANT SELECT, INSERT, UPDATE ON SCHEMA::bridge TO [<orchestration-database-user>];
-- Do not grant DDL rights on the bridge schema to runtime users.
