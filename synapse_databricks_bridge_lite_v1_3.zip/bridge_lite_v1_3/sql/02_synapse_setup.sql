-- Step S1 (SCRIPT_GUIDE.md). Run once in the dedicated SQL pool database as its deployment identity.
-- Precondition: database master key exists; an administrator provisions it separately.
-- CREATE MASTER KEY ENCRYPTION BY PASSWORD = '<secret from approved vault>';
-- Precondition: the Synapse workspace managed identity has write/list access to the ADLS staging
-- container (Microsoft's dedicated-pool managed-identity tutorial uses Storage Blob Data Contributor).

IF SCHEMA_ID(N'bridge_meta') IS NULL EXEC(N'CREATE SCHEMA bridge_meta');
GO
-- Dedicated SQL pool PolyBase/CETAS (TYPE=HADOOP) requires the literal 'Managed Service Identity'.
CREATE DATABASE SCOPED CREDENTIAL bridge_storage_mi WITH IDENTITY = 'Managed Service Identity';
GO
-- Change the URL to your ADLS Gen2 staging container (container root, same as staging_abfss_root).
CREATE EXTERNAL DATA SOURCE bridge_stage WITH (
 TYPE=HADOOP,
 LOCATION='abfss://<container>@<account>.dfs.core.windows.net',
 CREDENTIAL=bridge_storage_mi
);
GO
CREATE EXTERNAL FILE FORMAT bridge_parquet WITH (FORMAT_TYPE=PARQUET);
GO
-- Written by python/upstream_audit.py after each daily refresh.
CREATE TABLE bridge_meta.upstream_run (
 upstream_run_id varchar(128) NOT NULL,
 upstream_sequence bigint NOT NULL, business_date date NOT NULL,
 status varchar(16) NOT NULL,
 completed_utc datetime2 NULL
) WITH (DISTRIBUTION=ROUND_ROBIN, HEAP);
GO
CREATE TABLE bridge_meta.upstream_object (
 upstream_run_id varchar(128) NOT NULL, mapping_id varchar(128) NOT NULL,
 source_schema_version varchar(128) NOT NULL,
 status varchar(16) NOT NULL, row_count bigint NOT NULL,
 error_text varchar(1000) NULL,
 refresh_completed_utc datetime2 NULL
) WITH (DISTRIBUTION=ROUND_ROBIN, HEAP);
GO
-- Dedicated SQL pool primary/unique constraints are not enforced. upstream_audit.py refuses a
-- duplicate run ID and bridge_run.py rejects duplicate or missing audit rows.

-- CETAS execution identity (BRIDGE_CETAS_ODBC; a contained Entra user in this database).
-- All CETAS grants are database-scoped in a dedicated pool:
-- GRANT SELECT ON SCHEMA::<source_schema> TO [<cetas-user>];
-- GRANT CREATE TABLE TO [<cetas-user>];
-- GRANT ALTER ON SCHEMA::bridge_meta TO [<cetas-user>];      -- create/drop temporary CETAS metadata
-- GRANT ADMINISTER DATABASE BULK OPERATIONS TO [<cetas-user>];
-- GRANT ALTER ANY EXTERNAL DATA SOURCE TO [<cetas-user>];     -- security-sensitive: treat as trusted
-- GRANT ALTER ANY EXTERNAL FILE FORMAT TO [<cetas-user>];
--
-- Audit/metadata identity (BRIDGE_SYNAPSE_AUDIT_ODBC), a different user:
-- GRANT SELECT ON SCHEMA::<source_schema> TO [<audit-user>];  -- row counts and schema hashes
-- GRANT SELECT, INSERT ON SCHEMA::bridge_meta TO [<audit-user>];
