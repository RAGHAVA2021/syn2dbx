-- Run in the Azure SQL control database only after all v1.1 runs are terminal.
-- Back up the database and deploy v1.2 scripts before starting a new run.
SET XACT_ABORT ON;
BEGIN TRANSACTION;
IF COL_LENGTH('bridge.object_attempts','loader_attempts') IS NULL
    ALTER TABLE bridge.object_attempts ADD loader_attempts int NOT NULL
      CONSTRAINT DF_bridge_loader_attempts DEFAULT 0;
DECLARE @status_check sysname;
SELECT @status_check = cc.name FROM sys.check_constraints AS cc
WHERE cc.parent_object_id = OBJECT_ID(N'bridge.runs')
  AND cc.definition LIKE '%PUBLISHING%'
  AND cc.definition LIKE '%EXTRACTING%';
IF @status_check IS NULL THROW 51000, 'Cannot locate bridge.runs status CHECK constraint', 1;
EXEC(N'ALTER TABLE bridge.runs DROP CONSTRAINT ' + QUOTENAME(@status_check));
ALTER TABLE bridge.runs ADD CONSTRAINT CK_bridge_runs_status CHECK(status IN
 ('EXTRACTING','EXTRACTED','LOADING','READY','PUBLISHING','PUBLISHED','PARTIALLY_PUBLISHED',
  'FAILED','PUBLICATION_ABANDONED','ABANDONED'));
COMMIT;
