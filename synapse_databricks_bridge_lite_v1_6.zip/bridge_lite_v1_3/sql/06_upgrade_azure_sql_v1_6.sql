-- Apply once to an existing v1.5 Azure SQL control database before running v1.6 audits.
-- Stop/finish any in-progress upstream_audit.py jobs during this migration.
IF OBJECT_ID(N'bridge.audit_reservations', N'U') IS NULL
BEGIN
 CREATE TABLE bridge.audit_reservations (
  upstream_run_id nvarchar(128) NOT NULL PRIMARY KEY,
  upstream_sequence bigint NOT NULL UNIQUE,
  reserved_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME()
 );
END;
GO
