-- Run in the Azure SQL control database when upgrading an existing v1.2/v1.3 installation to v1.3.1.
-- Adds the database-level guarantee of at most one open bridge run per upstream refresh.
-- If this fails with a duplicate-key error, two open runs already exist for one refresh:
-- finish or abandon one of them (recovery.py abandon-run), then run this script again.
-- The session options below are required for filtered indexes; ODBC Driver 18 sets them by default.
SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'UX_bridge_runs_open_upstream'
               AND object_id = OBJECT_ID(N'bridge.runs'))
    CREATE UNIQUE INDEX UX_bridge_runs_open_upstream ON bridge.runs(upstream_run_id)
     WHERE status IN ('EXTRACTING','EXTRACTED','LOADING','READY','PUBLISHING','FAILED');
