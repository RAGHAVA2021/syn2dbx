# Where to enter values

## Config file

For a few tables, copy `config.example.json` to `config.json` and edit it. For hundreds or thousands of tables, generate it (next section). Each entry in `mappings` is one Synapse source object and one Databricks consumer table.

### Top level

| Field | Meaning | Example |
|---|---|---|
| `inventory_version` | Name of this reviewed inventory. A hash pins mappings and release policy; operational settings such as job IDs and worker limits may change for recovery. | `wave_001_v1` |
| `allow_partial_release` | If true, drifted or terminally failed mappings stay on their previous release while healthy tables publish; monitor `PARTIALLY_PUBLISHED`. | `true` |
| `max_loader_retries_per_attempt` | Maximum loader submissions from the same Parquet attempt before a fresh extraction attempt is needed. | `3` |
| `staging_abfss_root` | ADLS container root for Parquet staging (also in `sql/02_synapse_setup.sql`) | `abfss://landing@storageacct.dfs.core.windows.net` |
| `loader_job_id`, `publisher_job_id`, `retention_job_id` | Databricks job IDs from step S3 | numeric IDs |
| `max_extraction_workers` (1–32) | CETAS exports running at once | `4` |
| `extraction_class_limits` | Concurrent exports per size class | `{"SMALL": 4, "MEDIUM": 2, "LARGE": 1}` |
| `max_loader_workers`, `max_publisher_workers` (1–32) | Loader / publisher jobs running at once | `1` |
| `max_attempts` (1–9) | Extraction attempts per table per run | `3` |
| `takeover_after_minutes` (135–1440) | When a silent run's lease may be taken over; must cover the 2-hour job timeout plus 15 minutes | `150` |
| `heartbeat_seconds` (10–600) | Lease heartbeat interval | `60` |
| `retention_days_published`, `retention_days_unpublished` (0–3650) | Retention windows for candidates and staging | `7`, `30` |
| `profile_thresholds` | Rows/bytes/columns limits for MEDIUM and LARGE (used by I2) | see example |

### Per mapping

| Field | Meaning | Example |
|---|---|---|
| `mapping_id` | Stable unique ID, letters/digits/`_`/`-` | `MAP_v_orders` |
| `source_schema`, `source_view` | Synapse object to export (a view or a table) | `presentation`, `v_orders` |
| `source_schema_version` | Hash from `python/source_metadata.py` | `sha256:…` |
| `materialised_schema`, `materialised_table` | Physical table behind a view; only for profiling (both or neither) | `materialised`, `orders` |
| `target_catalog`, `target_schema`, `target_table` | Databricks consumer table | `analytics`, `gold`, `orders` |
| `candidate_schema` | Private schema for attempt-specific candidate tables | `bridge_candidate` |
| `consumer_properties` | Delta table properties, as strings exactly as `SHOW TBLPROPERTIES` reports them. The three retention properties are required. | see example |
| `columns[]` | `source`, `target`, `conversion` (`DIRECT` or `GUID_TEXT`), `source_spark_type` (Parquet type Spark reads), `target_type` | `order_id` / `bigint` → `bigint` |

Target types: `string`, `boolean`, `int`, `bigint`, `double`, `date`, `timestamp`, `timestamp_ntz`, `decimal(p,s)`. The column names `release_id`, `mapping_object_id`, `bridge_run_id`, `upstream_run_id`, `upstream_sequence`, `business_date` and `load_attempt` are reserved: the bridge adds them to every table.

## Generate mappings for many tables

**On Databricks:** upload the extracted `bridge_lite_v1_3` folder as Workspace files. Import `databricks/generate_mappings_pyspark.py` as a notebook and set its variables:

- `PACKAGE_DIR`;
- `SOURCE_SCHEMA`, `SOURCE_KIND` and `SOURCE_PREFIX`;
- `TARGET_CATALOG`, `TARGET_SCHEMA`;
- `INVENTORY_VERSION`;
- `OUTPUT`, a writable Unity Catalog volume path;
- either `UC_JDBC_CONNECTION` or `JDBC_URL` plus secret names.

Run it once. It reads only Synapse catalog metadata.

**On the control host** (with `BRIDGE_SYNAPSE_AUDIT_ODBC`):

```bash
python python/generate_mappings.py --schema presentation --source-kind table \
  --target-catalog analytics --target-schema gold \
  --inventory-version wave_001_v1 --output config.generated.json
```

For views, use `--source-kind view --view-prefix v_`. That selects names starting with `v_` and strips the prefix from the target table name.

The generator automatically maps these types:

- bounded `varchar`/`nvarchar`/`char`/`nchar`;
- `int`, `bigint`, `date`;
- `decimal`/`numeric`.

For any other type it writes no config and lists the object in `*.exceptions.json`. Review those objects individually: `datetime`, `datetime2`, `time`, GUIDs, `money`, binaries, `tinyint`, floats and `MAX` text. CETAS can also reject LOBs above 1 MB and text containing `|`, `"`, `\r` or `\n`, so include such values in acceptance tests.

Review the generated file and rename it `config.json`. Then fill in `staging_abfss_root` and the three job IDs.

## Profile tables (optional)

```bash
python python/profile_inventory.py --config config.json --inventory-version wave_001_v2 --output config.profiled.json
```

Or use `databricks/profile_inventory_pyspark.py` on a classic cluster with network access to the dedicated pool. Review the `.profile.csv`, then use the new config and rerun `render_setup.py`. Raise the worker and class limits gradually, based on Synapse queueing and measured run times.

## Environment variables on the control host

| Variable | Identity | Used by |
|---|---|---|
| `BRIDGE_CONTROL_ODBC` | Orchestration user in the Azure SQL control database (SELECT/INSERT/UPDATE on schema `bridge`) | all nightly, recovery and retention scripts |
| `BRIDGE_SYNAPSE_AUDIT_ODBC` | Synapse audit user (SELECT on sources, SELECT/INSERT on `bridge_meta`) | `upstream_audit.py`, `bridge_run.py`, generators, profiler |
| `BRIDGE_CETAS_ODBC` | Synapse CETAS user, a **different** user (grants in `sql/02_synapse_setup.sql`) | `bridge_run.py` |

Install Microsoft ODBC Driver 18 for SQL Server and `pip install -r requirements.txt`. The host also uses `DefaultAzureCredential` with these rights on the staging container:

- read/list, to prove an attempt folder is empty;
- create under `bridge/parquet-stage/_manifests/`, for job manifests;
- delete, only if you run `retire_releases.py --delete-staging`.

Configure Databricks unified authentication so the host can read (Can View) and start (Can Manage Run) the three jobs; each script reads its job IDs through the Jobs API before doing any work. Never print the connection strings.

## Staging in ADLS Gen2

`staging_abfss_root` is the **container root**. The same URI goes into the `bridge_stage` external data source in `sql/02_synapse_setup.sql`. The runner writes to folders like:

```text
abfss://landing@storageacct.dfs.core.windows.net/bridge/parquet-stage/2026-09-22/BRG_20260922/MAP_v_orders/attempt-001/
```

Grant the Synapse workspace managed identity write access to the container.

For Databricks, create a Unity Catalog storage credential backed by an Access Connector managed identity with read access. Then register the staging prefix as an external location:

```sql
CREATE EXTERNAL LOCATION bridge_parquet_stage
  URL 'abfss://landing@storageacct.dfs.core.windows.net/bridge/parquet-stage'
  WITH (STORAGE CREDENTIAL bridge_staging_credential);
-- Every job reads its manifest from this location:
GRANT READ FILES ON EXTERNAL LOCATION bridge_parquet_stage TO `bridge-loader-principal`;
GRANT READ FILES ON EXTERNAL LOCATION bridge_parquet_stage TO `bridge-publisher-principal`;
GRANT READ FILES ON EXTERNAL LOCATION bridge_parquet_stage TO `bridge-retention-principal`;
```

If the storage account has a firewall, configure serverless network access to it.

## Databricks jobs

Create three **single-task notebook jobs** on **Serverless** compute, each with its own Run-as service principal:

| Job | Notebook | Run-as needs |
|---|---|---|
| Loader | `databricks/load_candidate.py` | `USE CATALOG`/`USE SCHEMA`, `CREATE TABLE` on each `candidate_schema` |
| Publisher | `databricks/publish.py` | `SELECT` on candidates; `CREATE TABLE` on each consumer schema; `MANAGE` on each existing consumer table |
| Retention | `databricks/retire_releases.py` | Ownership or `MANAGE` on candidate tables; `SELECT` on consumer tables |

Configure every job the same way:

- **Notebook parameters:** `manifest_path` and `manifest_sha256`, both with empty defaults. These are task parameters (widgets), not job-level parameters.
- **Job timeout:** at most **7,200 seconds**. The runner polls for two hours, but if the control host itself stops, only the platform timeout can end the job.
- **Retries:** disable *serverless auto-optimization* (Task → Retries → Retry Policy). The runner creates its own attempts, and an automatic retry would outlive the takeover window.
- **Maximum concurrent runs:** at least `max_loader_workers` for the loader and at least `max_publisher_workers` for the publisher.

Consumers get only `USE CATALOG`, `USE SCHEMA` and `SELECT` on the consumer tables. Never give them access to candidate schemas or the staging location.

Test the exact `CREATE OR REPLACE TABLE … TBLPROPERTIES (…) AS SELECT …` statement as the publisher identity before the first production run.
