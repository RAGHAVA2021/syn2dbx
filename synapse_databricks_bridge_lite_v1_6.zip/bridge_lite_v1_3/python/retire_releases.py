"""Step M1 (SCRIPT_GUIDE.md): retire old candidate tables and staging files. Dry run unless --execute.

Per consumer table it always keeps the published release, the previous release (for
rollback) and any --keep-release. Everything else is retired once it can never be
published:

  * attempts that can never be published at all (FAILED, SUPERSEDED, ABANDONED);
  * attempts of a release whose sequence is at or below the table's high-water mark,
    or whose run was abandoned.

Retention windows are measured from the run's last state change: the READY attempt of a
PUBLISHED run becomes eligible retention_days_published (default 7) days later, every
other attempt retention_days_unpublished (default 30) days later. Runs that are still
extracting, loading or publishing, and attempts whose source read or loader may still be
running, are never touched.

  * candidate tables: dropped by the retention Databricks job, which re-checks that the
    attempt is not what the consumer table currently holds;
  * --delete-staging: deletes the exact recorded Parquet attempt paths (never a listing).
"""
import argparse
import json
import re
import sys
from datetime import datetime, timedelta, timezone

from bridge_run import MANIFEST_PREFIX, STAGE_PREFIX, config, container_client, db, need, notebook_job, staging_parts

RETIRABLE_RUNS = ("PUBLISHED", "PARTIALLY_PUBLISHED", "READY", "FAILED", "PUBLICATION_ABANDONED", "ABANDONED")
DEAD_ATTEMPTS = ("FAILED", "SUPERSEDED", "ABANDONED")
ATTEMPT_PATH = re.compile(re.escape(STAGE_PREFIX) + r"/\d{4}-\d{2}-\d{2}/[A-Za-z0-9_\-]+/[A-Za-z0-9_\-]+/attempt-\d{3}/")


def plan(cfg, pinned, report=None):
    with db("BRIDGE_CONTROL_ODBC") as control:
        states = {r[0]: {"published": r[1], "previous": r[2], "high_water": int(r[3])}
                  for r in control.cursor().execute("SELECT target_key,published_release_id,previous_release_id,"
                                                    "high_water_sequence FROM bridge.target_state").fetchall()}
        attempts = control.cursor().execute(
            "SELECT a.bridge_run_id,a.mapping_id,a.attempt,a.delta_target,a.leaf_path,a.retired_utc,"
            "a.staging_deleted_utc,r.release_id,r.upstream_sequence,r.status,a.target_key,a.consumer_target,"
            "a.source_operation_state,a.loader_operation_state,a.status,"
            "DATEDIFF(hour, r.updated_utc, SYSUTCDATETIME()) "
            "FROM bridge.object_attempts a JOIN bridge.runs r ON r.bridge_run_id=a.bridge_run_id").fetchall()
    published_hours = cfg.get("retention_days_published", 7) * 24
    unpublished_hours = cfg.get("retention_days_unpublished", 30) * 24
    waiting, drops, staging = [], [], []

    def keep_for(key):
        s = states.get(key, {})
        return {x for x in (s.get("published"), s.get("previous"), *pinned) if x and x != "NONE"}

    for (run_id, mid, attempt, dtarget, leaf, retired, deleted, release, seq, run_status, key, consumer,
         source_state, loader_state, attempt_status, run_age_hours) in attempts:
        if run_status not in RETIRABLE_RUNS:
            continue
        # A terminal-looking run is not proof that its external work stopped.
        if source_state in ("RUNNING", "UNKNOWN") or loader_state in ("RUNNING", "UNKNOWN"):
            continue
        state = states.get(key)
        if state is None:
            continue
        dead = attempt_status in DEAD_ATTEMPTS
        releasable = release not in keep_for(key) and (run_status in ("ABANDONED", "PUBLICATION_ABANDONED")
                       or (run_status in ("PUBLISHED", "PARTIALLY_PUBLISHED") and attempt_status != "READY")
                       or int(seq) <= state["high_water"])
        if not (dead or releasable):
            continue                      # kept, or could still be published
        window = published_hours if (run_status in ("PUBLISHED", "PARTIALLY_PUBLISHED")
                                     and attempt_status == "READY") else unpublished_hours
        pending_work = retired is None or (leaf and deleted is None)
        if run_age_hours is None or int(run_age_hours) < window:
            if pending_work:              # a missing timestamp is never old enough
                waiting.append({"run_id": run_id, "mapping_id": mid, "attempt": attempt,
                                "eligible_in_hours": window - int(run_age_hours or 0)})
            continue
        if retired is None:
            cat, sch, tab = dtarget.split(".")
            ccat, csch, ctab = consumer.split(".")
            drops.append({"run_id": run_id, "mapping_id": mid, "attempt": attempt, "catalog": cat,
                          "schema": sch, "table": tab, "release_id": release,
                          "target": {"catalog": ccat, "schema": csch, "table": ctab}})
        if leaf and deleted is None:
            staging.append({"run_id": run_id, "mapping_id": mid, "attempt": attempt, "leaf_path": leaf})
    if report is not None:
        report["waiting_for_retention_window"] = waiting
    return drops, staging


def delete_staging(cfg, items):
    root = cfg["staging_abfss_root"].rstrip("/") + "/"
    client = container_client(cfg["staging_abfss_root"])
    done = []
    for item in items:
        need(item["leaf_path"].startswith(root), f"Leaf path outside staging root: {item['leaf_path']}")
        relative = item["leaf_path"][len(root):]
        need(ATTEMPT_PATH.fullmatch(relative), f"Not an exact attempt path: {relative}")
        # Delete deepest names first so hierarchical-namespace directories empty cleanly.
        names = sorted((b.name for b in client.list_blobs(name_starts_with=relative)), key=len, reverse=True)
        for name in names:
            client.delete_blob(name)
        done.append(item)
    return done


def delete_old_manifests(cfg):
    """Only remove manifests for terminal runs after the unpublished retention window."""
    with db("BRIDGE_CONTROL_ODBC") as control:
        terminal = {r[0] for r in control.cursor().execute(
            "SELECT bridge_run_id FROM bridge.runs WHERE status IN "
            "('PUBLISHED','PARTIALLY_PUBLISHED','PUBLICATION_ABANDONED','ABANDONED')").fetchall()}
    client = container_client(cfg["staging_abfss_root"])
    limit = datetime.now(timezone.utc) - timedelta(days=cfg.get("retention_days_unpublished", 30))
    count = 0
    for blob in client.list_blobs(name_starts_with=MANIFEST_PREFIX + "/"):
        parts = blob.name[len(MANIFEST_PREFIX) + 1:].split("/")
        if (len(parts) != 2 or not re.fullmatch(r"[0-9a-f]{32}\.json", parts[1])
                or parts[0] not in terminal | {"retention"}
                or blob.last_modified is None or blob.last_modified > limit):
            continue
        client.delete_blob(blob.name)
        count += 1
    return count


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--keep-release", action="append", default=[],
                   help="Release to keep regardless of age, e.g. pinned by a consumer; repeatable")
    p.add_argument("--delete-staging", action="store_true", help="Also delete retired Parquet attempt paths")
    p.add_argument("--execute", action="store_true", help="Apply the plan (default is a dry run)")
    a = p.parse_args()
    cfg = config(a.config)
    staging_parts(cfg["staging_abfss_root"])
    for release in a.keep_release:
        need(re.fullmatch(r"[A-Za-z0-9_\-]+", release), f"Invalid release: {release}")
    report = {}
    drops, staging = plan(cfg, a.keep_release, report)
    summary = {"candidate_tables_to_drop": drops, "staging_paths_to_delete": staging if a.delete_staging else [],
               "not_yet_eligible": len(report["waiting_for_retention_window"])}
    if not a.execute:
        print(json.dumps({"dry_run": True, **summary}, indent=2))
        return
    dropped, skipped = set(), []
    if drops:
        job_id = cfg.get("retention_job_id", 0)
        need(type(job_id) is int and job_id > 0, "retention_job_id is not configured")
        import bridge_run
        bridge_run.verify_jobs(cfg, ("retention_job_id",))
        result = notebook_job(cfg, job_id, {"drop_tables": drops}, "retention")
        dropped = {(d["run_id"], d["mapping_id"], d["attempt"]) for d in result.get("dropped", [])}
        skipped = result.get("skipped", [])
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            for run_id, mid, attempt in dropped:
                cur.execute("UPDATE bridge.object_attempts SET retired_utc=SYSUTCDATETIME() WHERE bridge_run_id=? "
                            "AND mapping_id=? AND attempt=? AND retired_utc IS NULL", run_id, mid, attempt)
            control.commit()
    deleted = []
    manifests_deleted = 0
    if a.delete_staging:
        deleted = delete_staging(cfg, staging)
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            for item in deleted:
                cur.execute("UPDATE bridge.object_attempts SET staging_deleted_utc=SYSUTCDATETIME() "
                            "WHERE bridge_run_id=? AND mapping_id=? AND attempt=?",
                            item["run_id"], item["mapping_id"], item["attempt"])
            control.commit()
        manifests_deleted = delete_old_manifests(cfg)
    print(json.dumps({"candidate_tables_dropped": len(dropped), "skipped": skipped,
                      "staging_paths_deleted": len(deleted), "manifests_deleted": manifests_deleted}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR {exc}", file=sys.stderr)
        raise
