"""Publish a READY bridge run: atomically replace each consumer table from its candidate.

Step N4 of the nightly flow (see SCRIPT_GUIDE.md). A run interrupted in PUBLISHING is
continued with --resume: each target is first compared with its actual Delta state
(INSPECT mode of databricks/publish.py). A Delta commit whose Azure SQL update was lost
is reconciled instead of republished; an unexpected Delta state stops that target for
operator review.
"""
import argparse
import json
from concurrent.futures import ThreadPoolExecutor, as_completed

from bridge_run import (Indeterminate, LATEST_ATTEMPTS, OWNED, PhaseError, RunLease, candidate_table_name,
                        claim_run, config, config_sha256, db, delta_target, fetchone, is_indeterminate, need,
                        notebook_job, target_key, update_run)


def read_state(key):
    with db("BRIDGE_CONTROL_ODBC") as control:
        state = fetchone(control, "SELECT published_release_id,high_water_sequence,control_version,publish_owner,"
                                  "publish_external_run_id,publish_operation_state "
                                  "FROM bridge.target_state WHERE target_key=?", key)
    need(state, f"Missing control state: {key}")
    return state


def require_resolved_publisher(ctx, key, state):
    """Do not inspect or republish while an earlier mutating job of this run may still commit."""
    if ctx["resume"] and state[3] == ctx["run_id"] and state[5] in ("RUNNING", "UNKNOWN"):
        raise RuntimeError(
            f"Target {key} still has unresolved publisher {state[4]} ({state[5]}); "
            "verify it is terminal and run recovery.py resolve-publication before --resume")


def inspect_job(cfg, payload, run_id):
    """Run a read-only inspection without replacing the mutating publisher's ID.

    An unknown INSPECT outcome is safe to retry because INSPECT cannot change Delta.
    Convert it to an ordinary failure so the orchestrator lease is released promptly.
    """
    try:
        return notebook_job(cfg, cfg["publisher_job_id"], payload, run_id)
    except Indeterminate as exc:
        raise RuntimeError(f"Read-only Delta inspection did not return a result; retry is safe: {exc}") from None


def check_order(ctx, key, state):
    """Return None to proceed, or an outcome when this target needs no publication."""
    if state[0] == ctx["release"]:
        need(state[1] == ctx["sequence"], f"Inconsistent control state for {key}")
        return "already-published"
    if state[1] > ctx["sequence"] and state[3] != ctx["run_id"]:
        # A newer release is already live; publishing this older one would roll consumers back.
        return "superseded-by-newer"
    need(ctx["sequence"] > state[1], f"Stale target: {key}")
    return None


def claim_target(ctx, key, state):
    """Take the per-target publication claim before any Delta change.

    Two READY runs can overlap (for example a late run and the next night's run).
    CREATE OR REPLACE TABLE is unconditional, so without this claim both could replace the
    table and the loser's Azure SQL update would fail after its Delta commit. A claim left by
    a failed run is not taken over by other runs: only the owning run's --resume, which
    inspects Delta first, may continue.
    """
    with db("BRIDGE_CONTROL_ODBC") as control:
        cur = control.cursor()
        # A fresh claim clears the previous publication's operation ID and state, so they always
        # describe this claim. The owner's own re-claim on --resume keeps them.
        cur.execute("UPDATE bridge.target_state SET "
                    "publish_external_run_id=CASE WHEN publish_owner IS NULL THEN NULL "
                    "ELSE publish_external_run_id END,"
                    "publish_operation_state=CASE WHEN publish_owner IS NULL THEN NULL "
                    "ELSE publish_operation_state END,"
                    "publish_owner=?,publish_token=?,"
                    "publish_claimed_utc=SYSUTCDATETIME() WHERE target_key=? AND control_version=? "
                    "AND high_water_sequence=? AND high_water_sequence<? "
                    "AND (publish_owner IS NULL OR publish_owner=?) AND " + OWNED,
                    ctx["run_id"], ctx["token"], key, state[2], state[1], ctx["sequence"], ctx["run_id"],
                    ctx["run_id"], ctx["token"])
        if cur.rowcount != 1:
            now = fetchone(control, "SELECT publish_owner,control_version FROM bridge.target_state "
                                    "WHERE target_key=?", key)
            if now and now[0] and now[0] != ctx["run_id"]:
                raise RuntimeError(f"Target {key} is being published by run {now[0]}; wait for it to finish "
                                   "or resume that run")
            raise RuntimeError(f"Target {key} changed before it could be claimed; rerun with --resume")
        control.commit()


def record_publication(ctx, key, state):
    """Advance Azure SQL state and release the claim, only from the exact version observed."""
    with db("BRIDGE_CONTROL_ODBC") as control:
        cur = control.cursor()
        cur.execute("UPDATE bridge.target_state SET previous_release_id=published_release_id, "
                    "published_release_id=?,published_sequence=?,high_water_sequence=?, "
                    "control_version=control_version+1,publish_owner=NULL,publish_token=NULL,"
                    "publish_claimed_utc=NULL,publish_external_run_id=NULL,publish_operation_state='SUCCEEDED' "
                    "WHERE target_key=? AND control_version=? "
                    "AND high_water_sequence=? AND publish_owner=? AND publish_token=? AND " + OWNED,
                    ctx["release"], ctx["sequence"], ctx["sequence"], key, state[2], state[1],
                    ctx["run_id"], ctx["token"], ctx["run_id"], ctx["token"])
        need(cur.rowcount == 1, f"Delta is published but Azure SQL state changed concurrently; freeze {key} "
                                "and rerun with --resume after review")
        control.commit()


def publication_callbacks(ctx, key):
    def started(external_id):
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            cur.execute("UPDATE bridge.target_state SET publish_external_run_id=?,publish_operation_state='RUNNING' "
                        "WHERE target_key=? AND publish_owner=? AND publish_token=? AND " + OWNED,
                        external_id, key, ctx["run_id"], ctx["token"], ctx["run_id"], ctx["token"])
            need(cur.rowcount == 1, "Could not persist publisher external run ID")
            control.commit()

    def terminal(external_id, state):
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            cur.execute("UPDATE bridge.target_state SET publish_operation_state=? WHERE target_key=? "
                        "AND publish_owner=? AND publish_token=? AND publish_external_run_id=? AND " + OWNED,
                        state, key, ctx["run_id"], ctx["token"], external_id, ctx["run_id"], ctx["token"])
            need(cur.rowcount == 1, "Could not persist terminal publisher state")
            control.commit()
    return started, terminal


def state_is_this_release(seen, release, rows):
    return seen.get("exists") is True and seen.get("release_ids") == [release] and seen.get("rows") == rows


def state_matches_control(seen, published):
    """True only when Delta shows exactly what Azure SQL says is published.

    Before the first bridge publication (published == 'NONE') the target may be absent, or a
    pre-existing consumer table without bridge metadata (release_ids None). Anything else,
    including a partial or foreign release, is an unexpected state.
    """
    if published == "NONE":
        return seen.get("exists") is False or seen.get("release_ids") is None
    return seen.get("exists") is True and seen.get("release_ids") == [published]


def mark_superseded(ctx, mapping_id, attempt):
    """A newer release is live: this attempt will never be published. Record that on the attempt."""
    with db("BRIDGE_CONTROL_ODBC") as control:
        cur = control.cursor()
        cur.execute("UPDATE bridge.object_attempts SET status='SUPERSEDED',"
                    "error_text='Not published: a newer release is already live',updated_utc=SYSUTCDATETIME() "
                    "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status='READY' AND " + OWNED,
                    ctx["run_id"], mapping_id, attempt, ctx["run_id"], ctx["token"])
        need(cur.rowcount == 1, f"Attempt changed concurrently: {mapping_id}")
        control.commit()


def publish_one(cfg, ctx, lease, m, attempt_row):
    key = target_key(m)
    state = read_state(key)
    require_resolved_publisher(ctx, key, state)
    outcome = check_order(ctx, key, state)
    if outcome == "superseded-by-newer":
        mark_superseded(ctx, m["mapping_id"], attempt_row["attempt"])
    if outcome:
        return outcome
    lease.check()
    claim_target(ctx, key, state)
    started, terminal = publication_callbacks(ctx, key)
    mapping = {**m, "candidate_table": candidate_table_name(m["mapping_id"], ctx["run_id"], attempt_row["attempt"]),
               "attempt": attempt_row["attempt"], "source_rows": attempt_row["source_rows"],
               "upstream_run_id": ctx["upstream_run_id"]}
    base = {"mapping": mapping, "release_id": ctx["release"]}
    lease.check()
    if ctx["resume"]:
        seen = inspect_job(cfg, {**base, "mode": "INSPECT"}, ctx["run_id"])
        if state_is_this_release(seen, ctx["release"], mapping["source_rows"]):
            record_publication(ctx, key, state)          # earlier attempt committed; SQL update was lost
            return "reconciled"
        need(state_matches_control(seen, state[0]),
             f"Target {key} holds releases {seen.get('release_ids')} (exists={seen.get('exists')}), which match "
             f"neither Azure SQL ({state[0]}) nor a complete {ctx['release']}; freeze it for operator review")
    result = notebook_job(cfg, cfg["publisher_job_id"], {**base, "mode": "PUBLISH"}, ctx["run_id"],
                          started, terminal)
    need(result.get("release_id") == ctx["release"] and result.get("rows") == mapping["source_rows"],
         f"Publisher output mismatch: {key}")
    record_publication(ctx, key, state)
    return "published"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--bridge-run-id", required=True)
    parser.add_argument("--resume", action="store_true",
                        help="Continue a run left in PUBLISHING after reconciling each target with Delta")
    a = parser.parse_args()
    cfg = config(a.config)
    from bridge_run import require_jobs
    require_jobs(cfg)
    import bridge_run
    bridge_run.verify_jobs(cfg, ("publisher_job_id",))
    by_mapping = {m["mapping_id"]: m for m in cfg["mappings"]}
    with db("BRIDGE_CONTROL_ODBC") as control:
        run = fetchone(control, "SELECT upstream_run_id,inventory_version,release_id,status,upstream_sequence,config_sha256 "
                       "FROM bridge.runs WHERE bridge_run_id=?", a.bridge_run_id)
        need(run and run[1] == cfg["inventory_version"], "Run missing or inventory changed")
        need(run[5] == config_sha256(cfg), "Reviewed config changed since this run started")
        need(run[3] == ("PUBLISHING" if a.resume else "READY"),
             f"Run status is {run and run[3]}; use --resume only for PUBLISHING runs")
        rows = control.cursor().execute(LATEST_ATTEMPTS, a.bridge_run_id).fetchall()
        attempts = {r[0]: {"attempt": r[1], "status": r[2], "source_rows": r[4], "parquet_rows": r[5],
                           "delta_rows": r[6], "delta_target": r[7]} for r in rows}
        need(set(attempts) <= set(by_mapping), "Run has unexpected mapping attempts")
        # A SUPERSEDED latest attempt means an earlier pass of this run found a newer release live.
        # Report it as superseded only if the target really holds a newer sequence; anything else
        # (for example state written by an older version) is an ordinary exclusion.
        superseded = []
        for mid in sorted(by_mapping):
            if mid in attempts and attempts[mid]["status"] == "SUPERSEDED":
                high = fetchone(control, "SELECT high_water_sequence FROM bridge.target_state WHERE target_key=?",
                                target_key(by_mapping[mid]))
                if high and high[0] is not None and int(high[0]) > int(run[4]):
                    superseded.append(mid)
        # ABANDONED: an operator gave this table's publication up with recovery.py abandon-publication.
        # It is deliberately excluded, also in strict mode, and the other tables can still finish.
        abandoned = sorted(mid for mid in by_mapping if mid in attempts and attempts[mid]["status"] == "ABANDONED")
        skipped = sorted(mid for mid in by_mapping
                         if mid not in superseded and mid not in abandoned
                         and (mid not in attempts or attempts[mid]["status"] != "READY"))
        need(not skipped or cfg.get("allow_partial_release", False), "Run has missing or unready mappings")
        for mid, r in attempts.items():
            if r["status"] != "READY":
                continue
            need(r["source_rows"] == r["parquet_rows"] == r["delta_rows"], f"Mapping not reconciled: {mid}")
            need(r["delta_target"] == delta_target(by_mapping[mid], a.bridge_run_id, r["attempt"]),
                 f"Recorded Delta target differs: {mid}")
        token = claim_run(control, a.bridge_run_id, (run[3],), "PUBLISHING", cfg.get("takeover_after_minutes", 150))
    ctx = {"run_id": a.bridge_run_id, "token": token, "release": run[2], "upstream_run_id": run[0],
           "sequence": int(run[4]), "resume": a.resume}
    try:
        with RunLease(a.bridge_run_id, token, cfg.get("heartbeat_seconds", 60)) as lease:
            failures, outcomes = [], {mid: "superseded-by-newer" for mid in superseded}
            with ThreadPoolExecutor(max_workers=cfg.get("max_publisher_workers", 1)) as pool:
                futures = {pool.submit(publish_one, cfg, ctx, lease, m, attempts[m["mapping_id"]]): m["mapping_id"]
                           for m in cfg["mappings"]
                           if m["mapping_id"] not in skipped and m["mapping_id"] not in superseded
                           and m["mapping_id"] not in abandoned}
                for future in as_completed(futures):
                    try:
                        outcomes[futures[future]] = future.result()
                    except BaseException as exc:
                        failures.append(exc)
                        print(f"ERROR mapping {futures[future]}: {exc}")
            if failures:
                raise PhaseError(f"{len(failures)} publication(s) failed; first: {failures[0]}", failures)
            lease.check()
            # A superseded target was not published by this run. This also covers a run
            # for which every target was superseded, including after --resume.
            final_status = ("PARTIALLY_PUBLISHED" if skipped or abandoned or any(
                value == "superseded-by-newer" for value in outcomes.values()) else "PUBLISHED")
            with db("BRIDGE_CONTROL_ODBC") as control:
                update_run(control, a.bridge_run_id, token, "PUBLISHING", final_status, release_lease=True)
    except BaseException as exc:
        keep = is_indeterminate(exc)
        try:
            with db("BRIDGE_CONTROL_ODBC") as control:
                # PUBLISHING stays: other tables may be live. Release the lease so --resume can
                # reconcile, unless an external job may still be running.
                control.cursor().execute(
                    "UPDATE bridge.runs SET updated_utc=SYSUTCDATETIME(),"
                    "orchestrator_token=CASE WHEN ?=1 THEN orchestrator_token ELSE NULL END "
                    "WHERE bridge_run_id=? AND orchestrator_token=? AND status='PUBLISHING'",
                    1 if keep else 0, a.bridge_run_id, token)
                control.commit()
        except Exception as record_error:
            print(f"WARNING could not release publication lease: {record_error}")
        raise
    print(json.dumps({"bridge_run_id": a.bridge_run_id,
                      "status": final_status,
                      "excluded": skipped,
                      "abandoned": abandoned,
                      "superseded": sorted(k for k, v in outcomes.items() if v == "superseded-by-newer"),
                      "published": sorted(k for k, v in outcomes.items() if v in ("published", "reconciled",
                                                                                   "already-published")),
                      "targets": outcomes}))


if __name__ == "__main__":
    main()
