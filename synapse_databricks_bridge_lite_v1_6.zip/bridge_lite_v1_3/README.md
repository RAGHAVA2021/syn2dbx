# Synapse → ADLS → Databricks daily table bridge (lite, v1.6)

Copies Synapse dedicated-pool tables (or simple views over them) that are refreshed once a day into Unity Catalog Delta tables. Every day it follows the same four steps:

1. Count each table after the refresh.
2. Export each table with CETAS to Parquet in ADLS.
3. Load each export into a private candidate table, checking that the row counts match at every stage.
4. Atomically replace each consumer table from its candidate.

> **Read [`DESIGN.md`](DESIGN.md) first.** The package assumes one daily refresh, no other writers, and independent tables. It relies on your scheduler to keep the refresh and the export from overlapping.

This is parameterised code, not a finished deployment. The example config uses placeholder names. Real mappings, identities, networking and Databricks jobs must be supplied and tested (see *Before production*).

**v1.6** reserves each audit ID and sequence in Azure SQL before writing its Synapse
audit. This prevents overlapping audit triggers from assigning the same sequence. For
an existing installation, apply `sql/06_upgrade_azure_sql_v1_6.sql` between runs,
before replacing the Python files. Grant the orchestration identity SELECT/INSERT on
the new `bridge.audit_reservations` table. A failed audit may leave a reserved sequence;
start its replacement with a new upstream run ID. Existing config hashes are unchanged.

**v1.5** fixes recovery and reporting defects. There are no config or hash changes in
v1.5; replace the `python/`, `databricks/` and `tests/` files as a unit, between runs.

- A run left in `EXTRACTING`/`LOADING` with an `INDETERMINATE` attempt (the process died, or the
  control database failed, between the two writes) is no longer stuck: after its lease expires,
  `--resume` marks it `FAILED`, so `resolve-attempt` and `abandon-run` work again.
- A previous attempt is marked `SUPERSEDED` only in the same transaction that inserts its
  replacement. A retry that fails before starting leaves the table reported as `excluded`, not
  `superseded`. `publish_run.py` also reports a table as superseded only when its target really
  holds a newer release.
- `abandon-publication` gives up only that table: its attempt becomes `ABANDONED`, and the run
  stays `PUBLISHING` while other `READY` tables are unpublished, so `publish_run.py --resume` can
  finish them (also in strict mode). The command's output says which applies.
- A failure while handling an audited zero-row source is recorded on the attempt.
- A source read recorded as finished (`SUCCEEDED`/`FAILED`) but not yet marked extracted is
  retried on `--resume` without operator evidence. Reads that may still be running still need it.
- `catalog.schema.table` must be at most 444 characters (the control table's key limit).
- New installations: `sql/01_azure_sql_control.sql` sets the session options its filtered index
  needs and sizes two key columns within SQL Server's key limits. Existing databases need no change.
- The loader reports a timestamp-to-date narrowing with its specific message.

**v1.4** fixes the status of a publication run with superseded targets: it ends
`PARTIALLY_PUBLISHED` even when every target was superseded and no table was written.
The folder keeps the `bridge_lite_v1_3` name so workspace paths do not change.
There are no config or hash changes. Apply `sql/05_upgrade_azure_sql_v1_3_1.sql`
if its unique index has not yet been applied to an existing control database.

The v1.3.1 fixes are included:

- A new publication claim clears the previous publication's operation state, so `abandon-publication`
  before submission works after a table's first publication (it also accepts state left by v1.3 claims).
- A second run for the same refresh is refused atomically with the insert, and a filtered unique
  index enforces one open run per refresh in the database.
- With `allow_partial_release=true`, a mapping that has used `max_attempts` is recorded `FAILED` and
  excluded on `--resume` instead of blocking the other mappings. Strict mode still stops.
- A table skipped because a newer release is already live now has its attempt recorded `SUPERSEDED`,
  and `publish_run.py` lists `published` and `superseded` tables separately in its output.
- Job IDs are verified with the Jobs API before any work. A definite Databricks rejection of a
  submission (400/401/403/404) is an ordinary, retryable failure instead of an unknown outcome.

The v1.3 loader accepts an audited empty table and checks that casts preserve non-null
source values. Existing v1.2 control tables and config hashes are compatible; replace
the loader notebook and orchestration files as a unit, and resume only after any
older in-flight Databricks loader run has reached a terminal state.

## Files

| File | Purpose |
|---|---|
| `DESIGN.md` | Assumptions, the scheduling rule, guarantees and scope |
| `SCRIPT_GUIDE.md` | Every script in execution order |
| `WHERE_TO_ENTER_VALUES.md` | Config fields, environment variables, storage, jobs and grants |
| `config.example.json` | Example inventory with two tables |
| `sql/01_azure_sql_control.sql` | Azure SQL control tables (audit reservations, runs, attempts, per-table state, recovery log) |
| `sql/06_upgrade_azure_sql_v1_6.sql` | Adds the audit reservation table to an existing control database |
| `sql/05_upgrade_azure_sql_v1_3_1.sql` | Adds the one-open-run-per-refresh index to an existing control database |
| `sql/02_synapse_setup.sql` | Synapse credential, external data source, Parquet format, audit tables, grants |
| `python/generate_mappings.py`, `databricks/generate_mappings_pyspark.py` | Generate the inventory from a Synapse schema |
| `python/profile_inventory.py`, `databricks/profile_inventory_pyspark.py` | Optional size classification from DMVs |
| `python/source_metadata.py` | Source schema hash (CLI and library) |
| `python/render_setup.py` | Control-table seed and Unity Catalog schema SQL |
| `python/upstream_audit.py` | Nightly: record row counts after the refresh |
| `python/bridge_run.py` + `databricks/load_candidate.py` | Nightly: CETAS export and candidate load |
| `python/publish_run.py` + `databricks/publish.py` | Nightly: atomic table replacement |
| `python/retire_releases.py` + `databricks/retire_releases.py` | Periodic cleanup of old candidates and staging files |
| `python/recovery.py` | Audited recovery after unknown outcomes; abandoning a run |
| `tests/` | Contract tests and an end-to-end simulation on SQLite |

## Setup

1. **Inventory.** Generate `config.json` (`WHERE_TO_ENTER_VALUES.md`), review every mapping and the exceptions report, and fill in `staging_abfss_root`. Optionally profile it.
2. **Control database.** Run `sql/01_azure_sql_control.sql` in a new Azure SQL control database. Grant the orchestration user SELECT/INSERT/UPDATE on schema `bridge`. When upgrading from v1.1, finish or abandon in-progress runs with v1.1 first, then run `sql/03_upgrade_azure_sql_v1_1.sql`. The v1.2 hash covers a different set of config fields; do not resume a v1.1 run with v1.2 scripts. For an existing v1.2/v1.3 control database, run `sql/05_upgrade_azure_sql_v1_3_1.sql`. For any existing installation, also run `sql/06_upgrade_azure_sql_v1_6.sql` before the first v1.6 audit.
3. **Synapse.** Have an administrator create the database master key. Set the ADLS container in `sql/02_synapse_setup.sql`, run it once in the dedicated pool, and apply the grants at its end to two different users: CETAS and audit. For a v1.1 installation, run `sql/04_upgrade_synapse_v1_1.sql` instead.
4. **Storage and Unity Catalog.** Grant the Synapse workspace managed identity write access to the staging container. Create the UC storage credential and the external location, and grant `READ FILES` to the three job identities.
5. **Seed.** Run `python python/render_setup.py --config config.json --output-dir generated`, then execute:
   - `generated/azure_sql_seed.sql` in the control database;
   - `generated/unity_catalog_setup.sql` on a SQL warehouse.

   Repeat for every new inventory wave.
6. **Jobs.** Create the loader, publisher and retention serverless jobs as described in `WHERE_TO_ENTER_VALUES.md`, including the timeout, retries and concurrency settings. Put their IDs in the config.
7. **Control host.** Install ODBC Driver 18 and `pip install -r requirements.txt`. Set `BRIDGE_CONTROL_ODBC`, `BRIDGE_SYNAPSE_AUDIT_ODBC` and `BRIDGE_CETAS_ODBC`, and configure Databricks authentication.
8. **Test** the whole chain on representative tables with the real identities, including the largest ones, before tuning the worker limits.

## Nightly chain

Run as **one** orchestrated job with success dependencies and a concurrency of 1 (`DESIGN.md`):

```bash
# N1: your existing Synapse refresh runs here and must finish first.
python python/upstream_audit.py --config config.json --upstream-run-id SYN_20260922 --business-date 2026-09-22
python python/bridge_run.py     --config config.json --upstream-run-id SYN_20260922 --bridge-run-id BRG_20260922
python python/publish_run.py    --config config.json --bridge-run-id BRG_20260922
```

Choose IDs your scheduler can derive, for example from the business date. Suffix a second run on the same day (`BRG_20260922_2`). `bridge_run.py` takes the sequence and business date from the audit, so the three commands cannot disagree about which day they process.

Periodically (for example weekly), review the dry run first, then apply:

```bash
python python/retire_releases.py --config config.json
python python/retire_releases.py --config config.json --execute --delete-staging
```

## Failure and recovery

Nothing retries automatically. Every rerun is an explicit `--resume` of the same run, and the scripts refuse a second run for the same refresh while one is open.

| Situation | What to do |
|---|---|
| A run is `PARTIALLY_PUBLISHED` | Check `excluded`, `abandoned` and `superseded` in the publisher output. Investigate excluded attempts; superseded tables already have a newer release. The status also applies when no table was written because all were superseded. |
| `bridge_run.py` failed in strict mode or with an unknown operation | Fix or resolve the cause, then rerun with `--resume`. READY tables are kept; failed ones may be re-extracted up to `max_attempts`. |
| The control host died mid-run | Rerun with `--resume` after `takeover_after_minutes`. In-flight operations become `INDETERMINATE` and must be resolved first (next row). |
| An attempt is `INDETERMINATE` | Check the stored external ID (`source_request_id` for CETAS, `loader_run_id` for the loader) in Synapse or Databricks. When it is terminal, run `recovery.py resolve-attempt`, then `--resume`. |
| A newer refresh was audited before the failed run could finish | The run can no longer read its day's data. Run `recovery.py abandon-run`, then start a new run for the new refresh. |
| `publish_run.py` failed | Rerun with `--resume`. Each remaining table is inspected in Delta first, and a commit whose acknowledgement was lost is reconciled, not repeated. |
| A publisher job's outcome is unknown | Check the stored `publish_external_run_id`. When it is terminal and the old process has stopped, run `recovery.py resolve-publication`, then `publish_run.py --resume`. |
| A table's publication must be given up | `recovery.py abandon-publication` (after checking the Delta table). Only that table is given up. If the output shows `"run_status": "PUBLISHING"`, other tables are still unpublished: finish them with `publish_run.py --resume`, or give them up with `abandon-publishing-run`. |
| The publisher failed before receiving an external run ID | After verifying the old orchestrator stopped and no external submission occurred, `abandon-publication` can release its claim. |
| A mapping reached `max_attempts` in partial mode | `--resume` records it `FAILED` and continues with the other mappings; it is retried in the next daily run. |
| A run is stuck in `PUBLISHING` with no table claims | Use `recovery.py abandon-publishing-run` after the lease has been released or expired. This also gives up any `READY` tables not yet published. |

`takeover_after_minutes` must be at least 135: the 2-hour job timeout plus the 15-minute cancellation window. The example value is 150.

### Recovery commands and evidence files

```bash
python python/recovery.py resolve-attempt --bridge-run-id BRG_20260922 --mapping-id MAP_v_orders --attempt 1 \
  --actor alice --reason "CETAS request verified cancelled" --evidence terminal.json
python python/recovery.py resolve-publication --bridge-run-id BRG_20260922 --target-key table:analytics.gold.orders \
  --actor alice --reason "publisher run verified finished" --evidence publisher_terminal.json
python python/recovery.py abandon-publication --bridge-run-id BRG_20260922 --config config.json --target-key table:analytics.gold.orders \
  --actor alice --reason "..." --evidence publication_terminal.json
python python/recovery.py abandon-publishing-run --bridge-run-id BRG_20260922 --config config.json \
  --actor alice --reason "no claims remain" --evidence publishing_stopped.json
python python/recovery.py abandon-run --bridge-run-id BRG_20260922 --config config.json \
  --actor alice --reason "superseded by SYN_20260923"
```

The evidence is a JSON record of what you checked. Every file needs a non-empty `evidence_uri` pointing to where that check is kept, such as a monitor link or a ticket. Only create the file after actually checking; it is the audit record of that check.

- **`resolve-attempt`:** `{"phase": "SOURCE" or "LOADER", "external_terminal": true, "safe_to_retry": true, "external_run_id": "<stored ID>", "evidence_uri": "..."}`. `phase` must name the operation that is unresolved.
- **`resolve-publication`:** `{"external_terminal": true, "safe_to_resume": true, "orchestrator_stopped": true, "external_run_id": "<stored ID>", "evidence_uri": "..."}`.
- **`abandon-publication` with a stored external ID:** `{"external_terminal": true, "orchestrator_stopped": true, "delta_state_verified": true, "safe_to_abandon": true, "external_run_id": "<stored ID>", "evidence_uri": "..."}`. Its run lease must be released or expired.
- **`abandon-publication` before submission (no stored ID and no in-flight operation state):** `{"no_external_submission": true, "orchestrator_stopped": true, "delta_state_verified": true, "safe_to_abandon": true, "evidence_uri": "..."}`. Check the job history before asserting no submission.
- **`abandon-publishing-run`:** `{"orchestrator_stopped": true, "safe_to_abandon": true, "evidence_uri": "..."}`. Refuses outstanding claims or a live lease.

When a Databricks submission's answer was lost, the stored loader or publisher ID is a `token:...` value. Look up the job's runs for that idempotency token:

- If you find a run, add `"idempotency_token": "<stored token>"` and give the real run ID as `external_run_id`.
- If no run exists, repeat the stored `token:...` value as `external_run_id`.

## Tests

```bash
pip install -r requirements-dev.txt
python -m compileall -q python databricks tests
python -m pytest -q tests
```

The tests cover:

- **`test_contract.py`:** fail-closed config validation, naming and paths, and the classification of CETAS and Databricks errors.
- **`test_static.py`:** notebook sanity checks, and that the loader and publisher agree on metadata columns.
- **`test_orchestration_sim.py`:** the real scripts end to end against SQLite stand-ins for Azure SQL and Synapse, with fake CETAS and Databricks. It covers the happy path, next-day replacement, failures and resume, lease takeover, a newer refresh during a read, abandoning a stale run, rejected loader results, indeterminate operations and their recovery, lost publisher acknowledgements, overlapping runs and table claims, and retention windows.

- **`test_regressions_v1_3_1.py`, `test_regressions_v1_5.py`:** each fixed defect, reproduced on the same simulation.

These tests do not replace acceptance tests on Azure SQL, Synapse, ADLS and Databricks with the real identities.

## Before production

Prove these on the platform with the deployment identities:

- CETAS writes as the CETAS user, including text containing `|`, `"`, `\r`, `\n` and your largest tables.
- Measure the largest CETAS export; the ODBC statement timeout is two hours. A timeout needs terminal evidence and `resolve-attempt` before retrying.
- Include `date` columns and sentinel dates such as `0001-01-01` in CETAS → Spark tests. Validate physical Parquet type and values against Synapse before changing Parquet rebase settings.
- The loader reads the staging path through the external location on serverless.
- A source with zero audited rows produces an empty candidate and consumer table; on resume, the empty release is identified by `bridge.release_id` and `bridge.load_attempt` table properties.
- In partial mode, one mapped source has schema drift and another CETAS or loader task fails terminally. Confirm only healthy tables advance; investigate `EXCLUDED` and `PARTIALLY_PUBLISHED` before the next refresh.
- The publisher's `CREATE OR REPLACE TABLE … TBLPROPERTIES … AS SELECT` works with `MANAGE` plus `CREATE TABLE`, and existing consumer grants survive the replacement.
- Job timeout, disabled auto-optimization retries and concurrent-run limits are set as documented.
- The full inventory's nightly duration fits your window. Tune `max_extraction_workers`, `extraction_class_limits`, `max_loader_workers` and `max_publisher_workers` from measurements.
- The scheduler really enforces the no-overlap rule. Include a test in which the refresh runs late.
- Measure managed Delta history, retained candidates and staged Parquet together. Arrange `VACUUM` or managed predictive optimization according to your storage policy; `delta.deletedFileRetentionDuration` does not run cleanup by itself.
- Verify table and column comments and clustering after replacement if consumers rely on them; they are not expressed in this package's `CREATE OR REPLACE` statement.
- You have practised a manual rollback: `CREATE OR REPLACE TABLE <consumer> AS SELECT … FROM <previous candidate>`, then update `bridge.target_state` to match.
