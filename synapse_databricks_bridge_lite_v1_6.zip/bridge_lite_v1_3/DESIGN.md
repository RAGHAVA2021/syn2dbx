# Design: daily static-table copy from Synapse to Databricks

## Situation this package is built for

- Synapse dedicated-pool tables (or simple views over them) are refreshed **once a day** by one scheduled job.
- Nothing else writes to them: no users, no applications, no ad-hoc support fixes.
- Each healthy table is copied in full and replaces its Databricks copy. Tables are independent: a drifted or failed mapping remains on its previous release while healthy mappings advance. Configure `allow_partial_release=false` if the full inventory must succeed together.

If any of these stops being true, read *Outside this scope* below before relying on the package.

## The one rule the schedule must enforce

**The daily refresh and the bridge's source reads must never overlap.**

A dedicated SQL pool reads with `READ UNCOMMITTED` unless the database was changed to `READ_COMMITTED_SNAPSHOT`. A CETAS export that runs while a refresh is writing can therefore copy half-written data without raising any error.

Enforce the rule in the orchestrator (Synapse pipeline, ADF, Databricks Workflows, Control-M, …) with a single chain that runs one instance at a time:

```text
refresh  ──success──►  upstream_audit.py  ──success──►  bridge_run.py  ──success──►  publish_run.py
```

- Use **success dependencies**, not clock times: a late refresh must delay the bridge, never overlap it.
- Set the chain's **concurrency to 1**, so a manual rerun or backfill cannot start a refresh while `bridge_run.py` is reading.
- A manual refresh outside the chain must also be followed by `upstream_audit.py` before any bridge run uses it.

`publish_run.py` only reads Databricks candidate tables, never Synapse. The next refresh may start as soon as `bridge_run.py` has finished.

## Backstops in the code

The code cannot see a refresh that is in progress. It does catch the common scheduling mistakes after the fact:

| Check | Where | Catches |
|---|---|---|
| Audited row count = Parquet rows = Delta rows, per table | loader job, `bridge_run.py`, publisher job | A refresh that changed a table's row count between the audit and the read |
| Source schema hash equals the reviewed config | `upstream_audit.py`, `bridge_run.py` | Columns added, removed, retyped or reordered |
| The audited refresh is still the newest one, before **and after** every read | `bridge_run.py` | A resumed or late run reading tables that a newer refresh has already replaced |
| Each table's high-water sequence | `bridge_run.py`, `publish_run.py` | An older day overwriting a newer one |
| One open run per refresh | `bridge_run.py` (atomic insert) and a filtered unique index on `bridge.runs` | An orchestrator retry starting a second, parallel run |

Row counts do not detect a change that keeps the count the same. That residual risk is why the schedule rule above remains the primary control.

## What a run guarantees

- **Consumers never see a partial table.** Each table is loaded into a private, attempt-specific candidate table first, checked, and only then swapped in with one atomic `CREATE OR REPLACE TABLE`.
- **Each table is either the new day or the previous day, never a mixture.** A failed mapping can remain on the previous day until a later daily run succeeds. Alert on `EXCLUDED` audits and `PARTIALLY_PUBLISHED` runs. A run superseded by newer releases also ends `PARTIALLY_PUBLISHED`, including when it published no tables.
- **A run interrupted before READY is resumable.** `--resume` keeps READY tables, reloads extracted tables from retained Parquet, and re-extracts failed ones. Once a partial run publishes, excluded mappings are retried in the next daily run.
- **Nothing is retried blindly.** An external operation whose outcome is unknown (lost connection, timeout, killed orchestrator) blocks the run until someone checks the stored external ID and records evidence with `recovery.py`.
- **Two processes cannot act on the same run or table.** A heartbeat lease protects each run, and a claim protects each table during publication.
- **Rollback material is kept.** The previous release's candidate table and any Parquet files are kept; older releases are kept until `retention_days_published` days after their publication. Rollback itself is a manual `CREATE OR REPLACE TABLE … AS SELECT` from the kept candidate.
- **An audited zero-row source publishes an empty Delta table.** No CETAS request is submitted for it. The loader constructs an empty table with the reviewed column types, and the publisher records the release and attempt in table properties so recovery and retention can identify the empty release.
- **A resumed run uses exactly its starting data contract.** The config hash pins mappings, staging location and release policy while permitting fixes to job IDs, worker limits, heartbeat and retention. Each job ID is read through the Jobs API before any external work, so a wrong ID fails the run up front.

## Outside this scope

| Situation | What this package lacks | What to add |
|---|---|---|
| Other writers (support scripts, replays, other schedulers) can modify the source tables | A shared lock that every writer must hold | An orchestration fence that every writer acquires, or immutable per-day source tables |
| Several tables must switch to the new day together | Group publication | A release-pointer design (views over snapshot tables that switch via one control row) |
| CETAS cannot export some objects (LOBs above 1 MB, some text content, unsupported types) | Any extraction method other than CETAS | A Copy Activity route, or a reviewed view that converts the problem columns |
| Consumers need policy, row-filter or masking tests before new data goes live | Publication gates | A gate step between `bridge_run.py` and `publish_run.py` |
