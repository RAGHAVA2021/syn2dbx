"""Regression tests for the defects fixed in v1.3.1, on the same SQLite simulation harness."""
import json
import sqlite3
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import bridge_run  # noqa: E402
import publish_run  # noqa: E402
import source_metadata  # noqa: E402
from test_orchestration_sim import CUSTOMER, calls, env, reset_clock  # noqa: E402,F401


def _publish_fails_before_submission(monkeypatch):
    def upload_fails(cfg, job_id, payload, run_id, *callbacks):
        raise RuntimeError("ADLS manifest upload failed")   # before any Databricks call
    monkeypatch.setattr(publish_run, "notebook_job", upload_fails)


# 1. abandon-publication before submission must work after a table's first publication.
def test_fresh_claim_clears_previous_operation_state(env, monkeypatch):
    env["extract"]()
    env["publish"]()
    env["audit"]("SYN2", "2026-09-23")
    env["extract"]("BRG2", "SYN2")
    _publish_fails_before_submission(monkeypatch)
    with pytest.raises(bridge_run.PhaseError):
        env["publish"]("BRG2")
    assert env["query"]("SELECT publish_owner, publish_external_run_id, publish_operation_state "
                        "FROM bridge.target_state WHERE target_key=?", CUSTOMER) == [("BRG2", None, None)]
    env["recover"]("abandon-publication", "BRG2", evidence={
        "no_external_submission": True, "orchestrator_stopped": True,
        "delta_state_verified": True, "safe_to_abandon": True}, target_key=CUSTOMER)
    assert env["query"]("SELECT publish_owner FROM bridge.target_state WHERE target_key=?", CUSTOMER) == [(None,)]


def test_abandon_tolerates_state_left_by_pre_fix_claims(env):
    env["extract"]()
    env["publish"]()
    env["audit"]("SYN2", "2026-09-23")
    env["extract"]("BRG2", "SYN2")
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING', orchestrator_token=NULL WHERE bridge_run_id='BRG2'")
    env["query"]("UPDATE bridge.target_state SET publish_owner='BRG2', publish_token='dead' WHERE target_key=?",
                 CUSTOMER)                                  # claim taken by v1.3: 'SUCCEEDED' left in place
    env["recover"]("abandon-publication", "BRG2", evidence={
        "no_external_submission": True, "orchestrator_stopped": True,
        "delta_state_verified": True, "safe_to_abandon": True}, target_key=CUSTOMER)


def test_resumed_owner_keeps_its_unresolved_publisher_state(env):
    env["extract"]()
    env["state"]["fail_after_publish"] = True
    with pytest.raises(bridge_run.PhaseError):
        env["publish"]()
    env["query"]("UPDATE bridge.runs SET orchestrator_token=NULL")          # lease released, publisher unknown
    with pytest.raises(bridge_run.PhaseError, match="unresolved publisher"):
        env["publish"]("BRG1", "--resume")
    assert env["query"]("SELECT count(*) FROM bridge.target_state "
                        "WHERE publish_operation_state IN ('RUNNING','UNKNOWN')") == [(1,)]


# 2. Two triggers for the same refresh cannot both start a run.
def test_racing_second_run_for_same_refresh_is_refused(env, monkeypatch):
    fired = []

    def racing_hash(conn, schema, view):
        if not fired:
            fired.append(1)
            env["extract"]("BRG1b", "SYN1")       # second trigger during BRG1's Synapse checks
        return "sha256:x"
    monkeypatch.setattr(source_metadata, "schema_hash", racing_hash)
    with pytest.raises(RuntimeError, match="started meanwhile"):
        env["extract"]("BRG1", "SYN1")
    assert env["query"]("SELECT bridge_run_id FROM bridge.runs") == [("BRG1b",)]
    assert not calls(env, "extract", "MAP_v_customer")[1:]      # BRG1 extracted nothing


def test_database_index_backstops_duplicate_open_runs(env):
    env["extract"]()
    with pytest.raises(sqlite3.IntegrityError):
        env["query"]("INSERT INTO bridge.runs(bridge_run_id,upstream_run_id,upstream_sequence,business_date,"
                     "inventory_version,config_sha256,release_id,status) "
                     "VALUES ('X','SYN1',1,'2026-09-22','v','h','rel_X','EXTRACTING')")
    env["recover"]("abandon-run", config=env["cfg"])            # finished runs do not block
    env["extract"]("BRG1c", "SYN1")


# 3. In partial mode an exhausted mapping is excluded instead of blocking the resume.
def _customer_loader_unknown_sales_failed(env, monkeypatch):
    env["set_config"](allow_partial_release=True, max_attempts=1)
    env["state"]["fail_extract"].add("MAP_v_sales")
    real_job = bridge_run.notebook_job

    def loader_unknown(cfg, job_id, payload, run_id, started=None, terminal=None):
        if payload.get("mapping_id") == "MAP_v_customer":
            started("dbx_lost")
            raise bridge_run.Indeterminate("polling failed")
        return real_job(cfg, job_id, payload, run_id, started, terminal)
    monkeypatch.setattr(bridge_run, "notebook_job", loader_unknown)
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    env["recover"]("resolve-attempt", evidence={"external_terminal": True, "safe_to_retry": True,
                   "phase": "LOADER", "external_run_id": "dbx_lost"}, mapping_id="MAP_v_customer", attempt=1)
    monkeypatch.setattr(bridge_run, "notebook_job", real_job)


def test_partial_resume_excludes_exhausted_mapping(env, monkeypatch):
    _customer_loader_unknown_sales_failed(env, monkeypatch)
    env["extract"]("BRG1", "SYN1", "--resume")
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]
    assert sorted(env["query"]("SELECT mapping_id, attempt, status FROM bridge.object_attempts")) == \
        [("MAP_v_customer", 1, "READY"), ("MAP_v_sales", 1, "FAILED")]
    env["publish"]()
    assert env["state"]["delta"] == {"customer": "rel_BRG1"}
    assert env["query"]("SELECT status FROM bridge.runs") == [("PARTIALLY_PUBLISHED",)]


def test_strict_resume_still_stops_at_max_attempts(env):
    env["set_config"](max_attempts=1)                  # allow_partial_release is false in the harness
    env["state"]["fail_extract"].add("MAP_v_sales")
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    with pytest.raises(RuntimeError, match="reached max_attempts"):
        env["extract"]("BRG1", "SYN1", "--resume")


def test_partial_resume_retires_never_submitted_attempt_at_limit(env):
    env["set_config"](allow_partial_release=True, max_attempts=1)
    env["extract"]()
    env["query"]("UPDATE bridge.runs SET status='FAILED', orchestrator_token=NULL")
    env["query"]("UPDATE bridge.object_attempts SET status='EXTRACTING', source_operation_state='PENDING' "
                 "WHERE mapping_id='MAP_v_sales'")                       # died before submission
    env["extract"]("BRG1", "SYN1", "--resume")
    assert env["query"]("SELECT status, source_operation_state FROM bridge.object_attempts "
                        "WHERE mapping_id='MAP_v_sales'") == [("FAILED", "NOT_STARTED")]


# 4. A table skipped because a newer release is live is recorded as SUPERSEDED.
def test_superseded_tables_are_recorded(env, capsys):
    env["extract"]()
    env["audit"]("SYN2", "2026-09-23")
    env["extract"]("BRG2", "SYN2")
    env["publish"]("BRG2")
    capsys.readouterr()
    env["publish"]("BRG1")
    out = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert out["published"] == [] and out["superseded"] == ["MAP_v_customer", "MAP_v_sales"]
    assert out["status"] == "PARTIALLY_PUBLISHED"
    assert env["query"]("SELECT status FROM bridge.runs WHERE bridge_run_id='BRG1'") == \
        [("PARTIALLY_PUBLISHED",)]
    assert set(env["query"]("SELECT status FROM bridge.object_attempts WHERE bridge_run_id='BRG1'")) == \
        {("SUPERSEDED",)}


def test_superseded_mapping_is_settled_on_resume(env):
    env["extract"]()
    env["audit"]("SYN2", "2026-09-23")
    env["extract"]("BRG2", "SYN2")
    env["publish"]("BRG2")
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING', orchestrator_token=NULL WHERE bridge_run_id='BRG1'")
    env["query"]("UPDATE bridge.object_attempts SET status='SUPERSEDED' WHERE bridge_run_id='BRG1' "
                 "AND mapping_id='MAP_v_customer'")                      # first pass got this far
    env["publish"]("BRG1", "--resume")                                  # strict mode: not "unready"
    assert env["query"]("SELECT status FROM bridge.runs WHERE bridge_run_id='BRG1'") == \
        [("PARTIALLY_PUBLISHED",)]


def test_one_superseded_and_one_published_is_partial(env, capsys):
    env["extract"]()
    env["query"]("UPDATE bridge.target_state SET published_release_id='rel_BRG2',"
                 "published_sequence=2, high_water_sequence=2, control_version=1 WHERE target_key=?", CUSTOMER)
    env["state"]["delta"]["customer"] = "rel_BRG2"
    capsys.readouterr()
    env["publish"]()
    out = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert out["status"] == "PARTIALLY_PUBLISHED"
    assert out["published"] == ["MAP_v_sales"]
    assert out["superseded"] == ["MAP_v_customer"]
    assert env["state"]["delta"] == {"customer": "rel_BRG2", "sales": "rel_BRG1"}


# 5. A definite Databricks rejection is an ordinary failure, not an unknown outcome.
sdk_errors = pytest.importorskip("databricks.sdk.errors")


@pytest.mark.parametrize("exc, rejected", [
    (sdk_errors.NotFound("job 42 does not exist"), True),
    (sdk_errors.ResourceDoesNotExist("job 42"), True),
    (sdk_errors.InvalidParameterValue("bad"), True),
    (sdk_errors.PermissionDenied("no"), True),
    (sdk_errors.TooManyRequests("slow down"), False),
    (sdk_errors.InternalError("5xx"), False),
    (TimeoutError("read timed out"), False),
    (ConnectionError("reset"), False),
])
def test_submission_rejected_classification(exc, rejected):
    assert bridge_run.submission_rejected(exc) is rejected


def _fake_client(monkeypatch, error):
    import databricks.sdk

    class Jobs:
        def run_now(self, **kwargs):
            raise error
    monkeypatch.setattr(databricks.sdk, "WorkspaceClient", lambda: SimpleNamespace(jobs=Jobs()))
    monkeypatch.setattr(bridge_run, "write_manifest", lambda cfg, run_id, payload: ("abfss://x/m.json", "0" * 64))


def test_rejected_submission_records_failed_and_is_retryable(monkeypatch):
    _fake_client(monkeypatch, sdk_errors.NotFound("job 42 does not exist"))
    started, ended = [], []
    with pytest.raises(RuntimeError, match="rejected") as info:
        bridge_run.notebook_job({}, 42, {"k": 1}, "BRG1", started.append, lambda i, s: ended.append((i, s)))
    assert not bridge_run.is_indeterminate(info.value)
    assert ended == [(started[0], "FAILED")] and started[0].startswith("token:")


def test_unclear_submission_error_stays_indeterminate(monkeypatch):
    _fake_client(monkeypatch, TimeoutError("read timed out"))
    ended = []
    with pytest.raises(bridge_run.Indeterminate):
        bridge_run.notebook_job({}, 42, {"k": 1}, "BRG1", lambda i: None, lambda i, s: ended.append(s))
    assert ended == []


def test_verify_jobs_refuses_unknown_job(monkeypatch):
    import databricks.sdk

    class Jobs:
        def get(self, job_id):
            if job_id == 99:
                raise sdk_errors.NotFound("no such job")
    monkeypatch.setattr(databricks.sdk, "WorkspaceClient", lambda: SimpleNamespace(jobs=Jobs()))
    bridge_run.verify_jobs({"loader_job_id": 1, "publisher_job_id": 2}, ("loader_job_id", "publisher_job_id"))
    with pytest.raises(RuntimeError, match="publisher_job_id 99"):
        bridge_run.verify_jobs({"loader_job_id": 1, "publisher_job_id": 99}, ("loader_job_id", "publisher_job_id"))
