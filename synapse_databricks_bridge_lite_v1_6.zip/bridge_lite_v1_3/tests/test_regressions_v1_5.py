"""Regression tests for the defects fixed in v1.5, on the same SQLite simulation harness."""
import json
import sys
import threading
from datetime import timedelta
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import bridge_run  # noqa: E402
import publish_run  # noqa: E402
import upstream_audit  # noqa: E402
from test_orchestration_sim import CLOCK, CUSTOMER, SALES, calls, env, reset_clock  # noqa: E402,F401

LOADER_EVIDENCE = {"external_terminal": True, "safe_to_retry": True, "phase": "LOADER",
                   "external_run_id": "dbx_lost"}


def test_audit_reservations_prevent_duplicate_sequences_from_stale_observations(env):
    # Both triggers observed Synapse sequence 1 before either made its reservation.
    assert upstream_audit.reserve_sequence("SYN2", None, 1) == 2
    assert upstream_audit.reserve_sequence("SYN3", None, 1) == 3
    assert env["query"]("SELECT upstream_run_id,upstream_sequence FROM bridge.audit_reservations "
                        "ORDER BY upstream_sequence") == [("SYN1", 1), ("SYN2", 2), ("SYN3", 3)]
    with pytest.raises(Exception):
        upstream_audit.reserve_sequence("SYN2", None, 1)


def _customer_loader_unknown(monkeypatch, sales_fails=False):
    real_job = bridge_run.notebook_job

    def loader(cfg, job_id, payload, run_id, started=None, terminal=None):
        if payload.get("mapping_id") == "MAP_v_customer":
            started("dbx_lost")
            raise bridge_run.Indeterminate("polling failed")
        if sales_fails and payload.get("mapping_id") == "MAP_v_sales":
            started("dbx_s"); terminal("dbx_s", "FAILED")
            raise RuntimeError("loader failed")
        return real_job(cfg, job_id, payload, run_id, started, terminal)
    monkeypatch.setattr(bridge_run, "notebook_job", loader)
    return real_job


# 1. An INDETERMINATE attempt in a run that never got marked FAILED is recoverable.
def test_lost_run_failed_write_is_recoverable(env, monkeypatch):
    real_job = _customer_loader_unknown(monkeypatch)
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    env["query"]("UPDATE bridge.runs SET status='LOADING'")        # the run-level FAILED write was lost
    monkeypatch.setattr(bridge_run, "notebook_job", real_job)
    with pytest.raises(RuntimeError, match="live lease"):           # the lease still protects a live process
        env["extract"]("BRG1", "SYN1", "--resume")
    CLOCK["now"] += timedelta(hours=5)
    with pytest.raises(RuntimeError, match="indeterminate external operation"):
        env["extract"]("BRG1", "SYN1", "--resume")                 # takes over and marks the run FAILED
    assert env["query"]("SELECT status FROM bridge.runs") == [("FAILED",)]
    env["recover"]("resolve-attempt", evidence=LOADER_EVIDENCE, mapping_id="MAP_v_customer", attempt=1)
    env["extract"]("BRG1", "SYN1", "--resume")
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]


def test_failed_run_with_indeterminate_attempt_still_just_stops(env, monkeypatch):
    _customer_loader_unknown(monkeypatch)
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    token = env["query"]("SELECT orchestrator_token FROM bridge.runs")
    with pytest.raises(RuntimeError, match="indeterminate external operation"):
        env["extract"]("BRG1", "SYN1", "--resume")                 # no takeover needed: already FAILED
    assert env["query"]("SELECT orchestrator_token FROM bridge.runs") == token


# 2. A failed retry is reported as excluded, never as superseded by a newer release.
def test_failed_retry_is_excluded_not_superseded(env, monkeypatch, capsys):
    env["set_config"](allow_partial_release=True, max_loader_retries_per_attempt=1)
    real_job = _customer_loader_unknown(monkeypatch, sales_fails=True)
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    env["recover"]("resolve-attempt", evidence=LOADER_EVIDENCE, mapping_id="MAP_v_customer", attempt=1)
    monkeypatch.setattr(bridge_run, "notebook_job", real_job)

    def not_empty(root, relative):
        if "MAP_v_sales/attempt-002" in relative:
            raise RuntimeError("Attempt prefix is not empty")
    monkeypatch.setattr(bridge_run, "require_empty_adls", not_empty)
    env["extract"]("BRG1", "SYN1", "--resume")
    assert env["query"]("SELECT attempt,status FROM bridge.object_attempts WHERE mapping_id='MAP_v_sales'") == \
        [(1, "EXTRACTED")]                                         # not SUPERSEDED: no successor exists
    capsys.readouterr()
    env["publish"]()
    out = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert out["excluded"] == ["MAP_v_sales"] and out["superseded"] == []
    assert out["status"] == "PARTIALLY_PUBLISHED"


def test_successful_retry_still_supersedes_previous_attempt(env, monkeypatch):
    env["set_config"](allow_partial_release=True, max_loader_retries_per_attempt=1)
    real_job = _customer_loader_unknown(monkeypatch, sales_fails=True)
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    env["recover"]("resolve-attempt", evidence=LOADER_EVIDENCE, mapping_id="MAP_v_customer", attempt=1)
    monkeypatch.setattr(bridge_run, "notebook_job", real_job)
    env["extract"]("BRG1", "SYN1", "--resume")
    assert env["query"]("SELECT attempt,status FROM bridge.object_attempts WHERE mapping_id='MAP_v_sales' "
                        "ORDER BY attempt") == [(1, "SUPERSEDED"), (2, "READY")]


def test_legacy_superseded_marker_without_newer_release_is_excluded(env, capsys):
    env["set_config"](allow_partial_release=True)
    env["extract"]()
    env["query"]("UPDATE bridge.object_attempts SET status='SUPERSEDED' WHERE mapping_id='MAP_v_sales'")
    capsys.readouterr()
    env["publish"]()
    out = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert out["excluded"] == ["MAP_v_sales"] and out["superseded"] == []


# 3. Abandoning one table's publication leaves the other tables publishable.
def test_abandon_publication_keeps_run_open_for_other_tables(env, monkeypatch, capsys):
    env["extract"]()
    real_state, real_job = publish_run.read_state, publish_run.notebook_job

    def flaky(key):
        if key == SALES:
            raise RuntimeError("transient control DB error")
        return real_state(key)

    def customer_fails(cfg, job_id, payload, run_id, started=None, terminal=None):
        if payload["mapping"]["target_table"] == "customer" and payload["mode"] == "PUBLISH":
            started("dbx_c"); terminal("dbx_c", "FAILED")
            raise RuntimeError("publisher failed")
        return real_job(cfg, job_id, payload, run_id, started, terminal)
    monkeypatch.setattr(publish_run, "read_state", flaky)
    monkeypatch.setattr(publish_run, "notebook_job", customer_fails)
    with pytest.raises(bridge_run.PhaseError):
        env["publish"]()
    capsys.readouterr()
    env["recover"]("abandon-publication", evidence={
        "external_terminal": True, "orchestrator_stopped": True, "delta_state_verified": True,
        "safe_to_abandon": True, "external_run_id": "dbx_c"}, target_key=CUSTOMER)
    out = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert out["run_status"] == "PUBLISHING" and out["unpublished_tables_remaining"] == 1
    monkeypatch.setattr(publish_run, "read_state", real_state)
    monkeypatch.setattr(publish_run, "notebook_job", real_job)
    env["publish"]("BRG1", "--resume")
    out = json.loads(capsys.readouterr().out.strip().splitlines()[-1])
    assert env["state"]["delta"] == {"sales": "rel_BRG1"}
    assert out["abandoned"] == ["MAP_v_customer"] and out["published"] == ["MAP_v_sales"]
    assert env["query"]("SELECT status FROM bridge.runs") == [("PARTIALLY_PUBLISHED",)]


def test_abandoning_the_last_open_table_finishes_the_run(env, monkeypatch):
    env["extract"]()
    real_job = publish_run.notebook_job

    def customer_fails(cfg, job_id, payload, run_id, started=None, terminal=None):
        if payload["mapping"]["target_table"] == "customer" and payload["mode"] == "PUBLISH":
            started("dbx_c"); terminal("dbx_c", "FAILED")
            raise RuntimeError("publisher failed")
        return real_job(cfg, job_id, payload, run_id, started, terminal)
    monkeypatch.setattr(publish_run, "notebook_job", customer_fails)
    with pytest.raises(bridge_run.PhaseError):
        env["publish"]()                                          # sales published, customer failed
    env["recover"]("abandon-publication", evidence={
        "external_terminal": True, "orchestrator_stopped": True, "delta_state_verified": True,
        "safe_to_abandon": True, "external_run_id": "dbx_c"}, target_key=CUSTOMER)
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLICATION_ABANDONED",)]


# 4. A failure in the zero-row path is recorded on the attempt.
def test_zero_row_failure_is_recorded(env, monkeypatch):
    env["set_config"](allow_partial_release=True)
    armed, real = set(), bridge_run.require_current_upstream   # per worker thread: extractions run in parallel

    def mark(root, relative):
        if "MAP_v_sales" in relative:
            armed.add(threading.get_ident())

    def check(syn, sequence):
        if threading.get_ident() in armed:
            armed.discard(threading.get_ident())
            raise RuntimeError("transient Synapse error")
        return real(syn, sequence)
    monkeypatch.setattr(bridge_run, "require_empty_adls", mark)
    monkeypatch.setattr(bridge_run, "require_current_upstream", check)
    env["query"]("UPDATE bridge_meta.upstream_object SET row_count=0 WHERE mapping_id='MAP_v_sales'", db="SYN")
    env["extract"]()
    row = env["query"]("SELECT status,source_operation_state,error_text FROM bridge.object_attempts "
                       "WHERE mapping_id='MAP_v_sales'")[0]
    assert row[:2] == ("FAILED", "NOT_STARTED") and "transient Synapse error" in row[2]


# 5. A source read recorded as terminal needs no operator evidence on resume.
@pytest.mark.parametrize("state", ["SUCCEEDED", "FAILED"])
def test_recorded_terminal_read_is_retried_without_evidence(env, state):
    env["extract"]()
    env["query"]("UPDATE bridge.runs SET status='FAILED', orchestrator_token=NULL")
    env["query"](f"UPDATE bridge.object_attempts SET status='EXTRACTING', source_operation_state='{state}' "
                 "WHERE mapping_id='MAP_v_sales'")                  # died before the EXTRACTED write
    env["extract"]("BRG1", "SYN1", "--resume")
    assert env["query"]("SELECT attempt,status FROM bridge.object_attempts WHERE mapping_id='MAP_v_sales' "
                        "ORDER BY attempt") == [(1, "SUPERSEDED"), (2, "READY")]


def test_running_read_still_requires_evidence(env):
    env["extract"]()
    env["query"]("UPDATE bridge.runs SET status='FAILED', orchestrator_token=NULL")
    env["query"]("UPDATE bridge.object_attempts SET status='EXTRACTING', source_operation_state='RUNNING' "
                 "WHERE mapping_id='MAP_v_sales'")
    with pytest.raises(RuntimeError, match="now INDETERMINATE"):
        env["extract"]("BRG1", "SYN1", "--resume")


# 6. Consumer names that cannot fit the control database key are refused at config time.
def test_overlong_consumer_name_is_refused(env):
    cfg = json.loads(env["cfg"].read_text())
    cfg["mappings"][0]["target_table"] = "t" * 440
    env["cfg"].write_text(json.dumps(cfg))
    with pytest.raises(RuntimeError, match="too long for the control database key"):
        bridge_run.config(env["cfg"])
