"""Executes the nightly scripts end to end against SQLite stand-ins.

Azure SQL and Synapse are emulated with SQLite (T-SQL functions translated); CETAS, ADLS
and Databricks jobs are replaced by fakes. This checks the control-state wiring: leases,
attempts, failure, --resume, reconciliation, recovery and retention. It does not replace
the platform acceptance tests.
"""
import json
import re
import sqlite3
import sys
from contextlib import contextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
import bridge_run  # noqa: E402
import publish_run  # noqa: E402
import recovery  # noqa: E402
import retire_releases as retention  # noqa: E402
import upstream_audit  # noqa: E402

CONTROL_DDL = """
CREATE TABLE bridge.audit_reservations(upstream_run_id TEXT PRIMARY KEY, upstream_sequence INT UNIQUE,
  reserved_utc TEXT);
CREATE TABLE bridge.runs(bridge_run_id TEXT PRIMARY KEY, upstream_run_id TEXT, upstream_sequence INT,
  business_date TEXT, inventory_version TEXT, config_sha256 TEXT, release_id TEXT UNIQUE, status TEXT,
  orchestrator_token TEXT, heartbeat_utc TEXT, created_utc TEXT, updated_utc TEXT);
CREATE UNIQUE INDEX bridge.UX_bridge_runs_open_upstream ON runs(upstream_run_id)
  WHERE status IN ('EXTRACTING','EXTRACTED','LOADING','READY','PUBLISHING','FAILED');
CREATE TABLE bridge.object_attempts(bridge_run_id TEXT, mapping_id TEXT, attempt INT, status TEXT,
  leaf_path TEXT UNIQUE, source_request_id TEXT, source_rows INT, parquet_rows INT, delta_rows INT,
  error_text TEXT, delta_target TEXT NOT NULL, target_key TEXT NOT NULL, consumer_target TEXT NOT NULL,
  source_operation_state TEXT, loader_run_id TEXT, loader_operation_state TEXT, loader_attempts INT DEFAULT 0,
  updated_utc TEXT, retired_utc TEXT, staging_deleted_utc TEXT,
  PRIMARY KEY(bridge_run_id,mapping_id,attempt));
CREATE TABLE bridge.target_state(target_key TEXT PRIMARY KEY, published_release_id TEXT, published_sequence INT,
  high_water_sequence INT DEFAULT -1, previous_release_id TEXT, control_version INT DEFAULT 0,
  publish_owner TEXT, publish_token TEXT, publish_claimed_utc TEXT, publish_external_run_id TEXT,
  publish_operation_state TEXT);
CREATE TABLE bridge.recovery_events(recovery_event_id INTEGER PRIMARY KEY, action TEXT, bridge_run_id TEXT,
  mapping_id TEXT, attempt INT, target_key TEXT, external_run_id TEXT, actor TEXT, evidence_uri TEXT,
  reason TEXT NOT NULL, at_utc TEXT);
"""
SYN_DDL = """
CREATE TABLE bridge_meta.upstream_run(upstream_run_id TEXT, upstream_sequence INT, business_date TEXT,
  status TEXT, completed_utc TEXT);
CREATE TABLE bridge_meta.upstream_object(upstream_run_id TEXT, mapping_id TEXT, source_schema_version TEXT,
  status TEXT, row_count INT, error_text TEXT, refresh_completed_utc TEXT);
"""
START = datetime(2026, 9, 22, 1, 0, 0)
CLOCK = {"now": START}


def ts(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S.%f")


def translate(sql):
    sql = re.sub(r"\bINSERT (bridge|bridge_meta)\.", r"INSERT INTO \1.", sql)
    sql = sql.replace(" WITH (UPDLOCK,HOLDLOCK)", "")
    sql = sql.replace(" WITH (TABLOCKX,HOLDLOCK)", "")
    sql = sql.replace("COUNT_BIG(", "count(").replace("count_big(", "count(")
    sql = sql.replace("DATEADD(minute,", "DATEADD('minute',")
    sql = sql.replace("DATEDIFF(hour,", "DATEDIFF('hour',")
    return sql


class Cursor:
    def __init__(self, conn):
        self.c = conn.raw.cursor()
        self.rowcount = -1

    def execute(self, sql, *params):
        params = [str(p) if hasattr(p, "isoformat") else p for p in params]
        self.c.execute(translate(sql), params)
        self.rowcount = self.c.rowcount
        return self

    def fetchone(self):
        return self.c.fetchone()

    def fetchall(self):
        return self.c.fetchall()


class Conn:
    def __init__(self, path, schema):
        self.raw = sqlite3.connect(":memory:", isolation_level="DEFERRED", check_same_thread=False)
        self.raw.execute(f"ATTACH DATABASE '{path}' AS {schema}")
        self.raw.create_function("SYSUTCDATETIME", 0, lambda: ts(CLOCK["now"]))
        self.raw.create_function("DATEADD", 3, lambda unit, n, t: ts(
            datetime.strptime(t, "%Y-%m-%d %H:%M:%S.%f") + timedelta(minutes=n)))
        self.raw.create_function("DATEDIFF", 3, lambda unit, start, end: None if start is None or end is None
                                 else int((datetime.strptime(end, "%Y-%m-%d %H:%M:%S.%f") -
                                           datetime.strptime(start, "%Y-%m-%d %H:%M:%S.%f")).total_seconds() // 3600))
        self.timeout = 0

    def cursor(self):
        return Cursor(self)

    def commit(self):
        self.raw.commit()

    def rollback(self):
        self.raw.rollback()

    def close(self):
        self.raw.close()


@pytest.fixture(autouse=True)
def reset_clock():
    CLOCK["now"] = START
    yield
    CLOCK["now"] = START


@pytest.fixture
def env(tmp_path, monkeypatch):
    control_db, syn_db = tmp_path / "control.db", tmp_path / "syn.db"
    for path, schema, ddl in ((control_db, "bridge", CONTROL_DDL), (syn_db, "bridge_meta", SYN_DDL)):
        c = Conn(path, schema); c.raw.executescript(ddl); c.commit(); c.close()

    @contextmanager
    def fake_db(var, autocommit=False):
        conn = Conn(control_db, "bridge") if var == "BRIDGE_CONTROL_ODBC" else Conn(syn_db, "bridge_meta")
        try:
            yield conn
        except BaseException:
            conn.rollback(); raise
        finally:
            conn.close()

    doc = json.loads((ROOT / "config.example.json").read_text())
    doc["allow_partial_release"] = False  # legacy all-mappings contract tests
    doc["staging_abfss_root"] = "abfss://landing@acct.dfs.core.windows.net"
    doc["loader_job_id"] = doc["publisher_job_id"] = doc["retention_job_id"] = 1
    doc["heartbeat_seconds"] = 600
    for m in doc["mappings"]:
        m["target_catalog"] = "cat"
        m["source_schema_version"] = "sha256:x"
    cfg_path = tmp_path / "config.json"
    cfg_path.write_text(json.dumps(doc))

    import render_setup
    azure_seed, _ = render_setup.render(bridge_run.config(cfg_path))
    with fake_db("BRIDGE_CONTROL_ODBC") as c:
        for stmt in azure_seed.splitlines():
            match = re.search(r"INSERT bridge\.target_state.*VALUES \((.*)\);", stmt)
            if match:                                           # the T-SQL IF wrapper is not SQLite
                c.cursor().execute(translate("INSERT bridge.target_state(target_key,published_release_id,"
                                             f"published_sequence,high_water_sequence) VALUES ({match.group(1)})"))
        c.commit()

    source_rows = {m["mapping_id"]: 10 + i for i, m in enumerate(doc["mappings"])}
    state = {"fail_extract": set(), "delta": {}, "calls": [], "fail_after_publish": False, "loader_result": None}

    def fake_extract(m, relative, started_callback=None, terminal_callback=None):
        state["calls"].append(("extract", m["mapping_id"], relative))
        if started_callback: started_callback("x_req")
        hook = state.pop("during_extract", None)              # atomic: runs at most once
        if hook:
            hook()
        if m["mapping_id"] in state["fail_extract"]:
            state["fail_extract"].discard(m["mapping_id"])
            raise RuntimeError("simulated CETAS failure")
        if terminal_callback: terminal_callback("x_req", "SUCCEEDED")
        return "x_req"

    def fake_job(cfg, job_id, payload, run_id, started_callback=None, terminal_callback=None):
        external_id = "dbx_" + str(len(state["calls"]) + 1)
        if started_callback:
            started_callback(external_id)
        mode = payload.get("mode")
        if "leaf_path" in payload:                                   # loader
            n = payload["source_rows"]
            state["calls"].append(("load", payload["mapping_id"], payload["attempt"]))
            result = {"source_rows": n, "parquet_rows": n, "delta_rows": n,
                      "target": bridge_run.delta_target(payload, payload["bridge_run_id"], payload["attempt"]),
                      "release_id": payload["release_id"]}
            if state["loader_result"]:
                result = state["loader_result"](result)
            if terminal_callback: terminal_callback(external_id, "SUCCEEDED")
            return result
        if "drop_tables" in payload:                                 # retention
            state["calls"].append(("retention", len(payload["drop_tables"])))
            return {"dropped": [{k: d[k] for k in ("run_id", "mapping_id", "attempt")}
                                for d in payload["drop_tables"]], "skipped": []}
        m = payload["mapping"]
        if mode == "INSPECT":
            rel = state["delta"].get(m["target_table"])
            result = {"exists": bool(rel), "release_ids": [rel] if rel else [], "rows": m["source_rows"]}
            if terminal_callback: terminal_callback(external_id, "SUCCEEDED")
            return result
        if state.get("during_replace"):
            hook, state["during_replace"] = state["during_replace"], None
            hook()                                       # another run acts mid-replacement
        state["delta"][m["target_table"]] = payload["release_id"]
        state["calls"].append(("publish", m["target_table"], payload["release_id"]))
        if state["fail_after_publish"]:
            state["fail_after_publish"] = False
            raise bridge_run.Indeterminate("simulated lost acknowledgement after Delta commit")
        result = {"release_id": payload["release_id"], "rows": m["source_rows"]}
        if terminal_callback: terminal_callback(external_id, "SUCCEEDED")
        return result

    class FakeCursor:
        """Synapse cursor for upstream_audit.py: view counts come from source_rows."""

        def __init__(self, conn):
            self.conn, self.inner = conn, Cursor(conn)

        def execute(self, sql, *params):
            match = re.fullmatch(r"SELECT count_big\(\*\) FROM \[(\w+)\]\.\[(\w+)\]", sql)
            if match:
                mid = next(m["mapping_id"] for m in doc["mappings"] if m["source_view"] == match.group(2))
                self.inner.c = self.conn.raw.cursor()
                self.inner.c.execute("SELECT ?", [source_rows[mid]])
                return self.inner
            return self.inner.execute(sql, *params)

    @contextmanager
    def audit_db(var, autocommit=False):
        with fake_db(var, autocommit) as conn:
            conn.cursor = lambda: FakeCursor(conn)
            yield conn

    import source_metadata
    for module in (bridge_run, publish_run, recovery, retention):
        monkeypatch.setattr(module, "db", fake_db)
    monkeypatch.setattr(upstream_audit, "db", audit_db)
    monkeypatch.setattr(upstream_audit, "schema_hash", lambda conn, s, v: "sha256:x")
    monkeypatch.setattr(bridge_run, "cetas", fake_extract)
    monkeypatch.setattr(bridge_run, "notebook_job", fake_job)
    monkeypatch.setattr(publish_run, "notebook_job", fake_job)
    monkeypatch.setattr(retention, "notebook_job", fake_job)
    monkeypatch.setattr(bridge_run, "require_empty_adls", lambda root, rel: None)
    monkeypatch.setattr(bridge_run, "verify_jobs", lambda cfg, keys: None)   # no Databricks here
    monkeypatch.setattr(source_metadata, "schema_hash", lambda conn, s, v: "sha256:x")

    def run(module, *argv):
        monkeypatch.setattr(sys, "argv", ["x", *argv])
        module.main()

    def query(sql, *params, db="BRIDGE_CONTROL_ODBC"):
        with fake_db(db) as c:
            rows = c.cursor().execute(sql, *params).fetchall()
            c.commit()
            return rows

    def audit(upstream_run_id, business_date="2026-09-22"):
        run(upstream_audit, "--config", str(cfg_path), "--upstream-run-id", upstream_run_id,
            "--business-date", business_date)

    def extract(run_id="BRG1", upstream="SYN1", *extra):
        run(bridge_run, "--config", str(cfg_path), "--upstream-run-id", upstream, "--bridge-run-id", run_id, *extra)

    def publish(run_id="BRG1", *extra):
        run(publish_run, "--config", str(cfg_path), "--bridge-run-id", run_id, *extra)

    def recover(action, run_id="BRG1", evidence=None, **fields):
        argv = [action, "--bridge-run-id", run_id, "--actor", "operator", "--reason", "test"]
        if action in ("abandon-publication", "abandon-publishing-run", "abandon-run"):
            argv += ["--config", str(cfg_path)]
        if evidence is not None:
            path = tmp_path / f"evidence_{len(state['calls'])}_{action}.json"
            path.write_text(json.dumps({"evidence_uri": "https://evidence/x", **evidence}))
            argv += ["--evidence", str(path)]
        for k, v in fields.items():
            argv += ["--" + k.replace("_", "-"), str(v)]
        run(recovery, *argv)

    audit("SYN1")
    def set_config(**values):
        cfg = json.loads(cfg_path.read_text())
        cfg.update(values)
        cfg_path.write_text(json.dumps(cfg))

    return {"run": run, "query": query, "state": state, "source_rows": source_rows,
            "audit": audit, "extract": extract, "publish": publish,
            "recover": recover, "cfg": cfg_path, "set_config": set_config, "fake_extract": fake_extract}


CUSTOMER = "table:cat.gold.customer"
SALES = "table:cat.gold.sales"


def calls(env, kind, *prefix):
    return [c for c in env["state"]["calls"] if c[0] == kind and c[1:1 + len(prefix)] == prefix]


def test_upstream_audit_records_counts_and_sequence(env):
    assert env["query"]("SELECT upstream_run_id,upstream_sequence,business_date,status FROM bridge_meta.upstream_run",
                        db="SYN") == [("SYN1", 1, "2026-09-22", "COMPLETE")]
    assert sorted(env["query"]("SELECT mapping_id,row_count FROM bridge_meta.upstream_object", db="SYN")) == \
        [("MAP_v_customer", 10), ("MAP_v_sales", 11)]
    with pytest.raises(RuntimeError, match="already exists"):
        env["audit"]("SYN1")
    env["audit"]("SYN2", "2026-09-23")
    assert env["query"]("SELECT MAX(upstream_sequence) FROM bridge_meta.upstream_run", db="SYN") == [(2,)]


def test_happy_path_extract_load_publish(env):
    env["extract"]()
    assert env["query"]("SELECT status, orchestrator_token, upstream_sequence, business_date FROM bridge.runs") == \
        [("READY", None, 1, "2026-09-22")]
    env["publish"]()
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]
    states = dict(env["query"]("SELECT target_key, published_release_id FROM bridge.target_state"))
    assert states == {CUSTOMER: "rel_BRG1", SALES: "rel_BRG1"}
    assert env["state"]["delta"] == {"customer": "rel_BRG1", "sales": "rel_BRG1"}


def test_next_day_replaces_previous_release(env):
    env["extract"](); env["publish"]()
    env["audit"]("SYN2", "2026-09-23")
    env["extract"]("BRG2", "SYN2"); env["publish"]("BRG2")
    assert env["query"]("SELECT published_release_id, previous_release_id, high_water_sequence "
                        "FROM bridge.target_state WHERE target_key=?", CUSTOMER) == [("rel_BRG2", "rel_BRG1", 2)]
    assert env["query"]("SELECT DISTINCT leaf_path LIKE '%/2026-09-23/BRG2/%' FROM bridge.object_attempts "
                        "WHERE bridge_run_id='BRG2'") == [(1,)]


def test_missing_audit_or_duplicate_run_is_refused(env):
    with pytest.raises(RuntimeError, match="missing or duplicated"):
        env["extract"]("BRG1", "NOT_AUDITED")
    env["extract"]()
    with pytest.raises(RuntimeError, match="Run already exists"):
        env["extract"]()


def test_second_run_for_same_refresh_is_refused_while_first_is_open(env):
    env["state"]["fail_extract"].add("MAP_v_sales")
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    with pytest.raises(RuntimeError, match="already exists for upstream run SYN1"):
        env["extract"]("BRG1b")


def test_already_published_refresh_cannot_run_again(env):
    env["extract"](); env["publish"]()
    with pytest.raises(RuntimeError, match="is not newer"):
        env["extract"]("BRG1b")


def test_failed_extraction_resumes_with_new_attempt(env):
    env["state"]["fail_extract"].add("MAP_v_sales")
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    assert env["query"]("SELECT status, orchestrator_token FROM bridge.runs") == [("FAILED", None)]
    env["extract"]("BRG1", "SYN1", "--resume")
    rows = env["query"]("SELECT mapping_id, attempt, status FROM bridge.object_attempts ORDER BY 1, 2")
    assert ("MAP_v_sales", 1, "FAILED") in rows and ("MAP_v_sales", 2, "READY") in rows
    assert len(calls(env, "extract", "MAP_v_customer")) == 1
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]
    env["publish"]()
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]


def test_max_attempts_bounds_resume(env):
    for _ in range(3):
        env["state"]["fail_extract"].add("MAP_v_sales")
        with pytest.raises(bridge_run.PhaseError):
            env["extract"]("BRG1", "SYN1", *(["--resume"] if calls(env, "extract") else []))
    with pytest.raises(RuntimeError, match="reached max_attempts"):
        env["extract"]("BRG1", "SYN1", "--resume")


def test_live_lease_blocks_takeover_until_stale(env):
    env["state"]["fail_extract"].add("MAP_v_customer")
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    # Simulate a crashed orchestrator that still holds the lease.
    env["query"]("UPDATE bridge.runs SET status='EXTRACTING', orchestrator_token='other', heartbeat_utc=?",
                 ts(CLOCK["now"]))
    with pytest.raises(RuntimeError, match="live lease"):
        env["extract"]("BRG1", "SYN1", "--resume")
    CLOCK["now"] += timedelta(minutes=151)
    env["extract"]("BRG1", "SYN1", "--resume")
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]


def test_newer_refresh_during_read_fails_the_attempt(env):
    """Replaces the fence re-check: a read that finishes after a newer refresh was audited is refused."""
    env["set_config"](max_extraction_workers=1)             # customer reads first, sales never starts
    env["state"]["during_extract"] = lambda: env["audit"]("SYN2", "2026-09-23")
    with pytest.raises(bridge_run.PhaseError, match="newer refresh"):
        env["extract"]()
    rows = env["query"]("SELECT mapping_id, status, source_operation_state, error_text FROM bridge.object_attempts")
    assert len(rows) == 1 and rows[0][:3] == ("MAP_v_customer", "FAILED", "SUCCEEDED")
    assert "newer refresh" in rows[0][3]


def test_stale_run_cannot_resume_extraction_and_is_abandoned(env):
    env["state"]["fail_extract"].add("MAP_v_sales")
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    env["audit"]("SYN2", "2026-09-23")                         # next day's refresh already happened
    with pytest.raises(RuntimeError, match="newer refresh"):
        env["extract"]("BRG1", "SYN1", "--resume")
    with pytest.raises(RuntimeError, match="already exists for upstream run SYN1"):
        env["extract"]("BRG1b", "SYN1")
    env["recover"]("abandon-run", config=env["cfg"])
    assert env["query"]("SELECT status, orchestrator_token FROM bridge.runs") == [("ABANDONED", None)]
    assert {r[0] for r in env["query"]("SELECT status FROM bridge.object_attempts")} <= {"ABANDONED", "FAILED"}
    assert env["query"]("SELECT action FROM bridge.recovery_events") == [("ABANDON_RUN",)]
    env["extract"]("BRG2", "SYN2"); env["publish"]("BRG2")
    assert env["state"]["delta"] == {"customer": "rel_BRG2", "sales": "rel_BRG2"}


def test_abandon_run_refuses_live_lease_unresolved_work_and_published_runs(env, monkeypatch):
    env["extract"]()
    env["query"]("UPDATE bridge.runs SET status='LOADING', orchestrator_token='other', heartbeat_utc=?",
                 ts(CLOCK["now"]))
    with pytest.raises(RuntimeError, match="live orchestrator lease"):
        env["recover"]("abandon-run", config=env["cfg"])
    env["query"]("UPDATE bridge.runs SET status='FAILED', orchestrator_token=NULL")
    env["query"]("UPDATE bridge.object_attempts SET loader_operation_state='UNKNOWN' WHERE mapping_id='MAP_v_sales'")
    with pytest.raises(RuntimeError, match="External work may still be running"):
        env["recover"]("abandon-run", config=env["cfg"])
    env["query"]("UPDATE bridge.runs SET status='PUBLISHED'")
    with pytest.raises(RuntimeError, match="cannot be abandoned"):
        env["recover"]("abandon-run", config=env["cfg"])


def test_rejected_loader_result_is_re_extracted_on_resume(env):
    env["state"]["loader_result"] = lambda r: {**r, "delta_rows": r["delta_rows"] - 1}
    with pytest.raises(bridge_run.PhaseError, match="Three-way count mismatch"):
        env["extract"]()
    assert set(env["query"]("SELECT status, loader_operation_state FROM bridge.object_attempts")) == \
        {("FAILED", "REJECTED")}
    env["state"]["loader_result"] = None
    env["extract"]("BRG1", "SYN1", "--resume")
    assert env["query"]("SELECT DISTINCT attempt, status FROM bridge.object_attempts WHERE status='READY'") == \
        [(2, "READY")]


def test_failed_loader_reloads_retained_parquet_without_re_extracting(env, monkeypatch):
    original = bridge_run.notebook_job
    failed = []

    def fail_once(cfg, job_id, payload, run_id, *callbacks):
        if "leaf_path" in payload and payload["mapping_id"] == "MAP_v_customer" and not failed:
            failed.append(True)
            if callbacks and callbacks[0]: callbacks[0]("dbx_failed_loader")
            raise RuntimeError("known loader failure")
        return original(cfg, job_id, payload, run_id, *callbacks)

    monkeypatch.setattr(bridge_run, "notebook_job", fail_once)
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    row = env["query"]("SELECT status,delta_target,target_key,consumer_target,loader_run_id "
                       "FROM bridge.object_attempts WHERE mapping_id='MAP_v_customer'")[0]
    assert row[0] == "EXTRACTED" and row[1].startswith("cat.bridge_candidate.candidate_")
    assert row[2:] == (CUSTOMER, "cat.gold.customer", "dbx_failed_loader")
    env["extract"]("BRG1", "SYN1", "--resume")
    assert len(calls(env, "extract", "MAP_v_customer")) == 1          # reloaded, not re-extracted
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]


def test_indeterminate_extraction_blocks_until_audited_recovery(env, monkeypatch):
    def unknown(m, relative, started_callback=None, terminal_callback=None):
        if started_callback: started_callback("x_live_" + m["mapping_id"])
        raise bridge_run.Indeterminate("polling connection lost")
    monkeypatch.setattr(bridge_run, "cetas", unknown)
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    assert env["query"]("SELECT status,source_request_id,source_operation_state FROM bridge.object_attempts "
                        "WHERE mapping_id='MAP_v_customer'") == [("INDETERMINATE", "x_live_MAP_v_customer", "UNKNOWN")]
    assert env["query"]("SELECT status, orchestrator_token IS NOT NULL FROM bridge.runs") == [("FAILED", 1)]
    with pytest.raises(RuntimeError, match="indeterminate external operation"):
        env["extract"]("BRG1", "SYN1", "--resume")
    with pytest.raises(RuntimeError, match="Evidence external run ID differs"):
        env["recover"]("resolve-attempt", evidence={"external_terminal": True, "safe_to_retry": True,
                       "phase": "SOURCE", "external_run_id": "wrong"}, mapping_id="MAP_v_customer", attempt=1)
    with pytest.raises(RuntimeError, match="LOADER operation is not unresolved"):
        env["recover"]("resolve-attempt", evidence={"external_terminal": True, "safe_to_retry": True,
                       "phase": "LOADER", "external_run_id": "x"}, mapping_id="MAP_v_customer", attempt=1)
    for mid in ("MAP_v_customer", "MAP_v_sales"):
        env["recover"]("resolve-attempt", evidence={"external_terminal": True, "safe_to_retry": True,
                       "phase": "SOURCE", "external_run_id": "x_live_" + mid}, mapping_id=mid, attempt=1)
    assert set(env["query"]("SELECT status,source_operation_state FROM bridge.object_attempts")) == \
        {("FAILED", "VERIFIED_TERMINAL")}
    assert env["query"]("SELECT orchestrator_token FROM bridge.runs") == [(None,)]
    monkeypatch.setattr(bridge_run, "cetas", env["fake_extract"])
    env["extract"]("BRG1", "SYN1", "--resume")
    assert set(env["query"]("SELECT attempt, status FROM bridge.object_attempts WHERE attempt=2")) == {(2, "READY")}
    assert env["query"]("SELECT action FROM bridge.recovery_events") == [("RESOLVE_ATTEMPT",)] * 2


def test_orphaned_read_after_orchestrator_stop_becomes_indeterminate(env):
    env["state"]["fail_extract"].add("MAP_v_sales")
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    # Pretend the orchestrator died while the retry of MAP_v_sales was reading.
    env["query"]("UPDATE bridge.runs SET status='EXTRACTING', orchestrator_token='dead', heartbeat_utc=?",
                 ts(CLOCK["now"] - timedelta(hours=3)))
    env["query"]("INSERT INTO bridge.object_attempts(bridge_run_id,mapping_id,attempt,status,leaf_path,source_rows,"
                 "delta_target,target_key,consumer_target,source_request_id,source_operation_state) "
                 "VALUES ('BRG1','MAP_v_sales',2,'EXTRACTING','p2',11,'cat.bridge_candidate.candidate_x',?,"
                 "'cat.gold.sales','x_orphan','RUNNING')", SALES)
    with pytest.raises(RuntimeError, match="now INDETERMINATE"):
        env["extract"]("BRG1", "SYN1", "--resume")
    assert env["query"]("SELECT status,source_operation_state FROM bridge.object_attempts WHERE attempt=2") == \
        [("INDETERMINATE", "UNKNOWN")]


def test_publish_resume_reconciles_lost_acknowledgement(env):
    env["extract"]()
    env["state"]["fail_after_publish"] = True           # Delta commits, the acknowledgement is lost
    with pytest.raises(bridge_run.PhaseError):
        env["publish"]()
    assert env["query"]("SELECT status, orchestrator_token IS NOT NULL FROM bridge.runs") == [("PUBLISHING", 1)]
    unknown = env["query"]("SELECT target_key, publish_external_run_id FROM bridge.target_state "
                           "WHERE publish_operation_state IN ('RUNNING','UNKNOWN')")
    assert len(unknown) == 1
    key, external_id = unknown[0]
    with pytest.raises(RuntimeError, match="live lease"):
        env["publish"]("BRG1", "--resume")                   # the unknown publisher keeps the lease
    env["recover"]("resolve-publication", evidence={"external_terminal": True, "safe_to_resume": True,
                   "orchestrator_stopped": True, "external_run_id": external_id}, target_key=key)
    env["publish"]("BRG1", "--resume")
    assert set(dict(env["query"]("SELECT target_key, published_release_id FROM bridge.target_state")).values()) == \
        {"rel_BRG1"}
    table = key.rsplit(".", 1)[1]
    assert len(calls(env, "publish", table)) == 1                  # reconciled, not republished
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]


def _leave_in_publishing(env):
    env["extract"]()
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING', orchestrator_token=NULL")


def test_publish_resume_refuses_unexpected_table_state(env):
    _leave_in_publishing(env)
    env["state"]["delta"]["customer"] = "rel_SOMEONE_ELSE"       # not in Azure SQL, not this release
    with pytest.raises(bridge_run.PhaseError, match="freeze it for operator review"):
        env["publish"]("BRG1", "--resume")
    assert not calls(env, "publish", "customer")
    assert env["state"]["delta"]["customer"] == "rel_SOMEONE_ELSE"
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHING",)]


def test_publish_resume_reconciles_committed_table(env):
    _leave_in_publishing(env)
    env["state"]["delta"]["customer"] = "rel_BRG1"               # committed, SQL update lost
    env["publish"]("BRG1", "--resume")
    assert not calls(env, "publish", "customer")
    assert env["query"]("SELECT published_release_id FROM bridge.target_state WHERE target_key=?", CUSTOMER) == \
        [("rel_BRG1",)]
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]


def _second_ready_run(env):
    """BRG2: a newer READY run (next day's refresh) over the same tables."""
    env["extract"]()
    env["audit"]("SYN2", "2026-09-23")
    env["extract"]("BRG2", "SYN2")
    env["set_config"](max_publisher_workers=1)        # deterministic order


def test_two_runs_cannot_replace_the_same_table_at_once(env):
    _second_ready_run(env)
    blocked = []

    def overlap():
        try:
            env["publish"]("BRG2")
        except bridge_run.PhaseError as exc:
            blocked.append(str(exc))

    env["state"]["during_replace"] = overlap          # BRG2 starts while BRG1 is replacing its first table
    env["publish"]("BRG1")
    first, other = "customer", "sales"                # one publisher worker: config order
    assert blocked and "being published by run BRG1" in blocked[0]
    assert calls(env, "publish", first) == [("publish", first, "rel_BRG1")]
    assert env["state"]["delta"][other] == "rel_BRG2"                 # BRG2 published it meanwhile
    # v1.4: a run with a superseded table ends PARTIALLY_PUBLISHED.
    assert env["query"]("SELECT status FROM bridge.runs WHERE bridge_run_id='BRG1'") == [("PARTIALLY_PUBLISHED",)]
    env["publish"]("BRG2", "--resume")
    assert env["state"]["delta"] == {"customer": "rel_BRG2", "sales": "rel_BRG2"}
    assert set(dict(env["query"]("SELECT target_key, published_release_id FROM bridge.target_state")).values()) \
        == {"rel_BRG2"}


def test_older_run_never_rolls_back_a_newer_release(env):
    _second_ready_run(env)
    env["publish"]("BRG2")
    env["publish"]("BRG1")                             # finishes without replacing anything
    assert env["state"]["delta"] == {"customer": "rel_BRG2", "sales": "rel_BRG2"}
    assert not [c for c in calls(env, "publish") if c[2] == "rel_BRG1"]


def test_claim_left_by_failed_run_blocks_other_runs(env):
    _second_ready_run(env)
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING', orchestrator_token=NULL WHERE bridge_run_id='BRG1'")
    env["query"]("UPDATE bridge.target_state SET publish_owner='BRG1', publish_token='dead' WHERE target_key=?",
                 CUSTOMER)
    with pytest.raises(bridge_run.PhaseError, match="being published by run BRG1"):
        env["publish"]("BRG2")
    assert not calls(env, "publish", "customer")
    env["publish"]("BRG1", "--resume")                  # only the owner may continue
    assert env["query"]("SELECT published_release_id, publish_owner FROM bridge.target_state WHERE target_key=?",
                        CUSTOMER) == [("rel_BRG1", None)]


def test_abandon_publication_releases_claim(env):
    env["extract"]()
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING'")
    env["query"]("UPDATE bridge.target_state SET publish_owner='BRG1',publish_token='dead',"
                 "publish_external_run_id='dbx_pub_1' WHERE target_key=?", CUSTOMER)
    env["query"]("UPDATE bridge.runs SET orchestrator_token=NULL")
    env["recover"]("abandon-publication", evidence={"external_terminal": True, "delta_state_verified": True,
                   "orchestrator_stopped": True, "safe_to_abandon": True,
                   "external_run_id": "dbx_pub_1"}, target_key=CUSTOMER)
    assert env["query"]("SELECT publish_owner,publish_operation_state FROM bridge.target_state "
                        "WHERE target_key=?", CUSTOMER) == [(None, "ABANDONED")]
    # Only customer is given up; sales is still READY and unpublished, so the run stays open.
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHING",)]
    assert sorted(env["query"]("SELECT mapping_id,status FROM bridge.object_attempts")) == \
        [("MAP_v_customer", "ABANDONED"), ("MAP_v_sales", "READY")]
    env["publish"]("BRG1", "--resume")                    # strict mode: an abandoned table is allowed
    assert env["state"]["delta"] == {"sales": "rel_BRG1"}
    assert env["query"]("SELECT status FROM bridge.runs") == [("PARTIALLY_PUBLISHED",)]


def test_abandon_claim_before_external_submission(env):
    env["extract"]()
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING',orchestrator_token=NULL")
    env["query"]("UPDATE bridge.target_state SET publish_owner='BRG1',publish_token='stopped' "
                 "WHERE target_key=?", CUSTOMER)
    with pytest.raises(RuntimeError, match="no_external_submission"):
        env["recover"]("abandon-publication", evidence={"delta_state_verified": True,
                       "safe_to_abandon": True, "orchestrator_stopped": True}, target_key=CUSTOMER)
    env["recover"]("abandon-publication", evidence={"delta_state_verified": True,
                   "safe_to_abandon": True, "orchestrator_stopped": True,
                   "no_external_submission": True}, target_key=CUSTOMER)
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHING",)]   # sales still unpublished
    env["recover"]("abandon-publishing-run", evidence={"orchestrator_stopped": True, "safe_to_abandon": True})
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLICATION_ABANDONED",)]


def test_abandon_publishing_run_without_claims(env):
    env["extract"]()
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING',orchestrator_token=NULL")
    env["recover"]("abandon-publishing-run", evidence={"orchestrator_stopped": True,
                   "safe_to_abandon": True})
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLICATION_ABANDONED",)]


def test_resume_refuses_changed_config_with_same_inventory_version(env):
    env["extract"]()
    cfg = json.loads(env["cfg"].read_text())
    cfg["mappings"][0]["columns"][0]["target"] = "customer_key"
    env["cfg"].write_text(json.dumps(cfg))
    with pytest.raises(RuntimeError, match="Reviewed config changed"):
        env["publish"]()
    with pytest.raises(RuntimeError, match="Reviewed config changed"):
        env["extract"]("BRG1", "SYN1", "--resume")


def test_zero_row_mapping_skips_cetas_and_reaches_ready(env):
    env["source_rows"]["MAP_v_customer"] = 0
    env["audit"]("SYN2", "2026-09-23")
    env["extract"]("BRG2", "SYN2")
    assert not calls(env, "extract", "MAP_v_customer")
    assert env["query"]("SELECT source_rows,source_operation_state,status FROM bridge.object_attempts "
                        "WHERE bridge_run_id='BRG2' AND mapping_id='MAP_v_customer'") == \
        [(0, "NOT_STARTED", "READY")]
    env["publish"]("BRG2")


def test_partial_release_publishes_healthy_table_after_other_extract_fails(env):
    env["set_config"](allow_partial_release=True)
    env["state"]["fail_extract"].add("MAP_v_sales")
    env["extract"]()
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]
    env["publish"]()
    assert env["state"]["delta"] == {"customer": "rel_BRG1"}
    assert env["query"]("SELECT status FROM bridge.runs") == [("PARTIALLY_PUBLISHED",)]
    env["audit"]("SYN2", "2026-09-23")
    env["extract"]("BRG2", "SYN2")
    env["publish"]("BRG2")
    assert env["state"]["delta"] == {"customer": "rel_BRG2", "sales": "rel_BRG2"}


def test_partial_audit_excludes_schema_drift_but_publishes_healthy_table(env, monkeypatch):
    env["set_config"](allow_partial_release=True)
    monkeypatch.setattr(upstream_audit, "schema_hash",
                        lambda conn, schema, name: "wrong" if name == "v_sales" else "sha256:x")
    env["audit"]("SYN2", "2026-09-23")
    assert env["query"]("SELECT mapping_id,status FROM bridge_meta.upstream_object "
                        "WHERE upstream_run_id='SYN2'", db="SYN") == \
        [("MAP_v_customer", "COMPLETE"), ("MAP_v_sales", "EXCLUDED")]
    env["extract"]("BRG2", "SYN2")
    env["publish"]("BRG2")
    assert env["state"]["delta"] == {"customer": "rel_BRG2"}


def test_partial_audit_does_not_hide_unknown_connection_failure(env, monkeypatch):
    class LostConnection(Exception):
        pass
    LostConnection.__module__ = "pyodbc"
    monkeypatch.setattr(upstream_audit, "schema_hash", lambda conn, schema, name:
                        (_ for _ in ()).throw(LostConnection("08S01", "connection dropped")))
    env["set_config"](allow_partial_release=True)
    with pytest.raises(LostConnection):
        env["audit"]("SYN2", "2026-09-23")
    assert not env["query"]("SELECT upstream_run_id FROM bridge_meta.upstream_run WHERE upstream_run_id='SYN2'", db="SYN")


def test_runtime_job_id_can_be_fixed_but_data_contract_stays_pinned(env):
    env["set_config"](loader_job_id=0)
    with pytest.raises(RuntimeError, match="loader_job_id is not configured"):
        env["extract"]()
    assert not env["query"]("SELECT bridge_run_id FROM bridge.runs")
    env["set_config"](loader_job_id=1)
    env["extract"]()
    env["set_config"](publisher_job_id=2, max_loader_workers=2)
    env["publish"]()
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]


def test_loader_retry_limit_triggers_fresh_attempt(env):
    def fail(result):
        raise RuntimeError("loader rejected the file")
    env["state"]["loader_result"] = fail
    for retry in range(3):
        with pytest.raises(bridge_run.PhaseError):
            env["extract"]("BRG1", "SYN1", *("--resume",) if retry else ())
    env["state"]["loader_result"] = None
    env["extract"]("BRG1", "SYN1", "--resume")
    assert env["query"]("SELECT status,loader_attempts FROM bridge.object_attempts "
                        "WHERE mapping_id='MAP_v_customer' ORDER BY attempt") == \
        [("SUPERSEDED", 3), ("READY", 1)]


def test_manifest_cleanup_keeps_open_runs_and_recent_files(env, monkeypatch):
    env["extract"](); env["publish"]()
    env["audit"]("SYN2", "2026-09-23"); env["extract"]("BRG2", "SYN2")
    older = datetime.now(timezone.utc) - timedelta(days=40)
    recent = datetime.now(timezone.utc)
    root = "bridge/parquet-stage/_manifests/"
    blobs = [SimpleNamespace(name=f"{root}{run}/{'a'*32}.json", last_modified=when)
             for run, when in (("BRG1", older), ("BRG2", older), ("retention", recent))]
    deleted = []
    class Client:
        def list_blobs(self, name_starts_with):
            return [blob for blob in blobs if blob.name.startswith(name_starts_with)]
        def delete_blob(self, name):
            deleted.append(name)
    monkeypatch.setattr(retention, "container_client", lambda root: Client())
    assert retention.delete_old_manifests(bridge_run.config(env["cfg"])) == 1
    assert deleted == [f"{root}BRG1/{'a'*32}.json"]


def test_recovery_accepts_actual_run_id_for_stored_databricks_token(env):
    assert recovery.resolve_databricks_external_id("token:bridge_abc", {"external_run_id": "token:bridge_abc"}) \
        == "token:bridge_abc"
    assert recovery.resolve_databricks_external_id(
        "token:bridge_abc", {"idempotency_token": "bridge_abc", "external_run_id": "987"}) == "987"
    with pytest.raises(RuntimeError, match="idempotency_token differs"):
        recovery.resolve_databricks_external_id("token:bridge_abc", {"idempotency_token": "other",
                                                                     "external_run_id": "987"})


def test_retention_windows_and_kept_releases(env):
    env["extract"](); env["publish"]()
    for day, (syn, brg) in enumerate((("SYN2", "BRG2"), ("SYN3", "BRG3")), start=23):
        env["audit"](syn, f"2026-09-{day}")
        env["extract"](brg, syn); env["publish"](brg)
    cfg = bridge_run.config(env["cfg"])
    report = {}
    drops, staging = retention.plan(cfg, [], report)
    assert drops == [] and staging == []                       # BRG1 is superseded but only just
    assert {w["run_id"] for w in report["waiting_for_retention_window"]} == {"BRG1"}
    CLOCK["now"] += timedelta(days=8)
    drops, staging = retention.plan(cfg, [])
    assert {(d["run_id"], d["mapping_id"]) for d in drops} == {("BRG1", "MAP_v_customer"), ("BRG1", "MAP_v_sales")}
    assert {s["run_id"] for s in staging} == {"BRG1"}          # BRG3 published, BRG2 previous: kept
    drops, _ = retention.plan(cfg, ["rel_BRG1"])
    assert drops == []                                         # pinned with --keep-release
    env["run"](retention, "--config", str(env["cfg"]), "--execute")
    assert env["query"]("SELECT count(*) FROM bridge.object_attempts WHERE retired_utc IS NOT NULL") == [(2,)]
    assert retention.plan(cfg, [])[0] == []                    # already retired


def test_retention_cleans_abandoned_and_failed_attempts_after_30_days(env):
    env["state"]["fail_extract"].add("MAP_v_sales")
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    env["recover"]("abandon-run", config=env["cfg"])
    cfg = bridge_run.config(env["cfg"])
    CLOCK["now"] += timedelta(days=8)
    assert retention.plan(cfg, []) == ([], [])
    CLOCK["now"] += timedelta(days=23)
    drops, staging = retention.plan(cfg, [])
    assert {(d["mapping_id"], d["attempt"]) for d in drops} == {("MAP_v_customer", 1), ("MAP_v_sales", 1)}
    assert len(staging) == 2
