# Databricks notebook source
"""Step 0b alternative (SCRIPT_GUIDE.md): profile Synapse dedicated-pool tables with PySpark JDBC on a manually created cluster.

Reads only catalog/DMV metadata, never SELECTs table data. Run once per reviewed
inventory version on a Unity Catalog-enabled classic cluster.
"""
import csv
import json
import re
from datetime import datetime, timezone
from pathlib import Path

from pyspark.sql import functions as F

# COMMAND ----------
# Edit these values before running. Both JSON files live in an existing UC volume.
INPUT_CONFIG = "/Volumes/analytics/bridge_config/files/config.generated.json"
OUTPUT_CONFIG = "/Volumes/analytics/bridge_config/files/config.profiled.json"
NEW_INVENTORY_VERSION = "wave_001_v2"
JDBC_URL = "jdbc:sqlserver://<workspace>.sql.azuresynapse.net:1433;databaseName=<dedicated-pool>;encrypt=true;trustServerCertificate=false"
SECRET_SCOPE = "bridge"
USER_SECRET_KEY = "synapse-metadata-user"
PASSWORD_SECRET_KEY = "synapse-metadata-password"
JDBC_DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver"

# COMMAND ----------
NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
VERSION = re.compile(r"^[A-Za-z0-9_\-]{1,128}$")
THRESHOLDS = ("medium_rows", "large_rows", "medium_bytes", "large_bytes",
              "medium_columns", "large_columns")


def volume_path(value):
    p = Path(value)
    if not p.is_absolute() or p.parts[:2] != ("/", "Volumes") or len(p.parts) < 6 or p.suffix != ".json":
        raise ValueError("Use a .json path inside an existing /Volumes/catalog/schema/volume folder")
    return p


source = volume_path(INPUT_CONFIG)
target = volume_path(OUTPUT_CONFIG)
report = target.with_suffix(".profile.csv")
if source == target or target.exists() or report.exists():
    raise FileExistsError("Profile output already exists or would overwrite its input")
if not VERSION.fullmatch(NEW_INVENTORY_VERSION):
    raise ValueError("Use a safe, new inventory version")
if "<" in JDBC_URL or ">" in JDBC_URL:
    raise ValueError("Set the dedicated-pool JDBC URL")
config = json.loads(source.read_text())
if not config.get("mappings") or NEW_INVENTORY_VERSION == config["inventory_version"]:
    raise ValueError("Mappings are required and the profile needs a new inventory version")
limits = config.get("profile_thresholds", {})
if (not all(type(limits.get(k)) is int and limits[k] > 0 for k in THRESHOLDS)
    or not all(limits["medium_"+k] < limits["large_"+k] for k in ("rows", "bytes", "columns"))):
    raise ValueError("Set reviewed increasing profile_thresholds in the input config")
def physical_source(m):
    """A view is profiled through its reviewed materialised-table association."""
    if ("materialised_schema" in m) != ("materialised_table" in m):
        raise ValueError(f"materialised_schema/materialised_table must be set together: {m['mapping_id']}")
    return m.get("materialised_schema", m["source_schema"]), m.get("materialised_table", m["source_view"])


schemas = sorted({physical_source(m)[0] for m in config["mappings"]})
if not all(NAME.fullmatch(s) for s in schemas):
    raise ValueError("Unsupported source schema identifier")
for m in config["mappings"]:
    if not NAME.fullmatch(physical_source(m)[1]):
        raise ValueError(f"Unsupported source table identifier: {m['mapping_id']}")
schema_filter = ", ".join("'" + s + "'" for s in schemas)


def jdbc_query(sql):
    return (spark.read.format("jdbc")
            .option("url", JDBC_URL).option("driver", JDBC_DRIVER)
            .option("user", dbutils.secrets.get(SECRET_SCOPE, USER_SECRET_KEY))
            .option("password", dbutils.secrets.get(SECRET_SCOPE, PASSWORD_SECRET_KEY))
            .option("query", sql).option("queryTimeout", "300")
            .option("fetchsize", "10000").load())


# Fetch compact metadata through JDBC. The aggregate is on the Spark side;
# no full-table COUNT_BIG(*) or data transfer of the actual source tables.
columns_sql = f"""
SELECT s.name AS schema_name, t.name AS table_name, COUNT(*) AS column_count
FROM sys.schemas AS s
JOIN sys.tables AS t ON t.schema_id = s.schema_id
JOIN sys.columns AS c ON c.object_id = t.object_id
WHERE s.name IN ({schema_filter})
GROUP BY s.name, t.name
"""
pages_sql = f"""
SELECT s.name AS schema_name, t.name AS table_name,
       tp.distribution_policy_desc AS distribution_policy,
       nt.distribution_id, CAST(ps.row_count AS bigint) AS partition_rows,
       CAST(ps.used_page_count AS bigint) AS used_pages
FROM sys.schemas AS s
JOIN sys.tables AS t ON t.schema_id = s.schema_id
JOIN sys.indexes AS ix ON ix.object_id = t.object_id AND ix.index_id <= 1
JOIN sys.pdw_table_distribution_properties AS tp ON tp.object_id = t.object_id
JOIN sys.pdw_table_mappings AS tm ON tm.object_id = t.object_id
JOIN sys.pdw_nodes_tables AS nt ON nt.name = tm.physical_name
JOIN sys.dm_pdw_nodes AS pn ON pn.pdw_node_id = nt.pdw_node_id AND pn.type = 'COMPUTE'
JOIN sys.dm_pdw_nodes_db_partition_stats AS ps
  ON ps.object_id = nt.object_id AND ps.pdw_node_id = nt.pdw_node_id
 AND ps.distribution_id = nt.distribution_id AND ps.index_id = ix.index_id
WHERE s.name IN ({schema_filter})
"""
counts = jdbc_query(columns_sql)
pages = jdbc_query(pages_sql)
per_distribution = pages.groupBy("schema_name", "table_name", "distribution_policy", "distribution_id").agg(
    F.sum("partition_rows").alias("rows_in_distribution"),
    F.sum("used_pages").alias("used_pages_in_distribution"))
physical_df = per_distribution.groupBy("schema_name", "table_name", "distribution_policy").agg(
    F.sum("rows_in_distribution").alias("summed_rows"),
    F.max("rows_in_distribution").alias("replicated_rows"),
    (F.sum("used_pages_in_distribution") * F.lit(8192)).alias("physical_used_bytes"))
profile_df = (physical_df.join(counts, ["schema_name", "table_name"], "inner")
              .withColumn("estimated_rows", F.when(F.col("distribution_policy") == "REPLICATE",
                                                  F.col("replicated_rows")).otherwise(F.col("summed_rows"))))
profiles = {}
for row in profile_df.select("schema_name", "table_name", "distribution_policy", "column_count",
                             "estimated_rows", "physical_used_bytes").collect():
    key = (row.schema_name.lower(), row.table_name.lower())
    if key in profiles:
        raise ValueError(f"Duplicate physical source table: {key}")
    profiles[key] = row


def classify(rows, columns, used_bytes):
    if (rows >= limits["large_rows"] or used_bytes >= limits["large_bytes"]
        or columns >= limits["large_columns"]):
        return "LARGE"
    if (rows >= limits["medium_rows"] or used_bytes >= limits["medium_bytes"]
        or columns >= limits["medium_columns"]):
        return "MEDIUM"
    return "SMALL"


snapshot = datetime.now(timezone.utc).isoformat()
review = []
for m in config["mappings"]:
    key = tuple(x.lower() for x in physical_source(m))
    if key not in profiles:
        raise ValueError(f"Missing physical table profile for {key}; for a view set the reviewed "
                         "materialised_schema and materialised_table")
    r = profiles[key]
    rows, columns, used_bytes = int(r.estimated_rows), int(r.column_count), int(r.physical_used_bytes)
    if min(rows, columns, used_bytes) < 0 or columns != len(m["columns"]):
        raise ValueError(f"Invalid profile or incomplete all-column mapping: {key}")
    m["size_class"] = classify(rows, columns, used_bytes)
    m["source_profile"] = {"profiled_at_utc": snapshot, "estimated_rows": rows,
                           "column_count": columns, "physical_used_bytes": used_bytes,
                           "distribution_policy": r.distribution_policy,
                           "source_schema_version": m["source_schema_version"]}
    review.append({"source_schema": r.schema_name, "source_table": r.table_name,
                   "mapping_id": m["mapping_id"], "estimated_rows": rows,
                   "column_count": columns, "physical_used_gib": round(used_bytes / 2**30, 3),
                   "distribution_policy": r.distribution_policy,
                   "size_class": m["size_class"], "profiled_at_utc": snapshot})
if not review:
    raise ValueError("No physical source tables were profiled")
config["inventory_version"] = NEW_INVENTORY_VERSION
config["require_profiles"] = True
review.sort(key=lambda x: (-x["physical_used_gib"], -x["estimated_rows"], x["mapping_id"]))

# These are versioned planning files, not the nightly control store. Check both
# destinations before writing and never silently replace an approved inventory.
with report.open("x", newline="") as file:
    writer = csv.DictWriter(file, fieldnames=list(review[0]))
    writer.writeheader()
    writer.writerows(review)
with target.open("x") as file:
    json.dump(config, file, indent=2)
    file.write("\n")
print(f"Profiled {len(review)} physical tables; review {report} and seed {NEW_INVENTORY_VERSION}")
display(profile_df.orderBy(F.desc("physical_used_bytes")))
