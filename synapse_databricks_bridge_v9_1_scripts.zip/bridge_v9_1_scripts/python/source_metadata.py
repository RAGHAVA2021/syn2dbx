"""Step 0c (SCRIPT_GUIDE.md): canonical ordered source schema hash.

Also a shared library: upstream_audit.py and bridge_run.py use it to detect schema drift.
"""
import hashlib
import json
import re


def ident(value):
    if not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", value):
        raise ValueError(f"Unsafe identifier: {value!r}")
    return f"[{value}]"


def column_rows(conn, schema, view):
    rows=conn.cursor().execute(
        "SELECT c.name,c.column_id,t.name,c.max_length,c.precision,c.scale,c.is_nullable "
        "FROM sys.columns c JOIN sys.types t ON c.user_type_id=t.user_type_id "
        "WHERE c.object_id=OBJECT_ID(?) ORDER BY c.column_id",
        f"{ident(schema)}.{ident(view)}").fetchall()
    if not rows: raise ValueError(f"View missing/no columns: {schema}.{view}")
    return [list(x) for x in rows]


def hash_rows(rows):
    data=[list(x) for x in rows]
    canonical=json.dumps({"algorithm":"sys-columns-v1","columns":data},separators=(",", ":"),ensure_ascii=False)
    return "sha256:"+hashlib.sha256(canonical.encode()).hexdigest()


def schema_hash(conn, schema, view):
    return hash_rows(column_rows(conn, schema, view))


if __name__=="__main__":
    import argparse
    from bridge_run import db
    p=argparse.ArgumentParser();p.add_argument("--schema",required=True);p.add_argument("--view",required=True)
    a=p.parse_args()
    with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as conn:
        print(schema_hash(conn,a.schema,a.view))
