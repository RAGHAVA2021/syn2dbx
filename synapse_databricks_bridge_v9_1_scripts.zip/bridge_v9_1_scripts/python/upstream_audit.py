"""Step 4 (SCRIPT_GUIDE.md): run after existing Synapse transformations, before write-close.

This script records one authoritative view-result count per enabled mapping;
it cannot determine whether a view intentionally differs from its base table.
"""
import argparse
from datetime import date
from bridge_run import config, db, ident, need
from source_metadata import schema_hash


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--config",required=True)
    p.add_argument("--upstream-run-id",required=True)
    p.add_argument("--generation-id",required=True)
    p.add_argument("--writer-owner",required=True)
    p.add_argument("--sequence",required=True,type=int)
    p.add_argument("--business-date",required=True,type=date.fromisoformat)
    a=p.parse_args(); d=config(a.config)
    with db("BRIDGE_CONTROL_ODBC") as control, db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
        row=control.cursor().execute("SELECT state,generation_id,writer_owner FROM bridge.source_fence "
                                     "WHERE source_set_id=?",d["source_set_id"]).fetchone()
        need(row and tuple(row)==("WRITE_ACTIVE",a.generation_id,a.writer_owner),
             "Upstream writer does not own WRITE_ACTIVE")
        prior=syn.cursor().execute("SELECT count_big(*) FROM bridge_meta.upstream_run WHERE upstream_run_id=?",
                                   a.upstream_run_id).fetchone()[0]
        need(prior==0,"Upstream run audit already exists; recover it, never duplicate")
        # Sequences drive the publication high-water mark; a reused or lower sequence
        # would only be rejected much later, after a full extraction.
        latest=syn.cursor().execute("SELECT MAX(upstream_sequence) FROM bridge_meta.upstream_run").fetchone()[0]
        need(latest is None or a.sequence>int(latest),
             f"Sequence {a.sequence} must be greater than the latest recorded sequence {latest}")
        try:
            for m in d["mappings"]:
                actual=schema_hash(syn,m["source_schema"],m["source_view"])
                need(actual==m["source_schema_version"],f"Schema drift: {m['mapping_id']}")
                query=f"SELECT count_big(*) FROM {ident(m['source_schema'])}.{ident(m['source_view'])}"
                n=int(syn.cursor().execute(query).fetchone()[0])
                syn.cursor().execute("INSERT bridge_meta.upstream_object(upstream_run_id,mapping_id,"
                                     "source_schema_version,status,row_count,refresh_completed_utc) "
                                     "VALUES (?,?,?,'COMPLETE',?,SYSUTCDATETIME())",
                                     a.upstream_run_id,m["mapping_id"],actual,n)
            syn.cursor().execute("INSERT bridge_meta.upstream_run(upstream_run_id,source_generation_id,"
                                 "upstream_sequence,business_date,status,write_closed,completed_utc) "
                                 "VALUES (?,?,?,?,'COMPLETE',1,SYSUTCDATETIME())",
                                 a.upstream_run_id,a.generation_id,a.sequence,a.business_date)
            syn.commit()
        except Exception:
            syn.rollback()
            raise
    print("Completed audit",a.upstream_run_id,len(d["mappings"]))


if __name__=="__main__":main()
