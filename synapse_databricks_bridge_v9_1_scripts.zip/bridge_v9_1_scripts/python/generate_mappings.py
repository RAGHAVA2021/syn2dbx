"""Step 0a (SCRIPT_GUIDE.md): discover a Synapse schema and generate a pinned bridge config.

Only a deliberately narrow, predictable set of source types is generated.
Review the exceptions report and the output before seeding a new inventory wave.
"""
import argparse
import copy
import json
from pathlib import Path

from source_metadata import column_rows, hash_rows, ident


def column_contract(row):
    name, _ordinal, sql_type, max_length, precision, scale, _nullable = row
    ident(name)
    typ = sql_type.lower()
    if typ in ("varchar", "nvarchar", "char", "nchar"):
        if max_length == -1:
            raise ValueError(f"{name}: MAX-length text needs a reviewed LOB/CETAS route")
        spark_type = target_type = "string"
    elif typ == "int":
        spark_type = target_type = "int"
    elif typ == "bigint":
        spark_type = target_type = "bigint"
    elif typ == "date":
        spark_type = target_type = "date"
    elif typ in ("decimal", "numeric") and 1 <= precision <= 38 and 0 <= scale <= precision:
        spark_type = target_type = f"decimal({precision},{scale})"
    else:
        raise ValueError(f"{name}: SQL type {sql_type} requires a reviewed Parquet/Spark mapping")
    return {"source": name, "target": name, "conversion": "DIRECT",
            "source_spark_type": spark_type, "target_type": target_type}


TEMPLATE_ONLY_FIELDS = ("size_class", "source_profile", "materialised_schema", "materialised_table",
                        "physical_properties")


def make_mapping(base, schema, view, target_catalog, target_schema, prefix, rows, source_kind="view"):
    ident(schema); ident(view); ident(target_catalog); ident(target_schema)
    if prefix and not view.startswith(prefix):
        raise ValueError("View is outside the selected prefix")
    table = view[len(prefix):] if prefix else view
    ident(table)
    mapping_id = "MAP_" + view
    if len(mapping_id) > 70:
        raise ValueError("View name is too long for generated candidate table names")
    columns = [column_contract(row) for row in rows]
    if len({c["target"].lower() for c in columns}) != len(columns):
        raise ValueError("Case-insensitive duplicate column names")
    result = copy.deepcopy(base)
    # Never inherit the template's profile, size class or physical-table association.
    for field in TEMPLATE_ONLY_FIELDS:
        result.pop(field, None)
    result.update({"mapping_id": mapping_id, "group_id": "independent_" + view,
                   "strategy": "REPLACE_TABLE", "mandatory": False, "method": "CETAS",
                   "source_schema": schema, "source_view": view,
                   "source_schema_version": hash_rows(rows),
                   "group_contract_version": "independent_v1",
                   "target_catalog": target_catalog, "target_schema": target_schema,
                   "target_table": table, "allow_empty": False, "columns": columns})
    if source_kind == "table":
        # A directly selected table is its own materialised table (used by the profilers).
        result.update({"materialised_schema": schema, "materialised_table": view})
    return result


def main():
    from bridge_run import db
    p = argparse.ArgumentParser()
    p.add_argument("--schema", required=True, help="Synapse schema containing source objects")
    p.add_argument("--source-kind", choices=("table", "view"), default="view")
    p.add_argument("--view-prefix", default="", help="Optional object prefix to select and strip from target names")
    p.add_argument("--target-catalog", required=True)
    p.add_argument("--target-schema", required=True)
    p.add_argument("--inventory-version", required=True)
    p.add_argument("--output", required=True)
    args = p.parse_args()
    ident(args.schema); ident(args.target_catalog); ident(args.target_schema)
    if args.view_prefix: ident(args.view_prefix)
    source = Path(__file__).resolve().parents[1] / "config.example.json"
    template = json.loads(source.read_text())
    base = template["mappings"][0]
    template["inventory_version"] = args.inventory_version
    errors, mappings, targets = [], [], set()
    with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as conn:
        source_relation = "sys.tables" if args.source_kind == "table" else "sys.views"
        views = [r[0] for r in conn.cursor().execute(
            f"SELECT v.name FROM {source_relation} AS v JOIN sys.schemas AS s ON v.schema_id=s.schema_id "
            "WHERE s.name=? ORDER BY v.name", args.schema).fetchall()]
        if args.view_prefix:
            views = [v for v in views if v.startswith(args.view_prefix)]
        if not views: raise ValueError("No matching source views")
        for view in views:
            try:
                m = make_mapping(base, args.schema, view, args.target_catalog,
                                 args.target_schema, args.view_prefix,
                                 column_rows(conn, args.schema, view), args.source_kind)
                key = m["target_table"].lower()
                if key in targets: raise ValueError("Case-insensitive target collision")
                targets.add(key)
                mappings.append(m)
            except (ValueError, RuntimeError, KeyError) as exc:
                errors.append({"schema": args.schema, "view": view, "reason": str(exc)})
    report = Path(args.output).with_suffix(".exceptions.json")
    report.write_text(json.dumps({"selected_views": len(views), "generated": len(mappings),
                                  "exceptions": errors}, indent=2) + "\n")
    if errors:
        raise SystemExit(f"{len(errors)} view(s) need a reviewed mapping; see {report}. No config written.")
    template["mappings"] = mappings
    output = Path(args.output)
    if output.exists(): raise SystemExit(f"Refusing to overwrite {output}; inventory versions are immutable")
    output.write_text(json.dumps(template, indent=2) + "\n")
    print(f"Generated {len(mappings)} mappings in {output}; review before seeding. Exceptions: {report}")


if __name__ == "__main__":
    main()
