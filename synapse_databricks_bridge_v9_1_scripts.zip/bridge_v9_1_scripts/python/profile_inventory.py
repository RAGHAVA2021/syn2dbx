"""Step 0b (SCRIPT_GUIDE.md): profile dedicated-pool tables without scanning their data.

A mapping whose source is a view is profiled through its reviewed
materialised_schema/materialised_table association.

This is a planning snapshot, not an estimate of exported Parquet bytes or a
replacement for the upstream generation's exact row-count audit.
"""
import argparse
import csv
import json
from datetime import datetime, timezone
from pathlib import Path

from bridge_run import db, config, size_class, valid_thresholds


# Use only the base heap/clustered index (0/1); joining nonclustered indexes
# would count a table more than once. Physical bytes include replicated copies.
PROFILE_SQL = """
WITH column_counts AS (
 SELECT s.name AS schema_name, t.name AS table_name, COUNT(*) AS column_count
 FROM sys.schemas AS s
 JOIN sys.tables AS t ON t.schema_id = s.schema_id
 JOIN sys.columns AS c ON c.object_id = t.object_id
 WHERE s.name = ?
 GROUP BY s.name, t.name
), per_distribution AS (
 SELECT s.name AS schema_name, t.name AS table_name,
        tp.distribution_policy_desc AS distribution_policy,
        nt.distribution_id,
        SUM(CAST(ps.row_count AS bigint)) AS rows_in_distribution,
        SUM(CAST(ps.used_page_count AS bigint)) * CAST(8192 AS bigint) AS used_bytes
 FROM sys.schemas AS s
 JOIN sys.tables AS t ON t.schema_id = s.schema_id
 JOIN sys.indexes AS ix ON ix.object_id = t.object_id AND ix.index_id <= 1
 JOIN sys.pdw_table_distribution_properties AS tp ON tp.object_id = t.object_id
 JOIN sys.pdw_table_mappings AS tm ON tm.object_id = t.object_id
 JOIN sys.pdw_nodes_tables AS nt ON nt.name = tm.physical_name
 JOIN sys.dm_pdw_nodes AS pn ON pn.pdw_node_id = nt.pdw_node_id AND pn.type = 'COMPUTE'
 JOIN sys.dm_pdw_nodes_db_partition_stats AS ps
   ON ps.object_id = nt.object_id AND ps.pdw_node_id = nt.pdw_node_id
  AND ps.distribution_id = nt.distribution_id AND ps.index_id = ix.index_id
 WHERE s.name = ?
 GROUP BY s.name, t.name, tp.distribution_policy_desc, nt.distribution_id
)
SELECT pd.schema_name, pd.table_name, pd.distribution_policy, cc.column_count,
       CASE WHEN distribution_policy = 'REPLICATE'
            THEN MAX(rows_in_distribution) ELSE SUM(rows_in_distribution) END AS estimated_rows,
       SUM(used_bytes) AS physical_used_bytes
FROM per_distribution AS pd
JOIN column_counts AS cc ON cc.schema_name = pd.schema_name AND cc.table_name = pd.table_name
GROUP BY pd.schema_name, pd.table_name, pd.distribution_policy, cc.column_count
"""


def physical_key(m):
    schema = m.get("materialised_schema", m["source_schema"])
    table = m.get("materialised_table", m["source_view"])
    return schema.lower(), table.lower()


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True, help="Reviewed source-table inventory")
    p.add_argument("--output", required=True, help="New, immutable profiled config JSON")
    p.add_argument("--inventory-version", required=True, help="New inventory version")
    a = p.parse_args()
    source = config(a.config)
    dest = Path(a.output)
    report = dest.with_suffix(".profile.csv")
    if dest.exists() or report.exists():
        raise FileExistsError("Profile output or report already exists; use a new version")
    if a.inventory_version == source["inventory_version"]:
        raise ValueError("Profiled inventory needs a new version and reviewed control seed")
    limits = source.get("profile_thresholds", {})
    if not valid_thresholds(limits):
        raise ValueError("Set reviewed increasing profile_thresholds in the input config")
    with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as conn:
        schema_names = sorted({physical_key(m)[0] for m in source["mappings"]})
        profiles = {}
        for schema in schema_names:
            for row in conn.cursor().execute(PROFILE_SQL, schema, schema).fetchall():
                key = (row[0].lower(), row[1].lower())
                if key in profiles:
                    raise ValueError(f"Duplicate source profile: {key}")
                profiles[key] = tuple(row)

    snapshot = datetime.now(timezone.utc).isoformat()
    planned = []
    for m in source["mappings"]:
        key = physical_key(m)
        if key not in profiles:
            raise ValueError(f"No physical dedicated-pool table profile for {key}; for a view set the reviewed "
                             "materialised_schema and materialised_table")
        row = profiles[key]
        rows, used_bytes = int(row[4]), int(row[5])
        if rows < 0 or used_bytes < 0:
            raise ValueError(f"Invalid table statistics for {key}")
        columns = int(row[3])
        if columns != len(m["columns"]):
            raise ValueError(f"Approved mapping does not contain all {columns} source columns: {key}")
        cls = size_class(rows, columns, used_bytes, limits)
        m["size_class"] = cls
        m["source_profile"] = {"profiled_at_utc": snapshot, "estimated_rows": rows,
                               "column_count": columns, "physical_used_bytes": used_bytes,
                               "distribution_policy": row[2],
                               "source_schema_version": m["source_schema_version"]}
        planned.append({"source_schema": row[0], "source_table": row[1],
                        "mapping_id": m["mapping_id"], "estimated_rows": rows,
                        "column_count": columns, "physical_used_gib": round(used_bytes / 2**30, 3),
                        "distribution_policy": row[2], "size_class": cls,
                        "profiled_at_utc": snapshot})
    source["inventory_version"] = a.inventory_version
    source["require_profiles"] = True
    planned.sort(key=lambda x: (-x["physical_used_gib"], -x["estimated_rows"], x["mapping_id"]))
    # Validate the complete snapshot before either file is written.
    import tempfile
    with tempfile.TemporaryDirectory() as tmp:
        probe = Path(tmp) / "config.json"
        probe.write_text(json.dumps(source))
        config(probe)
    with report.open("x", newline="") as file:
        writer = csv.DictWriter(file, fieldnames=list(planned[0]))
        writer.writeheader()
        writer.writerows(planned)
    dest.write_text(json.dumps(source, indent=2) + "\n")
    print(f"Profiled {len(planned)} tables; review {report}, then seed {a.inventory_version}")


if __name__ == "__main__":
    main()
