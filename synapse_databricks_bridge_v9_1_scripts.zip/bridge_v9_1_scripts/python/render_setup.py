"""Step 2 (SCRIPT_GUIDE.md): render Azure SQL control seeds and Unity Catalog setup SQL.

Safe to run for every inventory wave: every statement is idempotent. Existing
target state and published pointers are never reset, and a seeded member that
differs from the config stops the script instead of being silently kept.
Physical snapshot tables are created here with the loader's exact DDL, so the
consumer views can be created before the first load.
"""
import argparse
from pathlib import Path

from bridge_run import METADATA_COLUMNS, config, ident, target_key


def q(s):
    ident(s)
    return "`" + s + "`"


def lit(s):
    if "'" in str(s):
        raise ValueError("Invalid literal")
    return "'" + str(s) + "'"


def physical_ddl(m):
    table = f"{q(m['target_catalog'])}.{q(m['physical_schema'])}.{q(m['target_table'] + '_snapshots')}"
    cols = ", ".join(f"{q(c['target'])} {c['target_type'].upper()}" for c in m["columns"])
    meta = ", ".join(f"{q(k)} STRING" for k in METADATA_COLUMNS)
    props = ", ".join(f"'{k}'='{v}'" for k, v in sorted(m["physical_properties"].items()))
    return f"CREATE TABLE IF NOT EXISTS {table} ({cols}, {meta}) USING DELTA TBLPROPERTIES ({props});", table


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--output-dir", required=True)
    a = p.parse_args()
    doc = config(a.config)
    dest = Path(a.output_dir); dest.mkdir(parents=True, exist_ok=True)
    control = f"{q(doc['control_catalog'])}.{q(doc['control_schema'])}"
    inv = lit(doc["inventory_version"])
    azure = ["-- Run against Azure SQL. Idempotent: safe to re-run and safe for later waves.",
             "SET XACT_ABORT ON;", "BEGIN TRANSACTION;"]
    uc = ["-- Run against a Unity Catalog SQL warehouse as the deployment identity. Idempotent.",
          f"CREATE SCHEMA IF NOT EXISTS {control};",
          f"CREATE TABLE IF NOT EXISTS {control}.published_groups (",
          " group_id STRING NOT NULL, published_release_id STRING, published_sequence BIGINT,",
          " high_water_sequence BIGINT, previous_release_id STRING,",
          " control_version BIGINT, published_at TIMESTAMP) USING DELTA;"]
    groups = {}
    for m in doc["mappings"]:
        member = (f"inventory_version={inv} AND mapping_id={lit(m['mapping_id'])}")
        same = (f"group_id={lit(m['group_id'])} AND enabled=1 AND mandatory={1 if m['mandatory'] else 0} "
                f"AND strategy={lit(m['strategy'])}")
        azure.append(f"IF EXISTS (SELECT 1 FROM bridge.group_members WHERE {member} AND NOT ({same})) "
                     f"THROW 51010, 'Seeded member {m['mapping_id']} differs from this config; use a new inventory version', 1;")
        azure.append(f"IF NOT EXISTS (SELECT 1 FROM bridge.group_members WHERE {member}) "
                     "INSERT bridge.group_members(inventory_version,group_id,mapping_id,enabled,mandatory,strategy) "
                     f"VALUES ({inv},{lit(m['group_id'])},{lit(m['mapping_id'])},1,"
                     f"{1 if m['mandatory'] else 0},{lit(m['strategy'])});")
        groups.setdefault(target_key(m), []).append(m)
        for s in ("candidate_schema", "physical_schema", "target_schema"):
            uc.append(f"CREATE SCHEMA IF NOT EXISTS {q(m['target_catalog'])}.{q(m[s])};")
    for key, members in groups.items():
        azure.append(f"IF NOT EXISTS (SELECT 1 FROM bridge.target_state WHERE target_key={lit(key)}) "
                     "INSERT bridge.target_state(target_key,published_release_id,published_sequence,high_water_sequence) "
                     f"VALUES ({lit(key)},'NONE',-1,-1);")
        if members[0]["strategy"] != "RELEASE_POINTER":
            continue
        group = members[0]["group_id"]
        uc.append(f"MERGE INTO {control}.published_groups AS t USING (SELECT {lit(group)} AS group_id) AS s "
                  "ON t.group_id = s.group_id WHEN NOT MATCHED THEN INSERT "
                  "(group_id,published_release_id,published_sequence,high_water_sequence,previous_release_id,"
                  "control_version,published_at) VALUES (s.group_id,'NONE',-1,-1,NULL,0,current_timestamp());")
        for m in members:
            ddl, table = physical_ddl(m)
            uc.append(ddl)
            view = f"{q(m['target_catalog'])}.{q(m['target_schema'])}.{q(m['target_table'])}"
            selected = ", ".join(q(c["target"]) for c in m["columns"])
            uc.append("-- Confirm governed row filters/masks on the PHYSICAL table and grant users only the VIEW.\n"
                      "-- IF NOT EXISTS keeps existing grants; a column change needs a governed view change.\n"
                      f"CREATE VIEW IF NOT EXISTS {view} AS SELECT {selected} FROM {table} WHERE release_id = "
                      f"(SELECT published_release_id FROM {control}.published_groups WHERE group_id={lit(group)});")
    azure.append("COMMIT;")
    (dest / "azure_sql_seed.sql").write_text("\n".join(azure) + "\n")
    (dest / "unity_catalog_setup.sql").write_text("\n".join(dict.fromkeys(uc)) + "\n")
    print(dest)


if __name__ == "__main__":
    main()
