# Synapse to Databricks bridge: v9.1 executable reference

> **Start with [`SCRIPT_GUIDE.md`](SCRIPT_GUIDE.md)** — it lists every script in execution order with its purpose, who runs it, and what it reads and writes. v9.1 fixes are summarised at the end of this file.

This package accompanies `syn_views_2_dbx_tbl_v9.md`. It is parameterised code, **not a completed deployment for the actual estate**. It cannot be run unchanged: the sample has fictitious names and the real mappings, identities, network, table contracts, security policies, ADF linked services and Databricks jobs have not been supplied.

## Scope and current limits

The supplied code implements the core full-load path: a governed source fence, upstream view audit, CETAS or ADF Copy to unique ADLS attempt paths, a three-way row count, Delta candidate or multi-release physical writes, independent table replacement and an atomic group pointer. It refuses unsafe identifiers, duplicate mappings, optional pointer members, schema drift, stale publication and blind reruns. Failed runs are continued explicitly with `--resume` under an orchestrator lease; nothing retries silently, and an operation whose outcome is unknown keeps the lease until it expires.

Several v9 production controls need environment-specific implementations before any production run: source writer inventory and removal of bypass writes; audit-stream/fence-violation detectors; table-level mask/ABAC inventory and restricted-identity policy tests; consumer contracts and streaming/CDF tests; source/Delta business-total checks; rollback automation; case-specific `time`/timestamp/ancient-date conversion; large-object chunking; and monitoring/on-call integration. The evidence file is a record of those external tests, not a way to bypass them. For any mapping requiring those features, extend and validate the code before enabling it. **Do not use this package alone to declare v9 fully implemented.**

Only direct named source columns and a controlled GUID-to-text conversion are rendered for CETAS/Copy. There is no unrestricted SQL expression field. The basic Spark type conversion should be extended for specific source timestamp/decimal contracts after full-volume testing. The ADF route uses one unpartitioned Copy Activity; set additional source parallelism only after capacity testing. The Python bridge runs bounded concurrent extracts, serverless loads, and publications across disjoint target keys. Members within one publication group remain ordered. Benchmark the full 1,000-table path before declaring an overnight SLO.

## Files

See [`SCRIPT_GUIDE.md`](SCRIPT_GUIDE.md) for the full, ordered explanation. Summary:

| File | Execution context |
|---|---|
| `sql/01_azure_sql_control.sql` | Azure SQL control database administrator (new deployments) |
| `sql/03_upgrade_v9_to_v9_1.sql` | Azure SQL control database administrator (existing v9 deployments) |
| `sql/02_synapse_setup.sql` | Existing Synapse dedicated SQL pool database administrator |
| `python/generate_mappings.py` / `databricks/generate_mappings_pyspark.py` | Discover a Synapse schema and generate a pinned mapping inventory |
| `python/profile_inventory.py` / `databricks/profile_inventory_pyspark.py` | Non-scanning dedicated-pool profile, CSV report and a new versioned config |
| `python/source_metadata.py` | Reproducible source schema hash (also a shared library) |
| `python/render_setup.py` | Idempotent control seeds and Unity Catalog setup SQL for each wave |
| `python/deploy_adf.py` | Optional Copy route; deploy reviewed ADF objects |
| `python/fence.py` | Source fence transitions, including `abandon`/`reopen` recovery |
| `python/upstream_audit.py` | After Synapse materialisation, while upstream owns WRITE_ACTIVE |
| `python/bridge_run.py` | Control host: extraction and Databricks loading; `--resume` |
| `databricks/load_candidate.py` | Loader Job |
| `python/publish_run.py` | Control host: gated publication; `--resume` reconciles with Delta |
| `databricks/publish.py` | Strategy A publisher Job and group-pointer Job (PUBLISH / INSPECT) |
| `python/retire_releases.py` / `databricks/retire_releases.py` | Retention of superseded releases, candidates and staging paths |
| `tests/` | Contract tests and a SQLite-backed orchestration simulation |

## Before the first run

1. Copy `config.example.json` to a private `config.json`, or use `python/generate_mappings.py` or `databricks/generate_mappings_pyspark.py` as documented in `WHERE_TO_ENTER_VALUES.md` to discover a large source schema. For physical source tables, run `databricks/profile_inventory_pyspark.py` on a manually created, Unity Catalog-enabled Databricks classic cluster. Set its input/output UC volume paths, dedicated-pool JDBC connection and new inventory version. Review the accompanying `.profile.csv` report and configured class thresholds. The orchestration-host `python/profile_inventory.py` remains an alternative, not a prerequisite. Seed **the new profile inventory version**, not the input version. Replace every `<...>` marker; review all mappings, source hashes, ordered column types and exceptions. Choose `REPLACE_TABLE` or `RELEASE_POINTER` by the v9 consistency review. All enabled pointer members must be mandatory and have the same `group_contract_version`. The example count and types are illustrations only.
2. Install Microsoft ODBC Driver 18 for SQL Server and `pip install -r requirements.txt`. Supply the secure ODBC connection strings via `BRIDGE_CONTROL_ODBC`, `BRIDGE_SYNAPSE_AUDIT_ODBC`, `BRIDGE_CETAS_ODBC`, and optionally the identity used for source writer procedures. Do not print them. The CETAS SQL login and source storage credential are different principals. The host identity also needs read/list access to the ADLS staging prefix to prove an attempt path is empty, and write access (create only) under `bridge/parquet-stage/_manifests/` for job manifests; delete access is needed only if you use `retire_releases.py --delete-staging`; the Databricks job reads through its UC external location. Configure Databricks unified authentication for the three job invocations. ADF API access uses `DefaultAzureCredential`.
3. Create Azure SQL tables and stored procedure (`01_azure_sql_control.sql`, or `03_upgrade_v9_to_v9_1.sql` for an existing v9 database — publish any READY v9 run with the v9 scripts first); seed `bridge.source_fence` once. Create Synapse audit, credential, external data source and Parquet file format after the administrator provisions its database master key. Fill the ADLS account/container in the SQL script, then run it once. Grant stored-procedure execution to registered writer/bridge identities but no direct fence-table write privileges. Ensure all governed Synapse writers, including replays and support, acquire the same fence before modification.
4. For each source view, run `python python/source_metadata.py --schema presentation --view v_customer` and record the hash in the config. Recompute on any schema change. Keep a versioned, immutable copy of `config.json` per run. Precreate UC catalogs, schemas, staging external location, service principals and policy functions. Verify runtime and warehouse support for every write and policy inspection command. Grant the Strategy A publisher `MANAGE` on existing consumer tables, `CREATE TABLE` on their schema, plus `SELECT` on candidate tables. Grant the loader no `MANAGE` on consumer tables.
5. Run `python python/render_setup.py --config config.json --output-dir generated`. Review and execute `generated/azure_sql_seed.sql` in the control database and `generated/unity_catalog_setup.sql` on a Databricks SQL warehouse. Both are idempotent: rerun them for every new inventory wave; existing target state and pointers are never reset, and a seeded member that differs from the config stops the script. The UC script creates the physical snapshot tables with the loader's exact DDL, inserts the `NONE` pointer and creates the stable views, so no load has to run first. Do not grant users access to physical snapshot tables, unpublished candidates or the pointer control table. Apply and test either governed policies on physical tables or approved dynamic view SQL; the generated views assume `PHYSICAL_TABLE_POLICY` and must not be used for groups requiring the other mode.
6. Follow `WHERE_TO_ENTER_VALUES.md` for the UC staging external location and four **Serverless** single-task notebook Jobs: loader (`databricks/load_candidate.py`), Strategy A publisher and group-pointer publisher (`databricks/publish.py`, separate identities), and retention (`databricks/retire_releases.py`). Each takes the notebook parameters `manifest_path` and `manifest_sha256`, and each Run-as identity needs `READ FILES` on the staging external location to read its manifest. Disable serverless automatic retries for publication and retention tasks. Set the four job IDs in config. If using Copy, deploy the reviewed datasets and pipeline with `python python/deploy_adf.py --config config.json --synapse-linked-service ... --adls-linked-service ... --container ... --source-dummy-table ...`. The linked services must exist already, with correct network and secret access. Inspect pipeline metrics for skipped/truncated rows during the acceptance run.
7. Test the exact privilege, policy and staging access paths with the intended service principals. Benchmark the full-sized largest objects, CETAS/Copy mixture, Parquet scan, Delta write, publication and rollback. Set `max_extraction_workers`, `extraction_class_limits`, `max_loader_workers`, `max_publisher_workers` and `minimum_fence_margin_minutes` to measured values. Set the loader and publisher Jobs' **Maximum concurrent runs** to at least their respective worker limits; verify workspace/serverless quotas separately. Set `max_attempts`, `takeover_after_minutes` and `heartbeat_seconds` (see *Failure and recovery*).

### Profiling and workload classes

Both profilers use dedicated-pool distribution metadata. Their `estimated_rows` and `physical_used_bytes` are planning measurements, not a point-in-time source audit and **not predicted Parquet output bytes**. Replicated tables are counted once for estimated logical rows, but physical bytes include replicated copies. Index maintenance affects the accuracy of DMV counts. The report includes source schema/table, estimated rows, actual source column count, physical GiB, distribution, and SMALL/MEDIUM/LARGE classification. Limits are initial *examples* (`profile_thresholds`); set them from measured execution time and source queue pressure. An object becomes the largest class triggered by its rows, physical size, or column count. The extract scheduler starts large objects early while respecting both the aggregate worker cap and each class cap. It does not use the profile count for reconciliation: the nightly upstream audit remains authoritative. Generate a fresh reviewed inventory when table shape or workload characteristics change. Views without a directly profiled materialised table require a separate approved size measurement; the profilers deliberately stop.

## Nightly command order

All identifiers below are examples. The **same generation** is used from upstream materialisation through the source read. An existing upstream scheduler invokes these as job steps; no secret or manual GUI action is required once the identities and external gates are implemented.

```bash
python python/fence.py write-start --source-set synapse_materialised --generation GEN_20260922_01 --actor SYN_20260922_01 --expiry-utc 2026-09-22T08:00:00
# Run the existing Synapse transformation/materialisation job here.
python python/upstream_audit.py --config config.json --upstream-run-id SYN_20260922_01 --generation-id GEN_20260922_01 --writer-owner SYN_20260922_01 --sequence 2026092201 --business-date 2026-09-22
python python/fence.py write-close --source-set synapse_materialised --generation GEN_20260922_01 --actor SYN_20260922_01 --expiry-utc 2026-09-22T08:00:00
python python/fence.py bridge-hold --config config.json --upstream-run-id SYN_20260922_01 --source-set synapse_materialised --generation GEN_20260922_01 --actor BRG_20260922_01 --expiry-utc 2026-09-22T08:00:00
python python/bridge_run.py --config config.json --upstream-run-id SYN_20260922_01 --generation-id GEN_20260922_01 --sequence 2026092201 --business-date 2026-09-22 --bridge-run-id BRG_20260922_01
# Produce real audit/monitoring/source-smoke evidence and inspect every source request.
python python/fence.py bridge-release --source-set synapse_materialised --generation GEN_20260922_01 --actor BRG_20260922_01 --evidence fence_evidence.json
# Run policy/consumer/readiness tests with the correct restricted identities.
python python/publish_run.py --config config.json --bridge-run-id BRG_20260922_01 --evidence publication_evidence.json
# Optional, e.g. weekly: review the dry run, then apply.
python python/retire_releases.py --config config.json
python python/retire_releases.py --config config.json --execute --delete-staging
```

The `fence_evidence.json` must contain `source_generation_id`, and each of `all_source_requests_terminal`, `no_source_retry_needed`, `audit_healthy`, `no_fence_violation`, `smoke_check_passed` set to `true`, with a separate `<field>_evidence_uri` for each. The publication evidence must contain `bridge_run_id`, `release_id`, `generation_id`, integer `upstream_sequence`, and `fence_clean`, `source_smoke_check`, `audit_health`, `policy_readiness`, `restricted_identity_tests`, `consumer_contract_tests`, each with a `<field>_evidence_uri`. An external evidence producer must generate them from actual platform records; a hand-written `true` file provides no assurance.

## Failure and recovery

Every run carries an orchestrator lease (`bridge.runs.orchestrator_token` plus a heartbeat every `heartbeat_seconds`). All control writes are conditional on the token, so a superseded process cannot change state. A run can be taken over only when no token is held or its heartbeat is older than `takeover_after_minutes`.

- **Extraction or load failed** (`bridge.runs.status = FAILED`): fix the cause, then rerun `bridge_run.py` with the **same arguments plus `--resume`**. READY mappings are kept; EXTRACTED/LOADING mappings are reloaded idempotently from their retained Parquet; FAILED or interrupted extractions get a new `attempt-NNN` path, up to `max_attempts`. The fence must still be held if anything needs re-extraction.
- **Orchestrator crashed or timed out on an external job**: the run keeps its token. Wait `takeover_after_minutes`, confirm the Databricks/ADF/Synapse request IDs in `bridge.object_attempts` are terminal, then `--resume`. Timed-out Databricks and ADF runs are cancelled automatically; if cancellation cannot be confirmed the error says so and the lease is not released.
- **Publication interrupted** (`PUBLISHING`): rerun `publish_run.py` with `--resume`. Each target is compared with its actual Delta state first: a commit whose Azure SQL update was lost is reconciled, not republished; an unexpected Delta state stops that target for review.
- **Generation unusable** (source changed, fence expired, too many attempts): `python python/fence.py abandon --source-set ... --generation ... --actor <current owner> --reason "..."` marks the generation's unpublished runs `ABANDONED_GENERATION`; then `fence.py reopen` returns the fence to AVAILABLE for a new generation. Abandon is refused while a run of that generation is PUBLISHING.
- **Fence release** is refused while the run still has an extraction in progress.

Do not publish a pointer group until all its physical slices, control row, policies and consumer views exist.

## Validation performed locally

`python -m compileall -q python databricks tests`; `python -m json.tool config.example.json`; `pytest -q tests` (43 tests). The contract tests check fail-closed config invariants; `tests/test_orchestration_sim.py` runs `bridge_run.py` and `publish_run.py` end to end against SQLite stand-ins for Azure SQL and Synapse with faked cloud calls, covering failure, `--resume`, lease takeover, post-extraction fence expiry and publication reconciliation, including refusal of an unexpected REPLACE_TABLE state on resume. `tests/test_static.py` checks the Databricks notebooks and scripts for top-level functions that are later overwritten, and that the notebook's `PACKAGE_DIR` matches the package folder. They do not run against Azure or prove permissions, policy visibility, lake storage semantics, performance or rollback. Run the deployment acceptance evidence from v9 in the actual workspaces.

## Product references

- [Synapse CETAS syntax and permissions](https://learn.microsoft.com/en-us/sql/t-sql/statements/create-external-table-as-select-transact-sql)
- [ADF pipeline createRun](https://learn.microsoft.com/en-us/rest/api/datafactory/pipelines/create-run)
- [ADF Copy from Synapse dedicated SQL pool](https://learn.microsoft.com/en-us/azure/data-factory/connector-azure-sql-data-warehouse)
- [Databricks SDK for Python](https://learn.microsoft.com/en-us/azure/databricks/dev-tools/sdk-python)
- [Databricks table replacement privileges](https://learn.microsoft.com/en-us/azure/databricks/tables/tables-concepts)
- [Delta idempotent writes](https://learn.microsoft.com/en-us/azure/databricks/structured-streaming/delta-lake)

## v9.1 fixes

| # | Problem in v9 | Fix |
|---|---|---|
| 1 | Fence checked only before extraction; a read could finish after the fence expired | `extract_one` re-checks the fence (margin 0) before marking EXTRACTED; expiry is compared in SQL |
| 2 | ADF row check passed when metrics were missing (`None == None`) and ignored the audited count | Requires integer `rowsRead == rowsCopied == source_rows`, filtered to the copy activity |
| 3 | No retry path: fixed `attempt-001`, rerun refused, fence could not be reassigned | `--resume`, attempt numbering, `max_attempts`, `SUPERSEDED` state; `fence.py abandon/reopen` |
| 4 | Multi-member REPLACE_TABLE groups published partially with no resume | REPLACE_TABLE groups must have exactly one member; `publish_run.py --resume` |
| 5 | Delta pointer and Azure SQL could diverge with no recovery | INSPECT mode + reconciliation on resume; pointer version read from Delta, not the SQL counter |
| 6 | Job payload in a notebook parameter exceeded the size limit for wide tables/groups | Payload written as an immutable, SHA-256-checked manifest under the staging location |
| 7 | Profilers could not size view-based mappings | Optional `materialised_schema`/`materialised_table`; generator sets them for tables |
| 8 | `render_setup.py` failed or duplicated rows on later waves | Fully idempotent SQL (`IF NOT EXISTS`, `MERGE`, drift check); physical tables pre-created |
| 9 | Candidate names collided for IDs differing only by `-`/`_` | Hash-based, attempt-specific candidate names computed once by the orchestrator |
| 10 | Property check failed for non-string values | Config requires string values; loader, publisher and check use them unchanged |
| 11 | CETAS metadata cleanup failure could hide the real error | Cleanup errors are reported separately and never replace the original error |
| — | ARM token fetched once, expired during two-hour ADF polls | Token fetched per request from a cached credential |
| — | Timed-out Databricks/ADF runs kept running while state moved on | Cancelled on timeout; unconfirmed cancellation keeps the lease |
| — | pyodbc `with` never closed connections; long-held idle connections | `db()` always closes; short-lived connections around long operations; CETAS statement timeout |
| — | Unknown `size_class` crashed the scheduler; profiler crashed on missing thresholds | Validated up front |
| — | Upstream sequence regressions caught only after a full extraction | `upstream_audit.py` enforces increasing sequences |
| — | `_snapshots`, candidates and staging grew without limit | `retire_releases.py` + retention Job |
| — | Unused imports, unused `LOADING` state, `CREATED` missing from the failure handler | Cleaned up; `LOADING` is now used |
| — | (v9.1 review) PySpark profiler rebound its `physical` lookup function as a DataFrame, so profiling failed | Function renamed `physical_source`, DataFrame `physical_df`; static test added |
| — | (v9.1 review) `publish_run.py --resume` could replace a REPLACE_TABLE target holding an unexpected release | Resume publishes only if Delta matches Azure SQL's published release (or no bridge release yet); otherwise the target is frozen |
| — | (v9.1 review) Notebook `PACKAGE_DIR` and docs used the old `bridge_v9_scripts` folder name | Updated to `bridge_v9_1_scripts`; test checks they match |
