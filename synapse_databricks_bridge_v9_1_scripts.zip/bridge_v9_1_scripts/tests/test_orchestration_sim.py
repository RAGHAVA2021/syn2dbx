"""Executes bridge_run.py and publish_run.py end to end against SQLite stand-ins.

Azure SQL and Synapse are emulated with SQLite (T-SQL functions translated);
CETAS, ADF, ADLS and Databricks jobs are replaced by fakes. This checks the
control-state wiring: leases, attempts, failure, --resume and reconciliation.
It does not replace the platform acceptance tests.
"""
import json
import re
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
import bridge_run  # noqa: E402
import publish_run  # noqa: E402

CONTROL_DDL = """
CREATE TABLE bridge.source_fence(source_set_id TEXT PRIMARY KEY, state TEXT, generation_id TEXT,
  writer_owner TEXT, bridge_owner TEXT, heartbeat_utc TEXT, expires_utc TEXT, control_version INT DEFAULT 0);
CREATE TABLE bridge.runs(bridge_run_id TEXT PRIMARY KEY, upstream_run_id TEXT, generation_id TEXT,
  upstream_sequence INT, business_date TEXT, inventory_version TEXT, release_id TEXT UNIQUE, status TEXT,
  orchestrator_token TEXT, heartbeat_utc TEXT, created_utc TEXT, updated_utc TEXT);
CREATE TABLE bridge.object_attempts(bridge_run_id TEXT, mapping_id TEXT, attempt INT, method TEXT, status TEXT,
  leaf_path TEXT UNIQUE, source_request_id TEXT, source_rows INT, parquet_rows INT, delta_rows INT,
  error_text TEXT, delta_target TEXT, updated_utc TEXT, retired_utc TEXT, staging_deleted_utc TEXT,
  PRIMARY KEY(bridge_run_id,mapping_id,attempt));
CREATE TABLE bridge.group_members(inventory_version TEXT, group_id TEXT, mapping_id TEXT, enabled INT,
  mandatory INT, strategy TEXT, PRIMARY KEY(inventory_version,mapping_id));
CREATE TABLE bridge.target_state(target_key TEXT PRIMARY KEY, published_release_id TEXT, published_sequence INT,
  high_water_sequence INT DEFAULT -1, previous_release_id TEXT, control_version INT DEFAULT 0);
"""
SYN_DDL = """
CREATE TABLE bridge_meta.upstream_run(upstream_run_id TEXT, source_generation_id TEXT, upstream_sequence INT,
  business_date TEXT, status TEXT, write_closed INT, completed_utc TEXT);
CREATE TABLE bridge_meta.upstream_object(upstream_run_id TEXT, mapping_id TEXT, source_schema_version TEXT,
  status TEXT, row_count INT, refresh_started_utc TEXT, refresh_completed_utc TEXT);
"""
CLOCK = {"now": datetime(2026, 9, 22, 1, 0, 0)}


def ts(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S.%f")


def translate(sql):
    sql = re.sub(r"\bINSERT (bridge|bridge_meta)\.", r"INSERT INTO \1.", sql)
    sql = sql.replace("COUNT_BIG(", "count(").replace("count_big(", "count(")
    sql = sql.replace("DATEADD(minute,", "DATEADD('minute',")
    return sql


class Cursor:
    def __init__(self, conn):
        self.c = conn.raw.cursor()
        self.rowcount = -1

    def execute(self, sql, *params):
        params = [str(p) if hasattr(p, "isoformat") else p for p in params]
        self.c.execute(translate(sql), params)
        self.rowcount = self.c.rowcount
        return self

    def fetchone(self):
        return self.c.fetchone()

    def fetchall(self):
        return self.c.fetchall()

    def __iter__(self):
        return iter(self.c.fetchall())


class Conn:
    def __init__(self, path, schema):
        self.raw = sqlite3.connect(":memory:", isolation_level="DEFERRED", check_same_thread=False)
        self.raw.execute(f"ATTACH DATABASE '{path}' AS {schema}")
        self.raw.create_function("SYSUTCDATETIME", 0, lambda: ts(CLOCK["now"]))
        self.raw.create_function("DATEADD", 3, lambda unit, n, t: ts(
            datetime.strptime(t, "%Y-%m-%d %H:%M:%S.%f") + timedelta(minutes=n)))
        self.timeout = 0

    def cursor(self):
        return Cursor(self)

    def commit(self):
        self.raw.commit()

    def rollback(self):
        self.raw.rollback()

    def close(self):
        self.raw.close()


@pytest.fixture
def env(tmp_path, monkeypatch):
    control_db, syn_db = tmp_path / "control.db", tmp_path / "syn.db"
    for path, schema, ddl in ((control_db, "bridge", CONTROL_DDL), (syn_db, "bridge_meta", SYN_DDL)):
        c = Conn(path, schema); c.raw.executescript(ddl); c.commit(); c.close()

    from contextlib import contextmanager

    @contextmanager
    def fake_db(var, autocommit=False):
        conn = Conn(control_db, "bridge") if var == "BRIDGE_CONTROL_ODBC" else Conn(syn_db, "bridge_meta")
        try:
            yield conn
        except BaseException:
            conn.rollback(); raise
        finally:
            conn.close()

    doc = json.loads((ROOT / "config.example.json").read_text())
    doc["control_catalog"] = "cat"
    doc["staging_abfss_root"] = "abfss://landing@acct.dfs.core.windows.net"
    doc["loader_job_id"] = doc["publisher_job_id"] = doc["pointer_job_id"] = 1
    doc["heartbeat_seconds"] = 600
    for m in doc["mappings"]:
        m["target_catalog"] = "cat"
        m["source_schema_version"] = "sha256:x"
    cfg_path = tmp_path / "config.json"; cfg_path.write_text(json.dumps(doc))

    with fake_db("BRIDGE_CONTROL_ODBC") as c:
        cur = c.cursor()
        cur.execute("INSERT INTO bridge.source_fence VALUES ('synapse_materialised','BRIDGE_HELD','GEN1',NULL,'BRG1',NULL,?,3)",
                    ts(CLOCK["now"] + timedelta(hours=6)))
        for m in doc["mappings"]:
            cur.execute("INSERT INTO bridge.group_members VALUES (?,?,?,1,?,?)", doc["inventory_version"],
                        m["group_id"], m["mapping_id"], 1 if m["mandatory"] else 0, m["strategy"])
        for key in {bridge_run.target_key(m) for m in doc["mappings"]}:
            cur.execute("INSERT INTO bridge.target_state(target_key,published_release_id,published_sequence,"
                        "high_water_sequence) VALUES (?,'NONE',-1,-1)", key)
        c.commit()
    with fake_db("SYN") as s:
        cur = s.cursor()
        cur.execute("INSERT INTO bridge_meta.upstream_run VALUES ('SYN1','GEN1',100,'2026-09-22','COMPLETE',1,NULL)")
        for i, m in enumerate(doc["mappings"]):
            cur.execute("INSERT INTO bridge_meta.upstream_object VALUES ('SYN1',?,'sha256:x','COMPLETE',?,NULL,NULL)",
                        m["mapping_id"], 10 + i)
        s.commit()

    state = {"fail_extract": set(), "delta": {}, "pointer": {"sales": "NONE"}, "calls": [],
             "fail_after_publish": False}

    def fake_extract(m, relative):
        state["calls"].append(("extract", m["mapping_id"], relative))
        if m["mapping_id"] in state["fail_extract"]:
            state["fail_extract"].discard(m["mapping_id"])
            raise RuntimeError("simulated CETAS failure")
        return "x_req"

    def fake_copy(cfg, m, item):
        return fake_extract(m, item["relative_path"])

    def fake_job(cfg, job_id, payload, run_id):
        mode = payload.get("mode")
        if "leaf_path" in payload:                                   # loader
            n = payload["source_rows"]
            state["calls"].append(("load", payload["mapping_id"], payload["attempt"]))
            return {"source_rows": n, "parquet_rows": n, "delta_rows": n,
                    "target": bridge_run.delta_target(payload, payload["bridge_run_id"], payload["attempt"]),
                    "release_id": payload["release_id"]}
        if payload["strategy"] == "REPLACE_TABLE":
            m = payload["mapping"]
            if mode == "INSPECT":
                rel = state["delta"].get(m["target_table"])
                return {"exists": bool(rel), "release_ids": [rel] if rel else [], "rows": m["source_rows"]}
            state["delta"][m["target_table"]] = payload["release_id"]
            state["calls"].append(("publish", m["target_table"]))
            return {"release_id": payload["release_id"], "rows": m["source_rows"]}
        if mode == "INSPECT":
            return {"published_release_id": state["pointer"][payload["group_id"]]}
        assert state["pointer"][payload["group_id"]] == payload["expected_current_release"]
        state["pointer"][payload["group_id"]] = payload["release_id"]
        state["calls"].append(("pointer", payload["group_id"]))
        if state["fail_after_publish"]:
            state["fail_after_publish"] = False
            raise RuntimeError("simulated lost acknowledgement after Delta commit")
        return {"group_id": payload["group_id"], "release_id": payload["release_id"]}

    import source_metadata
    monkeypatch.setattr(bridge_run, "db", fake_db)
    monkeypatch.setattr(publish_run, "db", fake_db)
    monkeypatch.setattr(bridge_run, "cetas", fake_extract)
    monkeypatch.setattr(bridge_run, "copy_activity", fake_copy)
    monkeypatch.setattr(bridge_run, "notebook_job", fake_job)
    monkeypatch.setattr(publish_run, "notebook_job", fake_job)
    monkeypatch.setattr(bridge_run, "require_empty_adls", lambda root, rel: None)
    monkeypatch.setattr(source_metadata, "schema_hash", lambda conn, s, v: "sha256:x")

    def run(module, *argv):
        monkeypatch.setattr(sys, "argv", ["x", *argv])
        module.main()

    def query(sql, *params):
        with fake_db("BRIDGE_CONTROL_ODBC") as c:
            rows = c.cursor().execute(sql, *params).fetchall()
            c.commit()
            return rows

    evidence = tmp_path / "ev.json"
    ev = {"bridge_run_id": "BRG1", "release_id": "rel_BRG1", "generation_id": "GEN1", "upstream_sequence": 100}
    for gate in ("fence_clean", "source_smoke_check", "audit_health", "policy_readiness",
                 "restricted_identity_tests", "consumer_contract_tests"):
        ev[gate] = True; ev[gate + "_evidence_uri"] = "https://evidence/" + gate
    evidence.write_text(json.dumps(ev))
    extract_args = ["--config", str(cfg_path), "--upstream-run-id", "SYN1", "--generation-id", "GEN1",
                    "--sequence", "100", "--business-date", "2026-09-22", "--bridge-run-id", "BRG1"]
    publish_args = ["--config", str(cfg_path), "--bridge-run-id", "BRG1", "--evidence", str(evidence)]
    return {"run": run, "query": query, "state": state, "extract": extract_args, "publish": publish_args}


def test_happy_path_extract_load_publish(env):
    env["run"](bridge_run, *env["extract"])
    assert env["query"]("SELECT status, orchestrator_token FROM bridge.runs") == [("READY", None)]
    env["run"](publish_run, *env["publish"])
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]
    states = dict(env["query"]("SELECT target_key, published_release_id FROM bridge.target_state"))
    assert set(states.values()) == {"rel_BRG1"}
    assert env["state"]["pointer"]["sales"] == "rel_BRG1"


def test_failed_extraction_resumes_with_new_attempt(env):
    env["state"]["fail_extract"].add("MAP_002")
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    assert env["query"]("SELECT status, orchestrator_token FROM bridge.runs") == [("FAILED", None)]
    with pytest.raises(RuntimeError, match="Run already exists"):
        env["run"](bridge_run, *env["extract"])
    env["run"](bridge_run, *env["extract"], "--resume")
    rows = env["query"]("SELECT mapping_id, attempt, status FROM bridge.object_attempts ORDER BY 1, 2")
    assert ("MAP_002", 1, "FAILED") in rows and ("MAP_002", 2, "READY") in rows
    assert [c for c in env["state"]["calls"] if c[0] == "extract" and c[1] == "MAP_001"].__len__() == 1
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]
    env["run"](publish_run, *env["publish"])
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]


def test_live_lease_blocks_takeover_until_stale(env):
    env["state"]["fail_extract"].add("MAP_001")
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    # Simulate a crashed orchestrator that still holds the lease.
    env["query"]("UPDATE bridge.runs SET status='EXTRACTING', orchestrator_token='other', heartbeat_utc=?",
                 ts(CLOCK["now"]))
    with pytest.raises(RuntimeError, match="live lease"):
        env["run"](bridge_run, *env["extract"], "--resume")
    CLOCK["now"] += timedelta(minutes=31)
    try:
        env["run"](bridge_run, *env["extract"], "--resume")
    finally:
        CLOCK["now"] -= timedelta(minutes=31)
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]


def test_expired_fence_after_extraction_fails_attempt(env, monkeypatch):
    original = bridge_run.cetas

    def slow(m, relative):
        CLOCK["now"] += timedelta(hours=7)                  # fence expires during the read
        return original(m, relative)

    monkeypatch.setattr(bridge_run, "cetas", slow)
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    CLOCK["now"] = datetime(2026, 9, 22, 1, 0, 0)
    assert "EXTRACTED" not in {r[0] for r in env["query"]("SELECT status FROM bridge.object_attempts")}


def test_publish_resume_reconciles_committed_pointer(env):
    env["run"](bridge_run, *env["extract"])
    env["state"]["fail_after_publish"] = True
    with pytest.raises(bridge_run.PhaseError):
        env["run"](publish_run, *env["publish"])
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHING",)]
    assert env["query"]("SELECT published_release_id FROM bridge.target_state WHERE target_key='group:sales'") \
        == [("NONE",)]
    env["run"](publish_run, *env["publish"], "--resume")
    assert env["query"]("SELECT published_release_id FROM bridge.target_state WHERE target_key='group:sales'") \
        == [("rel_BRG1",)]
    assert [c for c in env["state"]["calls"] if c[0] == "pointer"] == [("pointer", "sales")]  # not republished
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]


def _leave_in_publishing(env):
    env["run"](bridge_run, *env["extract"])
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING', orchestrator_token=NULL")


def test_publish_resume_refuses_unexpected_replace_table_state(env):
    _leave_in_publishing(env)
    env["state"]["delta"]["customer"] = "rel_SOMEONE_ELSE"       # not in Azure SQL, not this release
    with pytest.raises(bridge_run.PhaseError, match="freeze it for operator review"):
        env["run"](publish_run, *env["publish"], "--resume")
    assert ("publish", "customer") not in env["state"]["calls"]
    assert env["state"]["delta"]["customer"] == "rel_SOMEONE_ELSE"
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHING",)]


def test_publish_resume_reconciles_committed_replace_table(env):
    _leave_in_publishing(env)
    env["state"]["delta"]["customer"] = "rel_BRG1"               # committed, SQL update lost
    env["run"](publish_run, *env["publish"], "--resume")
    assert ("publish", "customer") not in env["state"]["calls"]
    assert env["query"]("SELECT published_release_id FROM bridge.target_state "
                        "WHERE target_key='table:cat.gold.customer'") == [("rel_BRG1",)]
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]
