"""Static checks for scripts that cannot run outside Databricks or Azure."""
import ast
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
SCRIPTS = sorted((ROOT / "databricks").glob("*.py")) + sorted((ROOT / "python").glob("*.py"))


@pytest.mark.parametrize("path", SCRIPTS, ids=lambda p: f"{p.parent.name}/{p.name}")
def test_no_top_level_function_is_rebound(path):
    """A module-level def later overwritten by an assignment breaks every later call."""
    tree = ast.parse(path.read_text())
    functions = {n.name for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))}
    rebound = set()
    for node in tree.body:
        targets = node.targets if isinstance(node, ast.Assign) else [getattr(node, "target", None)]
        for t in targets:
            if isinstance(t, ast.Name) and t.id in functions:
                rebound.add(t.id)
    assert not rebound, f"{path.name} rebinds function(s) {sorted(rebound)}"


def test_notebook_package_dir_matches_package_folder():
    text = (ROOT / "databricks" / "generate_mappings_pyspark.py").read_text()
    assert f'PACKAGE_DIR = "/Workspace/Shared/{ROOT.name}"' in text
    assert ROOT.name in (ROOT / "WHERE_TO_ENTER_VALUES.md").read_text()
