-- Step 1 (SCRIPT_GUIDE.md). Run in the existing dedicated SQL pool database as its deployment identity.
-- Precondition: database master key exists; an administrator provisions it separately.
-- CREATE MASTER KEY ENCRYPTION BY PASSWORD = '<secret from approved vault>';
-- Precondition: the Synapse workspace managed identity has ADLS staging write/list access.

IF SCHEMA_ID(N'bridge_meta') IS NULL EXEC(N'CREATE SCHEMA bridge_meta');
GO
-- Change the URL to your ADLS Gen2 staging container. Do not use a managed table path.
CREATE DATABASE SCOPED CREDENTIAL bridge_storage_mi WITH IDENTITY = 'Managed Identity';
GO
CREATE EXTERNAL DATA SOURCE bridge_stage WITH (
 TYPE=HADOOP,
 LOCATION='abfss://<container>@<account>.dfs.core.windows.net',
 CREDENTIAL=bridge_storage_mi
);
GO
CREATE EXTERNAL FILE FORMAT bridge_parquet WITH (FORMAT_TYPE=PARQUET);
GO
CREATE TABLE bridge_meta.upstream_run (
 upstream_run_id varchar(128) NOT NULL, source_generation_id varchar(128) NOT NULL,
 upstream_sequence bigint NOT NULL, business_date date NOT NULL,
 status varchar(16) NOT NULL, write_closed bit NOT NULL,
 completed_utc datetime2 NULL
) WITH (DISTRIBUTION=ROUND_ROBIN, HEAP);
GO
CREATE TABLE bridge_meta.upstream_object (
 upstream_run_id varchar(128) NOT NULL, mapping_id varchar(128) NOT NULL,
 source_schema_version varchar(128) NOT NULL,
 status varchar(16) NOT NULL, row_count bigint NOT NULL,
 refresh_started_utc datetime2 NULL, refresh_completed_utc datetime2 NULL
) WITH (DISTRIBUTION=ROUND_ROBIN, HEAP);
GO
-- Execute after EACH existing materialisation, using real identifiers.
-- Count the materialised table once, after its writer has finished.
-- INSERT bridge_meta.upstream_object(upstream_run_id,mapping_id,source_schema_version,
--   status,row_count,refresh_started_utc,refresh_completed_utc)
-- SELECT '<run>','<mapping>','<schema-hash>','COMPLETE',COUNT_BIG(*),'<start>',SYSUTCDATETIME()
-- FROM [source_schema].[materialised_table];
-- Dedicated SQL pool primary/unique constraints are not enforced. The bridge precheck
-- MUST reject duplicate or missing audit rows; do not treat this DDL as a uniqueness guard.
