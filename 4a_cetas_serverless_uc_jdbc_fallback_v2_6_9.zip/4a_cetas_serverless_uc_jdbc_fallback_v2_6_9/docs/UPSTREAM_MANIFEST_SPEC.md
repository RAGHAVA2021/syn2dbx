# Upstream manifest: file contract

For the team that runs the upstream pipeline rebuilding the Synapse source tables.

Every night, after your pipeline has finished rebuilding **all** source tables,
write two files to Azure storage:

1. `row_counts.csv`: one row per table, with the number of rows you loaded;
2. `_SUCCESS`: a small JSON marker, written **last**, saying the CSV is complete.

The Databricks bridge starts copying only when both files exist and agree with
each other. It uses your row counts to check that every copy is complete.

Examples: `config/row_counts.example.csv` and `config/success_marker.example.json`.

## 1. Where

Both files go in the same folder, one folder per business date:

```
abfss://<container>@<account>.dfs.core.windows.net/upstream-manifests/2026-10-12/row_counts.csv
abfss://<container>@<account>.dfs.core.windows.net/upstream-manifests/2026-10-12/_SUCCESS
```

The container, account and folder pattern are agreed once with the bridge team
(the date can also be written as `20261012`). The container must be separate
from the bridge's staging container; the bridge only reads it.

## 2. `row_counts.csv`

```
business_date,upstream_run_id,upstream_sequence,schema,table,row_count
2026-10-12,UP-20261012,2026101200,dbo,Customer,1204331
2026-10-12,UP-20261012,2026101200,dbo,SalesOrder,58412907
```

| Column | Required | Value |
|---|---|---|
| `business_date` | Yes | The business date, `yyyy-mm-dd` (see section 4). Same value on every row. |
| `upstream_run_id` | Yes | Your pipeline run ID, any non-empty text. Same value on every row. |
| `upstream_sequence` | Yes | `yyyymmdd` of the business date followed by a 2-digit revision: `2026101200` normally, `2026101201`, `…02` for same-day corrections. Same value on every row. |
| `schema` | Yes | Synapse schema of the object, e.g. `dbo`. |
| `table` | Yes | Synapse table or view name. Not case-sensitive. |
| `row_count` | Yes | Rows in that object now: a whole number, no separators or decimals (`1204331`, not `1,204,331`). |

Format rules:

* First line is the header. Column order does not matter.
* UTF-8 (a BOM is fine), comma-delimited, standard CSV quoting. Windows or Unix line endings are both fine.
* One row per object. List the object that the bridge actually copies: if the
  bridge copies a view, give the view's count, not its base table's.
* Rows for objects the bridge does not copy are ignored. A table missing from the
  file is counted by the bridge itself, which is slower; please include every table.
* Header names or the delimiter can differ if agreed in advance; the bridge maps them by configuration.
* Keep the file under 20 MB.

### Why `upstream_run_id` and `upstream_sequence`?

`business_date`, `schema`, `table` and `row_count` carry the counts. The other two
are safety checks.

**`upstream_run_id` — which pipeline run wrote this file.** It ties the `_SUCCESS`
marker to one specific CSV. Without it, a marker left over from an earlier run could
certify a CSV that a later run is still rewriting:

| Time | Files | Date only | With run ID |
|---|---|---|---|
| 23:30 | Run A writes the CSV and the marker (`run A`) | | |
| 01:00 | Run B is rewriting the CSV; the old marker is still there | The bridge sees "date matches, marker exists" and loads half-written counts | The marker says `run A` and the CSV says `run B`: the bridge waits |

Use your pipeline's own run ID (ADF run ID, Airflow run ID, a timestamp: anything
unique per run). It is also logged with every load, so a loaded table can be traced
back to the upstream run that produced it. **Required.**

**`upstream_sequence` — which version of the night this is.** The bridge uses it as
the write guard on every target table: a table remembers the highest sequence it has
loaded and skips any equal or lower one. This guarantees that:

* a retry never loads the same data twice (same sequence, so it is skipped);
* an older night can never overwrite a newer one (lower sequence, so it is skipped);
* a same-day correction is loaded, because it carries a **higher** sequence
  (`2026101201`); with the same sequence it would be treated as already loaded.

**Required.** Normally `yyyymmdd00` (e.g. `2026101200`); raise the last two digits
only for a same-day correction (section 7). The `_SUCCESS` marker carries the same value.

### When the night fails

The whole night fails (nothing is refreshed) if a required column is missing,
the file has no rows, or rows disagree on `business_date`, `upstream_run_id` or
`upstream_sequence`. A single bad row (for example a non-numeric count) only
makes the bridge count that table itself.

## 3. `_SUCCESS`

A JSON object naming exactly the CSV it certifies:

```json
{"business_date": "2026-10-12", "upstream_run_id": "UP-20261012", "upstream_sequence": 2026101200}
```

* All three values must equal the CSV's. `upstream_sequence` is a JSON number, not text.
  If the CSV has no `upstream_sequence` column, use `yyyymmdd00`.
* Under 64 KB. An empty marker is not accepted.
* Write it **only after** the CSV is completely written (or write the CSV under a
  temporary name and rename it, then write the marker).

## 4. Which date is the business date

The business date is the **Sydney calendar date of the morning the bridge loads
the data**, not the date your pipeline finished.

The bridge runs at **01:30 Sydney time** and looks only for that day's date.
If your pipeline finishes at 23:30 on 11 October, label the files `2026-10-12`.
A file labelled `2026-10-11` would be ignored and the night would fail.

## 5. Timing

* Both files must exist by **01:30 Sydney time**. The bridge then waits up to the
  agreed wait (`upstream_wait_minutes`; 60 minutes in the example settings, no wait
  if the setting is left out) and, if they still have not appeared,
  fails the night; every table keeps the previous day's data.
* Nothing is published after **07:00 Sydney**.
* The bridge judges freshness only by the values inside the files, never by file timestamps.

## 6. Do not change the source tables while the bridge is copying

After writing `_SUCCESS`, do not modify any source table until the bridge's run
for that night has finished. The bridge team will tell you how you receive that
signal (it is the `FINISHED` or `FINISHED_WITH_FAILURES` event of the run). The
bridge cannot detect a table that changes while it is being copied.

## 7. Same-day corrections

To republish corrected data for the same business date:

1. Wait until the bridge's current run has finished (section 6).
2. **Delete the old `_SUCCESS`** before touching any source table.
3. Rebuild the sources.
4. Write the new CSV with the **next revision**: `upstream_sequence` `2026101201`
   (then `…02`, …) and, ideally, a new `upstream_run_id`.
5. Write the new `_SUCCESS` last, with the same three values.

Then ask the bridge team to run the job again (same-day reruns are possible until
11:00 Sydney). Reusing the same sequence makes the bridge treat the night as already loaded.

## 8. Checklist before the first night

- [ ] Agreed folder path, container and access (bridge has read-only access).
- [ ] Sample CSV for a real night sent to the bridge team, with the real header names.
- [ ] `_SUCCESS` written last, with JSON matching the CSV.
- [ ] Business date is the Sydney date of the morning load.
- [ ] Every copied table and view is in the file, with counts of the copied object.
- [ ] Correction procedure (section 7) and the no-change window (section 6) agreed.
