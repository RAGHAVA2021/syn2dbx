-- Upgrade an existing v9 or v9.1 Azure SQL control database to v9.2. Run outside any active run,
-- as the control-database deployment identity. Every step checks first, so the script is safe to
-- rerun and works from either version. New deployments use 01_azure_sql_control.sql instead.
-- From v9.1 the only schema change is the per-target publication claim on bridge.target_state;
-- v9.1 runs in any state carry over unchanged.
IF COL_LENGTH('bridge.fence_events','reason') IS NULL
  ALTER TABLE bridge.fence_events ADD reason nvarchar(1000) NULL;
IF COL_LENGTH('bridge.runs','orchestrator_token') IS NULL
  ALTER TABLE bridge.runs ADD orchestrator_token nvarchar(64) NULL, heartbeat_utc datetime2(3) NULL;
IF COL_LENGTH('bridge.object_attempts','delta_target') IS NULL
  ALTER TABLE bridge.object_attempts ADD delta_target nvarchar(512) NULL,
    updated_utc datetime2(3) NOT NULL CONSTRAINT DF_object_attempts_updated DEFAULT SYSUTCDATETIME(),
    retired_utc datetime2(3) NULL, staging_deleted_utc datetime2(3) NULL;
IF COL_LENGTH('bridge.target_state','publish_owner') IS NULL
  ALTER TABLE bridge.target_state ADD publish_owner nvarchar(128) NULL,
    publish_token nvarchar(64) NULL, publish_claimed_utc datetime2(3) NULL;
GO
-- Replace the unnamed status CHECK so SUPERSEDED is allowed.
DECLARE @ck sysname = (SELECT cc.name FROM sys.check_constraints cc
  JOIN sys.columns c ON c.object_id = cc.parent_object_id AND c.column_id = cc.parent_column_id
  WHERE cc.parent_object_id = OBJECT_ID('bridge.object_attempts') AND c.name = 'status');
IF @ck IS NOT NULL EXEC(N'ALTER TABLE bridge.object_attempts DROP CONSTRAINT ' + QUOTENAME(@ck));
ALTER TABLE bridge.object_attempts ADD CONSTRAINT CK_object_attempts_status CHECK(status IN
  ('EXTRACTING','EXTRACTED','LOADING','READY','FAILED','SUPERSEDED','ABANDONED_GENERATION'));
GO
-- From v9 only: v9 candidate tables were named candidate_<mapping>_<run>_a1 and v9 attempts have
-- no recorded delta_target, so publish any READY v9 run with the v9 scripts before upgrading,
-- or reload it. (v9.1 already uses the current names.)
CREATE OR ALTER PROCEDURE bridge.transition_fence
 @source_set_id nvarchar(128), @expected_state varchar(20), @next_state varchar(20),
 @expected_version bigint, @generation_id nvarchar(128), @actor nvarchar(128),
 @expiry_utc datetime2(3) = NULL, @reason nvarchar(1000) = NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF NOT ((@expected_state='AVAILABLE' AND @next_state='WRITE_ACTIVE') OR
         (@expected_state='WRITE_ACTIVE' AND @next_state='CLOSED') OR
         (@expected_state='CLOSED' AND @next_state='BRIDGE_HELD') OR
         (@expected_state='BRIDGE_HELD' AND @next_state='AVAILABLE') OR
         (@next_state='ABANDONED' AND @expected_state IN ('WRITE_ACTIVE','CLOSED','BRIDGE_HELD')) OR
         (@expected_state='ABANDONED' AND @next_state='AVAILABLE'))
    THROW 51000, 'Illegal fence transition', 1;
 BEGIN TRANSACTION;
 UPDATE bridge.source_fence SET state=@next_state,
   generation_id=CASE WHEN @next_state='AVAILABLE' THEN NULL ELSE @generation_id END,
   writer_owner=CASE WHEN @next_state='WRITE_ACTIVE' THEN @actor WHEN @next_state IN ('AVAILABLE','ABANDONED') THEN NULL ELSE writer_owner END,
   bridge_owner=CASE WHEN @next_state='BRIDGE_HELD' THEN @actor WHEN @next_state IN ('AVAILABLE','ABANDONED') THEN NULL ELSE bridge_owner END,
   heartbeat_utc=SYSUTCDATETIME(),expires_utc=@expiry_utc,control_version=control_version+1
 WHERE source_set_id=@source_set_id AND state=@expected_state AND control_version=@expected_version
   AND ((@expected_state='AVAILABLE' AND generation_id IS NULL) OR generation_id=@generation_id)
   AND ((@expected_state<>'WRITE_ACTIVE') OR writer_owner=@actor)
   AND ((@expected_state<>'BRIDGE_HELD') OR bridge_owner=@actor);
 IF @@ROWCOUNT<>1 BEGIN ROLLBACK; THROW 51001, 'Fence owner/state/version mismatch', 1; END;
 INSERT bridge.fence_events(source_set_id,old_state,new_state,generation_id,actor,reason)
 VALUES (@source_set_id,@expected_state,@next_state,@generation_id,@actor,@reason);
 COMMIT;
END;
GO
