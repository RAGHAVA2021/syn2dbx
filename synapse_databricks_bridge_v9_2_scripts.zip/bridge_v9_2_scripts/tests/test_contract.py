import copy
import json
from pathlib import Path
import sys

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "python"))
from bridge_run import (attempt_relative_path, candidate_table_name, config, delta_target, is_indeterminate,
                        Indeterminate, PhaseError, projection, size_class, target_key)


ORIGINAL = json.loads((Path(__file__).resolve().parents[1] / "config.example.json").read_text())
for item in ORIGINAL["mappings"]:
    item["target_catalog"] = "example_catalog"
ORIGINAL["control_catalog"] = "example_catalog"


def write(tmp_path, doc):
    p = tmp_path / "config.json"; p.write_text(json.dumps(doc)); return p


def test_valid_reviewed_contract(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    config(write(tmp_path, doc))
    assert projection(doc["mappings"][0]) == "[customer_id] AS [customer_id], [name] AS [name]"


def test_optional_member_cannot_move_pointer(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][1]["mandatory"] = False
    with pytest.raises(RuntimeError, match="Optional pointer member"):
        config(write(tmp_path, doc))


def test_duplicate_target_case_insensitive(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["columns"][1]["target"] = "CUSTOMER_ID"
    with pytest.raises(RuntimeError, match="Duplicate/missing columns"):
        config(write(tmp_path, doc))


def test_unreviewed_expression_cannot_be_injected(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["columns"][0]["source"] = "id]; DROP TABLE t;--"
    with pytest.raises(RuntimeError, match="Unsafe SQL identifier"):
        config(write(tmp_path, doc))


def test_missing_retention_property(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    del doc["mappings"][1]["physical_properties"]["delta.deletedFileRetentionDuration"]
    with pytest.raises(RuntimeError, match="Missing governed property"):
        config(write(tmp_path, doc))


def test_profile_classification_uses_rows_columns_or_storage():
    limits = {"medium_rows": 100, "large_rows": 1000, "medium_bytes": 10000,
              "large_bytes": 100000, "medium_columns": 10, "large_columns": 50}
    assert size_class(2, 2, 40, limits) == "SMALL"
    assert size_class(101, 2, 40, limits) == "MEDIUM"
    assert size_class(2, 51, 40, limits) == "LARGE"
    assert size_class(2, 2, 100001, limits) == "LARGE"


def test_profiled_inventory_rejects_missing_or_mismatched_profile(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["require_profiles"] = True
    with pytest.raises(RuntimeError, match="Missing/stale profile"):
        config(write(tmp_path, doc))
    doc["mappings"][0]["size_class"] = "SMALL"
    doc["mappings"][0]["source_profile"] = {"profiled_at_utc": "2026-09-22T00:00:00Z",
        "estimated_rows": 1, "physical_used_bytes": 128, "column_count": 99,
        "source_schema_version": doc["mappings"][0]["source_schema_version"]}
    with pytest.raises(RuntimeError, match="Missing/stale profile"):
        config(write(tmp_path, doc))


# --- v9.1 / v9.2 regression tests -------------------------------------------------

def test_replace_table_group_must_have_one_member(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    extra = copy.deepcopy(doc["mappings"][0])
    extra.update({"mapping_id": "MAP_004", "source_view": "v_customer2", "target_table": "customer2"})
    doc["mappings"].append(extra)            # same group_id as MAP_001
    with pytest.raises(RuntimeError, match="exactly one mapping"):
        config(write(tmp_path, doc))


def test_property_values_must_be_strings(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["consumer_properties"]["delta.enableChangeDataFeed"] = True
    with pytest.raises(RuntimeError, match="quote-free strings"):
        config(write(tmp_path, doc))


def test_unknown_size_class_rejected_without_profiles(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["size_class"] = "HUGE"
    with pytest.raises(RuntimeError, match="Unknown size_class"):
        config(write(tmp_path, doc))


def test_materialised_fields_must_be_paired(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    del doc["mappings"][0]["materialised_table"]
    with pytest.raises(RuntimeError, match="given together"):
        config(write(tmp_path, doc))


@pytest.mark.parametrize("field,value", [("max_attempts", 0), ("takeover_after_minutes", 5),
                                         ("heartbeat_seconds", 5000)])
def test_invalid_resume_settings(tmp_path, field, value):
    doc = copy.deepcopy(ORIGINAL)
    doc[field] = value
    with pytest.raises(RuntimeError):
        config(write(tmp_path, doc))


def test_candidate_names_do_not_collide():
    assert candidate_table_name("A-B", "run-1", 1) != candidate_table_name("A_B", "run_1", 1)
    assert candidate_table_name("A", "r", 1) != candidate_table_name("A", "r", 2)
    assert candidate_table_name("A", "r", 1) == candidate_table_name("A", "r", 1)
    assert len(candidate_table_name("X" * 128, "Y" * 128, 9)) < 128


def test_attempt_paths_and_targets():
    assert attempt_relative_path("2026-09-22", "BRG_1", "MAP_1", 2) == \
        "bridge/parquet-stage/2026-09-22/BRG_1/MAP_1/attempt-002/"
    m = copy.deepcopy(ORIGINAL["mappings"][1])
    assert delta_target(m, "BRG_1", 1) == "example_catalog.bridge_physical.sales_snapshots"
    assert target_key(m) == "group:sales"


def test_indeterminate_detection_through_phase_errors():
    assert is_indeterminate(PhaseError("x", [RuntimeError("a"), Indeterminate("b")]))
    assert not is_indeterminate(PhaseError("x", [RuntimeError("a")]))


class _Resp:
    def __init__(self, body):
        self.body = body

    def raise_for_status(self):
        pass

    def json(self):
        return self.body


@pytest.mark.parametrize("output,ok", [({}, False),                                   # metrics missing
                                       ({"rowsRead": 5, "rowsCopied": 5}, False),     # differs from audit
                                       ({"rowsRead": 7, "rowsCopied": 7}, True)])
def test_adf_row_evidence_is_required(monkeypatch, output, ok):
    import bridge_run
    import requests
    monkeypatch.setattr(bridge_run, "arm_headers", lambda: {})
    monkeypatch.setattr(bridge_run.time, "sleep", lambda s: None)

    def post(url, **kw):
        if url.endswith("createRun?api-version=2018-06-01"):
            return _Resp({"runId": "r1"})
        return _Resp({"value": [{"activityName": "CopyApprovedProjection", "status": "Succeeded", "output": output}]})

    monkeypatch.setattr(requests, "post", post)
    monkeypatch.setattr(requests, "get", lambda url, **kw: _Resp({"status": "Succeeded"}))
    doc = {"adf": {"subscription_id": "s", "resource_group": "g", "factory": "f", "copy_pipeline": "p"}}
    m = copy.deepcopy(ORIGINAL["mappings"][2])
    payload = {"bridge_run_id": "B", "release_id": "rel_B", "generation_id": "G",
               "relative_path": "x/", "source_rows": 7}
    if ok:
        assert bridge_run.copy_activity(doc, m, payload) == "r1"
    else:
        with pytest.raises(RuntimeError):
            bridge_run.copy_activity(doc, m, payload)
