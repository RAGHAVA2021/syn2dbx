# Read me first

This page tells you **which document to read, and in what order**. Start here
if you are new to the Synapse → Databricks nightly full refresh package (v2.6.5).

## What the package does, in one paragraph

Every night, after the upstream process rebuilds about 1,000 tables in Azure
Synapse, a Databricks job copies each table in full into a Unity Catalog Delta
table before 07:00 Sydney time. Each table switches over on its own; if one
fails, it keeps serving the previous night's data and the others are not
affected. At the end, a summary of successes and failures is sent to an
operator email workflow.

## Recommended reading order (first time, whole package)

| # | Document | What you learn |
|---|---|---|
| 1 | `README.md` | Quick overview of what the package does and what it contains. |
| 2 | `docs/PACKAGE_GUIDE.md` | Purpose of every folder and file, how the folders relate, and the setup, nightly and recovery flow. **The main map.** |
| 3 | `docs/DESIGN.md` | Why it is built this way: architecture, per-table flow, key decisions, failure handling, security. |
| 4 | `docs/CODE_STRUCTURE.md` | How the code is wired: jobs, notebooks, module dependencies, call sequences. |
| 5 | `docs/DATA_DICTIONARY.md` | What gets written: control-table columns, statuses, IDs, the email summary. |
| 6 | `docs/RUNBOOK.md` | Exact setup commands, daily checks, recovery and rollback. |
| 7 | `AGENTS.md` | Rules that must never be broken, rejected alternatives, how to change code safely. |
| 8 | `docs/RELEASE_VALIDATION.md` | Go-live checklist. |
| 9 | `CHANGELOG.md` | What changed in each version. Read when upgrading. |
| 10 | `docs/V22_REVIEW_RESOLUTION.md` | Historical review record. Optional. |

## Shorter paths by role

| Reader | Read in this order |
|---|---|
| Manager or reviewer | `README.md` → `docs/PACKAGE_GUIDE.md` → `docs/DESIGN.md` (sections 1–2) |
| Operator (runs it daily) | `README.md` → `docs/PACKAGE_GUIDE.md` (section 3) → `docs/RUNBOOK.md` → `docs/DATA_DICTIONARY.md` |
| Developer (changes code) | `README.md` → `docs/PACKAGE_GUIDE.md` → `docs/DESIGN.md` → `docs/CODE_STRUCTURE.md` → `AGENTS.md` → `docs/DATA_DICTIONARY.md` |
| Go-live approver | `docs/DESIGN.md` (sections 6–8) → `docs/RELEASE_VALIDATION.md` |

## Where to find a specific answer

| Question | Go to |
|---|---|
| What is this folder or file for? | `docs/PACKAGE_GUIDE.md` section 2 |
| What happens each night, step by step? | `docs/PACKAGE_GUIDE.md` section 3, `docs/DESIGN.md` section 2 |
| Why was it designed like this? | `docs/DESIGN.md` section 3 |
| Which module calls which? | `docs/CODE_STRUCTURE.md` |
| What does a column or status mean? | `docs/DATA_DICTIONARY.md` |
| A table failed. What do I do? | `docs/RUNBOOK.md` ("Every morning", "Common situations") |
| How do I roll back a table? | `docs/RUNBOOK.md` ("Rollback a table") |
| How do I add or change a table? | `docs/RUNBOOK.md` ("Adding or changing a table") |
| I am installing for the first time. Where do I start? | `docs/RUNBOOK.md` ("Fresh installation with GitHub (dev, then prod)") |
| How do I deploy to dev and prod with GitHub? | `docs/RUNBOOK.md` ("Fresh installation with GitHub", "Deploying with GitHub Actions") |
| Is it ready for production? | `docs/RELEASE_VALIDATION.md` |

## Publishing these documents to Confluence

Upload these as Confluence pages, under one parent page, in this order:

| Page order | Source file | Audience |
|---|---|---|
| Parent page | `FIRST_READ_ME.md` | Everyone |
| 1 | `README.md` (as "Overview") | Everyone |
| 2 | `docs/PACKAGE_GUIDE.md` | Everyone |
| 3 | `docs/DESIGN.md` | Everyone |
| 4 | `docs/CODE_STRUCTURE.md` | Developers |
| 5 | `docs/DATA_DICTIONARY.md` | Operators, developers |
| 6 | `docs/RUNBOOK.md` | Operators |
| 7 | `docs/RELEASE_VALIDATION.md` | Approvers, operators |

Keep these in the Git repository only, not in Confluence: `AGENTS.md`
(maintainer and AI-agent rules tied to the code and checked by a test),
`CHANGELOG.md` (link to the repository instead), the `.github/workflows/`
files, and
`docs/V22_REVIEW_RESOLUTION.md` (historical).

Notes for uploading:

* Several documents contain Mermaid diagrams. Confluence shows them only if
  your site has a Mermaid macro or app installed. Otherwise, export each
  diagram as an image (for example from mermaid.live) and insert the image.
* Relative links between files (such as `DESIGN.md`) will not work in
  Confluence. Replace them with links to the matching Confluence pages.
* The Git repository stays the source of truth. After a document changes in
  Git, update its Confluence page, and add a line at the top of each page
  saying which package version it reflects (currently v2.6.5).
