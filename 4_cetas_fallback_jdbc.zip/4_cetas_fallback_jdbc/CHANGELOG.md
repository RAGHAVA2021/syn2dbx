# Changelog

## 2.6.5
GitHub deployment and documentation. **No change to the nightly load logic**
(`src/bridge` and the notebooks are unchanged apart from the package version).

* **GitHub deployment:** added `.github/workflows/ci-cd.yml` (tests on pull
  requests; merge to `main` deploys dev, then prod after approval; manual
  per-environment runs, prod from `main` only) and the reusable
  `bundle-deploy.yml` (checks variables, selects the inventory, GitHub OIDC →
  Azure login, `bundle validate` and `bundle deploy`).
* Added `tools/prepare_deploy.py`: rejects a placeholder workspace host,
  validates `config/inventory.<env>.json` with the job's own rules, and copies
  it to `config/inventory.json`. Dev and prod can now have different inventories.
* **Bundle:** schedule pause state comes from the `nightly_pause_status` and
  `maintenance_pause_status` variables (default `PAUSED`). Previously the
  schedules were hard-coded `PAUSED`, so every deploy re-paused a live
  production schedule. Per-environment inventories and `.github/` are excluded
  from the deployed files.
* Added `tests/test_deploy.py` (inventory selection, pause variables, sync
  excludes, workflow structure).
* **Documentation:** added `FIRST_READ_ME.md` (reading order, question index,
  Confluence publishing guide), `docs/CODE_STRUCTURE.md` (layers, job/task
  graph, module dependencies, call sequences, test map) and
  `docs/DATA_DICTIONARY.md` (control-table columns, `run_log` events, ID and
  path formats, target metadata, summary payload). `PACKAGE_GUIDE.md` gains a
  folder-relationship diagram, reading order and the new files. `DESIGN.md`
  adds section 3.12 (deployment) and clarifies that section 9's "v6" is the
  separate legacy system. `RUNBOOK.md` adds "Fresh installation with GitHub
  (dev, then prod)" and "Deploying with GitHub Actions".
  `RELEASE_VALIDATION.md` adds the v2.6.5 checks.
* `bridge.__version__` corrected from the stale `2.5.0` to `2.6.5`.

**Upgrade actions (from 2.6.4):**
* **Production already live:** every prod deploy must now pass
  `nightly_pause_status=UNPAUSED` (GitHub: `NIGHTLY_PAUSE_STATUS` on the `prod`
  Environment; by hand: `--var nightly_pause_status=UNPAUSED`), and the same
  for maintenance if it runs. Otherwise the deploy pauses the schedule, as
  before.
* To deploy from GitHub: complete RUNBOOK "Deploying with GitHub Actions",
  one-time GitHub setup (real workspace hosts, per-environment inventories,
  GitHub Environments, federated credentials, variables).
* No Unity Catalog or Synapse schema change. No upgrade SQL.

## 2.6.4
* Added an end-of-run HTTPS summary for every completed plan, regardless of
  whether the job crosses its failure threshold. It lists the total, successful,
  and failed table counts and every failed mapping ID/status. The operator-owned
  endpoint sends the email and deduplicates using `notification_id`.
* The endpoint URL is read from a Databricks secret. Delivery errors fail
  finalize so the existing job failure email remains a backstop. An early plan
  failure still uses that existing alert because no per-table plan exists.
* **Upgrade action:** add `notifications.summary_webhook.secret_scope` and
  `url_secret_key` to `config/inventory.json`; provision a reachable HTTPS
  workflow and its Databricks secret before enabling the nightly job.

## 2.6.3
Review fixes. **Upgrade action:** convert `governance.exempt_abac_policies` (see below).
* **Fix (high):** a Databricks **Repair run** keeps `{{job.run_id}}`, so a commit made
  by the original attempt counted as "this run's own". After finalize had logged
  `FINISHED_WITH_FAILURES` (which releases the upstream write fence), a repaired
  table whose manifest count was missing or wrong was judged by a live Synapse count
  and a correct publication could be RESTORED automatically. Commits now record
  `repair_count` (`{{job.repair_count}}`, passed to the batch task and validated;
  an unresolved reference fails loudly), and automatic RESTORE of an existing commit
  requires the same job run, the same repair attempt, and no `FINISHED*` event for
  the job run (`control.fence_released`). Otherwise the table ends as
  `FAILED_VERIFY` for an operator. Commits written before 2.6.3 are never treated
  as owned.
* **Fix (medium):** `tools/render_uc_setup.py` emitted `GRANT READ METADATA ON TABLE`,
  which does not exist in Unity Catalog, so the rendered setup failed at the first
  target table. Removed; `SELECT, MODIFY` is sufficient. A test now checks every
  rendered GRANT against the Unity Catalog privilege list.
* **Fix (medium, security):** ABAC exemptions matched on the bare policy name, but
  policy names are unique only per securable: exempting a reviewed catalog-level
  `pii_mask` also exempted any unreviewed `pii_mask` on a schema, table or other
  catalog. Entries are now objects naming the defining securable,
  `{"catalog": ..., "schema": ..., "table": ..., "name": ...}` (schema/table
  optional), matched case-insensitively against the `Catalog`, `Schema`, `Table`
  and `Policy Name` columns of `SHOW EFFECTIVE POLICIES`. A policy row without its
  catalog is never exempt. **Bare-name entries are rejected** when the inventory
  loads; re-review and convert them before deploying.
* **Fix (low):** finalize had `max_retries: 1`, so every failing night repeated its
  deliberate verdict, appended a second `FINISHED_WITH_FAILURES` and delayed the
  alert. Finalize is no longer retried.

## 2.6.2
Runtime 18 review fixes.
* **Fix (high):** the acceptance job could not run. Its scratch and partition
  mappings lacked `mapping_id`, so the first `loader.overwrite` raised `KeyError`.
  A local-Spark test now publishes the notebook's own mapping literals.
* **Fix (high):** `SHOW EFFECTIVE POLICIES` also lists policies inherited from the
  catalog or schema, so one catalog-wide ABAC mask blocked every target, including
  identities exempted through `EXCEPT`. New `governance.exempt_abac_policies`
  (reviewed names only; table-level filters and masks are never exempt). The
  decision is the pure, tested `contract.governance_problems`. The preflight also
  refuses runtimes below 17, where `DESCRIBE ... AS JSON` has no `row_filter` or
  `column_masks` keys and the check would silently pass.
* **Fix:** finalize fails when more than `execution.max_failed_table_ratio`
  (default 2%) of planned tables did not refresh, independent of `mandatory`
  flags (all optional from the generator) and `fail_on_any_failure` (default false).
* **Fix:** the plan (no task retries) retries transient platform errors itself for
  `execution.plan_transient_retry_minutes` (default 15), bounded by the cutoff:
  pool capacity codes, connection/timeout SQLSTATEs (including mssql-jdbc's
  code-0 `08S01` connection reset) and Java network errors. Anything else,
  including a malformed manifest, still fails at once.
* **Fix (Runtime 18):** missing-path detection no longer depends on message text
  first: `manifest.is_missing_path_error` checks the Python type, the Spark error
  condition and the Java cause chain before falling back to text, and every
  notebook uses it. `READ_ANCIENT_DATETIME` is matched on the error condition.
  Acceptance proves missing staging, manifest and marker paths on the runtime.
* **Fix:** the publication margin also stops new exports and bounds export
  timeouts, instead of exporting and then discarding the result.
* **New (Runtime 18):** a bridge commit recorded as `isDynamicPartitionOverwrite`
  fails verification (restored when it is this run's own commit) and is never a
  rollback candidate. Acceptance checks the flag is absent on a static overwrite.
* Plan and finalize record the runtime build (`runtime`) in `run_log`; runbook and
  acceptance say to rerun acceptance after Runtime 18 behavioural updates.
* Docs: Runtime 18 ships `azure-identity`; removed the install requirement.

## 2.6.1
* Read table-level row filters and column masks from the target's live
  `DESCRIBE TABLE EXTENDED ... AS JSON` metadata instead of information schema
  views, which can lag metadata changes. Continue checking effective ABAC
  policies and fail closed if either metadata query cannot be trusted.


## 2.6.0
* Same-day targeted reruns use a fixed 11:00 Sydney recovery cutoff; the nightly
  job rejects historical dates and late reruns. A five-minute margin stops
  submitting overwrites too close to either the 07:00 or 11:00 cutoff.
* Fail closed before exporting or rolling back governed targets whose table-level
  row filters, column masks or effective ABAC filters/masks are visible; fail
  when the metadata cannot be inspected. Dedicated `INSERT OVERWRITE` and
  `RESTORE` on those tables require a separate publication design.
* Reject `delta.setTransactionRetentionDuration` in inventory and on existing
  targets, to preserve the transaction guard.
* Workspace acceptance calls the actual `loader.overwrite`, including the
  static partition override under an explicitly dynamic session default.
* Repair instructions distinguish same-run repair before 07:00 from a new
  targeted run before 11:00. Correct the example for revision sequences.
* Use the Runtime 18 LTS selector; default optional failures to non-blocking;
  disable repeated plan waits; correct the release tag and packaging.


## 2.5.1
* **Fix (high):** in manifest completion mode the plan could never see the
  `_SUCCESS` marker. Spark file sources ignore `_`/`.` names even when the exact
  path is given, so `read_small_text_file` reported the marker as missing and
  every automatic night waited and then failed. The plan now reads hidden-named
  markers with `dbutils.fs.head` (64 KB cap); `read_small_text_file` refuses
  hidden names loudly; `manifest.path_template` may not name a hidden CSV.
* **Fix (high):** `process_table` froze its clock at table start when called
  without an injected clock (the production path). The closure read the local
  `now` after it was reassigned, so `remaining()` never shrank and the
  pre-publication cutoff check could not fire: an export that crossed 07:00 was
  still published (finalize then failed the job after the fact).

## 2.5.0
* **Fix (high):** rechecking an existing commit on a rerun could automatically
  RESTORE a correct publication. A wrong manifest count, or a missing count, led
  to a live Synapse recount hours after the commit; a legitimately changed source
  then triggered the restore. Now:
  * the evidence order is a logged verified publication of the exact Delta version
    and row metric, then the manifest count, then a Synapse count (v2.4 ignored the
    verified publication whenever the manifest had a count);
  * an automatic RESTORE only undoes a commit made by the current job run (a lost
    acknowledgement, while the upstream is still fenced). A disagreeing commit from
    another job run ends as `FAILED_VERIFY` for an operator.
  * `10_process_batch` loads verified publications for every planned table.
* **Fix:** the Spark-free tests collect and pass without PySpark again (a v2.4
  module imported the Spark loader at module level). The Spark case moved to
  `tests/test_loader_spark.py`, `is_missing_path_error` is now pure
  (`manifest.is_missing_path_error`, still aliased in `loader`), and a test
  collects the suite with PySpark blocked.
* **Fix:** in `synapse_table` completion mode, no manifest problem blocks the
  night any more (access denied, wrong encoding, too large, removed mid-read,
  malformed, other run). `manifest.optional_counts` records the reason and the
  tables are counted in Synapse, as invariant 12 always stated.
* **Fix:** the finalize deadline check uses each table's Delta commit time,
  logged in the new `table_log.commit_utc`, not the later log event. A commit at
  06:59:58 verified at 07:00:03 no longer fails the job; an `INSERT OVERWRITE`
  that itself commits after 07:00 is now caught. Late tables are listed as
  `late_tables`. **Run `sql/unity_catalog/upgrade_2.4_to_2.5.sql` before deploying.**
* **New setting:** `execution.additional_access_error_codes` (default empty) makes
  confirmed permission-denied codes final as `FAILED_SOURCE_ACCESS` instead of
  using a JDBC fallback slot. Likely candidates (262, 297, 300, 15247) are listed
  in `synapse.ACCESS_ERROR_CANDIDATES` but not built in until a trial shows them.
* Housekeeping: `generate_inventory.py` warns that view mappings have
  `estimated_bytes` 0 and are scheduled last; maintenance checks target existence
  with an unquoted name; removed the unused `planning.is_fresh` and
  `manifest.candidate_dates`; removed a duplicated placeholder guard in
  `01_export_setup.sql`; the `synapse.server` validation message names both
  endpoint forms; acceptance checks the UTC commit time from `loader.history`.

## 2.4.0
* Separate CETAS-error fallbacks from historical timestamp reroutes in the
  finalize alert; report both counts without alerting on predictable reroutes.
* Reject a missing staging folder, and require a completed Spark JDBC stage
  (`_SUCCESS`) even when it contains zero rows.
* Use the same deterministic schema, access, and data error classification for
  both JDBC fallback paths.
* Wait when a manifest or its marker is removed between readiness and read;
  retain a hard failure for malformed completed manifests or access errors.
* On a new run of an existing release, use a logged verified publication as a
  count hint only when its exact Delta version and history row metric match.
  Retry restores and unknown histories still fail closed or recount.
* Skip the validated-stage lookup on a first attempt, preserving it for retries;
  retry finalize once and continue maintenance VACUUM across independent tables.

## 2.3.0
* Treat invalid source SQL (207/208) and denied access (229/230) as
  deterministic failures without burning a JDBC fallback slot.
* Verify a previously committed but unlogged release after the cutoff using
  a bounded read-only source count. New exports remain cutoff-bound.
* Preserve a logged, verified rollback candidate restored to that exact
  version; unknown or intervening history remains ineligible.
* Guard every setup SQL batch against unreplaced placeholders, replace the
  upstream FORMAT example, and reject normalized external-table name collisions.
* Make azure-identity an explicit cluster prerequisite only for client_secret.
  Extend workspace acceptance to OPTIMIZE, empty and partitioned overwrites.
* Keep the historical-timestamp cutoff until real Synapse boundary probes and
  document the case where OPTIMIZE prevents an automatic RESTORE.

## 2.2.0
* Support standalone dedicated SQL pool endpoints with hostname-checked TLS.
  Pin DBR 16.4 LTS so the default service-credential mode is supported without
  relying on the 15.4 Public Preview.
* Bound all source counts by the remaining morning deadline; fix failure text
  when a prior publication was restored or changed.
* Keep pre-1900 timestamp reroutes outside the CETAS-error fallback budget.
  They still require JDBC; verify their volume in the live trial.
* Retry fallback event logging, clean both CETAS and JDBC stages after success,
  force static full-table overwrite and restore the prior Spark setting.
* Add weekly OPTIMIZE for control tables and reduce default fallback concurrency
  to four batches times four JDBC partitions. Specify a no-overlap source fence
  in the manifest completion protocol and expand workspace acceptance after RESTORE.
* Make Spark-free tests collect without PySpark, reject sources differing only in
  case, update package version, and omit generated Derby logs from the ZIP.


## 2.1.0
* In lost-acknowledgement recovery, a Synapse count that disproves the manifest
  now becomes the logged `source_rows` and `written_rows`. A regression test
  proves date-based rollback still finds that verified commit.
* After an automatic RESTORE, inspect Delta history before reporting that the
  previous version is serving. Fail verification if the RESTORE is not the
  latest commit or an intervening version appeared. Exclusive target-write
  ownership is still required because RESTORE has no conditional commit guard.
* Add a read-only Synapse credential-scope review and make the database-wide
  reach of `ALTER ANY EXTERNAL DATA SOURCE` an explicit go-live decision.
* No Unity Catalog control-table schema migration is needed from 2.0.

## 2.0.0
* Verify upstream sequence format and date before planning; reject inconsistent
  later Delta commits rather than reporting a stale table as SUPERSEDED.
* Reconcile and conditionally restore a wrong-count commit on the lost-ack path;
  only offer logged, verified, unrestored versions for business-date rollback.
* Treat known non-data Delta maintenance operations as data-neutral; check their
  actual history names in the acceptance job. Isolate table-level logging and
  history failures with bounded log retries.
* Use proleptic Gregorian Parquet settings; pre-1900 CETAS timestamps route to
  the Spark-written JDBC fallback because a local INT96 test showed a silent
  historical time shift. Validate the real encoding in the deployment trial.
* Reject Unicode numerals in manifests; respect disabled source counts during
  lost-ack verification; persist verified immutable stage paths for write retries;
  bound extraction timeouts by the remaining cutoff window.
* Fix the inventory path to the deployed bundle, set explicit service-principal
  run identity and separate job ACLs, isolate upstream signal/manifest access,
  enforce a per-batch JDBC fallback budget and alert threshold, clean up staged
  copies after verified publication, and retry the plan task.

## 1.9.0
* Classify an older commit as SUPERSEDED when the latest valid bridge commit has
  a higher sequence, even when the older release appears in retained history.
  A subsequent unverified write or RESTORE still fails closed.
* Recheck the current target version before an automatic restore; refuse to
  restore if a newer commit is visible.
* Manual rollback now requires `expected_current_version` on non-dry runs and
  checks the version immediately before RESTORE. A dedicated exclusive write
  window remains mandatory because SQL RESTORE is not conditional on the
  current Delta version.
* Regression tests cover these behaviors. No UC table migration from 1.8.

## 1.8.0
* Scope batch retry decisions and finalization to the current job run. A new
  job run reassesses repaired schema/data/contract failures from an earlier run.
* In Synapse-table completion mode, select the highest same-day COMPLETE
  sequence and reject conflicting rows at that sequence.
* Refuse to call an old bridge commit current after a later unverified target
  commit; allow a higher-sequence run to repair it. Layout-only OPTIMIZE commits
  do not invalidate a release.
* At the cutoff, check for an already verified publication before logging a
  skipped export, so retries do not hide a committed table.
* Added regression tests for corrections, later writes, restored releases, and
  cutoff retries. No Unity Catalog table migration is required from 1.7.

## 1.7.0
* Confirm a manifest zero in Synapse before rejecting a table that requires nonempty data.
* Match manifest completion markers to the CSV's date, run id and sequence. The
  upstream must remove an old marker before any same-day correction and write a
  generation-specific JSON marker last. This is a required upstream protocol change.
* Limit orphan external-table cleanup to package-generated names with a matching
  STARTED event; leave unverified definitions untouched.
* Default new target tables to seven days of deleted-file retention; existing
  targets require a reviewed ALTER TABLE to adopt that property. Surface VACUUM failures.
* Expand Delta history only when a bounded history window contains no bridge commit.
* Correct the local test command to pin the JVM time zone to UTC.

## 1.6.0
* A Delta RESTORE after a publish prevents a later run from reporting that release as current.
  Batch retries recheck successful log entries against Delta history.
* An existing same-release commit without a logged success has its output row count
  checked before it is accepted, including after a lost acknowledgement.
* One manifest row now supplies its count to every mapping of the same source object.
* The nightly job now alerts on any failed table by default (`fail_on_any_failure=true`).
* No UC schema migration is required from 1.5. A restored release needs a higher
  upstream sequence for republishing because Delta retains its transaction version.

## 1.5.0
* Automatic runs wait for exactly today's Sydney business date in manifest and
  Synapse completion modes. They never silently reuse yesterday's completed run.
* The automatic deadline is fixed at 07:00 Sydney for that date, including DST;
  planning cannot roll it into tomorrow. Planning waits at most until that deadline.
* Exports that finish after the deadline are skipped before the Delta write;
  finalization fails and alerts if it completes after the deadline. A commit already
  started before 07:00 can still complete later, so verify real publication timestamps.
* An absent Synapse completion row is pollable; duplicate rows remain an error.
* Empty Parquet exports now construct their schema using a Spark 3.5-compatible
  zero-row projection. The dedicated job cluster pins driver and executor JVM
  time zones to UTC for JDBC timestamp handling.
* Explicit `business_date` reruns remain available for a reviewed backfill.
* No UC control schema migration is required from 1.4.

## 1.4.0
**Upgrade:** run `sql/unity_catalog/upgrade_1.3_to_1.4.sql` once; grant READ FILES on
the manifest location; add the `upstream` and `manifest` settings.

* **Row counts from the upstream manifest CSV** (Azure storage). This removes the
  per-table `COUNT_BIG` scan (about 1,000 full scans a night).
  * Trust comes from the business date and run id inside the file, never from its
    last-modified time.
  * A bad row drops only that table's count.
  * A count that disagrees with the export triggers exactly one Synapse count for that
    table, which either confirms the export or refuses it.
* **Manifest as the completion signal** (`upstream.completion_source = "manifest"`): the
  CSV plus its `_SUCCESS` marker replaces `bridge_meta.upstream_run`. The sequence comes
  from `upstream_sequence`, or `yyyymmdd * 100`.
* **One catalog query for all schemas** in the plan, replacing 1,000 per-table
  `sys.columns` queries.
* **Net effect:** in manifest mode with no failures, Synapse sees two tiny catalog
  lookups, one catalog query, and one CETAS per table.
* **Bug found and fixed during testing:** reading the CSV with Spark's `text` source split
  lines and dropped the BOM, so a valid manifest looked empty. Manifests are now read as
  exact bytes (`binaryFile`).
* The control log records `count_source`; the plan records `expected_rows`,
  `count_source` and `source_schema_hash` per table.

## 1.3.0
**Upgrade:** run `sql/unity_catalog/upgrade_1.2_to_1.3.sql` once, then grant the job
identity WRITE FILES on the staging location.

* **JDBC fallback.** When CETAS itself fails, the table is re-exported once through
  Spark's JDBC source.
  * It uses the same casting query and credentials, optionally as a parallel read
    (`jdbc_partition_column`).
  * Its output is staged as Parquet and passes the same validation.
  * It never runs for data errors or pool-capacity errors.
* **Freshness gate.** An automatic run refuses an upstream run older than
  `max_upstream_lag_days`, optionally waiting `upstream_wait_minutes` for tonight's
  run. Previously a late upstream made every table `ALREADY_CURRENT` and the job looked
  green.
* **Authentication.** Added `sql_password` mode (SQL login from a secret scope) to match
  existing user/password JDBC setups. One `credentials_provider` serves CETAS and the
  fallback, with fresh credentials per connection.
* **Error classification.** SQL Server error codes and SQLSTATEs are read from deep in
  Spark/py4j Java exception chains, and grouped as DATA, CAPACITY or CETAS.
* **Observability.** `table_log` gains `method`, `error_code` and `duration_seconds`. There
  is a run-duration health warning in the job, and cost tags on the job and cluster.
* **Robustness.**
  * The Delta history scan is configurable (default 200 rows; was a fixed 50).
  * The time zone and every new setting are validated.
  * The mapping `enabled` flag is validated.
* **Tests.** Real JDBC tests against Derby cover the command connection, real
  Java error codes, and the fallback export (plain and partitioned).

## 1.2.0
* **Special characters:** confirmed and tested that line breaks, CRLF, pipes, quotes,
  tabs, NUL bytes and Unicode round-trip exactly (Parquet has no delimiters).
* **Reuse check:** the plan step verifies that the existing Synapse file format is
  PARQUET and that the data source points at `staging.root`, before any table runs.
* **Datetime overflow:** `datetime2(7)`/`datetimeoffset(7)` are truncated (not rounded)
  to microseconds. This prevents the CETAS overflow on `9999-12-31 23:59:59.9999999`.
* **Data errors:** CETAS failures caused by source data (SQL errors 220, 232, 241, 242,
  245, 248, 517, 8114, 8115, 8134) are now `FAILED_SOURCE_DATA`, final for the night,
  and are not retried. Other errors stay transient.

## 1.1.0
* Added `AGENTS.md` (design intent for AI agents) and tests that keep it consistent
  with the code. Setup now reuses the existing Databricks ↔ Synapse connection.

## 1.0.0
* Initial full-refresh design: CETAS → validate → guarded `INSERT OVERWRITE`.
