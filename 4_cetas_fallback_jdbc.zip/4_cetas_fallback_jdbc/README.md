# Synapse → Databricks nightly full refresh (v2.6.5)

Copies about 1,000 tables from an Azure Synapse dedicated SQL pool into Unity Catalog
Delta tables every night, in full, by 07:00 Australia/Sydney for the expected business date.

Each table follows the same steps:

1. It is exported once with CETAS. If CETAS fails for a supported fallback error,
   or its output contains a potentially shifted historical timestamp, it is
   exported once through JDBC instead, reusing your existing connection. Row counts come from the upstream's
   manifest CSV in storage, so Synapse only sees each table's own export.
2. The export is validated.
3. It replaces the target's data in **one atomic `INSERT OVERWRITE`**.

A table that fails before the Delta commit keeps serving the previous night's data. A
failed verification of a commit made by the same job run attempts a RESTORE and must
be inspected if that RESTORE cannot be confirmed; a commit left by an earlier job run
is never restored automatically. Automatic runs require today's Sydney business
date; a late upstream cannot make yesterday's release look successful. A missed
07:00 deadline fails the job.

After all batches finish, finalize sends one structured summary to an
operator-owned HTTPS workflow (such as an Azure Logic App) that emails the
table counts and every failed mapping ID. Configure the endpoint URL as a
Databricks secret before deploying; see the runbook. This also reports optional
table failures when the Databricks job as a whole succeeds.

Retries, lost acknowledgements, reruns of the same night, and stuck older jobs are all
made safe by one mechanism: Delta's idempotent-write guard. The table name is a
constant app id, and the nightly `upstream_sequence` is the version.

**AI agents: read [AGENTS.md](AGENTS.md) first.** It states the design intent, the
invariants that must not be broken, and the environment facts (Databricks and the
Synapse pool are already connected: reuse, do not re-provision).

See **[docs/DESIGN.md](docs/DESIGN.md)** for the architecture and the reasoning behind
it, **[docs/RUNBOOK.md](docs/RUNBOOK.md)** for setup and day-to-day operation,
and **[docs/PACKAGE_GUIDE.md](docs/PACKAGE_GUIDE.md)** for every folder and file,
their inputs and outputs, and the one-time, nightly, and recovery flows.

## Contents

```
FIRST_READ_ME.md               start here: reading order, where to find answers, Confluence upload
CHANGELOG.md                   what changed in each version
AGENTS.md                      design intent, invariants and safe-change guide for AI agents
databricks.yml                 Asset Bundle: nightly, maintenance, rollback, acceptance jobs
config/
  settings.example.json        top-level settings template (everything except mappings)
  row_counts.example.csv       example upstream row-count manifest
  inventory.example.json       complete example inventory with two tables
src/bridge/                    the Python package used by the notebooks
  contract.py                  type mapping, inventory validation, SQL builders
  planning.py                  batching, cutoff, status sets, Delta-history decisions
  manifest.py                  upstream row-count manifest: settings, paths, parsing, trust rules
  process.py                   the per-table flow (platform calls injected)
  loader.py                    Parquet validation/conversion, guarded overwrite, history
  synapse.py                   JDBC access to the pool (Entra token)
  control.py                   append-only control log
  notification.py              complete end-of-run summary sent to secret-backed HTTPS endpoint
src/notebooks/                 00_plan, 10_process_batch, 90_finalize,
                               _bootstrap, rollback, maintenance, acceptance_checks
sql/synapse/                   export objects + permissions; upstream completion table
sql/unity_catalog/             control-table upgrade scripts (1.2→1.3, 1.3→1.4, 2.4→2.5)
tools/                         generate_inventory.py, render_uc_setup.py, prepare_deploy.py
.github/workflows/             ci-cd.yml, bundle-deploy.yml: GitHub OIDC deploy to dev and prod
infra/                         ADLS lifecycle rule for staging, identity summary
tests/                         unit tests + local-Spark tests
docs/                          PACKAGE_GUIDE.md (start here), DESIGN.md,
                               CODE_STRUCTURE.md, DATA_DICTIONARY.md, RUNBOOK.md,
                               RELEASE_VALIDATION.md, V22_REVIEW_RESOLUTION.md
```

## Quick start

1. Confirm the existing Databricks ↔ Synapse connection meets AGENTS.md section 2; create
   `bridge_upstream.upstream_run` (`sql/synapse/02`) only if using `synapse_table`
   completion, and apply the ADLS lifecycle rule.
2. Generate `config/inventory.json` with `tools/generate_inventory.py`, then review it.
3. Render and run the Unity Catalog setup with `tools/render_uc_setup.py`.
4. `databricks bundle deploy -t prod --var job_identity=<sp-app-id> --var notification_email=<ops> \
   --var operations_group=<operations-group> --var rollback_approvers_group=<approvers-group>`,
   or deploy through GitHub Actions (`.github/workflows/`; see RUNBOOK "Deploying with GitHub Actions").
5. Run the **acceptance** job. It must pass before go-live.
6. Do a trial night in non-production, then unpause the schedule with the
   `nightly_pause_status` bundle variable (a UI-only unpause is reset by the next deploy).

**Go-live gate:** the workspace acceptance job, an end-to-end Synapse trial,
effective permission review (including the full reach of Synapse's
`ALTER ANY EXTERNAL DATA SOURCE` grant), and exclusive target-write ownership must be
confirmed in your environment. Local tests do not establish those facts.
See [docs/RELEASE_VALIDATION.md](docs/RELEASE_VALIDATION.md) for the checks.

The full steps, with commands, are in the runbook.

## Tests

```bash
pip install -r requirements-dev.txt
python -m pytest tests -q
```

For local Spark/JDBC tests, pin the JVM to UTC and give Spark a bindable address
(for example, `JAVA_TOOL_OPTIONS=-Duser.timezone=UTC SPARK_LOCAL_IP=127.0.0.1 python -m pytest tests -q`).

Unit tests cover the contract, planning, the per-table flow with every failure path,
and the tools. The Spark tests run on a local Spark session and are skipped
automatically when `pyspark` is not installed.

Delta-specific behaviour cannot run outside Databricks, so it is proven on your runtime
by `src/notebooks/acceptance_checks.py`.

## Requirements

* Databricks Runtime 18 (`18.x`, 17.0 is the minimum for the governance preflight) on a job cluster in dedicated (single-user)
  access mode (`18.x-scala2.13`); verify the
  selector and JDBC access in your workspace. Serverless is not used for the
  export or publish step in this architecture.

**Recovery:** an automatic run publishes before 07:00 Sydney time. A new, targeted
same-day run with `business_date` and `only_mappings` can repair failed tables before
11:00; the nightly job rejects it at or after 11:00. A fixed five-minute margin
stops starting exports and overwrites close to either deadline. After 11:00, leave the table
for the next night. The nightly job does not serve historical backfills.

**Governed targets:** this `INSERT OVERWRITE` path on dedicated compute is not
qualified for targets with table-level row filters or column masks. They also
affect the RESTORE recovery path. Do not enable those policies on a bridge target
without a separately reviewed publication design and workspace trial. ABAC
exemptions require their own validation. The plain-table acceptance job cannot
certify a governed target.

* Unity Catalog, with an external location on the staging container.
* A Synapse dedicated SQL pool (workspace endpoint or standalone
  `*.database.windows.net` endpoint) and an ADLS Gen2 staging account.
