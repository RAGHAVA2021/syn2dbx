# v2.6.5 release validation

## Additional for v2.6.5

v2.6.5 changes deployment only; the nightly load logic is unchanged from v2.6.4.

* Complete RUNBOOK "Deploying with GitHub Actions", one-time GitHub setup, for
  both environments.
* Open a pull request and confirm the `test` job passes with the Spark and
  Derby tests running (not skipped).
* Merge and confirm the dev deploy succeeds, the job names in dev carry the
  development-mode prefix, and the deployed `config/inventory.json` in the dev
  bundle folder matches `config/inventory.dev.json`.
* Confirm the prod deploy waits for approval, is refused from a non-`main`
  branch, and that the deployed prod inventory matches
  `config/inventory.prod.json`. Confirm no `inventory.dev.json` or
  `inventory.prod.json` file is present in either workspace bundle folder.
* With `NIGHTLY_PAUSE_STATUS` unset, confirm the prod nightly schedule is
  PAUSED after deploy. At go-live, set it to `UNPAUSED`, redeploy, confirm the
  schedule is active, then run one more ordinary deploy and confirm it stays
  active.
* Confirm the deployed jobs run as `job_identity`, not as the deploying
  identity, and that the job permissions match the variables.
* Temporarily set a placeholder host or remove an environment inventory in a
  branch and confirm the deploy stops at `prepare_deploy.py` with a clear message.

## Additional for v2.6.4

Configure a secret-backed HTTPS summary endpoint and verify that the dedicated
job cluster can POST to it. In a test run with one optional failed table,
verify one operator email with the total, success and failure counts and the
failed mapping ID/status even when the job succeeds. Exercise a mandatory
failure, a zero-failure run, a receiver timeout, and a manual Repair run.
Configure the receiver to deduplicate `notification_id`, since a sender cannot
guarantee exactly-once delivery across network acknowledgement loss. The
existing on-failure job email remains a separate alert for failed jobs or an
early plan failure; choose whether to route that alert to the same mailbox.

## Additional for v2.6.3

* Deploy with `databricks bundle validate` and confirm the batch task resolves
  `repair_count` to an integer (a literal `{{job.repair_count}}` fails the task).
* In a non-production trial, repair a run after finalize and confirm an existing
  commit whose count disagrees ends as `FAILED_VERIFY`, not restored.
* Run the rendered UC setup SQL end to end on a SQL warehouse.
* Convert every `governance.exempt_abac_policies` entry to `{catalog, schema?, table?, name}`
  from the reviewed `SHOW EFFECTIVE POLICIES` row, and rerun the acceptance job.

## Additional for v2.6.2

* Run the acceptance job on the production Runtime 18 cluster. v2.6.1's
  acceptance job could not run (its mappings lacked `mapping_id`). It now also
  proves: the runtime is 17+, the governance preflight runs on a plain target
  (and lists any inherited ABAC policy), a missing staging folder, manifest CSV
  and marker are classified as missing, and a bridge overwrite is not recorded
  as `isDynamicPartitionOverwrite`.
* If the preflight is blocked by an inherited ABAC policy, follow RUNBOOK
  *Governed targets*; never exempt a policy without checking its `EXCEPT` clause.
* Rehearse a transient plan failure (for example, pause the pool briefly at
  plan start in non-production): the plan should retry for up to
  `plan_transient_retry_minutes`, while a malformed manifest must still fail
  at once.
* Confirm finalize fails when more than `max_failed_table_ratio` of tables do
  not refresh, even with every mapping optional.
* Rerun acceptance after any Runtime 18 release-note entry that lists
  behavioural changes; compare `run_log` `runtime` values across nights.

## Additional for v2.6

* Run the acceptance job on the actual Runtime 18 LTS cluster; its writes now
  invoke `loader.overwrite` including the full column list, session setting
  cleanup, and static partition override under a dynamic session default.
* The nightly job rejects historical dates and same-day repairs at or after
  11:00 Sydney time. Confirm a new targeted run between 07:00 and 11:00 and
  check that a repair of the original job keeps its 07:00 cutoff.
* Review effective ABAC policies and table-level row filters or column masks on
  every target. The plain-table acceptance job cannot qualify a governed
  target for dedicated-compute INSERT OVERWRITE or RESTORE. The table worker and
  rollback fail closed when those policies are found or metadata cannot be
  inspected. v2.6.1 reads table-level policies from current `DESCRIBE TABLE
  EXTENDED ... AS JSON` metadata instead of potentially lagging information
  schema views. Such targets need a different reviewed publication design.
* Check that no target sets `delta.setTransactionRetentionDuration`, and verify
  the default five-minute publication margin against representative large
  overwrites. The margin is not a hard upper bound on a running overwrite.

The v2.5 release stopped a rerun from automatically restoring a correct publication
made by an earlier job run, judges the 07:00 deadline by Delta commit time, never
blocks `synapse_table` mode on the manifest, lets the Spark-free tests run
without PySpark, and adds `execution.additional_access_error_codes`. Everything
from v2.4 still applies. Local tests validate code paths only; do not unpause
production before the workspace checks below.

## Additional for v2.5

* Run `sql/unity_catalog/upgrade_2.4_to_2.5.sql` once **before** deploying; the
  job appends `commit_utc` to `table_log`.
* The acceptance job now also checks that `loader.history` exposes each commit's
  time in UTC. Rerun it on the production runtime.
* In the trial, include a rerun in a **new job run** after changing a source
  table's row count: the already-published table must end `ALREADY_CURRENT` (when
  the earlier publication was logged) or `FAILED_VERIFY`, and must never be
  restored. Also force a bad commit's lost acknowledgement within one job run and
  confirm it is still restored.
* Record every permission-denied code seen during the permission review and
  trial. Add a code to `execution.additional_access_error_codes` only after it has
  been observed from this pool.

## Completed on the packaged code

* On this review host, `TZ=UTC JAVA_TOOL_OPTIONS=-Duser.timezone=UTC
  SPARK_LOCAL_IP=127.0.0.1 python -m pytest tests -q` passed **344 tests** (PySpark 4.1.3 and 4.2.0, JDK 21),
  including local Spark and Derby JDBC. Runtime 18 LTS and Delta behavior
  must still pass workspace acceptance. The tests include regression checks for
  same-day corrections, later target writes, retry scope, cutoff behavior and
  a newer commit arriving before automatic restore.
* No source code, inventory example or deployment template contains a live
  password or token. Credentials are resolved at runtime.

## Required in the target environment before enabling the production schedule

1. Populate and review `config/inventory.json`; confirm the chosen completion
   mode, upstream correction protocol, mapping IDs, source-set sequence and
   target grants. Keep the upstream source set fixed while each release runs.
   Move the manifest and marker to a separate read-only container and the
   Synapse completion table to `bridge_upstream`. A preexisting `bridge_meta`
   table must be migrated by the upstream team; do not drop it until the
   upstream writer and job both use the new schema.
2. Run `sql/synapse/03_review_credential_scope.sql` as a pool administrator.
   Microsoft documents that `ALTER ANY EXTERNAL DATA SOURCE` reaches every
   database-scoped credential in the pool database. Review existing and future
   credentials, then formally approve this reach or isolate/redesign the export.
   Restrict the staging location to approved principals. Confirm no other
   process or operator job can commit to a bridge target while the nightly job
   may automatically RESTORE a bad commit. A post-RESTORE history check detects
   many races, but cannot prevent a competing write between the check and RESTORE.
3. Deploy the bundle and run the `acceptance` job on the production runtime.
   It must confirm idempotent SQL overwrites, history metrics, RESTORE metadata, and
   rejection of an untagged later target write, real OPTIMIZE operation history,
   empty and partitioned overwrites, history names for maintenance,
   and a real scratch SELECT grant. Check a governed target is rejected by the
   new preflight in a non-production run. The acceptance job requires `grant_principal`.
4. Run a controlled Synapse trial covering CETAS, a forced JDBC fallback,
   empty data including a missing folder and a missing JDBC `_SUCCESS`,
   a rejected schema change, a repaired same-release rerun in a
   **new job run**, and a higher-sequence same-day correction. Confirm source
   and staged counts, a prior target version on failure, and restoration steps.
5. Confirm the real upstream manifest is completed and marked last (or that
   `bridge_upstream.upstream_run` supplies increasing sequences), then measure
   the largest-table export against the 07:00 Sydney deadline.
   In manifest mode the upstream must prevent same-day corrections until the
   bridge finishes; removing a success marker alone does not fence an export
   that is already running. Check the pool's isolation setting and upstream
   scheduler, not only counts. RCSI is useful but does not make all 1,000
   table exports a single consistent snapshot.
   Confirm its business-date convention: the automatic 01:30 Sydney run expects
   that Sydney calendar date, not the date of the preceding daytime load.
   Remove the marker during a test plan wait; it should continue waiting.
6. Coordinate manual rollback with the nightly job and all other writers;
   RESTORE is not conditional on an expected current version. Review failure
   notifications and ADLS lifecycle rules.
7. Verify a historical date and timestamp against Synapse values on actual
   CETAS and JDBC files. Include dates and timestamps around 0001-01-01,
   1582-10-04/15, 1753-01-01 and 1899-12-31 where the source types permit them.
   The local PyArrow INT96 reproduction *silently shifted*
   a 1753 timestamp with `CORRECTED`; v2.0 detects pre-1900 CETAS timestamps
   and routes them through Spark-written JDBC staging. Live encodings still need
   explicit signoff. Measure the historical-timestamp fallback count and
   completion time; these contract fallbacks no longer consume the budget for
   CETAS errors, but still reread the table via JDBC.
   Do not lower the 1900 cutoff without comparing actual Synapse writer output
   with source values and recording the decision. Check DATE values separately.
8. Observe CETAS timeouts in the Synapse DMV before enabling task retries.
   This package does not automatically issue KILL: a timed-out client can leave
   a server query running, and a blind KILL would require broad new privileges.
9. Verify the configured authentication mode on the exact production job
   cluster. `client_secret` uses the `azure-identity` package that Runtime 18
   ships preinstalled; `service_credential` and `sql_password` do not use it.
   Check whether automatic compaction commits OPTIMIZE immediately after a bad
   overwrite. Automatic RESTORE is intentionally refused when the bad commit
   is no longer the newest version; rehearse a manual rollback under an
   exclusive target-writer window.
10. Record fixed overhead per small table, total duration by batch, how many
    manifest counts are missing, and CETAS-error versus historical timestamp
    fallback counts. The default four concurrent lanes process roughly 250
    tables each for a 1,000-table inventory. Only increase concurrency after
    checking the pool's workload limits and the measured trial duration.

Local tests cannot prove Synapse CETAS encoding, real credentials and grants,
Databricks runtime transaction behavior, or production throughput.
