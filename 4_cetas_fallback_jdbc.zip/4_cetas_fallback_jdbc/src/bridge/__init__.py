"""Synapse dedicated SQL pool -> Unity Catalog Delta nightly full refresh."""
__version__ = "2.6.5"
