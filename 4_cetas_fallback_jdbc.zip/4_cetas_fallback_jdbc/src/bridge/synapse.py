"""Synapse dedicated SQL pool access from a Databricks job cluster.

Two uses of the same connection settings and credentials:
  * Commands (schema check, count, CETAS, bounds) over a JDBC connection opened
    through the JVM with the SQL Server driver bundled in the Databricks Runtime.
    The JVM gateway needs a cluster in dedicated (single-user) access mode.
  * The fallback bulk read (loader.jdbc_export) through Spark's JDBC source,
    passing the same connection properties.

Authentication modes (synapse.auth.mode):
  * service_credential: Unity Catalog service credential (access connector managed
    identity). Entra token, no secret to rotate. Preferred.
  * client_secret: service principal; tenant/client id/secret in a secret scope.
  * sql_password: SQL user and password in a secret scope (matches an existing
    user/password JDBC setup; prefer an Entra mode when possible).
"""
from contextlib import contextmanager

from . import contract

SQL_SCOPE = "https://database.windows.net/.default"
DRIVER = "com.microsoft.sqlserver.jdbc.SQLServerDriver"


def credentials_provider(settings, dbutils):
    """Return a function giving fresh JDBC connection properties on every call.

    Tokens are fetched per connection, so a long night never uses an expired token.
    """
    auth = settings["synapse"]["auth"]
    if auth["mode"] == "sql_password":
        s = lambda k: dbutils.secrets.get(auth["secret_scope"], auth[k])
        return lambda: {"user": s("user_key"), "password": s("password_key")}
    if auth["mode"] == "service_credential":
        credential = dbutils.credentials.getServiceCredentialsProvider(auth["credential_name"])
    else:
        from azure.identity import ClientSecretCredential
        s = lambda k: dbutils.secrets.get(auth["secret_scope"], auth[k])
        credential = ClientSecretCredential(s("tenant_id_key"), s("client_id_key"), s("client_secret_key"))
    return lambda: {"accessToken": credential.get_token(SQL_SCOPE).token}


def jdbc_url(settings):
    syn = settings["synapse"]
    host = contract.SERVER.fullmatch(syn["server"])
    if host is None:
        raise ValueError("synapse.server must be a validated Azure Synapse dedicated-pool endpoint")
    certificate = ("*.database.windows.net" if syn["server"].endswith(".database.windows.net")
                   else "*.sql.azuresynapse.net")
    return (f"jdbc:sqlserver://{syn['server']}:1433;database={syn['database']};encrypt=true;"
            f"trustServerCertificate=false;hostNameInCertificate={certificate};loginTimeout=30;"
            f"applicationName=synapse-full-refresh")


class Connection:
    def __init__(self, jconn):
        self.j = jconn

    def query(self, sql, *params, timeout=600):
        """Run a query; every value comes back as str or None (callers convert)."""
        stmt = self.j.prepareStatement(sql)
        try:
            stmt.setQueryTimeout(int(timeout))
            for i, p in enumerate(params, start=1):
                stmt.setString(i, str(p))
            rs = stmt.executeQuery()
            n = rs.getMetaData().getColumnCount()
            rows = []
            while rs.next():
                rows.append(tuple(rs.getString(i) for i in range(1, n + 1)))
            return rows
        finally:
            stmt.close()

    def execute(self, sql, timeout):
        stmt = self.j.createStatement()
        try:
            stmt.setQueryTimeout(int(timeout))
            stmt.execute(sql)
        finally:
            stmt.close()


@contextmanager
def connect(spark, settings, get_props, url=None):
    jvm = spark.sparkContext._gateway.jvm
    props = jvm.java.util.Properties()
    for k, v in get_props().items():
        props.setProperty(k, v)
    jconn = jvm.java.sql.DriverManager.getConnection(url or jdbc_url(settings), props)
    jconn.setAutoCommit(True)
    try:
        yield Connection(jconn)
    finally:
        jconn.close()


# ------------------------------------------------------------------ helpers

def upstream_run(conn, settings, business_date=None):
    """Return the highest-sequence COMPLETE run for the requested date."""
    schema = contract.q_sql(settings["synapse"]["upstream_control_schema"])
    cols = "upstream_run_id, CONVERT(char(10), business_date, 23), upstream_sequence"
    where = f"FROM {schema}.[upstream_run] WHERE source_set_id=? AND status='COMPLETE'"
    if business_date:
        rows = conn.query(f"SELECT TOP 2 {cols} {where} AND business_date=CAST(? AS date) "
                          "ORDER BY upstream_sequence DESC",
                          settings["source_set_id"], business_date)
        if len(rows) > 1 and int(rows[0][2]) == int(rows[1][2]):
            raise RuntimeError(f"Conflicting COMPLETE upstream runs at sequence {rows[0][2]} "
                               f"for {business_date}")
        if not rows:
            return None
    else:
        rows = conn.query(f"SELECT TOP 1 {cols} {where} ORDER BY upstream_sequence DESC", settings["source_set_id"])
        if not rows:
            return None
    run_id, date, seq = rows[0]
    return {"upstream_run_id": run_id, "business_date": date, "sequence": int(seq)}


def schema_hash(conn, m):
    rows = conn.query(contract.SYS_COLUMNS_SQL, f"[{m['source_schema']}].[{m['source_object']}]")
    if not rows:
        raise contract.ContractError("FAILED_SCHEMA_DRIFT",
                                     f"source object {m['source_schema']}.{m['source_object']} not found")
    return contract.schema_hash(rows)


def schema_hashes(conn, mappings, timeout=600):
    """Schema hash for every mapping with ONE catalog query (instead of one per table)."""
    schemas = sorted({m["source_schema"] for m in mappings})
    rows = conn.query(contract.all_columns_sql(len(schemas)), *schemas, timeout=timeout)
    return contract.hashes_from_rows(rows, mappings)


def count_rows(conn, m, timeout):
    return int(conn.query(contract.count_sql(m), timeout=timeout)[0][0])


def partition_bounds(conn, m, timeout):
    """(lower, upper) as strings for a parallel JDBC read, or None when not partitioned/empty."""
    if not contract.partition_column(m):
        return None
    lo, hi = conn.query(contract.bounds_sql(m), timeout=timeout)[0]
    return None if lo is None or hi is None else (lo.strip(), hi.strip())


def export(conn, m, settings, external_table, location, timeout):
    """CETAS the mapping to location, always dropping the external table definition afterwards."""
    try:
        conn.execute(contract.cetas_sql(m, settings, external_table, location), timeout)
    finally:
        try:
            conn.execute(contract.drop_external_sql(settings, external_table), 300)
        except Exception:  # best effort; maintenance drops leftovers
            pass


# ------------------------------------------------ staging objects (reuse check)

def staging_problems(file_format_type, data_source_location, settings):
    """Pure check of the existing Synapse objects the export reuses.

    * The file format must be PARQUET. A DELIMITEDTEXT format would let line
      breaks, pipes and quotes inside text corrupt rows and columns.
    * The data source must point at the container Databricks reads
      (staging.root); otherwise CETAS succeeds but writes files elsewhere.
    """
    st = settings["staging"]
    problems = []
    if file_format_type is None:
        problems.append(f"external file format {st['file_format']!r} does not exist")
    elif str(file_format_type).upper() != "PARQUET":
        problems.append(f"external file format {st['file_format']!r} is {file_format_type}, must be PARQUET "
                        "(delimited text breaks on line breaks, pipes and quotes in the data)")
    if data_source_location is None:
        problems.append(f"external data source {st['external_data_source']!r} does not exist")
    elif str(data_source_location).rstrip("/").lower() != st["root"].rstrip("/").lower():
        problems.append(f"external data source {st['external_data_source']!r} points at {data_source_location}, "
                        f"but staging.root is {st['root']}")
    return problems


def check_staging_objects(conn, settings):
    st = settings["staging"]
    fmt = conn.query("SELECT format_type FROM sys.external_file_formats WHERE name=?", st["file_format"])
    ds = conn.query("SELECT location FROM sys.external_data_sources WHERE name=?", st["external_data_source"])
    problems = staging_problems(fmt[0][0] if fmt else None, ds[0][0] if ds else None, settings)
    if problems:
        raise RuntimeError("Synapse staging objects are not usable: " + "; ".join(problems))


# ------------------------------------------------- export error classification

# Caused by the source data itself: the same SELECT fails the same way on every
# retry and by any export route, so no retry and no fallback.
DATA_ERROR_CODES = {
    220: "arithmetic overflow",
    232: "arithmetic overflow",
    241: "date/time conversion from string failed",
    242: "out-of-range date/time from string",
    245: "conversion to number failed",
    248: "conversion overflowed int",
    517: "date arithmetic overflow",
    8114: "data type conversion failed",
    8115: "arithmetic overflow converting value",
    8134: "divide by zero in the source view",
}

# Pool capacity or connectivity: a second export route competes for the same pool
# or cannot connect either, so no fallback; the normal single task retry applies.
CAPACITY_ERROR_CODES = {
    -2: "timeout", 1105: "filegroup full", 9002: "log full", 40197: "service error, retry",
    40501: "service busy", 40613: "database unavailable", 10928: "resource limit",
    10929: "resource limit", 49918: "not enough resources", 49919: "too many requests",
    49920: "too many operations",
}
CAPACITY_SQLSTATE_PREFIXES = ("08", "HYT")   # connection failures, timeouts
SCHEMA_ERROR_CODES = {207, 208}  # invalid source column or object after the plan
ACCESS_ERROR_CODES = {229, 230}  # source/DDL permission denied; retrying JDBC cannot grant access
# Other SQL Server "permission denied" codes that are LIKELY on a CETAS grant
# regression, but not yet observed from this pool. They are not built in
# (AGENTS.md section 8 requires evidence from a real failure). Confirm a code
# in the trial, then list it in execution.additional_access_error_codes; it
# then ends as FAILED_SOURCE_ACCESS instead of burning a JDBC fallback slot.
ACCESS_ERROR_CANDIDATES = {262: "permission denied in database (e.g. CREATE TABLE)",
                           297: "user does not have permission to perform this action",
                           300: "permission was denied on object",
                           15247: "user does not have permission to perform this action"}


def sql_error_info(exc):
    """(error code, SQLSTATE) from a SQL Server error, walking Python and Java cause chains.

    Spark and py4j wrap the driver's SQLServerException several levels deep; the
    first Java exception in the chain with a non-zero error code wins.
    """
    seen = set()
    while exc is not None and id(exc) not in seen:
        seen.add(id(exc))
        java = getattr(exc, "java_exception", None)
        depth = 0
        while java is not None and depth < 20:
            depth += 1
            try:
                code = int(java.getErrorCode())
                if code:
                    try:
                        state = java.getSQLState()
                    except Exception:
                        state = None
                    return code, (str(state) if state else None)
            except Exception:
                pass
            try:
                java = java.getCause()
            except Exception:
                java = None
        exc = exc.__cause__ or exc.__context__
    return None, None


def sql_error_code(exc):
    return sql_error_info(exc)[0]


def classify_export_error(code, sqlstate, extra_access_codes=()):
    """Classify known deterministic failures before considering a JDBC fallback.

    extra_access_codes: confirmed access-denied codes from
    execution.additional_access_error_codes (validated not to overlap the
    schema, data or capacity sets).
    """
    if code in SCHEMA_ERROR_CODES:
        return "SCHEMA"
    if code in ACCESS_ERROR_CODES or (code is not None and code in set(extra_access_codes or ())):
        return "ACCESS"
    if code in DATA_ERROR_CODES:
        return "DATA"
    if code in CAPACITY_ERROR_CODES or (sqlstate and str(sqlstate).upper().startswith(CAPACITY_SQLSTATE_PREFIXES)):
        return "CAPACITY"
    if code is None:
        return "CAPACITY"   # no SQL Server error at all (client/network side): retry, do not switch route
    return "CETAS"


# ------------------------------------------------ plan-time transient errors

TRANSIENT_JAVA_CLASS_PREFIXES = ("java.net.", "javax.net.ssl.SSLException")
TRANSIENT_JAVA_CLASSES = {"java.io.InterruptedIOException", "java.util.concurrent.TimeoutException",
                          "java.io.EOFException"}


def is_transient_platform_error(exc):
    """Errors the plan may retry: pool capacity/connectivity or a network-level failure.

    Narrow on purpose. Only a real SQL Server capacity code, a connection or
    timeout SQLSTATE, or a Java networking exception in the cause chain
    qualifies. Unlike classify_export_error, an error with no SQL code at all
    is NOT transient here: a malformed manifest, wrong staging objects or a
    bug must fail the plan at once. Type-based, not message-based (Runtime 18
    changed exception types for SQLSTATE).
    """
    from .manifest import MISSING_PATH_JAVA_CLASSES, java_class_name, java_exception_chain
    code, state = sql_error_info(exc)
    if code in CAPACITY_ERROR_CODES:
        return True
    if state and str(state).upper().startswith(CAPACITY_SQLSTATE_PREFIXES):
        return True
    for java in java_exception_chain(exc):
        name = java_class_name(java)
        if name in MISSING_PATH_JAVA_CLASSES:
            return False
        if name in TRANSIENT_JAVA_CLASSES or name.startswith(TRANSIENT_JAVA_CLASS_PREFIXES):
            return True
        # mssql-jdbc reports a dropped connection with error code 0 and SQLSTATE
        # 08S01, which sql_error_info (first non-zero code) does not return.
        try:
            java_state = java.getSQLState()
        except Exception:  # noqa: BLE001 - not a SQLException
            java_state = None
        if java_state and str(java_state).upper().startswith(CAPACITY_SQLSTATE_PREFIXES):
            return True
    return False
