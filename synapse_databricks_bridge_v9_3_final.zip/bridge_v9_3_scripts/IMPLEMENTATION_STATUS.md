# Implementation status against the v9 design (package v9.3)

This is an execution reference, not a claim that every command in v9 has been implemented. The actual environment and mapping inventory were not supplied. No Synapse, ADLS, ADF, Azure SQL or Databricks connection was available for an integration run.

| v9 concern | Package status |
|---|---|
| Source-generation fence | SQL state machine, CLI hooks, post-extraction re-check, guarded release and `abandon`/`reopen` recovery supplied; writer inventory, bypass permission removal and detector streams still required |
| Upstream audit | Script counts each configured presentation view and checks ordered metadata hash; integrate after actual transformation completion |
| Large inventory discovery | Generator reads all tables or views in one Synapse schema and derives supported ordered columns, types and hashes; unsupported types or names stop generation and require reviewed exceptions |
| Source-table profiling | Databricks classic-cluster PySpark JDBC notebook or control-host ODBC script; dedicated-pool DMV rows/bytes plus separate physical and mapped column counts; subset views are supported, but joined/calculated views still need separate workload measurement |
| CETAS | Controlled column projection, unique path, metadata cleanup and bounded extraction concurrency; platform test required |
| Copy Activity | ADF dataset/pipeline and API runner; configure linked services, network, type and null behaviour, and verify route-specific capacity |
| ADLS | Fresh-path check, UC read, hash-checked job manifests and exact-path retention (`retire_releases.py --delete-staging`); path quarantine not implemented |
| Schema and temporal contracts | Column name/order/type checks and basic casts; application-specific TIME, timezone, ancient-date, nested, LOB and text compatibility profiles not implemented |
| Delta writes | Idempotent transaction pair and candidate/slice count; explicitly verify API support and retained transaction horizon on selected runtime |
| Independent publication | Separate publication Job, one table per REPLACE_TABLE group, per-target publication claim across runs, explicit string property contract; policy/consumer readiness must be produced and checked by independently built tests |
| Group pointer | Rejects optional member; validates enabled slices and conditional pointer update; generated consumer views assume physical-table policies |
| Empty result | Rejected until an auditable zero-row release manifest and empty-Parquet handling are implemented |
| Rollback and cleanup | Immutable attempt metadata lets retention cover failed-load candidates and mappings removed from later inventory waves; previous release is kept; rollback itself remains manual |
| Recovery and audit | External IDs/correlation tokens are persisted before polling; indeterminate work blocks release/resume; takeover covers job+cancel timeout; `recovery.py` records evidence-gated attempt/publication recovery. Source audit detectors still required |
| Throughput/SLO | Extracts have aggregate and class caps; Databricks loads and publications across disjoint groups have bounded parallel caps. Configure the corresponding Jobs' concurrent-run limits and benchmark representative full-volume objects and the full estate |

The fail-closed omissions above are deliberate: a placeholder claiming that a policy check or source-violation detector passed would create a false production assurance. Supply actual mapping metadata and environment details before completing those controls. Never treat an evidence JSON file containing manually entered `true` values as proof.
