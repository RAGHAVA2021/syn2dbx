"""Source-generation fence transitions (steps 3, 5, 7 and recovery in SCRIPT_GUIDE.md).

The upstream scheduler MUST call write-start before any governed table DML,
write-close after all audit rows commit, then bridge-hold. All other writer
identities must be constrained to the same entry point.

Recovery actions:
  abandon  WRITE_ACTIVE/CLOSED/BRIDGE_HELD -> ABANDONED. Marks unpublished bridge runs of the
           generation ABANDONED_GENERATION in the same transaction. Refused while a run publishes.
  reopen   ABANDONED -> AVAILABLE, so a new generation can be written.
"""
import argparse
import json
from datetime import datetime, timezone

from bridge_run import config, db, need

NEXT = {"write-start": ("AVAILABLE", "WRITE_ACTIVE"),
        "write-close": ("WRITE_ACTIVE", "CLOSED"),
        "bridge-hold": ("CLOSED", "BRIDGE_HELD"),
        "bridge-release": ("BRIDGE_HELD", "AVAILABLE"),
        "abandon": (None, "ABANDONED"),
        "reopen": ("ABANDONED", "AVAILABLE")}
NEEDS_EXPIRY = ("write-start", "write-close", "bridge-hold")


def main():
    p = argparse.ArgumentParser()
    p.add_argument("action", choices=NEXT)
    p.add_argument("--source-set", required=True)
    p.add_argument("--generation", required=True)
    p.add_argument("--actor", required=True,
                   help="Writer run ID on start/close; bridge run ID on hold/release; current owner for abandon")
    p.add_argument("--expiry-utc", help="UTC ISO time; required for write-start, write-close and bridge-hold")
    p.add_argument("--evidence", help="JSON evidence for bridge-release; all gate checks must pass")
    p.add_argument("--reason", help="Required for abandon and reopen; stored in bridge.fence_events")
    p.add_argument("--config", help="Required for bridge-hold source-audit preflight")
    p.add_argument("--upstream-run-id", help="Required for bridge-hold source-audit preflight")
    a = p.parse_args()
    prior, nxt = NEXT[a.action]
    expiry = None
    if a.action in NEEDS_EXPIRY:
        need(a.expiry_utc, "Fence needs a bounded expiry")
        parsed = datetime.fromisoformat(a.expiry_utc.replace("Z", "+00:00"))
        need(parsed.tzinfo is None or parsed.utcoffset().total_seconds() == 0, "Expiry must be UTC")
        now_utc = datetime.now(timezone.utc).replace(tzinfo=None)
        need(parsed.replace(tzinfo=None) > now_utc, "Expiry is in the past")
        expiry = parsed.replace(tzinfo=None).isoformat(timespec="milliseconds")
    if a.action in ("abandon", "reopen"):
        need(a.reason and len(a.reason) <= 1000, "abandon/reopen need a --reason (max 1000 characters)")
    if a.action == "bridge-release":
        need(a.evidence, "Bridge release needs independent detector evidence")
        with open(a.evidence, encoding="utf-8") as handle:
            data = json.load(handle)
        for field in ("all_source_requests_terminal", "no_source_retry_needed", "audit_healthy",
                      "no_fence_violation", "smoke_check_passed"):
            need(data.get(field) is True and data.get(field + "_evidence_uri"), f"Missing {field}")
        need(data.get("source_generation_id") == a.generation, "Wrong generation in evidence")
    if a.action == "bridge-hold":
        need(a.config and a.upstream_run_id, "Hold requires inventory and upstream run ID")
        cfg = config(a.config)
        need(cfg["source_set_id"] == a.source_set, "Wrong source set")
        with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
            run = syn.cursor().execute("SELECT count_big(*) FROM bridge_meta.upstream_run WHERE "
                                       "upstream_run_id=? AND source_generation_id=? AND status='COMPLETE' "
                                       "AND write_closed=1", a.upstream_run_id, a.generation).fetchone()
            need(run and run[0] == 1, "Upstream generation not uniquely closed")
            for m in cfg["mappings"]:
                obj = syn.cursor().execute("SELECT count_big(*) FROM bridge_meta.upstream_object WHERE "
                                           "upstream_run_id=? AND mapping_id=? AND source_schema_version=? "
                                           "AND status='COMPLETE'", a.upstream_run_id, m["mapping_id"],
                                           m["source_schema_version"]).fetchone()
                need(obj and obj[0] == 1, f"Incomplete upstream member: {m['mapping_id']}")
    with db("BRIDGE_CONTROL_ODBC") as conn:
        row = conn.cursor().execute("SELECT state,generation_id,writer_owner,bridge_owner,control_version "
                                    "FROM bridge.source_fence WITH (UPDLOCK,HOLDLOCK) WHERE source_set_id=?",
                                    a.source_set).fetchone()
        need(row, "Unknown source set")
        if a.action == "abandon":
            need(row[0] in ("WRITE_ACTIVE", "CLOSED", "BRIDGE_HELD"), f"Cannot abandon from {row[0]}")
            prior = row[0]
        need(row[0] == prior, "Fence changed; stop")
        if prior != "AVAILABLE":
            need(row[1] == a.generation, "Generation changed")
        if prior == "WRITE_ACTIVE":
            need(row[2] == a.actor, "Wrong writer")
        if prior == "BRIDGE_HELD":
            need(row[3] == a.actor, "Wrong bridge owner")
        cur = conn.cursor()
        if a.action == "bridge-release":
            # Releasing lets writers modify the source; no extraction may still be reading it.
            active = cur.execute("SELECT count(*) FROM bridge.object_attempts WHERE bridge_run_id=? "
                                 "AND (status IN ('EXTRACTING','INDETERMINATE') OR "
                                 "source_operation_state IN ('RUNNING','UNKNOWN'))", a.actor).fetchone()[0]
            status = cur.execute("SELECT status FROM bridge.runs WITH (UPDLOCK,HOLDLOCK) "
                                 "WHERE bridge_run_id=?", a.actor).fetchone()
            need(active == 0 and status is not None and status[0] == "READY",
                 "Bridge release requires a READY run with no running or indeterminate source operation")
        if a.action == "abandon":
            publishing = cur.execute("SELECT count(*) FROM bridge.runs WITH (UPDLOCK,HOLDLOCK) WHERE generation_id=? "
                                     "AND status='PUBLISHING'", a.generation).fetchone()[0]
            need(publishing == 0, "A run of this generation is PUBLISHING; finish or reconcile it first")
        cur.execute("EXEC bridge.transition_fence @source_set_id=?,@expected_state=?,@next_state=?,"
                    "@expected_version=?,@generation_id=?,@actor=?,@expiry_utc=?,@reason=?",
                    a.source_set, prior, nxt, row[4], a.generation, a.actor, expiry, a.reason)
        abandoned = 0
        if a.action == "abandon":
            cur.execute("UPDATE bridge.runs SET status='ABANDONED_GENERATION',orchestrator_token=NULL,"
                        "updated_utc=SYSUTCDATETIME() WHERE generation_id=? AND status IN "
                        "('CREATED','EXTRACTING','EXTRACTED','LOADING','READY','FAILED')", a.generation)
            abandoned = cur.rowcount
            cur.execute("UPDATE bridge.object_attempts SET status='ABANDONED_GENERATION',"
                        "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id IN "
                        "(SELECT bridge_run_id FROM bridge.runs WHERE generation_id=?) "
                        "AND status IN ('EXTRACTING','INDETERMINATE','EXTRACTED','LOADING','READY','FAILED','SUPERSEDED')",
                        a.generation)
            cur.execute("UPDATE ts SET publish_owner=NULL,publish_token=NULL,publish_claimed_utc=NULL,"
                        "publish_external_run_id=NULL,publish_operation_state='ABANDONED' "
                        "FROM bridge.target_state ts JOIN bridge.runs r ON r.bridge_run_id=ts.publish_owner "
                        "WHERE r.generation_id=? AND r.status='ABANDONED_GENERATION'", a.generation)
        conn.commit()
    print(json.dumps({"source_set": a.source_set, "generation": a.generation, "state": nxt,
                      **({"runs_abandoned": abandoned} if a.action == "abandon" else {})}))


if __name__ == "__main__":
    main()
