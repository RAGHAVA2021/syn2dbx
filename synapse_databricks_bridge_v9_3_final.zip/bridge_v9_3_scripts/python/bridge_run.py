"""Extract a closed Synapse generation (CETAS or ADF Copy) and load it into Delta.

Step 6 of the nightly flow (see SCRIPT_GUIDE.md). The Azure SQL, Synapse, ADF and
Databricks connections are separate identities. The run is resumable with
--resume: READY attempts are kept, EXTRACTED/LOADING attempts are reloaded
idempotently, and FAILED/interrupted extractions get a fresh attempt path.
Every control write is fenced by an orchestrator lease token so a superseded
process cannot change state after another process has taken the run over.
"""
import argparse
import hashlib
import json
import os
import re
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed, wait, FIRST_COMPLETED
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path


ID = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
KEY = re.compile(r"^[A-Za-z0-9_\-]{1,128}$")
RESERVED = {"release_id","mapping_object_id","source_generation_id","bridge_run_id",
            "upstream_run_id","upstream_sequence","business_date","load_attempt","group_contract_version"}
METADATA_COLUMNS = ("release_id","mapping_object_id","source_generation_id","bridge_run_id",
                    "upstream_run_id","upstream_sequence","business_date","load_attempt",
                    "group_contract_version")
STAGE_PREFIX = "bridge/parquet-stage"
MANIFEST_PREFIX = STAGE_PREFIX + "/_manifests"
MAX_MANIFEST_BYTES = 8 * 1024 * 1024
JOB_TIMEOUT_SECONDS = 7200          # Databricks job, ADF run and CETAS statement limit
CANCEL_WAIT_SECONDS = 900           # how long to wait for a cancelled run to become terminal
MIN_TAKEOVER_MINUTES = (JOB_TIMEOUT_SECONDS + CANCEL_WAIT_SECONDS + 59) // 60
RESUMABLE_EXTRACT_STATES = ("CREATED", "EXTRACTING", "EXTRACTED", "LOADING", "FAILED")
REQUIRED_PROPERTIES = ("delta.deletedFileRetentionDuration", "delta.logRetentionDuration",
                       "delta.setTransactionRetentionDuration")


class Indeterminate(RuntimeError):
    """An external operation may still be running; its outcome is unknown."""


class PhaseError(RuntimeError):
    def __init__(self, message, errors):
        super().__init__(message)
        self.errors = errors


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def ident(value):
    need(isinstance(value, str) and bool(ID.fullmatch(value)), f"Unsafe SQL identifier: {value!r}")
    return f"[{value}]"


def size_class(rows, columns, used_bytes, limits):
    if rows >= limits["large_rows"] or used_bytes >= limits["large_bytes"] or columns >= limits["large_columns"]:
        return "LARGE"
    if rows >= limits["medium_rows"] or used_bytes >= limits["medium_bytes"] or columns >= limits["medium_columns"]:
        return "MEDIUM"
    return "SMALL"


THRESHOLD_KEYS = ("medium_rows", "large_rows", "medium_bytes", "large_bytes", "medium_columns", "large_columns")


def valid_thresholds(t):
    return (all(type(t.get(k)) is int and t[k] > 0 for k in THRESHOLD_KEYS)
            and t["medium_rows"] < t["large_rows"] and t["medium_bytes"] < t["large_bytes"]
            and t["medium_columns"] < t["large_columns"])


def valid_target_type(value):
    if value in ("string", "boolean", "int", "bigint", "double", "date", "timestamp", "timestamp_ntz"):
        return True
    match = re.fullmatch(r"decimal\((\d{1,2}),(\d{1,2})\)", str(value))
    return bool(match and 1 <= int(match.group(1)) <= 38 and 0 <= int(match.group(2)) <= int(match.group(1)))


def staging_parts(root):
    match = re.fullmatch(r"abfss://([^@/]+)@([A-Za-z0-9]+)\.dfs\.core\.windows\.net", str(root).rstrip("/"))
    need(match, "staging_abfss_root must be the container-level ADLS URI")
    return match.groups()


def candidate_table_name(mapping_id, run_id, attempt):
    """Collision-free candidate name: '-' and '_' IDs never map to the same table."""
    digest = hashlib.sha256(f"{mapping_id}\x1f{run_id}".encode()).hexdigest()[:16]
    readable = re.sub(r"[^A-Za-z0-9_]", "_", mapping_id)[:80]
    return f"candidate_{readable}_{digest}_a{int(attempt)}"


def attempt_relative_path(business_date, run_id, mapping_id, attempt):
    return f"{STAGE_PREFIX}/{business_date}/{run_id}/{mapping_id}/attempt-{int(attempt):03d}/"


def delta_target(m, run_id, attempt):
    """Unquoted three-part name the loader writes; stored in object_attempts.delta_target."""
    if m["strategy"] == "REPLACE_TABLE":
        return f"{m['target_catalog']}.{m['candidate_schema']}.{candidate_table_name(m['mapping_id'], run_id, attempt)}"
    return f"{m['target_catalog']}.{m['physical_schema']}.{m['target_table']}_snapshots"


def target_key(m):
    if m["strategy"] == "RELEASE_POINTER":
        return "group:" + m["group_id"]
    return "table:" + ".".join(m[k] for k in ("target_catalog", "target_schema", "target_table"))


def config(path):
    doc = json.loads(Path(path).read_text())
    need(doc.get("inventory_version") and doc.get("source_set_id"), "Missing inventory/source set")
    for k in ("control_catalog", "control_schema"):
        ident(doc[k])
    mappings = doc.get("mappings")
    need(mappings, "At least one mapping is required")
    for name, default, low, high in (("max_extraction_workers", 4, 1, 32), ("max_loader_workers", 1, 1, 32),
                                     ("max_publisher_workers", 1, 1, 32), ("max_attempts", 3, 1, 9),
                                     ("takeover_after_minutes", 150, MIN_TAKEOVER_MINUTES, 1440),
                                     ("heartbeat_seconds", 60, 10, 600),
                                     ("minimum_fence_margin_minutes", 30, 0, 1440)):
        n = doc.get(name, default)
        need(type(n) is int and low <= n <= high, f"Invalid {name}: must be an integer {low}..{high}")
    need(doc.get("heartbeat_seconds", 60) * 3 <= doc.get("takeover_after_minutes", 150) * 60,
         "takeover_after_minutes must cover at least three missed heartbeats")
    class_limits = doc.get("extraction_class_limits", {"SMALL": 4, "MEDIUM": 2, "LARGE": 1})
    need(set(class_limits) == {"SMALL", "MEDIUM", "LARGE"} and
         all(type(x) is int and 1 <= x <= 32 for x in class_limits.values()),
         "Invalid extraction_class_limits")
    thresholds = doc.get("profile_thresholds", {})
    if thresholds:
        need(valid_thresholds(thresholds), "Invalid profile_thresholds")
    ids, targets, sources = set(), set(), set()
    for m in mappings:
        for k in ("mapping_id", "group_id"):
            need(isinstance(m.get(k), str) and bool(KEY.fullmatch(m[k])), f"Invalid {k}: {m.get(k)}")
        need(m["strategy"] in ("REPLACE_TABLE", "RELEASE_POINTER"), "Invalid strategy")
        need(m["method"] in ("CETAS", "COPY_ACTIVITY"), "Invalid route")
        need(type(m.get("mandatory")) is bool, f"mandatory must be true/false: {m['mapping_id']}")
        if "size_class" in m:
            need(m["size_class"] in class_limits, f"Unknown size_class: {m['mapping_id']}")
        if doc.get("require_profiles"):
            prof = m.get("source_profile", {})
            need(m.get("size_class") in class_limits and
                 prof.get("source_schema_version") == m["source_schema_version"] and
                 type(prof.get("estimated_rows")) is int and prof["estimated_rows"] >= 0 and
                 type(prof.get("physical_used_bytes")) is int and prof["physical_used_bytes"] >= 0 and
                 prof.get("mapped_column_count", prof.get("column_count")) == len(m["columns"]) and
                 type(prof.get("physical_column_count", prof.get("column_count"))) is int and
                 prof.get("physical_column_count", prof.get("column_count")) > 0 and
                 bool(prof.get("profiled_at_utc")),
                 f"Missing/stale profile: {m['mapping_id']}")
            need(bool(thresholds) and m["size_class"] == size_class(
                 prof["estimated_rows"], prof.get("physical_column_count", prof["column_count"]),
                 prof["physical_used_bytes"], thresholds),
                 f"Profile class differs from thresholds: {m['mapping_id']}")
        need(m["mandatory"] or m["strategy"] == "REPLACE_TABLE", "Optional pointer member")
        need(m.get("allow_empty") is False, "Empty-result publication requires a separate zero-row release manifest; not implemented here")
        need(m["mapping_id"] not in ids, "Duplicate mapping")
        ids.add(m["mapping_id"])
        src = (m["source_schema"].lower(), m["source_view"].lower())
        tgt = tuple(m[k].lower() for k in ("target_catalog", "target_schema", "target_table"))
        need(src not in sources and tgt not in targets, "Duplicate source or target")
        sources.add(src); targets.add(tgt)
        for k in ("source_schema", "source_view", "target_catalog", "target_schema", "target_table",
                  "candidate_schema", "physical_schema"):
            ident(m[k])
        need(("materialised_schema" in m) == ("materialised_table" in m),
             "materialised_schema and materialised_table must be given together")
        for k in ("materialised_schema", "materialised_table"):
            if k in m:
                ident(m[k])
        columns = m["columns"]
        need(columns and len({c["target"].lower() for c in columns}) == len(columns), "Duplicate/missing columns")
        need(not ({c["target"].lower() for c in columns} & RESERVED), "Target column clashes with bridge metadata")
        role = "consumer_properties" if m["strategy"] == "REPLACE_TABLE" else "physical_properties"
        props = m.get(role)
        need(isinstance(props, dict), f"Missing {role}: {m['mapping_id']}")
        for required in REQUIRED_PROPERTIES:
            need(required in props, f"Missing governed property: {required}")
        for k, v in props.items():
            need(isinstance(v, str) and "'" not in v and bool(re.fullmatch(r"[A-Za-z][A-Za-z0-9._]*", k)),
                 f"Delta property values must be quote-free strings exactly as Delta reports them: {k}")
        for c in columns:
            ident(c["source"]); ident(c["target"])
            need(c.get("conversion", "DIRECT") in ("DIRECT", "GUID_TEXT"), "Unsupported source conversion")
            need(valid_target_type(c["target_type"]), "Unsupported target type")
    groups = {}
    for m in mappings:
        groups.setdefault(m["group_id"], []).append(m)
    for group_id, members in groups.items():
        need(len({m["strategy"] for m in members}) == 1, f"Mixed publication strategies in a group: {group_id}")
        need(len({m["group_contract_version"] for m in members}) == 1, f"Mixed group-contract versions: {group_id}")
        if members[0]["strategy"] == "REPLACE_TABLE":
            # Sequential replacement of several tables is a mixed state the design forbids;
            # tables that must change together belong in a RELEASE_POINTER group.
            need(len(members) == 1, f"REPLACE_TABLE group must contain exactly one mapping: {group_id}")
    return doc


@contextmanager
def db(var, autocommit=False):
    """Open, yield and always close a connection. Nothing is committed implicitly."""
    import pyodbc
    # Supply complete ODBC connection strings through the named secret store at runtime.
    # Control and CETAS identities must differ. No connection strings are logged.
    conn = pyodbc.connect(os.environ[var], autocommit=autocommit, timeout=45)
    try:
        yield conn
    except BaseException:
        if not autocommit:
            try:
                conn.rollback()
            except Exception:
                pass
        raise
    finally:
        conn.close()


def fetchone(conn, sql, *params):
    return conn.cursor().execute(sql, *params).fetchone()


# Every orchestrator write carries this predicate: a process whose lease was taken
# over can no longer change run or attempt state.
OWNED = "EXISTS (SELECT 1 FROM bridge.runs r WHERE r.bridge_run_id=? AND r.orchestrator_token=?)"


def claim_run(conn, run_id, allowed, next_status, takeover_minutes):
    """Take the run lease. Succeeds when nobody holds it or its heartbeat is stale."""
    token = uuid.uuid4().hex
    marks = ",".join("?" * len(allowed))
    cur = conn.cursor()
    cur.execute("UPDATE bridge.runs SET status=?, orchestrator_token=?, heartbeat_utc=SYSUTCDATETIME(), "
                "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? "
                f"AND status IN ({marks}) AND (orchestrator_token IS NULL OR heartbeat_utc IS NULL "
                "OR heartbeat_utc < DATEADD(minute, -?, SYSUTCDATETIME()))",
                next_status, token, run_id, *allowed, takeover_minutes)
    need(cur.rowcount == 1, "Run cannot be claimed: wrong status, or another orchestrator holds a live lease "
                            f"(wait {takeover_minutes} minutes after its last heartbeat)")
    conn.commit()
    return token


def update_run(conn, run_id, token, prior, next_state, release_lease=False):
    cur = conn.cursor()
    cur.execute("UPDATE bridge.runs SET status=?, updated_utc=SYSUTCDATETIME(), "
                "orchestrator_token=CASE WHEN ?=1 THEN NULL ELSE orchestrator_token END "
                "WHERE bridge_run_id=? AND status=? AND orchestrator_token=?",
                next_state, 1 if release_lease else 0, run_id, prior, token)
    need(cur.rowcount == 1, f"Run state or lease changed concurrently: {prior} -> {next_state}")
    conn.commit()


def is_indeterminate(exc):
    if isinstance(exc, (Indeterminate, KeyboardInterrupt, SystemExit)):
        return True
    return any(is_indeterminate(e) for e in getattr(exc, "errors", []))


class RunLease:
    """Background heartbeat; `check()` stops new external work once the lease is lost."""

    def __init__(self, run_id, token, seconds):
        self.run_id, self.token, self.seconds = run_id, token, seconds
        self.lost = False
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._beat, daemon=True)

    def __enter__(self):
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        self._thread.join(timeout=60)

    def _beat(self):
        misses = 0
        while not self._stop.wait(self.seconds):
            try:
                with db("BRIDGE_CONTROL_ODBC") as conn:
                    cur = conn.cursor()
                    cur.execute("UPDATE bridge.runs SET heartbeat_utc=SYSUTCDATETIME() "
                                "WHERE bridge_run_id=? AND orchestrator_token=?", self.run_id, self.token)
                    owned = cur.rowcount == 1
                    conn.commit()
                if not owned:
                    self.lost = True
                    return
                misses = 0
            except Exception as exc:
                misses += 1
                print(f"WARNING heartbeat failed ({misses}/3): {exc}", file=sys.stderr)
                if misses >= 3:
                    self.lost = True
                    return

    def check(self):
        need(not self.lost, "Run lease lost (taken over or heartbeat failing); stopping new work")


def container_client(root):
    from azure.identity import DefaultAzureCredential
    from azure.storage.blob import BlobServiceClient
    container, account = staging_parts(root)
    service = BlobServiceClient(f"https://{account}.blob.core.windows.net", DefaultAzureCredential())
    return service.get_container_client(container)


def require_empty_adls(root, relative):
    found = next(iter(container_client(root).list_blobs(name_starts_with=relative)), None)
    need(found is None, f"Attempt prefix is not empty: {relative}")


def write_manifest(cfg, run_id, payload):
    """Store a job payload as an immutable, hash-checked file under the staging location.

    Notebook parameters are limited to ~10 KB; wide tables and pointer groups exceed that.
    """
    data = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True, default=str).encode("ascii")
    need(len(data) <= MAX_MANIFEST_BYTES, "Job manifest exceeds 8 MB")
    relative = f"{MANIFEST_PREFIX}/{run_id}/{uuid.uuid4().hex}.json"
    container_client(cfg["staging_abfss_root"]).upload_blob(relative, data, overwrite=False)
    return cfg["staging_abfss_root"].rstrip("/") + "/" + relative, hashlib.sha256(data).hexdigest()


TERMINAL_JOB_STATES = ("TERMINATED", "SKIPPED", "INTERNAL_ERROR")


def notebook_job(cfg, job_id, payload, run_id, started_callback=None, terminal_callback=None):
    from databricks.sdk import WorkspaceClient
    need(int(job_id) > 0, "Databricks job ID is not configured")
    path, digest = write_manifest(cfg, run_id, payload)
    client = WorkspaceClient()
    idempotency_token = "bridge_" + hashlib.sha256(
        json.dumps(payload, sort_keys=True, default=str).encode("utf-8")).hexdigest()[:48]
    if started_callback:
        started_callback("token:" + idempotency_token)
    try:
        started = client.jobs.run_now(job_id=int(job_id),
                                      notebook_params={"manifest_path": path, "manifest_sha256": digest},
                                      idempotency_token=idempotency_token)
    except Exception as exc:
        raise Indeterminate("Databricks submission outcome is unknown; inspect Jobs before recovery") from exc
    dbx_run = started.run_id
    if dbx_run is None:
        raise Indeterminate(f"Databricks accepted idempotency token {idempotency_token} but returned no run ID")
    try:
        if started_callback:
            started_callback(str(dbx_run))
    except Exception as exc:
        raise Indeterminate(f"Databricks run {dbx_run} started but its ID could not be persisted") from exc

    def terminal():
        run = client.jobs.get_run(run_id=dbx_run)
        state = run.state
        done = bool(state and state.life_cycle_state and state.life_cycle_state.value in TERMINAL_JOB_STATES)
        return done, run, state

    deadline = time.monotonic() + JOB_TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        try:
            done, run, state = terminal()
        except Exception as exc:
            raise Indeterminate(f"Databricks run {dbx_run} status is unknown after polling failed") from exc
        if done:
            if not (state.result_state and state.result_state.value == "SUCCESS"):
                if terminal_callback:
                    terminal_callback(str(dbx_run), "FAILED")
                raise RuntimeError(f"Job failed: {dbx_run}: {state}")
            task_id = run.tasks[0].run_id if run.tasks else dbx_run
            try:
                output = client.jobs.get_run_output(run_id=task_id)
                value = output.notebook_output.result if output.notebook_output else None
                need(value, f"No notebook output from {task_id}")
                result = json.loads(value)
                if terminal_callback:
                    terminal_callback(str(dbx_run), "SUCCEEDED")
                return result
            except Exception as exc:
                raise Indeterminate(f"Databricks run {dbx_run} terminated but its result is unknown") from exc
        time.sleep(10)
    # Cancel so the run cannot commit later while a resumed orchestrator acts.
    try:
        client.jobs.cancel_run(run_id=dbx_run)
    except Exception as exc:
        raise Indeterminate(f"Databricks run {dbx_run} timed out and cancellation was not submitted") from exc
    stop = time.monotonic() + CANCEL_WAIT_SECONDS
    while time.monotonic() < stop:
        try:
            stopped = terminal()[0]
        except Exception as exc:
            raise Indeterminate(f"Databricks run {dbx_run} cancellation outcome is unknown") from exc
        if stopped:
            if terminal_callback:
                terminal_callback(str(dbx_run), "CANCELLED")
            raise RuntimeError(f"Databricks run {dbx_run} timed out and was cancelled; it may have committed "
                               "before cancellation, which --resume reconciles")
        time.sleep(10)
    raise Indeterminate(f"Databricks run {dbx_run} timed out and did not stop after cancel; inspect it")


_ARM_CREDENTIAL = []


def arm_headers():
    # Fetch per request (the credential caches and refreshes): ARM tokens expire
    # well inside a two-hour poll, so a token taken once at start would fail with 401.
    if not _ARM_CREDENTIAL:
        from azure.identity import DefaultAzureCredential
        _ARM_CREDENTIAL.append(DefaultAzureCredential())
    token = _ARM_CREDENTIAL[0].get_token("https://management.azure.com/.default").token
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def copy_activity(doc, m, payload, started_callback=None, terminal_callback=None):
    import requests
    adf = doc["adf"]
    base = (f"https://management.azure.com/subscriptions/{adf['subscription_id']}"
            f"/resourceGroups/{adf['resource_group']}/providers/Microsoft.DataFactory"
            f"/factories/{adf['factory']}")
    url = f"{base}/pipelines/{adf['copy_pipeline']}/createRun?api-version=2018-06-01"
    p = {"mapping_id": m["mapping_id"], "bridge_run_id": payload["bridge_run_id"],
         "release_id": payload["release_id"], "generation_id": payload["generation_id"],
         "sourceSchema": m["source_schema"], "sourceView": m["source_view"],
         "projection": projection(m), "relativePath": payload["relative_path"]}
    correlation = f"correlation:{payload['bridge_run_id']}:{m['mapping_id']}:{payload.get('attempt', 0)}"
    if started_callback:
        started_callback(correlation)
    try:
        response = requests.post(url, json=p, headers=arm_headers(), timeout=60); response.raise_for_status()
    except Exception as exc:
        raise Indeterminate("ADF submission outcome is unknown; inspect pipeline runs before recovery") from exc
    try:
        activity_id = response.json()["runId"]
    except Exception as exc:
        raise Indeterminate(f"ADF submission {correlation} returned without a usable run ID") from exc
    try:
        if started_callback:
            started_callback(str(activity_id))
    except Exception as exc:
        raise Indeterminate(f"ADF run {activity_id} started but its ID could not be persisted") from exc

    def status():
        r = requests.get(f"{base}/pipelineruns/{activity_id}?api-version=2018-06-01",
                         headers=arm_headers(), timeout=60)
        r.raise_for_status()
        return r.json()["status"]

    deadline = time.monotonic() + JOB_TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        try:
            current = status()
        except Exception as exc:
            raise Indeterminate(f"ADF run {activity_id} status is unknown after polling failed") from exc
        if current in ("Succeeded", "Failed", "Cancelled"):
            if current != "Succeeded":
                if terminal_callback:
                    terminal_callback(str(activity_id), current.upper())
                raise RuntimeError(f"ADF run {activity_id} ended {current}")
            now = datetime.now(timezone.utc)
            window = {"lastUpdatedAfter": (now - timedelta(days=1)).isoformat(),
                      "lastUpdatedBefore": (now + timedelta(hours=1)).isoformat()}
            try:
                metrics = requests.post(f"{base}/pipelineruns/{activity_id}/queryActivityruns?api-version=2018-06-01",
                                        json=window, headers=arm_headers(), timeout=60)
                metrics.raise_for_status()
            except Exception as exc:
                raise Indeterminate(f"ADF run {activity_id} succeeded but metrics are unavailable") from exc
            activities = [a for a in metrics.json().get("value", [])
                          if a.get("activityName") == "CopyApprovedProjection"]
            need(len(activities) == 1 and activities[0]["status"] == "Succeeded", "Copy activity evidence missing")
            output = activities[0].get("output") or {}
            read, copied = output.get("rowsRead"), output.get("rowsCopied")
            # Missing metrics must fail: None == None is not evidence.
            need(type(read) is int and type(copied) is int, "ADF did not report integer rowsRead/rowsCopied")
            need(read == copied == int(payload["source_rows"]),
                 f"ADF rows read {read} / copied {copied} differ from audited {payload['source_rows']}")
            need(not output.get("rowsSkipped", 0), "ADF skipped rows")
            if terminal_callback:
                terminal_callback(str(activity_id), "SUCCEEDED")
            return activity_id
        time.sleep(10)
    try:
        requests.post(f"{base}/pipelineruns/{activity_id}/cancel?isRecursive=true&api-version=2018-06-01",
                      headers=arm_headers(), timeout=60).raise_for_status()
    except Exception as exc:
        raise Indeterminate(f"ADF run {activity_id} timed out and cancellation was not confirmed") from exc
    stop = time.monotonic() + CANCEL_WAIT_SECONDS
    while time.monotonic() < stop:
        try:
            stopped = status() in ("Succeeded", "Failed", "Cancelled")
        except Exception as exc:
            raise Indeterminate(f"ADF run {activity_id} cancellation outcome is unknown") from exc
        if stopped:
            if terminal_callback:
                terminal_callback(str(activity_id), "CANCELLED")
            raise RuntimeError(f"ADF run {activity_id} timed out and was cancelled")
        time.sleep(10)
    raise Indeterminate(f"ADF run {activity_id} did not stop after cancel; inspect before retrying")


def projection(m):
    result = []
    for c in m["columns"]:
        src = ident(c["source"])
        expr = f"CONVERT(varchar(36), {src})" if c.get("conversion") == "GUID_TEXT" else src
        result.append(f"{expr} AS {ident(c['target'])}")
    return ", ".join(result)


def cetas(m, relative_path, started_callback=None, terminal_callback=None):
    name = "x_" + uuid.uuid4().hex[:24]
    if started_callback:
        started_callback(name)
    source = f"{ident(m['source_schema'])}.{ident(m['source_view'])}"
    statement = (f"CREATE EXTERNAL TABLE bridge_meta.{ident(name)} WITH "
                 f"(LOCATION = '{relative_path}', DATA_SOURCE = bridge_stage, FILE_FORMAT = bridge_parquet) "
                 f"AS SELECT {projection(m)} FROM {source}")
    drop = f"IF OBJECT_ID(N'bridge_meta.{name}') IS NOT NULL DROP EXTERNAL TABLE bridge_meta.{ident(name)}"
    with db("BRIDGE_CETAS_ODBC", autocommit=True) as conn:
        conn.timeout = JOB_TIMEOUT_SECONDS

        def cleanup():
            # Dropping metadata never deletes the Parquet files. A cleanup failure is
            # reported but must never replace the original CETAS error.
            try:
                conn.cursor().execute(drop)
            except Exception as exc:
                print(f"WARNING CETAS metadata bridge_meta.{name} was not dropped: {exc}", file=sys.stderr)

        try:
            conn.cursor().execute(statement)
        except BaseException as exc:
            cleanup()
            raise Indeterminate(f"CETAS operation {name} outcome is unknown; inspect Synapse requests and ADLS") from exc
        cleanup()
    if terminal_callback:
        terminal_callback(name, "SUCCEEDED")
    return name


def fence(conn, doc, generation, run_id, margin_minutes=None):
    row = fetchone(conn, "SELECT state,generation_id,bridge_owner,expires_utc FROM bridge.source_fence WHERE source_set_id=?",
                   doc["source_set_id"])
    need(row and row[0] == "BRIDGE_HELD" and row[1] == generation and row[2] == run_id,
         "Source fence not held by this run/generation")
    need(row[3] is not None, "Fence expiry must be configured")
    margin = doc.get("minimum_fence_margin_minutes", 30) if margin_minutes is None else margin_minutes
    # Compared in the database, on database UTC, independent of driver datetime types.
    ok = fetchone(conn, "SELECT count(*) FROM bridge.source_fence WHERE source_set_id=? "
                        "AND expires_utc > DATEADD(minute, ?, SYSUTCDATETIME())", doc["source_set_id"], int(margin))
    need(ok and ok[0] == 1, "Insufficient source-fence time remaining")


def build_item(cfg, ctx, m, attempt):
    relative = attempt_relative_path(ctx["business_date"], ctx["run_id"], m["mapping_id"], attempt)
    return {**m, "bridge_run_id": ctx["run_id"], "release_id": ctx["release"],
            "generation_id": ctx["generation_id"], "upstream_run_id": ctx["upstream_run_id"],
            "upstream_sequence": ctx["sequence"], "business_date": ctx["business_date"],
            "source_rows": ctx["rows"][m["mapping_id"]],
            "leaf_path": cfg["staging_abfss_root"].rstrip("/") + "/" + relative,
            "relative_path": relative, "attempt": attempt, "delta_write_sequence": ctx["sequence"],
            "candidate_table": (candidate_table_name(m["mapping_id"], ctx["run_id"], attempt)
                                if m["strategy"] == "REPLACE_TABLE" else None),
            "inventory_version": cfg["inventory_version"],
            "control_catalog": cfg["control_catalog"], "control_schema": cfg["control_schema"]}


def extract_one(cfg, ctx, lease, m, attempt):
    lease.check()
    run_id, token, mid = ctx["run_id"], ctx["token"], m["mapping_id"]
    item = build_item(cfg, ctx, m, attempt)
    # Short-lived control connections: extraction can take hours.
    with db("BRIDGE_CONTROL_ODBC") as control:
        fence(control, cfg, ctx["generation_id"], run_id)
        require_empty_adls(cfg["staging_abfss_root"], item["relative_path"])
        cur = control.cursor()
        consumer_target = ".".join(m[k] for k in ("target_catalog", "target_schema", "target_table"))
        cur.execute("INSERT bridge.object_attempts(bridge_run_id,mapping_id,attempt,method,status,leaf_path,"
                    "source_rows,delta_target,target_key,publication_strategy,consumer_target,source_operation_state,"
                    "updated_utc) SELECT ?,?,?,?,'EXTRACTING',?,?,?,?,?,?,'PENDING',SYSUTCDATETIME() WHERE " + OWNED,
                    run_id, mid, attempt, m["method"], item["leaf_path"], item["source_rows"],
                    delta_target(m, run_id, attempt), target_key(m), m["strategy"], consumer_target, run_id, token)
        need(cur.rowcount == 1, "Run lease lost before extraction")
        control.commit()
    try:
        def source_started(external_id):
            with db("BRIDGE_CONTROL_ODBC") as control:
                cur = control.cursor()
                cur.execute("UPDATE bridge.object_attempts SET source_request_id=?,source_operation_state='RUNNING',"
                            "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND "
                            + OWNED, external_id, run_id, mid, attempt, run_id, token)
                need(cur.rowcount == 1, "Could not persist external source operation ID")
                control.commit()

        def source_terminal(external_id, state):
            with db("BRIDGE_CONTROL_ODBC") as control:
                cur = control.cursor()
                cur.execute("UPDATE bridge.object_attempts SET source_operation_state=?,updated_utc=SYSUTCDATETIME() "
                            "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND source_request_id=? AND " + OWNED,
                            state, run_id, mid, attempt, external_id, run_id, token)
                need(cur.rowcount == 1, "Could not persist terminal source operation state")
                control.commit()

        request_id = (cetas(m, item["relative_path"], source_started, source_terminal)
                      if m["method"] == "CETAS" else
                      copy_activity(cfg, m, item, source_started, source_terminal))
        with db("BRIDGE_CONTROL_ODBC") as control:
            # The fence must still be held (not expired, not abandoned) when the read
            # finishes; otherwise the files may include writes from another generation.
            fence(control, cfg, ctx["generation_id"], run_id, margin_minutes=0)
            cur = control.cursor()
            cur.execute("UPDATE bridge.object_attempts SET status='EXTRACTED',source_request_id=?,source_operation_state='SUCCEEDED',"
                        "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                        "AND status='EXTRACTING' AND " + OWNED,
                        request_id, run_id, mid, attempt, run_id, token)
            need(cur.rowcount == 1, "Extraction attempt or lease changed concurrently")
            control.commit()
    except BaseException as exc:
        unknown = is_indeterminate(exc)
        try:
            with db("BRIDGE_CONTROL_ODBC") as control:
                control.cursor().execute(
                    "UPDATE bridge.object_attempts SET status=?,source_operation_state=?,error_text=?,updated_utc=SYSUTCDATETIME() "
                    "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status='EXTRACTING' AND " + OWNED,
                    "INDETERMINATE" if unknown else "FAILED", "UNKNOWN" if unknown else "FAILED",
                    f"{type(exc).__name__}: {exc}"[:2000], run_id, mid, attempt, run_id, token)
                control.commit()
        except Exception as record_error:
            print(f"WARNING could not record failure for {mid}: {record_error}", file=sys.stderr)
        raise
    return item


def load_one(cfg, ctx, lease, item):
    lease.check()
    run_id, token, mid, attempt = ctx["run_id"], ctx["token"], item["mapping_id"], item["attempt"]
    with db("BRIDGE_CONTROL_ODBC") as control:
        cur = control.cursor()
        cur.execute("UPDATE bridge.object_attempts SET status='LOADING',updated_utc=SYSUTCDATETIME() "
                    "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status IN ('EXTRACTED','LOADING') AND "
                    + OWNED, run_id, mid, attempt, run_id, token)
        need(cur.rowcount == 1, f"Load state conflict: {mid}")
        control.commit()
    def loader_started(external_id):
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            cur.execute("UPDATE bridge.object_attempts SET loader_run_id=?,loader_operation_state='RUNNING',"
                        "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND "
                        + OWNED, external_id, run_id, mid, attempt, run_id, token)
            need(cur.rowcount == 1, "Could not persist Databricks loader run ID")
            control.commit()

    def loader_terminal(external_id, state):
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            cur.execute("UPDATE bridge.object_attempts SET loader_operation_state=?,updated_utc=SYSUTCDATETIME() "
                        "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND loader_run_id=? AND " + OWNED,
                        state, run_id, mid, attempt, external_id, run_id, token)
            need(cur.rowcount == 1, "Could not persist terminal loader state")
            control.commit()

    try:
        result = notebook_job(cfg, cfg["loader_job_id"], item, run_id, loader_started, loader_terminal)
    except BaseException as exc:
        unknown = is_indeterminate(exc)
        try:
            with db("BRIDGE_CONTROL_ODBC") as control:
                control.cursor().execute(
                    "UPDATE bridge.object_attempts SET status=?,loader_operation_state=?,error_text=?,"
                    "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                    "AND status='LOADING' AND " + OWNED,
                    "INDETERMINATE" if unknown else "EXTRACTED", "UNKNOWN" if unknown else "FAILED",
                    f"{type(exc).__name__}: {exc}"[:2000], run_id, mid, attempt, run_id, token)
                control.commit()
        except Exception as record_error:
            print(f"WARNING could not record loader failure for {mid}: {record_error}", file=sys.stderr)
        raise
    need(result["source_rows"] == result["parquet_rows"] == result["delta_rows"] == item["source_rows"],
         f"Three-way count mismatch: {mid}")
    expected_target = delta_target(item, run_id, attempt)
    need(result.get("target") == expected_target, f"Loader wrote {result.get('target')}, expected {expected_target}")
    with db("BRIDGE_CONTROL_ODBC") as control:
        cur = control.cursor()
        cur.execute("UPDATE bridge.object_attempts SET status='READY',parquet_rows=?,delta_rows=?,delta_target=?,"
                    "loader_operation_state='SUCCEEDED',"
                    "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                    "AND status='LOADING' AND " + OWNED,
                    result["parquet_rows"], result["delta_rows"], expected_target, run_id, mid, attempt, run_id, token)
        need(cur.rowcount == 1, f"Load state conflict: {mid}")
        control.commit()
    return result


LATEST_ATTEMPTS = ("SELECT a.mapping_id,a.attempt,a.status,a.leaf_path,a.source_rows,a.parquet_rows,a.delta_rows,"
                   "a.delta_target FROM bridge.object_attempts a WHERE a.bridge_run_id=? AND a.attempt="
                   "(SELECT MAX(b.attempt) FROM bridge.object_attempts b WHERE b.bridge_run_id=a.bridge_run_id "
                   "AND b.mapping_id=a.mapping_id)")


def run_extractions(cfg, ctx, lease, work):
    """Bounded, class-limited extraction; largest objects first."""
    workers = cfg.get("max_extraction_workers", 4)
    limits = cfg.get("extraction_class_limits", {"SMALL": 4, "MEDIUM": 2, "LARGE": 1})
    pending = sorted(work, key=lambda w: w[0].get("source_profile", {}).get("physical_used_bytes", 0), reverse=True)
    objects, errors, active = [], [], {}
    by_class = {k: 0 for k in limits}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        while pending or active:
            while len(active) < workers and not lease.lost:
                pos = next((i for i, (m, _) in enumerate(pending)
                            if by_class[m.get("size_class", "MEDIUM")] < limits[m.get("size_class", "MEDIUM")]), None)
                if pos is None:
                    break
                m, attempt = pending.pop(pos)
                cls = m.get("size_class", "MEDIUM")
                active[pool.submit(extract_one, cfg, ctx, lease, m, attempt)] = cls
                by_class[cls] += 1
            if not active:
                if lease.lost:
                    errors.append(RuntimeError("Run lease lost; unscheduled extractions skipped"))
                    break
                raise RuntimeError("No extraction capacity for pending mappings")
            completed, _ = wait(active, return_when=FIRST_COMPLETED)
            for future in completed:
                by_class[active.pop(future)] -= 1
                try:
                    objects.append(future.result())
                except BaseException as exc:
                    errors.append(exc)
    if errors:
        raise PhaseError(f"{len(errors)} extraction(s) failed; first: {errors[0]}", errors)
    return objects


def run_loads(cfg, ctx, lease, items):
    errors = []
    with ThreadPoolExecutor(max_workers=cfg.get("max_loader_workers", 1)) as pool:
        futures = [pool.submit(load_one, cfg, ctx, lease, item) for item in items]
        for future in as_completed(futures):
            try:
                future.result()
            except BaseException as exc:
                errors.append(exc)
    if errors:
        raise PhaseError(f"{len(errors)} load(s) failed; first: {errors[0]}", errors)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--upstream-run-id", required=True)
    parser.add_argument("--generation-id", required=True)
    parser.add_argument("--sequence", required=True, type=int)
    parser.add_argument("--business-date", required=True, type=date.fromisoformat)
    parser.add_argument("--bridge-run-id", required=True,
                        help="Approved BRIDGE_HELD owner. Reuse the same ID with --resume.")
    parser.add_argument("--resume", action="store_true",
                        help="Continue an existing FAILED run, or take over an interrupted one after its lease expires")
    args = parser.parse_args()
    cfg = config(args.config)
    staging_parts(cfg["staging_abfss_root"])
    need(bool(KEY.fullmatch(args.bridge_run_id)), "Unsafe bridge ID")
    run_id = args.bridge_run_id
    release = "rel_" + run_id
    ctx = {"run_id": run_id, "release": release, "generation_id": args.generation_id,
           "upstream_run_id": args.upstream_run_id, "sequence": args.sequence,
           "business_date": str(args.business_date), "rows": {}}
    by_id = {m["mapping_id"]: m for m in cfg["mappings"]}

    with db("BRIDGE_CONTROL_ODBC") as control:
        existing = fetchone(control, "SELECT upstream_run_id,generation_id,upstream_sequence,business_date,"
                                     "inventory_version,release_id,status FROM bridge.runs WHERE bridge_run_id=?", run_id)
        if args.resume:
            need(existing, "No run to resume")
            stored = (existing[0], existing[1], int(existing[2]), str(existing[3]), existing[4], existing[5])
            need(stored == (args.upstream_run_id, args.generation_id, args.sequence, ctx["business_date"],
                            cfg["inventory_version"], release), "Resume arguments/config differ from the stored run")
            need(existing[6] in RESUMABLE_EXTRACT_STATES,
                 f"Run status {existing[6]} is not resumable here (READY/PUBLISHING runs belong to publish_run.py)")
            latest = {r[0]: r for r in control.cursor().execute(LATEST_ATTEMPTS, run_id).fetchall()}
        else:
            need(not existing, "Run already exists: continue it with --resume, never rerun blindly")
            latest = {}
        need(set(latest) <= set(by_id), "Run has attempts for mappings outside this inventory")
        seeded = {r[0]: (r[1], bool(r[2]), r[3]) for r in control.cursor().execute(
            "SELECT mapping_id,group_id,mandatory,strategy FROM bridge.group_members "
            "WHERE inventory_version=? AND enabled=1", cfg["inventory_version"])}
        actual = {m["mapping_id"]: (m["group_id"], m["mandatory"], m["strategy"]) for m in cfg["mappings"]}
        need(actual == seeded, "Immutable enabled inventory does not match seeded control members")
        for m in cfg["mappings"]:
            key = target_key(m)
            state = fetchone(control, "SELECT high_water_sequence FROM bridge.target_state WHERE target_key=?", key)
            need(state and args.sequence > state[0], f"Missing/stale high-water state: {key}")

        # Plan: which mappings extract (and with which attempt) and which only reload.
        to_extract, to_load_attempts = [], []
        for m in cfg["mappings"]:
            row = latest.get(m["mapping_id"])
            if row is None:
                to_extract.append((m, 1))
            elif row[2] == "READY":
                continue
            elif row[2] in ("EXTRACTED", "LOADING"):
                to_load_attempts.append((m, row[1], row[3]))
            elif row[2] == "INDETERMINATE":
                raise RuntimeError(f"{m['mapping_id']} has an indeterminate external operation; verify the stored "
                                   "external run ID and resolve it with recovery.py before --resume")
            else:
                need(row[1] < cfg.get("max_attempts", 3), f"{m['mapping_id']} reached max_attempts ({row[1]})")
                to_extract.append((m, row[1] + 1))

        if to_extract:
            # Only a source read needs the fence; reloading retained Parquet does not.
            fence(control, cfg, args.generation_id, run_id)

    with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
        from source_metadata import schema_hash
        audit = fetchone(syn, "SELECT COUNT_BIG(*), MAX(upstream_sequence) FROM bridge_meta.upstream_run "
                         "WHERE upstream_run_id=? AND source_generation_id=? AND status='COMPLETE' AND write_closed=1",
                         args.upstream_run_id, args.generation_id)
        need(audit and audit[0] == 1 and audit[1] == args.sequence, "Upstream run missing/duplicate/unclosed")
        extracting = {m["mapping_id"] for m, _ in to_extract}
        for m in cfg["mappings"]:
            if m["mapping_id"] in extracting:
                need(schema_hash(syn, m["source_schema"], m["source_view"]) == m["source_schema_version"],
                     f"Current presentation schema drift: {m['mapping_id']}")
            r = fetchone(syn, "SELECT COUNT_BIG(*),MAX(row_count),MIN(row_count) FROM bridge_meta.upstream_object "
                         "WHERE upstream_run_id=? AND mapping_id=? AND status='COMPLETE' AND source_schema_version=?",
                         args.upstream_run_id, m["mapping_id"], m["source_schema_version"])
            need(r and r[0] == 1 and r[1] == r[2], f"Missing/duplicate source audit: {m['mapping_id']}")
            ctx["rows"][m["mapping_id"]] = int(r[1])

    takeover = cfg.get("takeover_after_minutes", 150)
    with db("BRIDGE_CONTROL_ODBC") as control:
        if args.resume:
            token = claim_run(control, run_id, RESUMABLE_EXTRACT_STATES, "EXTRACTING", takeover)
            ctx["token"] = token
            cur = control.cursor()
            for m, attempt in to_extract:
                if attempt > 1:
                    cur.execute("UPDATE bridge.object_attempts SET status='SUPERSEDED',updated_utc=SYSUTCDATETIME(),"
                                "error_text=COALESCE(error_text,'Interrupted; superseded on resume') "
                                "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status='EXTRACTING' AND "
                                + OWNED, run_id, m["mapping_id"], attempt - 1, run_id, token)
            control.commit()
        else:
            token = uuid.uuid4().hex
            ctx["token"] = token
            control.cursor().execute(
                "INSERT bridge.runs(bridge_run_id,upstream_run_id,generation_id,upstream_sequence,business_date,"
                "inventory_version,release_id,status,orchestrator_token,heartbeat_utc) "
                "VALUES (?,?,?,?,?,?,?,'EXTRACTING',?,SYSUTCDATETIME())", run_id, args.upstream_run_id,
                args.generation_id, args.sequence, args.business_date, cfg["inventory_version"], release, token)
            control.commit()

    for m, attempt, leaf in to_load_attempts:
        need(leaf == build_item(cfg, ctx, m, attempt)["leaf_path"], f"Stored leaf path differs: {m['mapping_id']}")

    try:
        with RunLease(run_id, token, cfg.get("heartbeat_seconds", 60)) as lease:
            items = [build_item(cfg, ctx, m, attempt) for m, attempt, _ in to_load_attempts]
            items += run_extractions(cfg, ctx, lease, to_extract)
            with db("BRIDGE_CONTROL_ODBC") as control:
                update_run(control, run_id, token, "EXTRACTING", "EXTRACTED")
                # The fence is not released here: detectors and the smoke check must pass first.
                update_run(control, run_id, token, "EXTRACTED", "LOADING")
            run_loads(cfg, ctx, lease, items)
            lease.check()
            with db("BRIDGE_CONTROL_ODBC") as control:
                rows = control.cursor().execute(LATEST_ATTEMPTS, run_id).fetchall()
                need(len(rows) == len(cfg["mappings"]) and all(r[2] == "READY" for r in rows),
                     "Not every mapping reached READY")
                update_run(control, run_id, token, "LOADING", "READY", release_lease=True)
        print(json.dumps({"bridge_run_id": run_id, "release_id": release, "status": "READY",
                          "next": "Release the fence with evidence, then run publish_run.py"}))
    except BaseException as exc:
        keep = is_indeterminate(exc)
        try:
            with db("BRIDGE_CONTROL_ODBC") as control:
                # Keep the lease if work may still be running, so a resume must wait for it to expire.
                control.cursor().execute(
                    "UPDATE bridge.runs SET status='FAILED',updated_utc=SYSUTCDATETIME(),"
                    "orchestrator_token=CASE WHEN ?=1 THEN orchestrator_token ELSE NULL END "
                    "WHERE bridge_run_id=? AND orchestrator_token=? "
                    "AND status IN ('CREATED','EXTRACTING','EXTRACTED','LOADING')", 1 if keep else 0, run_id, token)
                control.commit()
        except Exception as record_error:
            print(f"WARNING could not mark run FAILED: {record_error}", file=sys.stderr)
        raise


if __name__ == "__main__":
    main()
