"""Audited recovery for indeterminate attempts and abandoned publication claims.

This command never infers that an external operation stopped. An operator or an
independent monitor must inspect the stored external run ID and supply evidence.
"""
import argparse
import json
from pathlib import Path

from bridge_run import db, need


def evidence(path, required):
    doc = json.loads(Path(path).read_text())
    for field in required:
        need(doc.get(field) is True, f"Evidence must set {field}=true")
    need(isinstance(doc.get("evidence_uri"), str) and doc["evidence_uri"], "Evidence URI is required")
    return doc


def resolve_attempt(a):
    ev = evidence(a.evidence, ("external_terminal", "safe_to_retry"))
    need(ev.get("phase") in ("SOURCE", "LOADER"), "Evidence phase must be SOURCE or LOADER")
    with db("BRIDGE_CONTROL_ODBC") as conn:
        cur = conn.cursor()
        row = cur.execute(
            "SELECT a.status,a.source_request_id,a.loader_run_id,r.status FROM bridge.object_attempts a "
            "JOIN bridge.runs r ON r.bridge_run_id=a.bridge_run_id WHERE a.bridge_run_id=? AND a.mapping_id=? "
            "AND a.attempt=?", a.bridge_run_id, a.mapping_id, a.attempt).fetchone()
        need(row and row[0] == "INDETERMINATE" and row[3] == "FAILED", "Attempt/run is not awaiting recovery")
        external_id = row[1] if ev["phase"] == "SOURCE" else row[2]
        need(external_id and ev.get("external_run_id") == external_id, "Evidence external run ID differs")
        next_status = "FAILED" if ev["phase"] == "SOURCE" else "EXTRACTED"
        state_col = "source_operation_state" if ev["phase"] == "SOURCE" else "loader_operation_state"
        cur.execute(f"UPDATE bridge.object_attempts SET status=?,{state_col}='VERIFIED_TERMINAL',"
                    "error_text=?,updated_utc=SYSUTCDATETIME() "
                    "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status='INDETERMINATE'",
                    next_status, ("Recovered after terminal evidence: " + a.reason)[:2000],
                    a.bridge_run_id, a.mapping_id, a.attempt)
        need(cur.rowcount == 1, "Attempt changed concurrently")
        remaining = cur.execute("SELECT count(*) FROM bridge.object_attempts WHERE bridge_run_id=? "
                                "AND status='INDETERMINATE'", a.bridge_run_id).fetchone()[0]
        if remaining == 0:
            cur.execute("UPDATE bridge.runs SET orchestrator_token=NULL,updated_utc=SYSUTCDATETIME() "
                        "WHERE bridge_run_id=? AND status='FAILED'", a.bridge_run_id)
        cur.execute("INSERT bridge.recovery_events(action,bridge_run_id,mapping_id,attempt,external_run_id,actor,"
                    "evidence_uri,reason) VALUES ('RESOLVE_ATTEMPT',?,?,?,?,?,?,?)",
                    a.bridge_run_id, a.mapping_id, a.attempt, external_id, a.actor, ev["evidence_uri"], a.reason)
        conn.commit()


def abandon_publication(a):
    ev = evidence(a.evidence, ("external_terminal", "delta_state_verified", "safe_to_abandon"))
    with db("BRIDGE_CONTROL_ODBC") as conn:
        cur = conn.cursor()
        target = cur.execute("SELECT publish_owner,publish_external_run_id FROM bridge.target_state "
                             "WITH (UPDLOCK,HOLDLOCK) WHERE target_key=?", a.target_key).fetchone()
        run = cur.execute("SELECT status FROM bridge.runs WITH (UPDLOCK,HOLDLOCK) WHERE bridge_run_id=?",
                          a.bridge_run_id).fetchone()
        need(target and run and target[0] == a.bridge_run_id and run[0] == "PUBLISHING",
             "Run does not own an active publication claim")
        need(target[1] and ev.get("external_run_id") == target[1], "Evidence external run ID differs")
        cur.execute("UPDATE bridge.target_state SET publish_owner=NULL,publish_token=NULL,publish_claimed_utc=NULL,"
                    "publish_operation_state='ABANDONED' WHERE target_key=? AND publish_owner=?",
                    a.target_key, a.bridge_run_id)
        need(cur.rowcount == 1, "Publication claim changed concurrently")
        remaining = cur.execute("SELECT count(*) FROM bridge.target_state WHERE publish_owner=?",
                                a.bridge_run_id).fetchone()[0]
        if remaining == 0:
            cur.execute("UPDATE bridge.runs SET status='PUBLICATION_ABANDONED',orchestrator_token=NULL,"
                        "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND status='PUBLISHING'", a.bridge_run_id)
        cur.execute("INSERT bridge.recovery_events(action,bridge_run_id,target_key,external_run_id,actor,evidence_uri,"
                    "reason) VALUES ('ABANDON_PUBLICATION',?,?,?,?,?,?)", a.bridge_run_id, a.target_key,
                    target[1], a.actor, ev["evidence_uri"], a.reason)
        conn.commit()


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="action", required=True)
    attempt = sub.add_parser("resolve-attempt")
    attempt.add_argument("--bridge-run-id", required=True); attempt.add_argument("--mapping-id", required=True)
    attempt.add_argument("--attempt", required=True, type=int)
    publication = sub.add_parser("abandon-publication")
    publication.add_argument("--bridge-run-id", required=True); publication.add_argument("--target-key", required=True)
    for command in (attempt, publication):
        command.add_argument("--actor", required=True); command.add_argument("--evidence", required=True)
        command.add_argument("--reason", required=True)
    a = p.parse_args()
    need(len(a.reason) <= 1000, "Reason must be at most 1000 characters")
    resolve_attempt(a) if a.action == "resolve-attempt" else abandon_publication(a)
    print(json.dumps({"action": a.action, "bridge_run_id": a.bridge_run_id, "status": "RECORDED"}))


if __name__ == "__main__":
    main()
