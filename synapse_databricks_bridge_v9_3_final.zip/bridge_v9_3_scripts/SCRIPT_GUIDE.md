# Script guide: what each script does, in the order you use it

This package moves Synapse dedicated-pool materialised views into Unity Catalog Delta tables. The work falls into four phases, and every script belongs to exactly one of them:

1. **Build the inventory** (once per wave): decide what gets copied.
2. **Set up the platform** (once, plus once per wave): create control tables, storage objects and Databricks jobs.
3. **Nightly run**: freeze a source generation, extract it, load it, then publish it.
4. **Maintenance and recovery**: retention, resuming failed runs and abandoning bad generations.

Step numbers match the header comment at the top of each script. "Control host" means the orchestration machine that holds the ODBC connection strings in environment variables.

---

## Phase A: build the inventory

### Step 0a: `python/generate_mappings.py` (or `databricks/generate_mappings_pyspark.py`)

**Purpose:** discover every table or view in one Synapse schema and write a pinned mapping config (`config.json`) with one mapping per object.

Each mapping gets all of its columns in source order, supported type conversions and a schema hash, and it defaults to an independent `REPLACE_TABLE` publication via CETAS. If any column has a type that needs human review, the script writes nothing and lists the problem objects in `*.exceptions.json`. For `--source-kind table` it also records `materialised_schema`/`materialised_table`, which the profilers use.

- **Runs on:** the control host (ODBC, `BRIDGE_SYNAPSE_AUDIT_ODBC`) or a Databricks cluster (JDBC, writes to a UC volume).
- **Reads:** Synapse `sys.tables`/`sys.views`, `sys.columns` and `config.example.json` as a template.
- **Writes:** a new config file (never overwrites) plus an exceptions report.
- **Next:** review the config. Assign `RELEASE_POINTER` groups for tables that must change together. For views, add the reviewed `materialised_schema`/`materialised_table`.

### Step 0b: `python/profile_inventory.py` (or `databricks/profile_inventory_pyspark.py`)

**Purpose:** measure each materialised table's estimated rows, physical bytes and physical column count from Synapse DMVs, without scanning data. The profiled config separately records the mapped view-column count, so a view may select a subset of the materialised table. Physical measurements classify each mapping as SMALL, MEDIUM or LARGE.

- **Reads:** the reviewed config and dedicated-pool distribution and partition DMVs. For views it reads the `materialised_*` table.
- **Writes:** a **new inventory version** config with `size_class` and `source_profile`, plus a `.profile.csv` review report.
- **Optional:** without it, every mapping is scheduled as MEDIUM.

### Step 0c: `python/source_metadata.py`

**Purpose:** print the canonical schema hash of one source view (`--schema`, `--view`). Use it when you write or edit a mapping by hand and need its `source_schema_version`.

It is also the shared library that `upstream_audit.py` and `bridge_run.py` use to detect schema drift.

---

## Phase B: set up the platform

### Step 1: SQL setup scripts

| Script | Purpose |
|---|---|
| `sql/01_azure_sql_control.sql` | Creates the Azure SQL **control database** schema. It holds the source fence state machine, run records with the orchestrator lease, per-object attempts, group membership and per-target publication state, plus the `bridge.transition_fence` procedure. Run once for a new deployment, then seed one `bridge.source_fence` row. |
| `sql/03_upgrade_to_v9_3.sql` | Upgrades an **existing v9, v9.1 or v9.2** control database in place instead of running 01. Safe to rerun. From v9, publish any READY v9 run with the v9 scripts first. |
| `sql/02_synapse_setup.sql` | Creates the Synapse side: `bridge_meta` schema, managed-identity credential, ADLS external data source and Parquet file format (used by CETAS), and the `upstream_run`/`upstream_object` audit tables. Run once per dedicated pool. |

### Step 2: `python/render_setup.py`

**Purpose:** turn the config into two SQL files for the current inventory wave:

- `azure_sql_seed.sql` seeds group membership and initial per-target publication state.
- `unity_catalog_setup.sql` creates schemas, the pointer control table and its `NONE` rows, the physical `_snapshots` tables and the stable consumer views.

Every statement is idempotent. Rerun it for each wave; it never resets live state, and it stops if a seeded member differs from the config.

### Step 2b (optional): `python/deploy_adf.py` + `adf/*.json`

**Purpose:** deploy the ADF source dataset, Parquet sink dataset and Copy pipeline. You only need this for mappings with `"method": "COPY_ACTIVITY"`; CETAS mappings don't use ADF. The linked services must already exist.

### Step 2c: create the Databricks jobs

Import these notebooks and create one serverless single-task job for each. Each job has its own Run-as identity and takes the parameters `manifest_path` and `manifest_sha256`. Put the job IDs in `config.json`.

| Notebook | Job | Config key |
|---|---|---|
| `databricks/load_candidate.py` | Loader | `loader_job_id` |
| `databricks/publish.py` | Strategy A publisher (REPLACE_TABLE) | `publisher_job_id` |
| `databricks/publish.py` | Group-pointer publisher (RELEASE_POINTER) | `pointer_job_id` |
| `databricks/retire_releases.py` | Retention | `retention_job_id` |

`WHERE_TO_ENTER_VALUES.md` lists the exact grants.

---

## Phase C: the nightly run

The same generation ID flows from Synapse materialisation through to publication. `README.md` shows the full command sequence.

### Step 3: `python/fence.py write-start`

**Purpose:** the upstream writer claims the source fence (`AVAILABLE → WRITE_ACTIVE`) before any governed Synapse table changes. This is what guarantees the bridge later reads one complete, unchanging generation.

*Your existing Synapse transformation or materialisation job runs here.*

### Step 4: `python/upstream_audit.py`

**Purpose:** while the writer still holds the fence, record the authoritative facts for this generation:

- the row count and schema hash of each mapped view, in `bridge_meta.upstream_object`;
- one closed run record, in `bridge_meta.upstream_run`.

It refuses a duplicate run ID, a schema that drifted from the config, and a sequence number that isn't higher than the last one. These counts are what every later stage reconciles against.

### Step 5: `python/fence.py write-close`, then `python/fence.py bridge-hold`

**Purpose:**

- `write-close` ends the writer's ownership (`WRITE_ACTIVE → CLOSED`).
- `bridge-hold` hands the frozen generation to one bridge run (`CLOSED → BRIDGE_HELD`), after checking that the audit is complete for every mapping.

### Step 6: `python/bridge_run.py` (runs `databricks/load_candidate.py`)

**Purpose:** extract every mapping to Parquet and load it into Delta, with a three-way row-count check (audit = Parquet = Delta).

1. **Pre-checks:** fence ownership and time margin, closed upstream run, schema hashes, audited counts, seeded inventory, and the high-water mark per target.
2. **Extract:** CETAS or the ADF Copy writes to a fresh, empty `…/attempt-NNN/` path. Large objects start first, within the worker and class caps. The fence is **checked again after each read finishes** before the attempt is marked EXTRACTED.
3. **Load:** the loader job reads its hash-checked manifest and verifies Parquet column names, order and types. It then appends an idempotent Delta slice: to an attempt-specific candidate table for REPLACE_TABLE, or to the group's `_snapshots` table for RELEASE_POINTER.
4. The run ends `READY`. **It publishes nothing.**

The run holds an orchestrator lease with a heartbeat. After a failure, `--resume` continues the same run (see Step R1).

### Step 7: `python/fence.py bridge-release`

**Purpose:** return the source to writers (`BRIDGE_HELD → AVAILABLE`). It needs an evidence file from independent detectors: all source requests terminal, audit healthy, no fence violation, smoke check passed. It additionally requires the owning bridge run to be `READY` and refuses any running or indeterminate source operation.

### Step 8: `python/publish_run.py` (runs `databricks/publish.py`)

**Purpose:** make the READY release visible to consumers, but only once the recorded gate evidence (policy, restricted identity, consumer contract, fence) matches this run.

- **REPLACE_TABLE:** atomic `CREATE OR REPLACE TABLE` from the candidate, then a check of row count, release ID and governed properties.
- **RELEASE_POINTER:** checks every member slice, then flips the group's pointer row in one conditional Delta update, so the whole group changes together.

Before touching Delta, the run takes that target's **publication claim** in Azure SQL, so two runs can never change the same table or group at once. Azure SQL publication state is then advanced with a conditional update that also releases the claim. A target that already holds a newer release is reported as `superseded-by-newer` and left alone. The run ends `PUBLISHED`.

---

## Phase D: maintenance and recovery

### Step 9: `python/retire_releases.py` (runs `databricks/retire_releases.py`)

**Purpose:** stop storage from growing without limit.

- Deletes superseded release rows from `_snapshots` tables.
- Drops old candidate tables.
- With `--delete-staging`, deletes the exact recorded Parquet attempt paths.

It always keeps the published release, the previous release (for rollback) and any `--keep-release`. It never touches a release that could still be published, or a run that is publishing. It is a dry run unless you pass `--execute`, and the Databricks job re-reads the live pointer, so a stale plan can't delete a live release.
For pre-v9.3 attempts, provide every applicable versioned mapping file with repeatable `--inventory-config`; v9.3 attempts carry target/strategy metadata in the control row and remain discoverable after their mapping is removed from the current wave.

### Step R1: `python/bridge_run.py … --resume`

**Purpose:** continue a FAILED or crashed extraction/load run with the same arguments.

- READY mappings are kept.
- EXTRACTED/LOADING mappings are reloaded idempotently.
- Failed extractions get the next attempt path, up to `max_attempts`.

A run whose lease is still live can't be taken over until `takeover_after_minutes` after its last heartbeat.
The value must be at least 135 minutes, covering the two-hour job timeout and 15-minute cancellation window. An `INDETERMINATE` attempt is never superseded by takeover; resolve its stored external ID with `python/recovery.py resolve-attempt` first.

### Step R2: `python/publish_run.py … --resume`

**Purpose:** continue a run left in PUBLISHING. It first asks Databricks for each target's actual state (INSPECT mode):

- a commit whose Azure SQL update was lost is reconciled, not republished;
- a target is republished only if Delta still shows exactly the release Azure SQL records as published (or, before the first bridge publication, no bridge release at all);
- any other state, such as a foreign or partial release, stops that target for operator review.

### Step R3: `python/fence.py abandon` / `python/fence.py reopen`

**Purpose:** give up on an unusable generation, for example after source drift, fence expiry or exhausted attempts.

- `abandon` moves the fence to ABANDONED and marks that generation's unpublished runs `ABANDONED_GENERATION`. It is refused while a run is publishing.
- `reopen` returns the fence to AVAILABLE so the next generation can start at Step 3.

Both require `--reason`, which is stored in `bridge.fence_events`.

### Step R4: `python/recovery.py`

**Purpose:** make exceptional recovery explicit and auditable.

- `resolve-attempt` requires evidence that the stored source or loader operation is terminal before changing an `INDETERMINATE` attempt to a retryable state.
- `abandon-publication` requires evidence that the stored publisher operation is terminal, Delta was inspected and abandonment is safe before clearing the claim.
- Both write `bridge.recovery_events`; neither accepts an unmatched external run ID.

---

## Supporting files

| File | Purpose |
|---|---|
| `config.example.json` | Annotated example inventory: one REPLACE_TABLE mapping and a two-member RELEASE_POINTER group. |
| `requirements.txt` | Python dependencies for the control host. |
| `requirements-dev.txt` | Test-only dependencies. |
| `python/recovery.py` | Evidence-gated recovery for indeterminate attempts and publication claims. |
| `tests/test_contract.py` | Fail-closed config rules, naming, paths and ADF row-evidence checks. |
| `tests/test_static.py` | Checks that no script or notebook overwrites one of its own top-level functions, and that `PACKAGE_DIR` matches the package folder. |
| `tests/test_orchestration_sim.py` | Runs `bridge_run.py` and `publish_run.py` end to end against SQLite stand-ins with faked cloud calls. Covers failure, resume, lease takeover, fence expiry during a read and publication reconciliation, including refusal of an unexpected REPLACE_TABLE state on resume and two runs racing for the same table. |
| `README.md` | Deployment steps, nightly command sequence, recovery rules and version changes. |
| `WHERE_TO_ENTER_VALUES.md` | Every environment value, config field and grant. |
| `IMPLEMENTATION_STATUS.md` | What is implemented versus what still needs environment-specific work. |
| `DESIGN_v9.md` | The governing design. |

## How the pieces connect

```text
generate_mappings ─► profile_inventory ─► config.json (reviewed, versioned)
                                              │
sql/01 + sql/02 ─► render_setup ─► seeds + UC tables/views      deploy_adf (optional)
                                              │
nightly:  fence write-start ─► [Synapse transforms] ─► upstream_audit ─► fence write-close
          ─► fence bridge-hold ─► bridge_run ──(loader job)──► READY
          ─► fence bridge-release ─► publish_run ──(publisher / pointer job)──► PUBLISHED
periodic: retire_releases ──(retention job)
recovery: bridge_run --resume · publish_run --resume · fence abandon / reopen
```
