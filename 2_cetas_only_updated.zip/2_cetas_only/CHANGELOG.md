# Changelog — 2_cetas_only

## Package naming/documentation refresh

- Renamed the extracted top-level folder from the previous bridge folder name to `2_cetas_only`.
- Updated live workspace-path/documentation references to use `2_cetas_only`.
- Added `FIRST_READ_ME.md` and a `docs/` documentation set aligned with the companion package documentation style.
- Clarified throughout that this variant is **CETAS only** and has no Copy Activity/JDBC extraction fallback.
- Kept historical upgrade SQL filenames and v1.x regression-test names unchanged because they identify migration/test lineage.

## Implementation lineage

The underlying bridge implementation remains the v1.6 lineage described in `README.md`; this documentation change does not alter runtime logic.
