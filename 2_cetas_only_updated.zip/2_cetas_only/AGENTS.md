# Maintainer notes — 2_cetas_only

## Invariants

- This is the **CETAS-only** variant. Do not silently introduce JDBC or Copy Activity fallback behavior.
- Source refresh and CETAS extraction must never overlap.
- Source schema hash and audited row count are part of the run contract.
- A consumer table is published only from a validated private candidate.
- Publication is per table; `allow_partial_release=true` permits healthy mappings to publish while failed mappings remain on their previous release.
- Unknown external outcomes must be reconciled through `python/recovery.py`; do not convert unknown outcomes into ordinary failures without evidence.
- Keep secrets in environment variables/Databricks secret mechanisms, never in config files or logs.

## Package layout rule

Use `2_cetas_only` in live folder/workspace examples. Do not rename historical migration scripts only to make their version suffix match the package name.

## Before changing orchestration or state logic

Read `DESIGN.md`, `SCRIPT_GUIDE.md`, `docs/CODE_STRUCTURE.md`, and the regression tests. Run the full test suite after changes.
