"""Regressions for publication, audit, scheduling and recovery fixes."""
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
sys.path.insert(0, str(Path(__file__).resolve().parent))
import bridge_run  # noqa: E402
import publish_run  # noqa: E402
from test_orchestration_sim import env, calls  # noqa: E402,F401


def test_reconciliation_requires_properties_even_with_correct_release_and_rows():
    observed = {"exists": True, "release_ids": ["rel_BRG1"], "rows": 10,
                "consumer_properties": {"delta.logRetentionDuration": "interval 1 days"}}
    expected = {"delta.logRetentionDuration": "interval 7 days"}
    assert not publish_run.state_is_this_release(observed, "rel_BRG1", 10, expected)
    observed["consumer_properties"] = expected
    assert publish_run.state_is_this_release(observed, "rel_BRG1", 10, expected)
    del observed["consumer_properties"]
    assert not publish_run.state_is_this_release(observed, "rel_BRG1", 10, expected)


def test_resume_refuses_committed_release_with_property_drift(env, monkeypatch):
    env["extract"]()
    env["state"]["fail_after_publish"] = True
    with pytest.raises(bridge_run.PhaseError):
        env["publish"]()
    key, external_id = env["query"](
        "SELECT target_key,publish_external_run_id FROM bridge.target_state "
        "WHERE publish_operation_state IN ('RUNNING','UNKNOWN')")[0]
    env["recover"]("resolve-publication", evidence={"external_terminal": True,
                   "safe_to_resume": True, "orchestrator_stopped": True,
                   "external_run_id": external_id}, target_key=key)
    original = publish_run.notebook_job

    def inspect_with_drift(cfg, job_id, payload, run_id, *callbacks):
        result = original(cfg, job_id, payload, run_id, *callbacks)
        if payload.get("mode") == "INSPECT" and payload["mapping"]["target_table"] == key.rsplit(".", 1)[1]:
            result["consumer_properties"] = {**result["consumer_properties"],
                "delta.logRetentionDuration": "interval 1 days"}
        return result

    monkeypatch.setattr(publish_run, "notebook_job", inspect_with_drift)
    with pytest.raises(bridge_run.PhaseError, match="neither Azure SQL"):
        env["publish"]("BRG1", "--resume")
    assert env["query"]("SELECT published_release_id FROM bridge.target_state WHERE target_key=?", key) == [("NONE",)]


def test_reserved_audit_id_fails_before_source_counts(env, monkeypatch):
    env["query"]("INSERT INTO bridge.audit_reservations(upstream_run_id,upstream_sequence) VALUES ('SYN2', 2)")
    observed = []
    monkeypatch.setattr(bridge_run, "config", lambda path: observed.append("config") or
                        json.loads(env["cfg"].read_text()))
    with pytest.raises(RuntimeError, match="already exists as a reservation"):
        env["audit"]("SYN2", "2026-09-23")
    assert env["query"]("SELECT count(*) FROM bridge_meta.upstream_run", db="SYN") == [(1,)]


def test_strict_extraction_stops_scheduling_after_failure(env):
    env["set_config"](max_extraction_workers=1)
    env["state"]["fail_extract"].add("MAP_v_customer")
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    assert len(calls(env, "extract")) == 1


def test_strict_loader_stops_scheduling_after_failure(env):
    env["set_config"](max_loader_workers=1)
    env["state"]["loader_result"] = lambda r: {**r, "delta_rows": r["delta_rows"] - 1}
    with pytest.raises(bridge_run.PhaseError):
        env["extract"]()
    assert len(calls(env, "load")) == 1


def test_partial_release_with_no_ready_tables_fails(env):
    env["set_config"](allow_partial_release=True, max_extraction_workers=1)
    env["state"]["fail_extract"].update(("MAP_v_customer", "MAP_v_sales"))
    with pytest.raises(RuntimeError, match="No mappings reached READY"):
        env["extract"]()
    assert env["query"]("SELECT status FROM bridge.runs") == [("FAILED",)]


def test_candidate_name_bounds_and_property_escaping(env):
    d = json.loads(env["cfg"].read_text())
    d["mappings"][0]["candidate_schema"] = "x" * 480
    env["cfg"].write_text(json.dumps(d))
    with pytest.raises(RuntimeError, match="Unsafe SQL identifier"):
        bridge_run.config(env["cfg"])
    d["mappings"][0]["candidate_schema"] = "bridge_candidate"
    d["mappings"][0]["consumer_properties"]["delta.logRetentionDuration"] = "abc\\"
    env["cfg"].write_text(json.dumps(d))
    with pytest.raises(RuntimeError, match="backslashes"):
        bridge_run.config(env["cfg"])


def test_abandon_publishing_run_marks_unpublished_ready_attempts(env):
    env["extract"]()
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING',orchestrator_token=NULL")
    env["recover"]("abandon-publishing-run", evidence={"orchestrator_stopped": True,
                   "safe_to_abandon": True})
    assert env["query"]("SELECT DISTINCT status FROM bridge.object_attempts") == [("ABANDONED",)]
