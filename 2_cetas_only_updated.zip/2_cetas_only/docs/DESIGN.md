# Design — 2_cetas_only

The authoritative design is [`../DESIGN.md`](../DESIGN.md). This companion page exists so the `docs/` set has the same navigational shape as the related package.

The key design points are: static once-daily Synapse sources; no concurrent writers during extraction; full refresh per mapping; CETAS as the only extraction method; ADLS Parquet staging; validated private Delta candidates; atomic per-table publication; partial release when configured; explicit reconciliation for unknown external outcomes; and no JDBC/Copy fallback in this variant.
