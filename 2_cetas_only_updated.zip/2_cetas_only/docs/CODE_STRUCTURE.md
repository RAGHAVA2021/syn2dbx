# Code structure — 2_cetas_only

This document shows the runtime wiring. For file purpose see [`PACKAGE_GUIDE.md`](PACKAGE_GUIDE.md).

## 1. Runtime layers

```mermaid
flowchart TD
  O[Control host / scheduler] --> P[python/*.py orchestration]
  P --> A[(Azure SQL control)]
  P --> S[(Synapse dedicated pool)]
  P --> J[Databricks Jobs API]
  S -->|CETAS| D[(ADLS Gen2 Parquet)]
  J --> N[databricks/*.py notebooks]
  N --> D
  N --> U[(Unity Catalog Delta)]
```

The control host owns run sequencing and recovery decisions. Databricks notebooks perform candidate validation/loading, publication/inspection, and retention.

## 2. Nightly call sequence

```mermaid
sequenceDiagram
  participant SCH as Scheduler
  participant SYN as Synapse
  participant AUD as upstream_audit.py
  participant BR as bridge_run.py
  participant DB as Databricks loader
  participant PUB as publish_run.py
  participant DP as Databricks publisher
  SCH->>SYN: Daily source refresh
  SCH->>AUD: Audit refreshed sources
  AUD->>SYN: Row counts + schema hashes
  SCH->>BR: Start bridge run
  loop each mapping/attempt
    BR->>SYN: CETAS export
    SYN-->>BR: ADLS Parquet
    BR->>DB: Load/validate candidate
    DB-->>BR: Candidate result
  end
  SCH->>PUB: Publish READY mappings
  loop each READY mapping
    PUB->>DP: PUBLISH or INSPECT
    DP-->>PUB: Published/current state
  end
```

There is deliberately no JDBC/Copy fallback branch.

## 3. Setup relationship

`generate_mappings.py` or its PySpark alternative creates the mapping inventory. `profile_inventory.py` optionally adds sizing metadata. `render_setup.py` converts the reviewed config into idempotent Azure SQL seed and Unity Catalog setup SQL. The three Databricks operational jobs use the loader, publisher, and retention notebooks.

## 4. Recovery relationship

`bridge_run.py --resume` and `publish_run.py --resume` handle known safe resumptions. `recovery.py` is required when an external operation is `INDETERMINATE` or when an operator explicitly abandons an unrecoverable run/publication. Evidence is recorded in `bridge.recovery_events`.
