# Data dictionary — 2_cetas_only

This is an operator/developer glossary for the identifiers and datasets passed between package components.

| Term | Meaning | Created/owned by |
|---|---|---|
| `inventory_version` | Human-reviewed version of mapping inventory | Config |
| `mapping_id` | Stable identifier for one source → one consumer mapping | Config |
| `upstream_run_id` | Unique ID for one completed Synapse refresh | Scheduler / `upstream_audit.py` |
| `upstream_sequence` | Monotonically increasing refresh sequence | Audit process |
| `business_date` | Business date assigned to the audited source refresh | Audit process |
| `bridge_run_id` | Unique ID for one bridge execution; reused with `--resume` | Scheduler/operator |
| `release_id` | Derived release identity associated with the bridge run | Bridge logic |
| `attempt` / `load_attempt` | Per-mapping extraction/load attempt number | Bridge logic |
| `source_schema_version` | Hash of ordered source column metadata | Inventory/audit |
| `candidate table` | Private attempt-specific Delta table validated before publication | Loader notebook |
| `consumer table` | Stable table queried by business consumers | Publisher notebook |
| `staging_abfss_root` | ADLS Gen2 container root containing CETAS Parquet and manifests | Config |
| `consumer_properties` | Required Delta table properties checked/preserved at publication | Config / publisher |

## Metadata added to published data

The bridge reserves and adds these columns to published tables: `release_id`, `mapping_object_id`, `bridge_run_id`, `upstream_run_id`, `upstream_sequence`, `business_date`, and `load_attempt`. Source mappings must not use these names.

## Important control states

Common run/table states include `EXTRACTING`, `LOADING`, `READY`, `PUBLISHING`, `PUBLISHED`, `PARTIALLY_PUBLISHED`, `EXCLUDED`, `SUPERSEDED`, `ABANDONED`, `FAILED`, and `INDETERMINATE`. Exact state-transition rules are implemented in the orchestration scripts and covered by regression tests.
