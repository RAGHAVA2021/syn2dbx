# Runbook — 2_cetas_only

## 1. Normal nightly run

Run the source refresh, audit, bridge, and publication as one success-chained workflow with concurrency 1. Do not start CETAS reads until the source refresh has finished.

```bash
python python/upstream_audit.py --config config.json --upstream-run-id SYN_YYYYMMDD --business-date YYYY-MM-DD
python python/bridge_run.py --config config.json --upstream-run-id SYN_YYYYMMDD --bridge-run-id BRG_YYYYMMDD
python python/publish_run.py --config config.json --bridge-run-id BRG_YYYYMMDD
```

## 2. What to check after the run

Confirm the bridge/publisher output identifies which mappings are ready/published, excluded, superseded, abandoned, or failed. With partial release enabled, healthy mappings can publish while failed mappings remain on the prior consumer release.

## 3. CETAS failure

This package does **not** fall back to JDBC or Copy Activity. For a deterministic CETAS incompatibility, investigate the source object/type/content and either correct the mapping/source view or use a fallback-capable package. Do not repeatedly retry an unchanged deterministic failure.

## 4. Resume

Use the same IDs when resuming:

```bash
python python/bridge_run.py --config config.json --upstream-run-id SYN_YYYYMMDD --bridge-run-id BRG_YYYYMMDD --resume
python python/publish_run.py --config config.json --bridge-run-id BRG_YYYYMMDD --resume
```

A resume is not permission to guess an unknown external outcome. If the package reports an indeterminate operation, use `python/recovery.py` with operator evidence.

## 5. Recovery

Use `python/recovery.py --help` and the relevant subcommand to resolve an attempt/publication or abandon blocked work. Every recovery action is audit logged. Preserve external job/run evidence before acting.

## 6. Retention

Review the dry-run plan first, then execute if correct:

```bash
python python/retire_releases.py --config config.json
python python/retire_releases.py --config config.json --execute --delete-staging
```

## 7. Escalation checklist

Before changing code or control state, capture the bridge run ID, mapping ID, attempt number, upstream run ID/sequence, current control state, Databricks job run ID if any, CETAS error text, and whether the source refresh has remained unchanged since the audit.
