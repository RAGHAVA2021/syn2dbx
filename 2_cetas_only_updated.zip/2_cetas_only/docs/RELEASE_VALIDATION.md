# Release validation — 2_cetas_only

Use this checklist before promoting the package into a real environment.

## Package integrity

- Extracted root folder is `2_cetas_only/`.
- No live documentation or code path still references the previous package folder name.
- Full local test suite passes.
- `config.example.json` contains placeholders only; no credentials/secrets are packaged.

## Platform setup

- Azure SQL control schema is installed/upgraded to the expected version.
- Synapse CETAS external data source/file format and audit objects are installed.
- Synapse workspace managed identity can write the staging container.
- Databricks loader/publisher/retention jobs exist with reviewed Run-as identities and permissions.
- Workspace upload/path uses `2_cetas_only`.

## Functional acceptance

Test representative small/medium/large tables, an empty table, schema drift, row-count mismatch, interrupted loader/publication recovery, partial-release behavior, retention, and a CETAS-incompatible table. For the last case, verify the CETAS-only package fails visibly rather than silently switching extraction method.

## Scheduling acceptance

Prove the source refresh cannot overlap `bridge_run.py`: success dependencies plus workflow concurrency 1 (or an equivalent scheduler control).

## Go-live evidence

Record the reviewed config hash/version, test result, platform identities, grants, job IDs, staging path, rollback/retention settings, and operator runbook location.
