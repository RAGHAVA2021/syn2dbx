# Package guide — 2_cetas_only

This is the map of the package: what every folder is for, which files are setup-time vs nightly, and how the pieces connect. For design reasoning see [`DESIGN.md`](../DESIGN.md); for execution order see [`SCRIPT_GUIDE.md`](../SCRIPT_GUIDE.md).

## 1. Top-level files

| File | Purpose | When used |
|---|---|---|
| `FIRST_READ_ME.md` | Entry point and reading order | Before setup |
| `README.md` | Package overview, setup, nightly commands, recovery concepts | Setup / operations |
| `DESIGN.md` | Assumptions, non-overlap rule, guarantees, out-of-scope cases | Design / review |
| `SCRIPT_GUIDE.md` | Detailed I/S/N/M/R step order | Setup / operations |
| `WHERE_TO_ENTER_VALUES.md` | Config fields, environment variables, ADLS/UC/job settings | Configuration |
| `CHANGELOG.md` | Package naming/documentation changes and lineage | Release review |
| `AGENTS.md` | Maintainer invariants and change rules | Development |
| `config.example.json` | Example inventory and operational settings | Copy/generate into real config |
| `requirements.txt` | Runtime Python dependencies | Control host |
| `requirements-dev.txt` | Test/development dependencies | Development |

## 2. `python/` — control-plane orchestration

| File | Purpose | Main input | Main output/effect |
|---|---|---|---|
| `generate_mappings.py` | Discover source metadata and generate mappings | Synapse metadata + CLI args | New config JSON + exceptions |
| `profile_inventory.py` | Classify mapping size from Synapse DMVs | Reviewed config | New profiled config + CSV |
| `source_metadata.py` | Compute ordered source-schema hash | Source schema/object | Schema hash |
| `render_setup.py` | Render platform setup SQL from config | Config | Azure SQL seed + UC setup SQL |
| `upstream_audit.py` | Record nightly business date, sequence, row counts, schema hashes | Config + upstream run ID/date | Synapse audit + Azure SQL reservation |
| `bridge_run.py` | Orchestrate CETAS extraction and Databricks candidate loads | Audited refresh + config | ADLS Parquet + candidate tables + control state |
| `publish_run.py` | Atomically publish validated candidates to consumer tables | READY bridge run | Consumer table replacements + state |
| `retire_releases.py` | Plan/apply candidate and staging retention | Config + retained releases | Drop/delete plan or execution |
| `recovery.py` | Resolve unknown outcomes and abandon blocked work with evidence | Run/table IDs + evidence | Audited recovery state transitions |

## 3. `databricks/` — data-plane notebooks

| File | Purpose | Compute |
|---|---|---|
| `generate_mappings_pyspark.py` | Databricks alternative for source metadata discovery | Databricks compute with Synapse connectivity |
| `profile_inventory_pyspark.py` | Databricks alternative for DMV profiling | Classic/compatible compute with JDBC connectivity |
| `load_candidate.py` | Validate Parquet contract/count and write attempt-specific candidate Delta | Loader job |
| `publish.py` | Publish or inspect consumer state | Publisher job |
| `retire_releases.py` | Drop retired candidate tables safely | Retention job |

## 4. `sql/` — one-time and upgrade SQL

`01_azure_sql_control.sql` creates control-state objects. `02_synapse_setup.sql` creates Synapse metadata/audit and CETAS external objects. `03_...` through `06_...` are historical upgrade scripts for existing installations; their versioned filenames are intentionally retained.

## 5. `tests/`

The tests cover config/contract validation, orchestration simulation, historical regressions, recovery behavior, and static-source assumptions. Run them after any code or documentation-linked path change.

## 6. End-to-end relationship

```mermaid
flowchart TD
  CFG[config.json] --> AU[upstream_audit.py]
  CFG --> BR[bridge_run.py]
  CFG --> PU[publish_run.py]
  SYN[(Synapse dedicated pool)] --> AU
  AU --> CTL[(Azure SQL control + Synapse audit)]
  BR -->|CETAS only| ADLS[(ADLS Parquet staging)]
  ADLS --> LD[load_candidate.py]
  LD --> CAND[(UC candidate Delta)]
  CAND --> PUB[publish.py]
  PU --> PUB
  PUB --> CONS[(UC consumer Delta)]
  BR --> CTL
  PU --> CTL
  RET[retire_releases.py] --> CAND
  REC[recovery.py] --> CTL
```

## 7. Important limitation of this variant

If CETAS cannot export an object because of source type/content constraints, the table fails in this package. There is no automatic alternate extraction path. Use a reviewed source view/type conversion, or choose a fallback-capable companion package.
