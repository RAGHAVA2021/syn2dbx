# First read me — 2_cetas_only

`2_cetas_only` is the **CETAS-only** Synapse → ADLS Gen2 → Databricks full-refresh package. Use it when all mapped source objects are known to be exportable with CETAS. There is no automatic Copy Activity or JDBC fallback in this variant.

## Read in this order

1. [`docs/PACKAGE_GUIDE.md`](docs/PACKAGE_GUIDE.md) — folder/file purpose and how everything connects.
2. [`DESIGN.md`](DESIGN.md) — assumptions, guarantees, and the non-overlap scheduling rule.
3. [`WHERE_TO_ENTER_VALUES.md`](WHERE_TO_ENTER_VALUES.md) — values, identities, paths, jobs, and grants to configure.
4. [`SCRIPT_GUIDE.md`](SCRIPT_GUIDE.md) — setup, nightly, maintenance, and recovery execution order.
5. [`docs/RUNBOOK.md`](docs/RUNBOOK.md) — operator flow for normal nights and failures.
6. [`docs/RELEASE_VALIDATION.md`](docs/RELEASE_VALIDATION.md) — checks to complete before production.

## Core flow

```mermaid
flowchart LR
  R[Synapse refresh] --> A[upstream_audit.py]
  A --> C[bridge_run.py]
  C -->|CETAS| S[ADLS Parquet]
  S --> L[Databricks load_candidate.py]
  L --> D[Private candidate Delta]
  D --> P[publish_run.py]
  P --> U[Consumer Delta table]
```

The refresh and CETAS reads must never overlap. Healthy tables can advance independently when `allow_partial_release=true`; failed mappings remain on their previous published release.

## Package identity

The extracted top-level folder is `2_cetas_only/`. Workspace examples and PySpark helper defaults use that folder name. Historical SQL migration filenames retain their original version suffixes because those names describe database upgrade steps, not the package name.
