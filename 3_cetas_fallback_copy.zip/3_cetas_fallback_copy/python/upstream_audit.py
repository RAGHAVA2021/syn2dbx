"""Audit a completed nightly Synapse load before any bridge extraction begins.

This script records one authoritative view-result count per enabled mapping;
it cannot determine whether a view intentionally differs from its base table.
"""
import argparse
import sys
from datetime import date
from bridge_run import config, db, ident, need, require_inventory_contract
from source_metadata import schema_hash


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--config",required=True)
    p.add_argument("--upstream-run-id",required=True)
    p.add_argument("--generation-id",required=True)
    p.add_argument("--sequence",required=True,type=int)
    p.add_argument("--business-date",required=True,type=date.fromisoformat)
    a=p.parse_args(); d=config(a.config)
    with db("BRIDGE_CONTROL_ODBC") as control:
        require_inventory_contract(control,d)
    with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
        prior=syn.cursor().execute("SELECT count_big(*) FROM bridge_meta.upstream_run "
                                   "WHERE source_set_id=? AND upstream_run_id=?",
                                   d['source_set_id'],a.upstream_run_id).fetchone()[0]
        need(prior==0,"Upstream run audit already exists; recover it, never duplicate")
        # Sequences drive the publication high-water mark; a reused or lower sequence
        # would only be rejected much later, after a full extraction.
        latest=syn.cursor().execute("SELECT MAX(upstream_sequence) FROM bridge_meta.upstream_run "
                                    "WHERE source_set_id=?", d['source_set_id']).fetchone()[0]
        need(latest is None or a.sequence>int(latest),
             f"Sequence {a.sequence} must be greater than the latest recorded sequence {latest}")
    for m in d["mappings"]:
        with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
            prior_object = syn.cursor().execute(
                "SELECT COUNT_BIG(*) FROM bridge_meta.upstream_object "
                "WHERE source_set_id=? AND upstream_run_id=? AND mapping_id=?",
                d['source_set_id'], a.upstream_run_id, m["mapping_id"]).fetchone()[0]
        need(prior_object <= 1, f"Duplicate source audit: {m['mapping_id']}")
        if prior_object == 1:
            continue  # A stopped audit resumes without writing a duplicate object row.
        try:
            with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
                actual=schema_hash(syn,m["source_schema"],m["source_view"])
                if actual != m["source_schema_version"]:
                    n, status = -1, 'REJECTED'
                else:
                    query=f"SELECT count_big(*) FROM {ident(m['source_schema'])}.{ident(m['source_view'])}"
                    n=int(syn.cursor().execute(query).fetchone()[0])
                    status = 'COMPLETE' if n or m['allow_empty'] else 'REJECTED'
        except Exception as exc:
            actual, n, status = m["source_schema_version"], -1, 'REJECTED'
            print(f"WARNING source audit rejected {m['mapping_id']}: {exc}", file=sys.stderr)
        with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
            syn.cursor().execute("INSERT bridge_meta.upstream_object(source_set_id,upstream_run_id,mapping_id,"
                                 "source_schema_version,status,row_count,refresh_completed_utc) "
                                 "VALUES (?,?,?,?,?,?,SYSUTCDATETIME())",
                                 d['source_set_id'],a.upstream_run_id,m["mapping_id"],actual,status,n)
            syn.commit()
    with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
        syn.cursor().execute("INSERT bridge_meta.upstream_run(source_set_id,upstream_run_id,source_generation_id,"
                             "upstream_sequence,business_date,status,write_closed,completed_utc) "
                             "VALUES (?,?,?,?,?,'COMPLETE',1,SYSUTCDATETIME())",
                             d['source_set_id'],a.upstream_run_id,a.generation_id,a.sequence,a.business_date)
        syn.commit()
    print("Completed audit",a.upstream_run_id,len(d["mappings"]))


if __name__=="__main__":main()
