"""Extract a completed nightly Synapse generation (CETAS or Synapse Copy) and load it into Delta.

Step 2 of the static nightly flow (see README.md). The Azure SQL, Synapse pipeline and
Databricks connections are separate identities. The run is resumable with
--resume: READY attempts are kept, EXTRACTED/LOADING attempts are reloaded
idempotently, and FAILED/interrupted extractions get a fresh attempt path.
Every control write is fenced by an orchestrator lease token so a superseded
process cannot change state after another process has taken the run over.
"""
import argparse
import copy
import hashlib
import json
import os
import re
import sys
import threading
import time
import uuid
from concurrent.futures import ThreadPoolExecutor, as_completed, wait, FIRST_COMPLETED
from contextlib import contextmanager
from datetime import date, datetime, timedelta, timezone
from pathlib import Path


ID = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
KEY = re.compile(r"^[A-Za-z0-9_\-]{1,128}$")
BRIDGE_RUN_ID = re.compile(r"^[A-Za-z0-9_\-]{1,124}$")  # rel_ prefix must fit nvarchar(128)
RESERVED = {"release_id","mapping_object_id","source_generation_id","bridge_run_id",
            "upstream_run_id","upstream_sequence","business_date","load_attempt","group_contract_version"}
METADATA_COLUMNS = ("release_id","mapping_object_id","source_generation_id","bridge_run_id",
                    "upstream_run_id","upstream_sequence","business_date","load_attempt",
                    "group_contract_version")
STAGE_PREFIX = "bridge/parquet-stage"
MANIFEST_PREFIX = STAGE_PREFIX + "/_manifests"
MAX_MANIFEST_BYTES = 8 * 1024 * 1024
JOB_TIMEOUT_SECONDS = 7200          # Databricks job, Synapse pipeline run and CETAS statement limit
CANCEL_WAIT_SECONDS = 900           # how long to wait for a cancelled run to become terminal
MIN_TAKEOVER_MINUTES = (JOB_TIMEOUT_SECONDS + CANCEL_WAIT_SECONDS + 59) // 60
RESUMABLE_EXTRACT_STATES = ("CREATED", "EXTRACTING", "EXTRACTED", "LOADING", "FAILED", "READY")
REQUIRED_PROPERTIES = ("delta.deletedFileRetentionDuration", "delta.logRetentionDuration",
                       "delta.setTransactionRetentionDuration")


class Indeterminate(RuntimeError):
    """An external operation may still be running; its outcome is unknown."""


class CetasRejected(RuntimeError):
    """Synapse confirmed the CETAS statement is terminal and rejected."""


class LoaderRejected(RuntimeError):
    """The loader returned a deterministic data/contract error for immutable input."""


class CopyCountMismatch(RuntimeError):
    """A completed Copy disagrees with the immutable, audited source count."""


PERMANENT_LOADER_ERRORS = ("Parquet columns/order differ:", "Physical/logical type drift in ",
                           "Unapproved empty result", "Source-to-Parquet count:")


def permanent_loader_failure(message):
    return any(marker in str(message) for marker in PERMANENT_LOADER_ERRORS)


def copy_fallback_mapping(mapping):
    result = copy.deepcopy(mapping)
    result["method"] = "COPY_ACTIVITY"
    for column in result["columns"]:
        if column["source_spark_type"].lower() == "date":
            column["source_spark_type"] = "timestamp"
    return result


def mapped_route(mapping, stored_method, source_state=None):
    """Reconstruct the route after a restart from the recorded attempt, never from a guess."""
    copy_route = stored_method == "COPY_ACTIVITY" or (
        stored_method == "CETAS" and source_state == "CETAS_REJECTED" and
        mapping.get("fallback_method") == "COPY_ACTIVITY")
    need(stored_method in ("CETAS", "COPY_ACTIVITY") and
         (not copy_route or mapping["method"] == "COPY_ACTIVITY" or
          mapping.get("fallback_method") == "COPY_ACTIVITY"), "Stored extraction route differs from mapping")
    route = copy_fallback_mapping(mapping) if copy_route else mapping
    need(stored_method == route["method"] or source_state == "CETAS_REJECTED",
         "Stored extraction route differs from mapping")
    return route


class PhaseError(RuntimeError):
    def __init__(self, message, errors):
        super().__init__(message)
        self.errors = errors


def need(condition, message):
    if not condition:
        raise RuntimeError(message)


def ident(value):
    need(isinstance(value, str) and bool(ID.fullmatch(value)), f"Unsafe SQL identifier: {value!r}")
    return f"[{value}]"


def size_class(rows, columns, used_bytes, limits):
    if rows >= limits["large_rows"] or used_bytes >= limits["large_bytes"] or columns >= limits["large_columns"]:
        return "LARGE"
    if rows >= limits["medium_rows"] or used_bytes >= limits["medium_bytes"] or columns >= limits["medium_columns"]:
        return "MEDIUM"
    return "SMALL"


THRESHOLD_KEYS = ("medium_rows", "large_rows", "medium_bytes", "large_bytes", "medium_columns", "large_columns")


def valid_thresholds(t):
    return (all(type(t.get(k)) is int and t[k] > 0 for k in THRESHOLD_KEYS)
            and t["medium_rows"] < t["large_rows"] and t["medium_bytes"] < t["large_bytes"]
            and t["medium_columns"] < t["large_columns"])


def valid_target_type(value):
    if value in ("string", "boolean", "int", "bigint", "double", "date", "timestamp", "timestamp_ntz"):
        return True
    match = re.fullmatch(r"decimal\((\d{1,2}),(\d{1,2})\)", str(value))
    return bool(match and 1 <= int(match.group(1)) <= 38 and 0 <= int(match.group(2)) <= int(match.group(1)))


def staging_parts(root):
    match = re.fullmatch(r"abfss://([^@/]+)@([A-Za-z0-9]+)\.dfs\.core\.windows\.net", str(root).rstrip("/"))
    need(match, "staging_abfss_root must be the container-level ADLS URI")
    return match.groups()


def candidate_table_name(mapping_id, run_id, attempt):
    """Collision-free candidate name: '-' and '_' IDs never map to the same table."""
    digest = hashlib.sha256(f"{mapping_id}\x1f{run_id}".encode()).hexdigest()[:16]
    readable = re.sub(r"[^A-Za-z0-9_]", "_", mapping_id)[:80]
    return f"candidate_{readable}_{digest}_a{int(attempt)}"


def attempt_relative_path(business_date, run_id, mapping_id, attempt):
    return f"{STAGE_PREFIX}/{business_date}/{run_id}/{mapping_id}/attempt-{int(attempt):03d}/"


def delta_target(m, run_id, attempt):
    """Unquoted three-part name the loader writes; stored in object_attempts.delta_target."""
    return f"{m['target_catalog']}.{m['candidate_schema']}.{candidate_table_name(m['mapping_id'], run_id, attempt)}"


def target_key(m):
    return "table:" + ".".join(m[k] for k in ("target_catalog", "target_schema", "target_table"))


def contract_sha256(doc):
    """Pin source, routes, business columns and targets; exclude scheduling estimates."""
    mappings = [{k: v for k, v in m.items() if k not in ("size_class", "source_profile")}
                for m in doc["mappings"]]
    contract = {k: doc[k] for k in ("inventory_version", "source_set_id", "staging_abfss_root",
                                  "control_catalog", "control_schema")}
    contract["mappings"] = sorted(mappings, key=lambda m: m["mapping_id"])
    contract["synapse_pipeline"] = doc.get("synapse_pipeline")
    return hashlib.sha256(json.dumps(contract, sort_keys=True, separators=(",", ":"),
                                     ensure_ascii=True).encode("ascii")).hexdigest()


def require_inventory_contract(conn, doc):
    digest = contract_sha256(doc)
    row = fetchone(conn, "SELECT contract_sha256 FROM bridge.inventory_contracts WHERE inventory_version=?",
                   doc["inventory_version"])
    need(row and row[0] == digest, "Inventory contract changed: review and seed a NEW inventory_version")
    return digest


def config(path):
    doc = json.loads(Path(path).read_text())
    need(doc.get("inventory_version") and doc.get("source_set_id"), "Missing inventory/source set")
    need(isinstance(doc["source_set_id"], str) and 0 < len(doc["source_set_id"].strip()) and
         len(doc["source_set_id"]) <= 128 and doc["source_set_id"] == doc["source_set_id"].strip(),
         "source_set_id must be a string of 1..128 characters without surrounding spaces")
    for k in ("control_catalog", "control_schema"):
        need(k in doc, f"Missing {k}")
        ident(doc[k])
    mappings = doc.get("mappings")
    need(mappings, "At least one mapping is required")
    if any(m.get("method") == "COPY_ACTIVITY" or m.get("fallback_method") == "COPY_ACTIVITY" for m in mappings):
        syn = doc.get("synapse_pipeline")
        need(isinstance(syn, dict), "COPY_ACTIVITY requires synapse_pipeline configuration")
        need(isinstance(syn.get("workspace_name"), str) and syn["workspace_name"].strip(),
             "synapse_pipeline.workspace_name is required")
        need(isinstance(syn.get("copy_pipeline"), str) and syn["copy_pipeline"].strip(),
             "synapse_pipeline.copy_pipeline is required")
        for linked in ("synapse_linked_service", "adls_linked_service"):
            need(isinstance(syn.get(linked), str) and syn[linked].strip(),
                 f"synapse_pipeline.{linked} is required for Copy fallback")
        if syn.get("endpoint") is not None:
            need(isinstance(syn["endpoint"], str) and syn["endpoint"].startswith("https://") and
                 syn["endpoint"].rstrip("/").endswith(".dev.azuresynapse.net"),
                 "synapse_pipeline.endpoint must be an https://<workspace>.dev.azuresynapse.net endpoint")
    for name, default, low, high in (("max_extraction_workers", 4, 1, 32), ("max_loader_workers", 8, 1, 32),
                                     ("max_publisher_workers", 8, 1, 32), ("max_attempts", 3, 1, 9),
                                     ("takeover_after_minutes", 150, MIN_TAKEOVER_MINUTES, 1440),
                                     ("heartbeat_seconds", 60, 10, 600),
                                     ("retention_days_published", 7, 0, 3650),
                                     ("retention_days_unpublished", 30, 0, 3650)):
        n = doc.get(name, default)
        need(type(n) is int and low <= n <= high, f"Invalid {name}: must be an integer {low}..{high}")
    need(doc.get("heartbeat_seconds", 60) * 3 <= doc.get("takeover_after_minutes", 150) * 60,
         "takeover_after_minutes must cover at least three missed heartbeats")
    class_limits = doc.get("extraction_class_limits", {"SMALL": 4, "MEDIUM": 2, "LARGE": 1})
    need(set(class_limits) == {"SMALL", "MEDIUM", "LARGE"} and
         all(type(x) is int and 1 <= x <= 32 for x in class_limits.values()),
         "Invalid extraction_class_limits")
    thresholds = doc.get("profile_thresholds", {})
    if thresholds:
        need(valid_thresholds(thresholds), "Invalid profile_thresholds")
    ids, targets, sources = set(), set(), set()
    # Every Unity Catalog object this inventory creates, by lower-case three-part name. A consumer
    # table or view must never share a name with another mapping's snapshot table (or the control
    # table): one would be written into, or read through, the other.
    objects = {(doc["control_catalog"].lower(), doc["control_schema"].lower(), "published_targets"):
               "the publication pointer table"}
    candidate_schemas = set()

    def claim(name, owner):
        clash = objects.get(name)
        if clash is not None:
            both_snapshots = "snapshot table" in clash and "snapshot table" in owner
            raise RuntimeError(("Snapshot table shared by more than one mapping" if both_snapshots else
                                "Unity Catalog name collision") + f": {'.'.join(name)} is {clash} and {owner}")
        objects[name] = owner
    for m in mappings:
        for k in ("mapping_id", "group_id"):
            need(isinstance(m.get(k), str) and bool(KEY.fullmatch(m[k])), f"Invalid {k}: {m.get(k)}")
        for k in ("source_schema_version", "group_contract_version"):
            need(isinstance(m.get(k), str) and 0 < len(m[k]) <= 128,
                 f"Missing/invalid {k}: {m['mapping_id']}")
        need(m["strategy"] == "REPLACE_TABLE", "Static bridge supports one independent table per group")
        need(m["method"] in ("CETAS", "COPY_ACTIVITY"), "Invalid route")
        need(m.get("fallback_method") in (None, "COPY_ACTIVITY"), "Invalid fallback route")
        need(m.get("fallback_method") is None or m["method"] == "CETAS",
             "Copy fallback requires a CETAS primary route")
        need(m.get("fallback_method") is None or doc.get("max_attempts", 3) >= 2,
             "Copy fallback requires at least two attempts")
        need(type(m.get("mandatory")) is bool, f"mandatory must be true/false: {m['mapping_id']}")
        if "size_class" in m:
            need(m["size_class"] in class_limits, f"Unknown size_class: {m['mapping_id']}")
        if doc.get("require_profiles"):
            prof = m.get("source_profile", {})
            need(m.get("size_class") in class_limits and
                 prof.get("source_schema_version") == m["source_schema_version"] and
                 type(prof.get("estimated_rows")) is int and prof["estimated_rows"] >= 0 and
                 type(prof.get("physical_used_bytes")) is int and prof["physical_used_bytes"] >= 0 and
                 prof.get("mapped_column_count", prof.get("column_count")) == len(m["columns"]) and
                 type(prof.get("physical_column_count", prof.get("column_count"))) is int and
                 prof.get("physical_column_count", prof.get("column_count")) > 0 and
                 bool(prof.get("profiled_at_utc")),
                 f"Missing/stale profile: {m['mapping_id']}")
            need(bool(thresholds) and m["size_class"] == size_class(
                 prof["estimated_rows"], prof.get("physical_column_count", prof.get("column_count")),
                 prof["physical_used_bytes"], thresholds),
                 f"Profile class differs from thresholds: {m['mapping_id']}")
        need(type(m.get("allow_empty")) is bool, f"allow_empty must be true/false: {m['mapping_id']}")
        need(m["mapping_id"] not in ids, "Duplicate mapping")
        ids.add(m["mapping_id"])
        src = (m["source_schema"].lower(), m["source_view"].lower())
        tgt = tuple(m[k].lower() for k in ("target_catalog", "target_schema", "target_table"))
        need(src not in sources and tgt not in targets, "Duplicate source or target")
        sources.add(src); targets.add(tgt)
        claim(tgt, f"the consumer view of {m['mapping_id']}")
        for k in ("candidate_schema", "physical_schema"):
            need(k in m, f"Missing {k}: {m['mapping_id']}")
        claim((m["target_catalog"].lower(), m["physical_schema"].lower(),
               m["target_table"].lower() + "_snapshots"), f"the physical table of {m['mapping_id']}")
        candidate_schemas.add((m["target_catalog"].lower(), m["candidate_schema"].lower()))
        for k in ("source_schema", "source_view", "target_catalog", "target_schema", "target_table",
                  "candidate_schema", "physical_schema"):
            ident(m[k])
        need(("materialised_schema" in m) == ("materialised_table" in m),
             "materialised_schema and materialised_table must be given together")
        for k in ("materialised_schema", "materialised_table"):
            if k in m:
                ident(m[k])
        columns = m["columns"]
        need(columns and len({c["target"].lower() for c in columns}) == len(columns), "Duplicate/missing columns")
        need(not ({c["target"].lower() for c in columns} & RESERVED), "Target column clashes with bridge metadata")
        role = "consumer_properties"
        props = m.get(role)
        need(isinstance(props, dict), f"Missing {role}: {m['mapping_id']}")
        for required in REQUIRED_PROPERTIES:
            need(required in props, f"Missing governed property: {required}")
        for k, v in props.items():
            need(isinstance(v, str) and "'" not in v and bool(re.fullmatch(r"[A-Za-z][A-Za-z0-9._]*", k)),
                 f"Delta property values must be quote-free strings exactly as Delta reports them: {k}")
        for c in columns:
            ident(c["source"]); ident(c["target"])
            need(isinstance(c.get("source_spark_type"), str) and c["source_spark_type"].strip(),
                 f"Missing source_spark_type: {m['mapping_id']}.{c.get('target', '?')}")
            need(valid_target_type(c["source_spark_type"]),
                 f"Unsupported physical Spark type: {m['mapping_id']}.{c['target']}")
            need(c.get("conversion", "DIRECT") in ("DIRECT", "GUID_TEXT"), "Unsupported source conversion")
            need(valid_target_type(c["target_type"]), "Unsupported target type")
            if m["method"] == "COPY_ACTIVITY":
                # Synapse Copy maps SQL date/datetime/datetime2/smalldatetime to the interim type DateTime,
                # which the Parquet sink writes as INT96: Spark reads it as timestamp, never as date.
                need(c["source_spark_type"].strip().lower() != "date",
                     f"COPY_ACTIVITY writes SQL date as Parquet INT96 (Spark timestamp): set source_spark_type "
                     f"to timestamp for {m['mapping_id']}.{c['target']} (generate_mappings.for_copy_activity does this)")
    groups = {}
    for m in mappings:
        groups.setdefault(m["group_id"], []).append(m)
    for group_id, members in groups.items():
        need(len(members) == 1, f"Each independent table needs its own group_id: {group_id}")
    for name, owner in objects.items():
        # REPLACE_TABLE candidates are generated as candidate_<mapping>_<digest>_a<n> in candidate_schema.
        need(not (name[:2] in candidate_schemas and name[2].startswith("candidate_")),
             f"{'.'.join(name)} ({owner}) uses the name space reserved for generated candidate tables")
    return doc


@contextmanager
def db(var, autocommit=False):
    """Open, yield and always close a connection. Nothing is committed implicitly."""
    import pyodbc
    # Supply complete ODBC connection strings through the named secret store at runtime.
    # Control and CETAS identities must differ. No connection strings are logged.
    conn = pyodbc.connect(os.environ[var], autocommit=autocommit, timeout=45)
    try:
        yield conn
    except BaseException:
        if not autocommit:
            try:
                conn.rollback()
            except Exception:
                pass
        raise
    finally:
        conn.close()


def fetchone(conn, sql, *params):
    return conn.cursor().execute(sql, *params).fetchone()


# Every orchestrator write carries this predicate: a process whose lease was taken
# over can no longer change run or attempt state.
OWNED = "EXISTS (SELECT 1 FROM bridge.runs r WHERE r.bridge_run_id=? AND r.orchestrator_token=?)"


def claim_run(conn, run_id, allowed, next_status, takeover_minutes):
    """Take the run lease. Succeeds when nobody holds it or its heartbeat is stale."""
    token = uuid.uuid4().hex
    marks = ",".join("?" * len(allowed))
    cur = conn.cursor()
    cur.execute("UPDATE bridge.runs SET status=?, orchestrator_token=?, heartbeat_utc=SYSUTCDATETIME(), "
                "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? "
                f"AND status IN ({marks}) AND (orchestrator_token IS NULL OR heartbeat_utc IS NULL "
                "OR heartbeat_utc < DATEADD(minute, -?, SYSUTCDATETIME()))",
                next_status, token, run_id, *allowed, takeover_minutes)
    need(cur.rowcount == 1, "Run cannot be claimed: wrong status, or another orchestrator holds a live lease "
                            f"(wait {takeover_minutes} minutes after its last heartbeat)")
    conn.commit()
    return token


def update_run(conn, run_id, token, prior, next_state, release_lease=False):
    cur = conn.cursor()
    cur.execute("UPDATE bridge.runs SET status=?, updated_utc=SYSUTCDATETIME(), "
                "orchestrator_token=CASE WHEN ?=1 THEN NULL ELSE orchestrator_token END "
                "WHERE bridge_run_id=? AND status=? AND orchestrator_token=?",
                next_state, 1 if release_lease else 0, run_id, prior, token)
    need(cur.rowcount == 1, f"Run state or lease changed concurrently: {prior} -> {next_state}")
    conn.commit()


def is_indeterminate(exc):
    if isinstance(exc, (Indeterminate, KeyboardInterrupt, SystemExit)):
        return True
    return any(is_indeterminate(e) for e in getattr(exc, "errors", []))


class RunLease:
    """Background heartbeat; `check()` stops new external work once the lease is lost."""

    def __init__(self, run_id, token, seconds, takeover_minutes=150):
        self.run_id, self.token, self.seconds = run_id, token, seconds
        self.takeover_minutes = takeover_minutes
        self.last_success = time.monotonic()
        self.lost = False
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._beat, daemon=True)

    def __enter__(self):
        with db("BRIDGE_CONTROL_ODBC") as conn:
            cur = conn.cursor()
            cur.execute("UPDATE bridge.runs SET heartbeat_utc=SYSUTCDATETIME() "
                        "WHERE bridge_run_id=? AND orchestrator_token=?", self.run_id, self.token)
            need(cur.rowcount == 1, "Run lease lost before work started")
            conn.commit()
        self.last_success = time.monotonic()
        self._thread.start()
        return self

    def __exit__(self, *exc):
        self._stop.set()
        self._thread.join(timeout=60)

    def _beat(self):
        misses = 0
        while not self._stop.wait(self.seconds):
            try:
                with db("BRIDGE_CONTROL_ODBC") as conn:
                    cur = conn.cursor()
                    cur.execute("UPDATE bridge.runs SET heartbeat_utc=SYSUTCDATETIME() "
                                "WHERE bridge_run_id=? AND orchestrator_token=?", self.run_id, self.token)
                    owned = cur.rowcount == 1
                    conn.commit()
                if not owned:
                    self.lost = True
                    return
                misses = 0
                self.last_success = time.monotonic()
            except Exception as exc:
                misses += 1
                if misses == 1 or misses % 3 == 0:
                    print(f"WARNING heartbeat failed ({misses} misses): {exc}", file=sys.stderr)
                # Keep trying through short control outages. Stop before a different
                # orchestrator can legally take over this lease.
                if time.monotonic() - self.last_success >= self.takeover_minutes * 60 - self.seconds:
                    self.lost = True
                    return

    def check(self):
        need(not self.lost, "Run lease lost (taken over or heartbeat failing); stopping new work")


def container_client(root):
    from azure.identity import DefaultAzureCredential
    from azure.storage.blob import BlobServiceClient
    container, account = staging_parts(root)
    service = BlobServiceClient(f"https://{account}.blob.core.windows.net", DefaultAzureCredential())
    return service.get_container_client(container)


def require_empty_adls(root, relative):
    found = next(iter(container_client(root).list_blobs(name_starts_with=relative)), None)
    need(found is None, f"Attempt prefix is not empty: {relative}")


def write_manifest(cfg, run_id, payload):
    """Store a job payload as an immutable, hash-checked file under the staging location.

    Notebook parameters are limited to ~10 KB; wide tables and pointer groups exceed that.
    """
    data = json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True, default=str).encode("ascii")
    need(len(data) <= MAX_MANIFEST_BYTES, "Job manifest exceeds 8 MB")
    relative = f"{MANIFEST_PREFIX}/{run_id}/{uuid.uuid4().hex}.json"
    container_client(cfg["staging_abfss_root"]).upload_blob(relative, data, overwrite=False)
    return cfg["staging_abfss_root"].rstrip("/") + "/" + relative, hashlib.sha256(data).hexdigest()


def validate_job_capacity(cfg, role):
    """Fail before extraction/publication when the Job cannot run configured parallel tasks."""
    from databricks.sdk import WorkspaceClient
    key, workers = (("loader_job_id", cfg.get("max_loader_workers", 8)) if role == "loader" else
                    ("publisher_job_id", cfg.get("max_publisher_workers", 8)))
    job_id = int(cfg.get(key) or 0)
    need(job_id > 0, f"{key} is not configured")
    settings = WorkspaceClient().jobs.get(job_id=job_id).settings
    actual = getattr(settings, "max_concurrent_runs", None) or 1
    need(actual >= workers, f"Databricks Job {job_id} max_concurrent_runs={actual}; "
         f"configure at least {workers} for {role} workers or lower the worker setting")
    tasks = getattr(settings, "tasks", None) or []
    need(len(tasks) == 1, f"Databricks Job {job_id} must have exactly one notebook task")
    task = tasks[0]
    need(getattr(task, "notebook_task", None) is not None,
         f"Databricks Job {job_id} must use a notebook task")
    need(getattr(task, "max_retries", None) == 0,
         f"Databricks Job {job_id} task max_retries must explicitly be 0")
    # Serverless can retry under auto-optimization even when max_retries=0.
    need(getattr(task, "disable_auto_optimization", None) is True,
         f"Databricks Job {job_id} task must disable serverless auto-optimization retries")
    need(getattr(task, "retry_on_timeout", None) is not True,
         f"Databricks Job {job_id} task must not retry on timeout")
    for label, seconds in (("job", getattr(settings, "timeout_seconds", None)),
                           ("task", getattr(task, "timeout_seconds", None))):
        need(seconds is not None and 0 < seconds <= JOB_TIMEOUT_SECONDS,
             f"Databricks Job {job_id} {label} timeout must be 1..{JOB_TIMEOUT_SECONDS} seconds")
    queue = getattr(settings, "queue", None)
    need(queue is not None and getattr(queue, "enabled", None) is False,
         f"Databricks Job {job_id} queue must be explicitly disabled")


TERMINAL_JOB_STATES = ("TERMINATED", "SKIPPED", "INTERNAL_ERROR")


def notebook_job(cfg, job_id, payload, run_id, started_callback=None, terminal_callback=None):
    from databricks.sdk import WorkspaceClient
    need(int(job_id) > 0, "Databricks job ID is not configured")
    path, digest = write_manifest(cfg, run_id, payload)
    client = WorkspaceClient()
    # One token per invocation. Databricks returns the EXISTING run for a known token whatever its
    # state, so a token derived only from the payload would make every retry adopt the first
    # (possibly failed) run and every INSPECT return the first snapshot. The token is persisted
    # before submission. If the submission outcome is unknown, calling run-now again with the stored
    # token returns the existing run if one was created; if none was, that call STARTS it (Databricks
    # guarantees exactly one run per token). It is not a read-only probe: prefer checking the job's
    # run list first, and re-submit with the token only when a run is actually wanted.
    idempotency_token = "bridge_" + hashlib.sha256(
        (json.dumps(payload, sort_keys=True, default=str) + "\x1f" + uuid.uuid4().hex)
        .encode("utf-8")).hexdigest()[:48]
    if started_callback:
        started_callback("token:" + idempotency_token)
    try:
        # notebook_params is deprecated in favour of job_parameters but still supported; it requires the
        # job to define notebook widgets (task base parameters), not job-level parameters.
        started = client.jobs.run_now(job_id=int(job_id),
                                      notebook_params={"manifest_path": path, "manifest_sha256": digest},
                                      idempotency_token=idempotency_token)
    except Exception as exc:
        raise Indeterminate("Databricks submission outcome is unknown; inspect Jobs before recovery") from exc
    dbx_run = started.run_id
    if dbx_run is None:
        raise Indeterminate(f"Databricks accepted idempotency token {idempotency_token} but returned no run ID")
    try:
        if started_callback:
            started_callback(str(dbx_run))
    except Exception as exc:
        raise Indeterminate(f"Databricks run {dbx_run} started but its ID could not be persisted") from exc

    def terminal():
        run = client.jobs.get_run(run_id=dbx_run)
        state = run.state
        done = bool(state and state.life_cycle_state and state.life_cycle_state.value in TERMINAL_JOB_STATES)
        return done, run, state

    deadline = time.monotonic() + JOB_TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        try:
            done, run, state = terminal()
        except Exception as exc:
            raise Indeterminate(f"Databricks run {dbx_run} status is unknown after polling failed") from exc
        if done:
            if not (state.result_state and state.result_state.value == "SUCCESS"):
                if terminal_callback:
                    terminal_callback(str(dbx_run), "FAILED")
                if "leaf_path" in payload:
                    task_id = run.tasks[0].run_id if run.tasks else dbx_run
                    try:
                        output = client.jobs.get_run_output(run_id=task_id)
                        error = str(getattr(output, "error", "") or getattr(output, "error_trace", "") or "")
                    except Exception:
                        error = ""
                    if permanent_loader_failure(error):
                        raise LoaderRejected(f"Loader rejected immutable input: {error[:1700]}")
                raise RuntimeError(f"Job failed: {dbx_run}: {state}")
            task_id = run.tasks[0].run_id if run.tasks else dbx_run
            try:
                output = client.jobs.get_run_output(run_id=task_id)
                value = output.notebook_output.result if output.notebook_output else None
                need(value, f"No notebook output from {task_id}")
                result = json.loads(value)
                if terminal_callback:
                    terminal_callback(str(dbx_run), "SUCCEEDED")
                return result
            except Exception as exc:
                raise Indeterminate(f"Databricks run {dbx_run} terminated but its result is unknown") from exc
        time.sleep(10)
    # Cancel so the run cannot commit later while a resumed orchestrator acts.
    try:
        client.jobs.cancel_run(run_id=dbx_run)
    except Exception as exc:
        raise Indeterminate(f"Databricks run {dbx_run} timed out and cancellation was not submitted") from exc
    stop = time.monotonic() + CANCEL_WAIT_SECONDS
    while time.monotonic() < stop:
        try:
            stopped = terminal()[0]
        except Exception as exc:
            raise Indeterminate(f"Databricks run {dbx_run} cancellation outcome is unknown") from exc
        if stopped:
            if terminal_callback:
                terminal_callback(str(dbx_run), "CANCELLED")
            raise RuntimeError(f"Databricks run {dbx_run} timed out and was cancelled; it may have committed "
                               "before cancellation, which --resume reconciles")
        time.sleep(10)
    raise Indeterminate(f"Databricks run {dbx_run} timed out and did not stop after cancel; inspect it")


_SYNAPSE_CREDENTIAL = []


def synapse_headers():
    # Synapse pipeline execution/monitoring uses the workspace data-plane endpoint.
    # Fetch per request so long polls can refresh expiring tokens.
    if not _SYNAPSE_CREDENTIAL:
        from azure.identity import DefaultAzureCredential
        _SYNAPSE_CREDENTIAL.append(DefaultAzureCredential())
    token = _SYNAPSE_CREDENTIAL[0].get_token("https://dev.azuresynapse.net/.default").token
    return {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}


def source_correlation(bridge_run_id, mapping_id, attempt):
    raw = f"{bridge_run_id}:{mapping_id}:{attempt}"
    value = "correlation:" + raw[:83] + ":" + hashlib.sha256(raw.encode()).hexdigest()[:32]
    need(len(value) <= 128, "Internal correlation ID overflow")
    return value


def synapse_pipeline_base(doc):
    cfg = doc["synapse_pipeline"]
    endpoint = cfg.get("endpoint") or f"https://{cfg['workspace_name']}.dev.azuresynapse.net"
    return endpoint.rstrip("/"), cfg


def validate_copy_artifacts(source, sink, pipeline, syn, expected_container):
    """Check the deployed destination and named connections before Copy submission."""
    src = source.get("properties", source)
    dst = sink.get("properties", sink)
    flow = pipeline.get("properties", pipeline)
    need(src.get("linkedServiceName", {}).get("referenceName") == syn["synapse_linked_service"],
         "Deployed Copy source linked service differs from inventory")
    need(dst.get("linkedServiceName", {}).get("referenceName") == syn["adls_linked_service"],
         "Deployed Copy sink linked service differs from inventory")
    need(dst.get("typeProperties", {}).get("location", {}).get("fileSystem") == expected_container,
         "Deployed Copy sink container differs from staging root")
    need(dst.get("typeProperties", {}).get("location", {}).get("folderPath", {}).get("value") ==
         "@dataset().folder", "Deployed Copy sink folder expression differs")
    activities = [a for a in flow.get("activities", []) if a.get("name") == "CopyApprovedProjection"]
    need(len(activities) == 1 and activities[0].get("type") == "Copy", "Deployed Copy activity differs")
    activity = activities[0]
    expected_query = ("@concat('SELECT ',pipeline().parameters.projection,' FROM [',"
                      "pipeline().parameters.sourceSchema,'].[',pipeline().parameters.sourceView,']')")
    source = activity.get("typeProperties", {}).get("source", {})
    need(source.get("type") == "SqlDWSource" and
         source.get("sqlReaderQuery", {}).get("value") == expected_query and
         source.get("partitionOption") == "None", "Deployed Copy source query differs")
    need(activity.get("typeProperties", {}).get("parallelCopies") == 1,
         "Deployed Copy parallelCopies differs from reviewed single-query route")
    need(activity.get("inputs", [{}])[0].get("referenceName") == "bridge_synapse_source" and
         activity.get("outputs", [{}])[0].get("referenceName") == "bridge_parquet_sink" and
         activity.get("outputs", [{}])[0].get("parameters", {}).get("folder", {}).get("value") ==
         "@pipeline().parameters.relativePath", "Deployed Copy dataset references/path differ")


def verify_copy_deployment(doc, requests, base, syn):
    artifacts = []
    for kind, name in (("datasets", "bridge_synapse_source"), ("datasets", "bridge_parquet_sink"),
                       ("pipelines", syn["copy_pipeline"])):
        response = requests.get(f"{base}/{kind}/{name}?api-version=2020-12-01",
                                headers=synapse_headers(), timeout=60)
        response.raise_for_status()
        artifacts.append(response.json())
    validate_copy_artifacts(*artifacts, syn, staging_parts(doc["staging_abfss_root"])[0])


def copy_activity(doc, m, payload, started_callback=None, terminal_callback=None):
    import requests
    base, syn = synapse_pipeline_base(doc)
    verify_copy_deployment(doc, requests, base, syn)
    pipeline_name = syn["copy_pipeline"]
    url = f"{base}/pipelines/{pipeline_name}/createRun?api-version=2020-12-01"
    # Persist before submission. The same immutable correlation is also sent into the
    # Synapse pipeline so an operator can link a lost acknowledgement to the actual
    # pipeline run even if persisting runId fails.
    correlation = source_correlation(payload["bridge_run_id"], m["mapping_id"], payload.get("attempt", 0))
    p = {"mapping_id": m["mapping_id"], "bridge_run_id": payload["bridge_run_id"],
         "release_id": payload["release_id"], "generation_id": payload["generation_id"],
         "source_correlation": correlation,
         "sourceSchema": m["source_schema"], "sourceView": m["source_view"],
         "projection": projection(m), "relativePath": payload["relative_path"]}
    if started_callback:
        started_callback(correlation)
    try:
        response = requests.post(url, json=p, headers=synapse_headers(), timeout=60); response.raise_for_status()
    except Exception as exc:
        raise Indeterminate(
            f"Synapse pipeline submission outcome is unknown; locate {correlation} in pipeline parameters before recovery"
        ) from exc
    try:
        activity_id = response.json()["runId"]
        need(isinstance(activity_id, str) and activity_id, "Synapse returned an empty run ID")
    except Exception as exc:
        raise Indeterminate(f"Synapse pipeline submission {correlation} returned without a usable run ID") from exc
    try:
        if started_callback:
            started_callback(str(activity_id))
    except Exception as exc:
        raise Indeterminate(
            f"Synapse pipeline run {activity_id} started but its ID could not be persisted; "
            f"recover it using source_correlation={correlation}"
        ) from exc

    def status():
        r = requests.get(f"{base}/pipelineruns/{activity_id}?api-version=2020-12-01",
                         headers=synapse_headers(), timeout=60)
        r.raise_for_status()
        return r.json()["status"]

    deadline = time.monotonic() + JOB_TIMEOUT_SECONDS
    while time.monotonic() < deadline:
        try:
            current = status()
        except Exception as exc:
            raise Indeterminate(f"Synapse pipeline run {activity_id} status is unknown after polling failed") from exc
        if current in ("Succeeded", "Failed", "Cancelled"):
            if current != "Succeeded":
                if terminal_callback:
                    terminal_callback(str(activity_id), current.upper())
                raise RuntimeError(f"Synapse pipeline run {activity_id} ended {current}")
            now = datetime.now(timezone.utc)
            window = {"lastUpdatedAfter": (now - timedelta(days=1)).isoformat(),
                      "lastUpdatedBefore": (now + timedelta(hours=1)).isoformat()}
            try:
                metrics = requests.post(
                    f"{base}/pipelines/{pipeline_name}/pipelineruns/{activity_id}/queryActivityruns?api-version=2020-12-01",
                    json=window, headers=synapse_headers(), timeout=60)
                metrics.raise_for_status()
            except Exception as exc:
                raise Indeterminate(f"Synapse pipeline run {activity_id} succeeded but metrics are unavailable") from exc
            activities = [a for a in metrics.json().get("value", [])
                          if a.get("activityName") == "CopyApprovedProjection"]
            if len(activities) != 1 or activities[0]["status"] != "Succeeded":
                raise Indeterminate(f"Synapse Copy pipeline {activity_id} succeeded but activity evidence is incomplete")
            output = activities[0].get("output") or {}
            read, copied = output.get("rowsRead"), output.get("rowsCopied")
            if terminal_callback:
                terminal_callback(str(activity_id), "SUCCEEDED")
            if type(read) is not int or type(copied) is not int:
                raise CopyCountMismatch("Synapse Copy did not report integer rowsRead/rowsCopied")
            if read != copied or copied != int(payload["source_rows"]) or output.get("rowsSkipped", 0):
                raise CopyCountMismatch(f"Synapse Copy rows read {read} / copied {copied}, "
                                        f"skipped {output.get('rowsSkipped', 0)}, "
                                        f"audited {payload['source_rows']}")
            return activity_id
        time.sleep(10)
    try:
        requests.post(
            f"{base}/pipelineruns/{activity_id}/cancel?isRecursive=true&api-version=2020-12-01",
            headers=synapse_headers(), timeout=60).raise_for_status()
    except Exception as exc:
        raise Indeterminate(f"Synapse pipeline run {activity_id} timed out and cancellation was not confirmed") from exc
    stop = time.monotonic() + CANCEL_WAIT_SECONDS
    while time.monotonic() < stop:
        try:
            stopped = status() in ("Succeeded", "Failed", "Cancelled")
        except Exception as exc:
            raise Indeterminate(f"Synapse pipeline run {activity_id} cancellation outcome is unknown") from exc
        if stopped:
            if terminal_callback:
                terminal_callback(str(activity_id), "CANCELLED")
            raise RuntimeError(f"Synapse pipeline run {activity_id} timed out and was cancelled")
        time.sleep(10)
    raise Indeterminate(f"Synapse pipeline run {activity_id} did not stop after cancel; inspect before retrying")


def projection(m):
    result = []
    for c in m["columns"]:
        src = ident(c["source"])
        expr = f"CONVERT(varchar(36), {src})" if c.get("conversion") == "GUID_TEXT" else src
        result.append(f"{expr} AS {ident(c['target'])}")
    return ", ".join(result)


# SQLSTATE classes that the server returns for a statement it has finished rejecting or
# rolling back (syntax/permission, data, constraint, transaction rollback, ...). Anything
# else - connection loss (08xxx), query timeout (HYT00/HYT01), cancel (HY008), a generic
# driver error (HY000), an interrupt or a non-ODBC exception - leaves the outcome unknown.
TERMINAL_SQLSTATE_CLASSES = ("21", "22", "23", "24", "25", "28", "3D", "3F", "40", "42", "44")


def cetas_error_is_terminal(exc):
    if not isinstance(exc, Exception) or not type(exc).__module__.startswith("pyodbc"):
        return False
    state = exc.args[0] if exc.args and isinstance(exc.args[0], str) else ""
    return len(state) == 5 and state[:2].upper() in TERMINAL_SQLSTATE_CLASSES


def cetas(m, relative_path, started_callback=None, terminal_callback=None):
    name = "x_" + uuid.uuid4().hex[:24]
    if started_callback:
        started_callback(name)
    source = f"{ident(m['source_schema'])}.{ident(m['source_view'])}"
    statement = (f"CREATE EXTERNAL TABLE bridge_meta.{ident(name)} WITH "
                 f"(LOCATION = '{relative_path}', DATA_SOURCE = bridge_stage, FILE_FORMAT = bridge_parquet) "
                 f"AS SELECT {projection(m)} FROM {source}")
    drop = f"IF OBJECT_ID(N'bridge_meta.{name}') IS NOT NULL DROP EXTERNAL TABLE bridge_meta.{ident(name)}"
    with db("BRIDGE_CETAS_ODBC", autocommit=True) as conn:
        conn.timeout = JOB_TIMEOUT_SECONDS

        def cleanup():
            # Dropping metadata never deletes the Parquet files. A cleanup failure is
            # reported but must never replace the original CETAS error.
            try:
                conn.cursor().execute(drop)
            except Exception as exc:
                print(f"WARNING CETAS metadata bridge_meta.{name} was not dropped: {exc}", file=sys.stderr)

        try:
            conn.cursor().execute(statement)
        except BaseException as exc:
            cleanup()
            if cetas_error_is_terminal(exc):
                # The server returned an error for the statement: it is not still running.
                if terminal_callback:
                    terminal_callback(name, "FAILED")
                raise CetasRejected(f"CETAS operation {name} failed: {exc}") from exc
            raise Indeterminate(f"CETAS operation {name} outcome is unknown; inspect Synapse requests and ADLS") from exc
        cleanup()
    if terminal_callback:
        terminal_callback(name, "SUCCEEDED")
    return name


def build_item(cfg, ctx, m, attempt):
    relative = attempt_relative_path(ctx["business_date"], ctx["run_id"], m["mapping_id"], attempt)
    leaf = cfg["staging_abfss_root"].rstrip("/") + "/" + relative
    need(len(leaf) <= 700, "Attempt path exceeds control database limit")
    return {**m, "bridge_run_id": ctx["run_id"], "release_id": ctx["release"],
            "generation_id": ctx["generation_id"], "upstream_run_id": ctx["upstream_run_id"],
            "upstream_sequence": ctx["sequence"], "business_date": ctx["business_date"],
            "source_rows": ctx["rows"][m["mapping_id"]],
            "leaf_path": leaf,
            "relative_path": relative, "attempt": attempt, "delta_write_sequence": ctx["sequence"],
            "candidate_table": candidate_table_name(m["mapping_id"], ctx["run_id"], attempt),
            "inventory_version": cfg["inventory_version"],
            "control_catalog": cfg["control_catalog"], "control_schema": cfg["control_schema"]}


def extract_one(cfg, ctx, lease, m, attempt):
    lease.check()
    run_id, token, mid = ctx["run_id"], ctx["token"], m["mapping_id"]
    item = build_item(cfg, ctx, m, attempt)
    # Short-lived control connections: extraction can take hours.
    with db("BRIDGE_CONTROL_ODBC") as control:
        require_empty_adls(cfg["staging_abfss_root"], item["relative_path"])
        cur = control.cursor()
        consumer_target = ".".join(m[k] for k in ("target_catalog", "target_schema", "target_table"))
        cur.execute("INSERT bridge.object_attempts(bridge_run_id,mapping_id,attempt,method,status,leaf_path,"
                    "source_rows,delta_target,target_key,publication_strategy,consumer_target,source_operation_state,"
                    "updated_utc) SELECT ?,?,?,?,'EXTRACTING',?,?,?,?,?,?,'PENDING',SYSUTCDATETIME() WHERE " + OWNED,
                    run_id, mid, attempt, m["method"], item["leaf_path"], item["source_rows"],
                    delta_target(m, run_id, attempt), target_key(m), m["strategy"], consumer_target, run_id, token)
        need(cur.rowcount == 1, "Run lease lost before extraction")
        control.commit()
    try:
        def source_started(external_id):
            with db("BRIDGE_CONTROL_ODBC") as control:
                cur = control.cursor()
                cur.execute("UPDATE bridge.object_attempts SET source_request_id=?,source_operation_state='RUNNING',"
                            "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND "
                            + OWNED, external_id, run_id, mid, attempt, run_id, token)
                need(cur.rowcount == 1, "Could not persist external source operation ID")
                control.commit()

        def source_terminal(external_id, state):
            with db("BRIDGE_CONTROL_ODBC") as control:
                cur = control.cursor()
                cur.execute("UPDATE bridge.object_attempts SET source_operation_state=?,updated_utc=SYSUTCDATETIME() "
                            "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND source_request_id=? AND " + OWNED,
                            state, run_id, mid, attempt, external_id, run_id, token)
                need(cur.rowcount == 1, "Could not persist terminal source operation state")
                control.commit()

        request_id = (cetas(m, item["relative_path"], source_started, source_terminal)
                      if m["method"] == "CETAS" else
                      copy_activity(cfg, m, item, source_started, source_terminal))
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            cur.execute("UPDATE bridge.object_attempts SET status='EXTRACTED',source_request_id=?,source_operation_state='SUCCEEDED',"
                        "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                        "AND status='EXTRACTING' AND " + OWNED,
                        request_id, run_id, mid, attempt, run_id, token)
            need(cur.rowcount == 1, "Extraction attempt or lease changed concurrently")
            control.commit()
    except BaseException as exc:
        unknown = is_indeterminate(exc)
        failure_recorded = False
        try:
            with db("BRIDGE_CONTROL_ODBC") as control:
                # A stored state of PENDING proves nothing was submitted: CETAS and Copy both persist
                # RUNNING through started_callback BEFORE submitting. Such an attempt is FAILED /
                # NOT_STARTED even after an interrupt; recording it INDETERMINATE would leave no
                # external ID to resolve, blocking recovery and resume alike.
                # Otherwise, on an ordinary failure a read already recorded SUCCEEDED keeps that
                # state: the attempt can still fail afterwards (e.g. recording the completed extraction failed), but the audit trail must not claim the source operation itself failed. An
                # indeterminate outcome records UNKNOWN so recovery.py resolve-attempt can resolve
                # the attempt with SOURCE evidence. Both CASEs read the row's pre-update state.
                cur = control.cursor()
                cur.execute(
                    "UPDATE bridge.object_attempts SET "
                    "status=CASE WHEN source_operation_state='PENDING' THEN 'FAILED' ELSE ? END,"
                    "source_operation_state=CASE WHEN source_operation_state='PENDING' THEN 'NOT_STARTED' "
                    "WHEN ?=0 AND source_operation_state='SUCCEEDED' THEN 'SUCCEEDED' ELSE ? END,"
                    "error_text=?,updated_utc=SYSUTCDATETIME() "
                    "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status='EXTRACTING' AND " + OWNED,
                    "INDETERMINATE" if unknown else "FAILED", 1 if unknown else 0,
                    "UNKNOWN" if unknown else ("CETAS_REJECTED" if isinstance(exc, CetasRejected) else "FAILED"),
                    f"{type(exc).__name__}: {exc}"[:2000], run_id, mid, attempt, run_id, token)
                need(cur.rowcount == 1, "Could not record terminal extraction attempt")
                control.commit()
                failure_recorded = True
        except Exception as record_error:
            print(f"WARNING could not record failure for {mid}: {record_error}", file=sys.stderr)
        if failure_recorded and isinstance(exc, CetasRejected) and m.get("fallback_method") == "COPY_ACTIVITY" \
                and attempt < cfg.get("max_attempts", 3):
            # A terminal CETAS rejection is the only automatic switch. The failed attempt's
            # files are never reused, and the Copy physical column types travel with its manifest.
            lease.check()
            return extract_one(cfg, ctx, lease, copy_fallback_mapping(m), attempt + 1)
        raise
    return item


def load_one(cfg, ctx, lease, item):
    lease.check()
    run_id, token, mid, attempt = ctx["run_id"], ctx["token"], item["mapping_id"], item["attempt"]
    with db("BRIDGE_CONTROL_ODBC") as control:
        cur = control.cursor()
        cur.execute("UPDATE bridge.object_attempts SET status='LOADING',updated_utc=SYSUTCDATETIME() "
                    "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status IN ('EXTRACTED','LOADING') AND "
                    + OWNED, run_id, mid, attempt, run_id, token)
        need(cur.rowcount == 1, f"Load state conflict: {mid}")
        control.commit()
    def loader_started(external_id):
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            cur.execute("UPDATE bridge.object_attempts SET loader_run_id=?,loader_operation_state='RUNNING',"
                        "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND "
                        + OWNED, external_id, run_id, mid, attempt, run_id, token)
            need(cur.rowcount == 1, "Could not persist Databricks loader run ID")
            control.commit()

    def loader_terminal(external_id, state):
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            cur.execute("UPDATE bridge.object_attempts SET loader_operation_state=?,updated_utc=SYSUTCDATETIME() "
                        "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND loader_run_id=? AND " + OWNED,
                        state, run_id, mid, attempt, external_id, run_id, token)
            need(cur.rowcount == 1, "Could not persist terminal loader state")
            control.commit()

    try:
        result = notebook_job(cfg, cfg["loader_job_id"], item, run_id, loader_started, loader_terminal)
    except BaseException as exc:
        unknown = is_indeterminate(exc)
        recorded = False
        try:
            with db("BRIDGE_CONTROL_ODBC") as control:
                cur = control.cursor()
                cur.execute(
                    "UPDATE bridge.object_attempts SET status=?,loader_operation_state=?,error_text=?,"
                    "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                    "AND status='LOADING' AND " + OWNED,
                    "INDETERMINATE" if unknown else ("FAILED" if isinstance(exc, LoaderRejected) else "EXTRACTED"),
                    "UNKNOWN" if unknown else ("REJECTED" if isinstance(exc, LoaderRejected) else "FAILED"),
                    f"{type(exc).__name__}: {exc}"[:2000], run_id, mid, attempt, run_id, token)
                need(cur.rowcount == 1, "Could not record loader failure")
                control.commit()
                recorded = True
        except Exception as record_error:
            print(f"WARNING could not record loader failure for {mid}: {record_error}", file=sys.stderr)
        if (recorded and isinstance(exc, LoaderRejected) and item["method"] == "CETAS" and
                item.get("fallback_method") == "COPY_ACTIVITY" and attempt < cfg.get("max_attempts", 3)):
            # A CETAS-specific Parquet representation may work through Copy's serializer.
            # Never reuse the rejected attempt's immutable path or candidate table.
            fallback = extract_with_limits(cfg, ctx, lease, copy_fallback_mapping(item), attempt + 1)
            return load_one(cfg, ctx, lease, fallback)
        raise
    expected_target = delta_target(item, run_id, attempt)
    try:
        need(isinstance(result, dict), f"Loader returned no result object: {mid}")
        need(result.get("source_rows") == result.get("parquet_rows") == result.get("delta_rows")
             == item["source_rows"], f"Three-way count mismatch: {mid}")
        need(result.get("target") == expected_target,
             f"Loader wrote {result.get('target')}, expected {expected_target}")
    except RuntimeError as exc:
        # The loader job finished, but its result contradicts the orchestrator's expectation.
        # Reloading the same Parquet cannot change that, so the attempt must not stay LOADING
        # (every --resume would rerun the loader and never reach max_attempts). It is FAILED with
        # loader state REJECTED: Copy can retry a CETAS serialization mismatch once.
        recorded = False
        try:
            with db("BRIDGE_CONTROL_ODBC") as control:
                cur = control.cursor()
                cur.execute(
                    "UPDATE bridge.object_attempts SET status='FAILED',loader_operation_state='REJECTED',"
                    "error_text=?,updated_utc=SYSUTCDATETIME() "
                    "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status='LOADING' AND " + OWNED,
                    f"Loader result rejected: {exc}"[:2000], run_id, mid, attempt, run_id, token)
                need(cur.rowcount == 1, "Could not record loader result rejection")
                control.commit()
                recorded = True
        except Exception as record_error:
            print(f"WARNING could not record loader result error for {mid}: {record_error}", file=sys.stderr)
        if (recorded and item["method"] == "CETAS" and
                item.get("fallback_method") == "COPY_ACTIVITY" and attempt < cfg.get("max_attempts", 3)):
            fallback = extract_with_limits(cfg, ctx, lease, copy_fallback_mapping(item), attempt + 1)
            return load_one(cfg, ctx, lease, fallback)
        raise
    with db("BRIDGE_CONTROL_ODBC") as control:
        cur = control.cursor()
        cur.execute("UPDATE bridge.object_attempts SET status='READY',parquet_rows=?,delta_rows=?,delta_target=?,"
                    "loader_operation_state='SUCCEEDED',"
                    "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                    "AND status='LOADING' AND " + OWNED,
                    result["parquet_rows"], result["delta_rows"], expected_target, run_id, mid, attempt, run_id, token)
        need(cur.rowcount == 1, f"Load state conflict: {mid}")
        control.commit()
    return result


LATEST_ATTEMPTS = ("SELECT a.mapping_id,a.attempt,a.status,a.leaf_path,a.source_rows,a.parquet_rows,a.delta_rows,"
                   "a.delta_target,a.source_operation_state,a.loader_operation_state,a.method FROM bridge.object_attempts a WHERE a.bridge_run_id=? AND a.attempt="
                   "(SELECT MAX(b.attempt) FROM bridge.object_attempts b WHERE b.bridge_run_id=a.bridge_run_id "
                   "AND b.mapping_id=a.mapping_id)")


def extract_with_limits(cfg, ctx, lease, mapping, attempt):
    """Apply the same global/class pool limits to scheduled and loader-triggered reads."""
    slots = ctx.get("extract_slots")
    if slots is None:  # Direct calls from the small local simulation harness.
        return extract_one(cfg, ctx, lease, mapping, attempt)
    group = mapping.get("size_class", "MEDIUM")
    global_slot, class_slot = slots["global"], slots[group]
    # Do not hold a global slot while waiting for the class limit.
    while not class_slot.acquire(timeout=1):
        lease.check()
    try:
        while not global_slot.acquire(timeout=1):
            lease.check()
        try:
            lease.check()
            return extract_one(cfg, ctx, lease, mapping, attempt)
        finally:
            global_slot.release()
    finally:
        class_slot.release()


def run_extractions(cfg, ctx, lease, work, on_extracted=None):
    """Bounded, class-limited extraction; largest objects first."""
    workers = cfg.get("max_extraction_workers", 4)
    limits = cfg.get("extraction_class_limits", {"SMALL": 4, "MEDIUM": 2, "LARGE": 1})
    pending = sorted(work, key=lambda w: w[0].get("source_profile", {}).get("physical_used_bytes", 0), reverse=True)
    objects, errors, active = [], [], {}
    by_class = {k: 0 for k in limits}
    with ThreadPoolExecutor(max_workers=workers) as pool:
        while pending or active:
            while len(active) < workers and not lease.lost:
                pos = next((i for i, (m, _) in enumerate(pending)
                            if by_class[m.get("size_class", "MEDIUM")] < limits[m.get("size_class", "MEDIUM")]), None)
                if pos is None:
                    break
                m, attempt = pending.pop(pos)
                cls = m.get("size_class", "MEDIUM")
                active[pool.submit(extract_with_limits, cfg, ctx, lease, m, attempt)] = cls
                by_class[cls] += 1
            if not active:
                if lease.lost:
                    errors.append(RuntimeError("Run lease lost; unscheduled extractions skipped"))
                    break
                raise RuntimeError("No extraction capacity for pending mappings")
            completed, _ = wait(active, return_when=FIRST_COMPLETED)
            for future in completed:
                by_class[active.pop(future)] -= 1
                try:
                    item = future.result()
                    objects.append(item)
                    if on_extracted is not None:
                        on_extracted(item)  # Start this table's load while other extracts run.
                except BaseException as exc:
                    errors.append(exc)
    return objects, errors


def publication_selection(mappings, latest, superseded=frozenset()):
    """Only independently verified candidates may advance their table's pointer."""
    ready, skipped = [], []
    for m in mappings:
        if m["mapping_id"] in superseded:
            skipped.append({"mapping_id": m["mapping_id"], "status": "SUPERSEDED_BY_NEWER",
                            "mandatory": m["mandatory"]})
            continue
        row = latest.get(m["mapping_id"])
        if row and row[2] == "READY":
            need(row[4] == row[5] == row[6], f"Count mismatch: {m['mapping_id']}")
            ready.append(m["mapping_id"])
        else:
            skipped.append({"mapping_id": m["mapping_id"], "status": row[2] if row else "NOT_ATTEMPTED",
                            "mandatory": m["mandatory"]})
    return ready, skipped


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--upstream-run-id", required=True)
    parser.add_argument("--generation-id", required=True)
    parser.add_argument("--sequence", required=True, type=int)
    parser.add_argument("--business-date", required=True, type=date.fromisoformat)
    parser.add_argument("--bridge-run-id", required=True,
                        help="Approved BRIDGE_HELD owner. Reuse the same ID with --resume.")
    parser.add_argument("--resume", action="store_true",
                        help="Retry failed tables before publishing, or take over an interrupted run")
    args = parser.parse_args()
    cfg = config(args.config)
    validate_job_capacity(cfg, "loader")
    validate_job_capacity(cfg, "publisher")  # catch publication-job drift before any extraction
    staging_parts(cfg["staging_abfss_root"])
    need(bool(BRIDGE_RUN_ID.fullmatch(args.bridge_run_id)), "Unsafe bridge ID (1..124 characters)")
    need(args.bridge_run_id != "retention", "Reserved bridge run ID")
    run_id = args.bridge_run_id
    release = "rel_" + run_id
    ctx = {"run_id": run_id, "release": release, "generation_id": args.generation_id,
           "upstream_run_id": args.upstream_run_id, "sequence": args.sequence,
           "business_date": str(args.business_date), "rows": {}}
    by_id = {m["mapping_id"]: m for m in cfg["mappings"]}

    with db("BRIDGE_CONTROL_ODBC") as control:
        contract = require_inventory_contract(control, cfg)
        existing = fetchone(control, "SELECT upstream_run_id,generation_id,upstream_sequence,business_date,"
                                     "inventory_version,release_id,status,source_set_id,contract_sha256 FROM bridge.runs "
                                     "WHERE bridge_run_id=?", run_id)
        if args.resume:
            need(existing, "No run to resume")
            stored = (existing[0], existing[1], int(existing[2]), str(existing[3]), existing[4], existing[5])
            need(stored == (args.upstream_run_id, args.generation_id, args.sequence, ctx["business_date"],
                            cfg["inventory_version"], release), "Resume arguments/config differ from the stored run")
            need(existing[7] == cfg["source_set_id"], "Resume config names a different source set")
            need(existing[8] == contract, "Resume contract differs from the recorded run")
            need(existing[6] in RESUMABLE_EXTRACT_STATES,
                 f"Run status {existing[6]} is not resumable here (PUBLISHING runs belong to publish_run.py)")
            latest = {r[0]: r for r in control.cursor().execute(LATEST_ATTEMPTS, run_id).fetchall()}
        else:
            need(not existing, "Run already exists: continue it with --resume, never rerun blindly")
            duplicate = fetchone(control, "SELECT bridge_run_id FROM bridge.runs WHERE source_set_id=? "
                                 "AND upstream_run_id=? AND bridge_run_id<>?",
                                 cfg["source_set_id"], args.upstream_run_id, run_id)
            need(not duplicate, f"Upstream night already belongs to bridge run {duplicate[0] if duplicate else ''}")
            latest = {}
        need(set(latest) <= set(by_id), "Run has attempts for mappings outside this inventory")
        seeded = {r[0]: (r[1], bool(r[2]), r[3]) for r in control.cursor().execute(
            "SELECT mapping_id,group_id,mandatory,strategy FROM bridge.group_members "
            "WHERE inventory_version=? AND enabled=1", cfg["inventory_version"])}
        actual = {m["mapping_id"]: (m["group_id"], m["mandatory"], m["strategy"]) for m in cfg["mappings"]}
        need(actual == seeded, "Immutable enabled inventory does not match seeded control members")
        superseded = set()
        for m in cfg["mappings"]:
            key = target_key(m)
            state = fetchone(control, "SELECT high_water_sequence FROM bridge.target_state WHERE target_key=?", key)
            need(state, f"Missing high-water state: {key}")
            if args.sequence <= state[0]:
                need(args.resume, f"Stale high-water state: {key}")
                superseded.add(m["mapping_id"])

        # Plan: which mappings extract (and with which attempt) and which only reload.
        to_extract, to_load_attempts, orphaned, stranded = [], [], [], []
        for m in cfg["mappings"]:
            if m["mapping_id"] in superseded:
                continue
            row = latest.get(m["mapping_id"])
            if row is None:
                to_extract.append((m, 1))
            elif row[2] == "READY":
                continue
            elif row[2] == "EXTRACTING" and row[8] != "PENDING":
                # A previous orchestrator stopped while a source read was (or may have been)
                # submitted. Never infer that it stopped: route it through audited recovery.
                orphaned.append((m["mapping_id"], row[1], "SOURCE"))
            elif row[2] == "LOADING" and row[9] in ("RUNNING", "UNKNOWN"):
                orphaned.append((m["mapping_id"], row[1], "LOADER"))
            elif row[2] in ("EXTRACTED", "LOADING"):
                route = mapped_route(m, row[10])
                to_load_attempts.append((route, row[1], row[3]))
            elif row[2] == "INDETERMINATE":
                continue  # This table needs evidence; other independent tables can retry.
            else:
                if row[2] == "EXTRACTING" and row[8] == "PENDING" and row[1] >= cfg.get("max_attempts", 3):
                    stranded.append((m["mapping_id"], row[1]))
                    continue
                if row[2] == "FAILED" and row[9] == "REJECTED":
                    if (row[10] == "CETAS" and m.get("fallback_method") == "COPY_ACTIVITY" and
                            row[1] < cfg.get("max_attempts", 3)):
                        to_extract.append((copy_fallback_mapping(m), row[1] + 1))
                    continue  # Copy rejection (or no fallback) is final for this night.
                if row[2] == "FAILED" and row[10] == "COPY_ACTIVITY" and row[8] == "SUCCEEDED":
                    continue  # Completed Copy with a deterministic count mismatch is final.
                if row[1] >= cfg.get("max_attempts", 3):
                    continue  # exhausted table stays on its previously published release
                # A known CETAS rejection switches to Copy on resume, including a crash
                # between recording the rejection and submitting its fallback attempt.
                to_extract.append((mapped_route(m, row[10], row[8]), row[1] + 1))

        if orphaned:
            # Mark orphaned operations unknown before continuing with other mappings. Never
            # schedule another attempt for one of these mappings without terminal evidence.
            token = claim_run(control, run_id, RESUMABLE_EXTRACT_STATES, "EXTRACTING",
                              cfg.get("takeover_after_minutes", 150))
            cur = control.cursor()
            for mid, attempt, phase in orphaned:
                state_col = "source_operation_state" if phase == "SOURCE" else "loader_operation_state"
                cur.execute(f"UPDATE bridge.object_attempts SET status='INDETERMINATE',{state_col}='UNKNOWN',"
                            "error_text='Orchestrator stopped while this operation was in flight',"
                            "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                            "AND status IN ('EXTRACTING','LOADING') AND " + OWNED,
                            run_id, mid, attempt, run_id, token)
                need(cur.rowcount == 1, f"Attempt changed concurrently: {mid}")
            cur.execute("UPDATE bridge.runs SET status='FAILED',orchestrator_token=NULL,"
                        "updated_utc=SYSUTCDATETIME() "
                        "WHERE bridge_run_id=? AND orchestrator_token=?", run_id, token)
            control.commit()
            print("WARNING unresolved external operations skipped: " +
                  ", ".join(f"{mid} attempt {n} ({phase})" for mid, n, phase in orphaned), file=sys.stderr)


    with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
        from source_metadata import schema_hash
        audit = fetchone(syn, "SELECT COUNT_BIG(*), MAX(upstream_sequence), MIN(business_date), MAX(business_date) "
                         "FROM bridge_meta.upstream_run "
                         "WHERE source_set_id=? AND upstream_run_id=? AND source_generation_id=? "
                         "AND status='COMPLETE' AND write_closed=1",
                         cfg['source_set_id'], args.upstream_run_id, args.generation_id)
        need(audit and audit[0] == 1 and audit[1] == args.sequence, "Upstream run missing/duplicate/unclosed")
        # The business date names the staging paths and is stamped on every Delta row, so it must be
        # the one the upstream writer recorded for this generation, not only a well-formed date.
        need(str(audit[2]) == str(audit[3]) == ctx["business_date"],
             f"--business-date {ctx['business_date']} differs from the upstream audit ({audit[2]}) "
             f"for {args.upstream_run_id}")
        extracting = {m["mapping_id"] for m, _ in to_extract}
        rejected_audits = set()
        for m in cfg["mappings"]:
            r = fetchone(syn, "SELECT COUNT_BIG(*),MAX(row_count),MIN(row_count),MAX(status),"
                         "MAX(source_schema_version) FROM bridge_meta.upstream_object "
                         "WHERE source_set_id=? AND upstream_run_id=? AND mapping_id=?",
                         cfg['source_set_id'], args.upstream_run_id, m["mapping_id"])
            need(r and r[0] == 1, f"Missing/duplicate source audit: {m['mapping_id']}")
            if (r[3] != 'COMPLETE' or r[4] != m['source_schema_version'] or
                    (int(r[1]) == 0 and not m['allow_empty'])):
                rejected_audits.add(m["mapping_id"])
                continue
            if m["mapping_id"] in extracting:
                try:
                    current_schema = schema_hash(syn, m["source_schema"], m["source_view"])
                except Exception as exc:
                    print(f"WARNING source schema unavailable for {m['mapping_id']}: {exc}", file=sys.stderr)
                    rejected_audits.add(m["mapping_id"])
                    continue
                if current_schema != m["source_schema_version"]:
                    rejected_audits.add(m["mapping_id"])
                    continue
            ctx["rows"][m["mapping_id"]] = int(r[1])
        # Rejected source audits never generate an attempt or advance the old pointer.
        to_extract = [(m, n) for m, n in to_extract if m['mapping_id'] not in rejected_audits]
        to_load_attempts = [(m, n, leaf) for m, n, leaf in to_load_attempts
                            if m['mapping_id'] not in rejected_audits]

    takeover = cfg.get("takeover_after_minutes", 150)
    with db("BRIDGE_CONTROL_ODBC") as control:
        if args.resume:
            token = claim_run(control, run_id, RESUMABLE_EXTRACT_STATES, "EXTRACTING", takeover)
            ctx["token"] = token
            cur = control.cursor()
            for mid, attempt in stranded:
                cur.execute("UPDATE bridge.object_attempts SET status='FAILED',"
                            "source_operation_state='NOT_STARTED',updated_utc=SYSUTCDATETIME(),"
                            "error_text='Attempt limit reached before source submission' "
                            "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                            "AND status='EXTRACTING' AND source_operation_state='PENDING' AND " + OWNED,
                            run_id, mid, attempt, run_id, token)
                need(cur.rowcount == 1, f"Stranded attempt changed: {mid}")
            for m, attempt in to_extract:
                if attempt > 1:
                    # Only an attempt whose source operation was never submitted can still be
                    # EXTRACTING here (PENDING); anything submitted went through recovery above.
                    cur.execute("UPDATE bridge.object_attempts SET status='SUPERSEDED',"
                                "source_operation_state='NOT_STARTED',updated_utc=SYSUTCDATETIME(),"
                                "error_text=COALESCE(error_text,'Interrupted before submission; superseded on resume') "
                                "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status='EXTRACTING' "
                                "AND source_operation_state='PENDING' AND "
                                + OWNED, run_id, m["mapping_id"], attempt - 1, run_id, token)
            control.commit()
        else:
            token = uuid.uuid4().hex
            ctx["token"] = token
            control.cursor().execute(
                "INSERT bridge.runs(bridge_run_id,upstream_run_id,generation_id,upstream_sequence,business_date,"
                "inventory_version,release_id,status,orchestrator_token,heartbeat_utc,source_set_id,contract_sha256) "
                "VALUES (?,?,?,?,?,?,?,'EXTRACTING',?,SYSUTCDATETIME(),?,?)", run_id, args.upstream_run_id,
                args.generation_id, args.sequence, args.business_date, cfg["inventory_version"], release, token,
                cfg["source_set_id"], contract)
            control.commit()

    limits = cfg.get("extraction_class_limits", {"SMALL": 4, "MEDIUM": 2, "LARGE": 1})
    ctx["extract_slots"] = {"global": threading.BoundedSemaphore(cfg.get("max_extraction_workers", 4)),
                            **{k: threading.BoundedSemaphore(v) for k, v in limits.items()}}
    try:
        for m, attempt, leaf in to_load_attempts:
            need(leaf == build_item(cfg, ctx, m, attempt)["leaf_path"],
                 f"Stored leaf path differs: {m['mapping_id']}")
        with RunLease(run_id, token, cfg.get("heartbeat_seconds", 60),
                      cfg.get("takeover_after_minutes", 150)) as lease:
            items = [build_item(cfg, ctx, m, attempt) for m, attempt, _ in to_load_attempts]
            with ThreadPoolExecutor(max_workers=cfg.get("max_loader_workers", 8)) as loaders:
                load_futures = [loaders.submit(load_one, cfg, ctx, lease, item) for item in items]
                _, extraction_errors = run_extractions(
                    cfg, ctx, lease, to_extract,
                    on_extracted=lambda item: load_futures.append(loaders.submit(load_one, cfg, ctx, lease, item)))
                with db("BRIDGE_CONTROL_ODBC") as control:
                    update_run(control, run_id, token, "EXTRACTING", "EXTRACTED")
                    update_run(control, run_id, token, "EXTRACTED", "LOADING")
                load_errors = []
                for future in as_completed(load_futures):
                    try:
                        future.result()
                    except BaseException as exc:
                        load_errors.append(exc)
            lease.check()
            with db("BRIDGE_CONTROL_ODBC") as control:
                rows = control.cursor().execute(LATEST_ATTEMPTS, run_id).fetchall()
                ready, skipped = publication_selection(cfg["mappings"], {r[0]: r for r in rows}, superseded)
                # Failures are kept in attempt history. They do not move their target pointer.
                update_run(control, run_id, token, "LOADING", "READY", release_lease=True)
        print(json.dumps({"bridge_run_id": run_id, "release_id": release, "status": "READY",
                          "ready": ready, "skipped": skipped,
                          "errors": [str(e) for e in extraction_errors + load_errors],
                          "next": "Run publish_run.py with validation evidence"}))
    except BaseException as exc:
        keep = is_indeterminate(exc)
        try:
            with db("BRIDGE_CONTROL_ODBC") as control:
                # Keep the lease if work may still be running, so a resume must wait for it to expire.
                control.cursor().execute(
                    "UPDATE bridge.runs SET status='FAILED',updated_utc=SYSUTCDATETIME(),"
                    "orchestrator_token=CASE WHEN ?=1 THEN orchestrator_token ELSE NULL END "
                    "WHERE bridge_run_id=? AND orchestrator_token=? "
                    "AND status IN ('CREATED','EXTRACTING','EXTRACTED','LOADING')", 1 if keep else 0, run_id, token)
                control.commit()
        except Exception as record_error:
            print(f"WARNING could not mark run FAILED: {record_error}", file=sys.stderr)
        raise
    if any(item["mandatory"] for item in skipped):
        raise SystemExit(2)


if __name__ == "__main__":
    main()
