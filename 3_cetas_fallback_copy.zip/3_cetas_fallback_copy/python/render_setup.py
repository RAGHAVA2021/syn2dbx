"""Step 2 (README.md): render Azure SQL control seeds and Unity Catalog setup SQL.

Azure SQL seeds are idempotent. UC consumer views use CREATE VIEW (once per
target) so an existing, unrelated object cannot be silently adopted. A later
schema wave requires a reviewed view/physical-table migration.
"""
import argparse
from pathlib import Path

from bridge_run import METADATA_COLUMNS, config, contract_sha256, ident, target_key


def q(s):
    ident(s)
    return "`" + s + "`"


def lit(s):
    if "'" in str(s):
        raise ValueError("Invalid literal")
    return "'" + str(s) + "'"


def physical_ddl(m):
    name = f"{q(m['target_catalog'])}.{q(m['physical_schema'])}.{q(m['target_table'] + '_snapshots')}"
    columns = ", ".join(f"{q(c['target'])} {c['target_type'].upper()}" for c in m["columns"])
    metadata = ", ".join(f"{q(k)} STRING" for k in METADATA_COLUMNS)
    props = ", ".join(f"'{k}'='{v}'" for k, v in sorted(m["consumer_properties"].items()))
    # release_id is in the default file statistics even on wide business tables.
    return f"CREATE TABLE IF NOT EXISTS {name} ({metadata}, {columns}) USING DELTA TBLPROPERTIES ({props});", name


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--output-dir", required=True)
    a = p.parse_args()
    doc = config(a.config)
    dest = Path(a.output_dir); dest.mkdir(parents=True, exist_ok=True)
    control = f"{q(doc['control_catalog'])}.{q(doc['control_schema'])}"
    inv = lit(doc["inventory_version"])
    digest = lit(contract_sha256(doc))
    azure = ["-- Run against Azure SQL. Idempotent: safe to re-run and safe for later waves.",
             "SET XACT_ABORT ON;", "BEGIN TRANSACTION;"]
    azure.extend([
        f"IF EXISTS (SELECT 1 FROM bridge.inventory_contracts WHERE inventory_version={inv} "
        f"AND contract_sha256<>{digest}) THROW 51011, 'Inventory contract changed; use a new version', 1;",
        f"IF NOT EXISTS (SELECT 1 FROM bridge.inventory_contracts WHERE inventory_version={inv}) "
        f"INSERT bridge.inventory_contracts(inventory_version,contract_sha256) VALUES ({inv},{digest});"])
    uc = ["-- Run against a Unity Catalog SQL warehouse as the deployment identity.",
          f"CREATE SCHEMA IF NOT EXISTS {control};",
          f"CREATE TABLE IF NOT EXISTS {control}.`published_targets` ("
          "target_key STRING NOT NULL, published_release_id STRING, previous_release_id STRING, "
          "high_water_sequence BIGINT, control_version BIGINT, published_at TIMESTAMP) USING DELTA "
          "TBLPROPERTIES ('delta.enableDeletionVectors'='true');",
          f"ALTER TABLE {control}.`published_targets` SET TBLPROPERTIES ('delta.enableDeletionVectors'='true');"]
    groups = {}
    for m in doc["mappings"]:
        member = (f"inventory_version={inv} AND mapping_id={lit(m['mapping_id'])}")
        same = (f"group_id={lit(m['group_id'])} AND enabled=1 AND mandatory={1 if m['mandatory'] else 0} "
                f"AND strategy={lit(m['strategy'])}")
        azure.append(f"IF EXISTS (SELECT 1 FROM bridge.group_members WHERE {member} AND NOT ({same})) "
                     f"THROW 51010, 'Seeded member {m['mapping_id']} differs from this config; use a new inventory version', 1;")
        azure.append(f"IF NOT EXISTS (SELECT 1 FROM bridge.group_members WHERE {member}) "
                     "INSERT bridge.group_members(inventory_version,group_id,mapping_id,enabled,mandatory,strategy) "
                     f"VALUES ({inv},{lit(m['group_id'])},{lit(m['mapping_id'])},1,"
                     f"{1 if m['mandatory'] else 0},{lit(m['strategy'])});")
        groups.setdefault(target_key(m), []).append(m)
        for s in ("candidate_schema", "target_schema", "physical_schema"):
            uc.append(f"CREATE SCHEMA IF NOT EXISTS {q(m['target_catalog'])}.{q(m[s])};")
        table_ddl, physical = physical_ddl(m)
        uc.append(table_ddl)
        key = lit(target_key(m))
        uc.append(f"MERGE INTO {control}.`published_targets` AS t USING (SELECT {key} AS target_key) AS s "
                  "ON t.target_key=s.target_key WHEN NOT MATCHED THEN INSERT "
                  "(target_key,published_release_id,previous_release_id,high_water_sequence,control_version,published_at) "
                  "VALUES (s.target_key,'NONE',NULL,-1,0,current_timestamp());")
        consumer = f"{q(m['target_catalog'])}.{q(m['target_schema'])}.{q(m['target_table'])}"
        selected = ", ".join(q(c["target"]) for c in m["columns"])
        selected += ", " + ", ".join(q(k) for k in METADATA_COLUMNS)
        uc.append("-- New target only. Review and migrate an existing table/view explicitly.\n"
                  f"CREATE VIEW {consumer} AS SELECT {selected} FROM {physical} "
                  f"WHERE mapping_object_id={lit(m['mapping_id'])} AND release_id=(SELECT published_release_id "
                  f"FROM {control}.`published_targets` WHERE target_key={key});")
    for key, members in groups.items():
        azure.append(f"IF NOT EXISTS (SELECT 1 FROM bridge.target_state WHERE target_key={lit(key)}) "
                     "INSERT bridge.target_state(target_key,published_release_id,published_sequence,high_water_sequence) "
                     f"VALUES ({lit(key)},'NONE',-1,-1);")
    azure.append("COMMIT;")
    (dest / "azure_sql_seed.sql").write_text("\n".join(azure) + "\n")
    (dest / "unity_catalog_setup.sql").write_text("\n".join(dict.fromkeys(uc)) + "\n")
    (dest / "unity_catalog_existing_targets.sql").write_text("\n".join(dict.fromkeys(
        line for line in uc if not line.startswith("-- New target only."))) + "\n")
    print(dest)


if __name__ == "__main__":
    main()
