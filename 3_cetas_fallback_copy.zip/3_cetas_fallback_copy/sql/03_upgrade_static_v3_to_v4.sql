-- Existing static v3 Azure SQL control database only. Fresh v4 installs use 01_azure_sql_control.sql.
-- Stop orchestrators, publishers and recovery commands for this short migration.
SET XACT_ABORT ON;
BEGIN TRANSACTION;
IF EXISTS (SELECT 1 FROM bridge.runs WHERE source_set_id IS NULL)
    THROW 51040, 'Resolve NULL source_set_id before v4 migration', 1;
IF EXISTS (SELECT 1 FROM bridge.runs GROUP BY source_set_id,upstream_run_id HAVING COUNT_BIG(*) > 1)
    THROW 51041, 'Resolve duplicate upstream nights before v4 migration', 1;
IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE object_id=OBJECT_ID(N'bridge.runs')
               AND name=N'UX_bridge_runs_source_upstream')
BEGIN
    ALTER TABLE bridge.runs ALTER COLUMN source_set_id nvarchar(128) NOT NULL;
    CREATE UNIQUE INDEX UX_bridge_runs_source_upstream
      ON bridge.runs(source_set_id,upstream_run_id);
END;
COMMIT TRANSACTION;
