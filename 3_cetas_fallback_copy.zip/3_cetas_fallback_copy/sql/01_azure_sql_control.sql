-- Static nightly bridge: new control databases only. Existing fenced v9 deployments require a reviewed migration.
-- Run in a dedicated Azure SQL Database using an administrator identity.
-- Replace database roles/grants with your named deployment, orchestrator and publisher identities.
IF SCHEMA_ID(N'bridge') IS NULL EXEC(N'CREATE SCHEMA bridge');
GO
CREATE TABLE bridge.inventory_contracts (
 inventory_version nvarchar(128) NOT NULL PRIMARY KEY,
 contract_sha256 char(64) NOT NULL
);
GO
CREATE TABLE bridge.runs (
 bridge_run_id nvarchar(128) NOT NULL PRIMARY KEY,
 upstream_run_id nvarchar(128) NOT NULL, generation_id nvarchar(128) NOT NULL,
 upstream_sequence bigint NOT NULL, business_date date NOT NULL,
 inventory_version nvarchar(128) NOT NULL, release_id nvarchar(128) NOT NULL UNIQUE,
 status varchar(24) NOT NULL CHECK(status IN ('CREATED','EXTRACTING','EXTRACTED','LOADING','READY','PUBLISHING','PUBLISHED','FAILED','PUBLICATION_ABANDONED','ABANDONED_GENERATION')),
 -- Orchestrator lease: every write by bridge_run.py/publish_run.py is conditional on the
 -- token; a process whose heartbeat is older than takeover_after_minutes can be taken over.
 orchestrator_token nvarchar(64) NULL,
 heartbeat_utc datetime2(3) NULL,
 created_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 updated_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 -- Source set plus upstream run identifies exactly one nightly extraction.
 source_set_id nvarchar(128) NOT NULL,
 contract_sha256 char(64) NOT NULL
);
GO
-- One bridge run per completed upstream load; a second run ID cannot duplicate the night.
CREATE UNIQUE INDEX UX_bridge_runs_source_upstream ON bridge.runs(source_set_id,upstream_run_id);
GO
CREATE TABLE bridge.object_attempts (
 bridge_run_id nvarchar(128) NOT NULL REFERENCES bridge.runs(bridge_run_id),
 mapping_id nvarchar(128) NOT NULL, attempt int NOT NULL CHECK(attempt>0),
 method varchar(16) NOT NULL CHECK(method IN ('CETAS','COPY_ACTIVITY')),
 status varchar(24) NOT NULL CHECK(status IN ('EXTRACTING','INDETERMINATE','EXTRACTED','LOADING','READY','FAILED','SUPERSEDED','ABANDONED_GENERATION')),
 -- Full attempt paths fit this length under the validated run/mapping ID limits.
 -- 700 NVARCHAR characters fit the 1,700-byte nonclustered key limit.
 leaf_path nvarchar(700) NOT NULL UNIQUE,
 source_request_id nvarchar(128) NULL, source_rows bigint NULL,
 parquet_rows bigint NULL, delta_rows bigint NULL,
 error_text nvarchar(2000) NULL,
 delta_target nvarchar(512) NULL,
 target_key nvarchar(512) NULL,
 publication_strategy varchar(16) NULL CHECK(publication_strategy IS NULL OR publication_strategy = 'REPLACE_TABLE'),
 consumer_target nvarchar(512) NULL,
 source_operation_state varchar(24) NULL,
 loader_run_id nvarchar(128) NULL,
 loader_operation_state varchar(24) NULL,
 updated_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 retired_utc datetime2(3) NULL,
 staging_deleted_utc datetime2(3) NULL,
 PRIMARY KEY(bridge_run_id,mapping_id,attempt)
);
GO
CREATE TABLE bridge.recovery_events (
 recovery_event_id bigint IDENTITY PRIMARY KEY,
 action varchar(32) NOT NULL,
 bridge_run_id nvarchar(128) NOT NULL,
 mapping_id nvarchar(128) NULL,
 attempt int NULL,
 target_key nvarchar(512) NULL,
 external_run_id nvarchar(128) NULL,
 actor nvarchar(128) NOT NULL,
 evidence_uri nvarchar(2048) NOT NULL,
 reason nvarchar(1000) NOT NULL,
 at_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
CREATE TABLE bridge.group_members (
 inventory_version nvarchar(128) NOT NULL,
 group_id nvarchar(128) NOT NULL,
 mapping_id nvarchar(128) NOT NULL,
 enabled bit NOT NULL, mandatory bit NOT NULL,
 strategy varchar(16) NOT NULL CHECK(strategy = 'REPLACE_TABLE'),
 PRIMARY KEY(inventory_version,mapping_id)
);
GO
CREATE TABLE bridge.target_state (
 -- 512 NVARCHAR characters fit the 1,700-byte nonclustered key limit.
 target_key nvarchar(512) NOT NULL PRIMARY KEY NONCLUSTERED,
 published_release_id nvarchar(128) NULL,
 published_sequence bigint NULL,
 high_water_sequence bigint NOT NULL DEFAULT -1,
 previous_release_id nvarchar(128) NULL,
 control_version bigint NOT NULL DEFAULT 0,
 -- Publication claim: only one bridge run may change a target's Delta state at a time.
 -- Cleared in the same update that records the publication; kept by the owning run if
 -- the outcome is unknown, so only that run's publish_run.py --resume can continue.
 publish_owner nvarchar(128) NULL,
 publish_token nvarchar(64) NULL,
 publish_claimed_utc datetime2(3) NULL,
 publish_external_run_id nvarchar(128) NULL,
 publish_operation_state varchar(24) NULL
);
GO
