-- Existing static v4 dedicated SQL pool metadata, only. Pause the nightly audit and bridge.
-- Replace the placeholder with the source_set_id used by EVERY existing audit row in this pool.
-- If rows represent multiple source sets, classify and backfill them separately before v5.
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'bridge_meta.upstream_run')
               AND name=N'source_set_id')
    ALTER TABLE bridge_meta.upstream_run ADD source_set_id varchar(128) NULL;
GO
IF NOT EXISTS (SELECT 1 FROM sys.columns WHERE object_id=OBJECT_ID(N'bridge_meta.upstream_object')
               AND name=N'source_set_id')
    ALTER TABLE bridge_meta.upstream_object ADD source_set_id varchar(128) NULL;
GO
-- Stop if the deployment placeholder was not reviewed.
IF '<existing-source-set-id>' LIKE '<%>'
    THROW 51050, 'Replace existing-source-set-id before backfill', 1;
UPDATE bridge_meta.upstream_run SET source_set_id='<existing-source-set-id>' WHERE source_set_id IS NULL;
UPDATE bridge_meta.upstream_object SET source_set_id='<existing-source-set-id>' WHERE source_set_id IS NULL;
IF EXISTS (SELECT 1 FROM bridge_meta.upstream_run WHERE source_set_id IS NULL)
    THROW 51051, 'Unscoped upstream_run audit rows remain', 1;
IF EXISTS (SELECT 1 FROM bridge_meta.upstream_object WHERE source_set_id IS NULL)
    THROW 51052, 'Unscoped upstream_object audit rows remain', 1;
