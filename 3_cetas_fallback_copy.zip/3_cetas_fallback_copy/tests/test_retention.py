"""Retention plans old physical releases while preserving both active pointers."""
import sys
from contextlib import contextmanager
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'python'))
import retire_releases as retention


class Cursor:
    def __init__(self, states, attempts):
        self.states, self.attempts = states, attempts
    def execute(self, sql):
        self.result = self.states if 'FROM bridge.target_state' in sql else self.attempts
        return self
    def fetchall(self):
        return self.result


class DB:
    def __init__(self, states, attempts):
        self.states, self.attempts = states, attempts
    def cursor(self):
        return Cursor(self.states, self.attempts)


def test_old_release_snapshot_retired_only_after_window_and_pointer_advance(monkeypatch):
    m = dict(mapping_id='MAP_001', group_id='customer', strategy='REPLACE_TABLE',
             target_catalog='analytics', target_schema='gold', target_table='customer',
             physical_schema='bridge_physical')
    cfg = dict(inventory_version='wave1', mappings=[m], retention_days_published=7)
    key = 'table:analytics.gold.customer'
    states = [(key, 'rel_3', 'rel_2', 3)]
    def attempt(release, seq, age):
        return (f'BRG{seq}', 'MAP_001', 1, f'analytics.bridge_candidate.candidate_{seq}',
                f'abfss://stage@acct.dfs.core.windows.net/bridge/parquet-stage/2026-09-25/BRG{seq}/MAP_001/attempt-001/',
                None, None, release, seq, 'PUBLISHED', key, 'REPLACE_TABLE',
                'analytics.gold.customer', 'wave1', 'SUCCEEDED', 'SUCCEEDED', 'READY', age)
    attempts = [attempt('rel_1', 1, 8*24), attempt('rel_2', 2, 8*24),
                attempt('rel_3', 3, 8*24), attempt('rel_recent', 0, 24)]
    @contextmanager
    def fake_db(_):
        yield DB(states, attempts)
    monkeypatch.setattr(retention, 'db', fake_db)
    groups, drops, _ = retention.plan(cfg, [])
    assert len(groups) == 1
    assert groups[0]['releases'] == ['rel_1']
    assert groups[0]['table']['table'] == 'customer_snapshots'
    assert {d['release_id'] for d in drops} == {'rel_1'}
