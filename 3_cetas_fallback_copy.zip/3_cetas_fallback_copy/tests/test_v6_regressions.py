"""Focused recovery and capacity checks for the static v6 bridge."""
import json
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace

import pytest

from test_flow_sim import env  # reuse the package's SQLite/external-service fixture
import bridge_run as br
import recovery
import render_setup
import publish_run as pub


def test_resume_bad_stored_path_releases_lease(env):
    env['run'](br, env['extract'])
    with env['db']('BRIDGE_CONTROL_ODBC') as conn:
        conn.cursor().execute("UPDATE bridge.object_attempts SET status='EXTRACTED',leaf_path='wrong' "
                              "WHERE attempt=2")
        conn.commit()
    with pytest.raises(RuntimeError, match='Stored leaf path'):
        env['run'](br, [*env['extract'], '--resume'])
    assert env['query']('SELECT status,orchestrator_token FROM bridge.runs') == [('FAILED', None)]


def test_completed_copy_mismatch_is_final_for_night(env, monkeypatch):
    def mismatch(cfg, mapping, item, started, terminal):
        started('copy-run-2')
        terminal('copy-run-2', 'SUCCEEDED')
        raise br.CopyCountMismatch('Copy reported 6 but audited 7')
    monkeypatch.setattr(br, 'copy_activity', mismatch)
    env['run'](br, env['extract'])
    assert env['query']('SELECT method,status,source_operation_state FROM bridge.object_attempts '
                        'WHERE attempt=2') == [('COPY_ACTIVITY', 'FAILED', 'SUCCEEDED')]
    env['run'](br, [*env['extract'], '--resume'])
    assert env['query']('SELECT count(*) FROM bridge.object_attempts') == [(2,)]


def test_loader_triggered_copy_obeys_large_class_limit(monkeypatch):
    lock = threading.Lock()
    active = [0, 0]
    def fake_extract(cfg, ctx, lease, mapping, attempt):
        with lock:
            active[0] += 1
            active[1] = max(active[1], active[0])
        threading.Event().wait(.025)
        with lock:
            active[0] -= 1
        return attempt
    monkeypatch.setattr(br, 'extract_one', fake_extract)
    ctx = {'extract_slots': {'global': threading.BoundedSemaphore(2),
                             'SMALL': threading.BoundedSemaphore(2),
                             'MEDIUM': threading.BoundedSemaphore(2),
                             'LARGE': threading.BoundedSemaphore(1)}}
    lease = SimpleNamespace(check=lambda: None)
    with ThreadPoolExecutor(max_workers=2) as pool:
        results = list(pool.map(lambda i: br.extract_with_limits({}, ctx, lease,
                              {'size_class': 'LARGE'}, i), (1, 2)))
    assert results == [1, 2] and active[1] == 1


def test_newer_target_does_not_abort_older_resume(env, capsys):
    env['run'](br, env['extract'])
    with env['db']('BRIDGE_CONTROL_ODBC') as conn:
        conn.cursor().execute('UPDATE bridge.target_state SET high_water_sequence=2')
        conn.commit()
    env['run'](br, [*env['extract'], '--resume'])
    result = json.loads(capsys.readouterr().out.splitlines()[-1])
    assert result['skipped'][0]['status'] == 'SUPERSEDED_BY_NEWER'
    assert result['ready'] == []


def test_resolve_publication_refuses_live_lease(env, tmp_path):
    env['run'](br, env['extract'])
    with env['db']('BRIDGE_CONTROL_ODBC') as conn:
        conn.cursor().execute("UPDATE bridge.runs SET status='PUBLISHING',orchestrator_token='live',"
                              "heartbeat_utc=SYSUTCDATETIME()")
        conn.cursor().execute("UPDATE bridge.target_state SET publish_owner='BRG1',"
                              "publish_external_run_id='job-1',publish_operation_state='RUNNING'")
        conn.commit()
    proof = tmp_path / 'proof.json'
    proof.write_text(json.dumps(dict(external_terminal=True, safe_to_resume=True,
                                     orchestrator_stopped=True, external_run_id='job-1',
                                     evidence_uri='evidence://terminal')))
    with pytest.raises(RuntimeError, match='Live orchestrator lease'):
        recovery.resolve_publication(SimpleNamespace(evidence=str(proof), bridge_run_id='BRG1',
                            target_key='table:analytics.gold.customer', takeover_after_minutes=150,
                            actor='operator', reason='terminal verified'))


def test_mandatory_skip_returns_distinct_exit_code(env, monkeypatch):
    cfg = json.loads(env['config_path'].read_text())
    cfg['mappings'][0]['mandatory'] = True
    env['config_path'].write_text(json.dumps(cfg))
    with env['db']('BRIDGE_CONTROL_ODBC') as conn:
        conn.cursor().execute('UPDATE bridge.inventory_contracts SET contract_sha256=?',
                              br.contract_sha256(cfg))
        conn.cursor().execute('UPDATE bridge.group_members SET mandatory=1')
        conn.commit()
    def fail_copy(cfg, mapping, item, started, terminal):
        started('copy-fail')
        terminal('copy-fail', 'FAILED')
        raise RuntimeError('Copy failed')
    monkeypatch.setattr(br, 'copy_activity', fail_copy)
    with pytest.raises(SystemExit) as exc:
        env['run'](br, env['extract'])
    assert exc.value.code == 2
    assert env['query']('SELECT status FROM bridge.runs') == [('READY',)]


def test_job_settings_checked_before_work(monkeypatch):
    sdk = SimpleNamespace(WorkspaceClient=lambda: SimpleNamespace(jobs=SimpleNamespace(
        get=lambda job_id: SimpleNamespace(settings=settings))))
    monkeypatch.setitem(sys.modules, 'databricks', SimpleNamespace(sdk=sdk))
    monkeypatch.setitem(sys.modules, 'databricks.sdk', sdk)
    task = SimpleNamespace(notebook_task=object(), max_retries=0, timeout_seconds=7200,
                           disable_auto_optimization=True, retry_on_timeout=False)
    settings = SimpleNamespace(max_concurrent_runs=8, tasks=[task], timeout_seconds=7200,
                               queue=SimpleNamespace(enabled=False))
    br.validate_job_capacity({'loader_job_id': 1, 'max_loader_workers': 8}, 'loader')
    task.max_retries = 1
    with pytest.raises(RuntimeError, match='retries'):
        br.validate_job_capacity({'loader_job_id': 1}, 'loader')
    task.max_retries = 0
    task.disable_auto_optimization = False
    with pytest.raises(RuntimeError, match='auto-optimization'):
        br.validate_job_capacity({'loader_job_id': 1}, 'loader')
    task.disable_auto_optimization = True
    task.max_retries = None
    with pytest.raises(RuntimeError, match='max_retries'):
        br.validate_job_capacity({'loader_job_id': 1}, 'loader')
    task.max_retries = 0
    task.retry_on_timeout = True
    with pytest.raises(RuntimeError, match='retry on timeout'):
        br.validate_job_capacity({'loader_job_id': 1}, 'loader')
    task.retry_on_timeout = False
    task.timeout_seconds = 0
    with pytest.raises(RuntimeError, match='timeout'):
        br.validate_job_capacity({'loader_job_id': 1}, 'loader')
    task.timeout_seconds = 7200
    settings.queue.enabled = True
    with pytest.raises(RuntimeError, match='queue'):
        br.validate_job_capacity({'loader_job_id': 1}, 'loader')


def test_release_dead_controller_requires_exact_external_ids(env, tmp_path):
    env['run'](br, env['extract'])
    with env['db']('BRIDGE_CONTROL_ODBC') as conn:
        conn.cursor().execute("UPDATE bridge.runs SET status='LOADING',orchestrator_token='dead',"
                              "heartbeat_utc=SYSUTCDATETIME()")
        conn.cursor().execute("UPDATE bridge.object_attempts SET status='LOADING',"
                              "loader_run_id='job-live',loader_operation_state='RUNNING' WHERE attempt=2")
        conn.commit()
    proof = tmp_path / 'dead.json'
    record = dict(orchestrator_stopped=True, external_terminal=True, safe_to_resume=True,
                  orchestrator_token='dead', external_ids=[], evidence_uri='evidence://dead')
    proof.write_text(json.dumps(record))
    args = SimpleNamespace(evidence=str(proof), bridge_run_id='BRG1', actor='operator', reason='host terminated')
    with pytest.raises(RuntimeError, match='enumerate'):
        recovery.release_dead_orchestrator(args)
    record['external_ids'] = ['job-live']
    proof.write_text(json.dumps(record))
    recovery.release_dead_orchestrator(args)
    assert env['query']('SELECT status,orchestrator_token FROM bridge.runs') == [('FAILED', None)]
    assert env['query']('SELECT loader_operation_state FROM bridge.object_attempts WHERE attempt=2') == [('RUNNING',)]


def test_release_id_is_first_for_wide_physical_table(env):
    mapping = json.loads(env['config_path'].read_text())['mappings'][0]
    ddl, _ = render_setup.physical_ddl(mapping)
    assert ddl.index('`release_id` STRING') < ddl.index('`' + mapping['columns'][0]['target'] + '`')


def test_failed_mandatory_publisher_is_reported_as_skip(env, monkeypatch, capsys):
    cfg = json.loads(env['config_path'].read_text())
    cfg['mappings'][0]['mandatory'] = True
    env['config_path'].write_text(json.dumps(cfg))
    with env['db']('BRIDGE_CONTROL_ODBC') as conn:
        conn.cursor().execute('UPDATE bridge.inventory_contracts SET contract_sha256=?',
                              br.contract_sha256(cfg))
        conn.cursor().execute('UPDATE bridge.group_members SET mandatory=1')
        conn.commit()
    env['run'](br, env['extract'])
    monkeypatch.setattr(pub, 'publish_group', lambda *args: 'skipped-failed-publisher')
    with pytest.raises(SystemExit) as exc:
        env['run'](pub, env['publish'])
    result = json.loads(capsys.readouterr().out.splitlines()[-1])
    assert exc.value.code == 2
    assert result['skipped'][0]['status'] == 'skipped-failed-publisher'
