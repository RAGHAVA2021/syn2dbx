"""Independent checks for COPY-fallback retries, recovery fencing, and manifest retirement."""
import json
from datetime import datetime, timezone
from types import SimpleNamespace

import pytest

import bridge_run as br
import recovery
import retire_releases as retention
import test_flow_sim as sim
from test_flow_sim import env


def test_live_controller_cannot_be_cleared_by_attempt_recovery(env, tmp_path):
    env['run'](br, env['extract'])
    with env['db']('BRIDGE_CONTROL_ODBC') as conn:
        conn.cursor().execute("UPDATE bridge.runs SET status='FAILED',orchestrator_token='live-token',"
                              "heartbeat_utc=SYSUTCDATETIME()")
        conn.cursor().execute("UPDATE bridge.object_attempts SET status='INDETERMINATE',"
                              "loader_run_id='job-1',loader_operation_state='UNKNOWN' WHERE attempt=2")
        conn.commit()
    proof = tmp_path / 'attempt.json'
    proof.write_text(json.dumps(dict(phase='LOADER',external_terminal=True,safe_to_retry=True,
                                     external_run_id='job-1',evidence_uri='evidence://loader')))
    args = SimpleNamespace(evidence=str(proof),bridge_run_id='BRG1',mapping_id='MAP_001',
                           attempt=2,actor='operator',reason='run finished',takeover_after_minutes=150)
    with pytest.raises(RuntimeError, match='Live orchestrator lease'):
        recovery.resolve_attempt(args)
    assert env['query']('SELECT orchestrator_token FROM bridge.runs') == [('live-token',)]
    assert env['query']('SELECT status FROM bridge.object_attempts WHERE attempt=2') == [('INDETERMINATE',)]

    # The separate, audited dead-controller operation fences the token first.
    dead = tmp_path / 'dead.json'
    dead.write_text(json.dumps(dict(orchestrator_stopped=True,external_terminal=True,
                                    safe_to_resume=True,orchestrator_token='live-token',
                                    external_ids=['job-1'],evidence_uri='evidence://host')))
    recovery.release_dead_orchestrator(SimpleNamespace(evidence=str(dead),bridge_run_id='BRG1',
                                                       actor='operator',reason='host terminated'))
    recovery.resolve_attempt(args)
    assert env['query']('SELECT status,orchestrator_token FROM bridge.runs') == [('FAILED',None)]
    assert env['query']('SELECT status FROM bridge.object_attempts WHERE attempt=2') == [('EXTRACTED',)]


def test_unpublished_manifest_retires_only_after_newer_pointer(env, monkeypatch):
    env['run'](br,env['extract'])
    with env['db']('BRIDGE_CONTROL_ODBC') as conn:
        conn.cursor().execute("UPDATE bridge.runs SET updated_utc='2026-07-01 00:00:00.000000'")
        conn.commit()
    blob = SimpleNamespace(name=br.MANIFEST_PREFIX + '/BRG1/' + 'a'*32 + '.json',
                           last_modified=datetime(2026,7,1,tzinfo=timezone.utc))
    deleted = []
    client = SimpleNamespace(list_blobs=lambda **kw:[blob],delete_blob=deleted.append)
    monkeypatch.setattr(retention,'db',env['db'])
    monkeypatch.setattr(retention,'container_client',lambda root:client)
    original = sim.translate
    monkeypatch.setattr(sim,'translate',lambda sql:original(sql).replace(
        'DATEDIFF(hour,', "DATEDIFF('hour',"))
    cfg = br.config(str(env['config_path']))
    assert retention.delete_old_manifests(cfg) == 0
    with env['db']('BRIDGE_CONTROL_ODBC') as conn:
        conn.cursor().execute('UPDATE bridge.target_state SET high_water_sequence=2')
        conn.commit()
    assert retention.delete_old_manifests(cfg) == 1
    assert deleted == [blob.name]
