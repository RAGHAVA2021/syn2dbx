"""Full static orchestration through SQLite control and fake external services."""
import json
import re
import sqlite3
import sys
from contextlib import contextmanager
from datetime import datetime, timedelta
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'python'))
import bridge_run as br
import publish_run as pub
import recovery
import upstream_audit
import render_setup
import source_metadata

CONTROL_DDL = """
CREATE TABLE bridge.inventory_contracts(inventory_version TEXT PRIMARY KEY, contract_sha256 TEXT);
CREATE TABLE bridge.runs(bridge_run_id TEXT PRIMARY KEY, upstream_run_id TEXT, generation_id TEXT,
 upstream_sequence INT, business_date TEXT, inventory_version TEXT, release_id TEXT UNIQUE, status TEXT,
 orchestrator_token TEXT, heartbeat_utc TEXT, created_utc TEXT, updated_utc TEXT, source_set_id TEXT,
 contract_sha256 TEXT, UNIQUE(source_set_id,upstream_run_id));
CREATE TABLE bridge.object_attempts(bridge_run_id TEXT, mapping_id TEXT, attempt INT, method TEXT, status TEXT,
 leaf_path TEXT UNIQUE, source_request_id TEXT, source_rows INT, parquet_rows INT, delta_rows INT,
 error_text TEXT, delta_target TEXT, target_key TEXT, publication_strategy TEXT, consumer_target TEXT,
 source_operation_state TEXT, loader_run_id TEXT, loader_operation_state TEXT,
 updated_utc TEXT, retired_utc TEXT, staging_deleted_utc TEXT,
 PRIMARY KEY(bridge_run_id,mapping_id,attempt));
CREATE TABLE bridge.group_members(inventory_version TEXT, group_id TEXT, mapping_id TEXT, enabled INT,
 mandatory INT, strategy TEXT, PRIMARY KEY(inventory_version,mapping_id));
CREATE TABLE bridge.recovery_events(action TEXT, bridge_run_id TEXT, mapping_id TEXT, attempt INT,
 target_key TEXT, external_run_id TEXT, actor TEXT, evidence_uri TEXT, reason TEXT);
CREATE TABLE bridge.target_state(target_key TEXT PRIMARY KEY, published_release_id TEXT, published_sequence INT,
 high_water_sequence INT DEFAULT -1, previous_release_id TEXT, control_version INT DEFAULT 0,
 publish_owner TEXT, publish_token TEXT, publish_claimed_utc TEXT, publish_external_run_id TEXT,
 publish_operation_state TEXT);
"""
SYN_DDL = """
CREATE TABLE bridge_meta.upstream_run(source_set_id TEXT, upstream_run_id TEXT, source_generation_id TEXT, upstream_sequence INT,
 business_date TEXT, status TEXT, write_closed INT, completed_utc TEXT);
CREATE TABLE bridge_meta.upstream_object(source_set_id TEXT, upstream_run_id TEXT, mapping_id TEXT, source_schema_version TEXT,
 status TEXT, row_count INT, refresh_started_utc TEXT, refresh_completed_utc TEXT);
"""
NOW = '2026-09-25 01:00:00.000000'


def translate(sql):
    sql = re.sub(r'\bINSERT (bridge|bridge_meta)\.', r'INSERT INTO \1.', sql)
    sql = sql.replace(' WITH (UPDLOCK,HOLDLOCK)', '')
    return (sql.replace('COUNT_BIG(', 'count(').replace('count_big(', 'count(')
            .replace('DATEADD(minute,', "DATEADD('minute',"))


class Cursor:
    def __init__(self, c):
        self.c = c.raw.cursor()
        self.rowcount = -1
    def execute(self, sql, *params):
        params = [str(p) if hasattr(p, 'isoformat') else p for p in params]
        self.c.execute(translate(sql), params)
        self.rowcount = self.c.rowcount
        return self
    def fetchone(self):
        return self.c.fetchone()
    def fetchall(self):
        return self.c.fetchall()
    def __iter__(self):
        return iter(self.c.fetchall())


class Conn:
    def __init__(self, path, schema):
        self.raw = sqlite3.connect(':memory:', isolation_level='DEFERRED', check_same_thread=False)
        self.raw.execute(f"ATTACH DATABASE '{path}' AS {schema}")
        self.raw.create_function('SYSUTCDATETIME', 0, lambda: NOW)
        self.raw.create_function('DATEADD', 3, lambda unit, n, value: (
            datetime.strptime(value, '%Y-%m-%d %H:%M:%S.%f') + timedelta(minutes=n)
        ).strftime('%Y-%m-%d %H:%M:%S.%f'))
        self.raw.create_function('DATEDIFF', 3, lambda unit, start, end: None if start is None or end is None else
                                 int((datetime.strptime(end, '%Y-%m-%d %H:%M:%S.%f') -
                                      datetime.strptime(start, '%Y-%m-%d %H:%M:%S.%f')).total_seconds() // 3600))
    def cursor(self):
        return Cursor(self)
    def commit(self):
        self.raw.commit()
    def rollback(self):
        self.raw.rollback()
    def close(self):
        self.raw.close()


@pytest.fixture
def env(tmp_path, monkeypatch):
    control_path, syn_path = tmp_path / 'control.db', tmp_path / 'syn.db'
    for path, schema, ddl in ((control_path, 'bridge', CONTROL_DDL), (syn_path, 'bridge_meta', SYN_DDL)):
        c = Conn(path, schema)
        c.raw.executescript(ddl)
        c.commit()
        c.close()

    @contextmanager
    def db(name, autocommit=False):
        conn = Conn(control_path, 'bridge') if name == 'BRIDGE_CONTROL_ODBC' else Conn(syn_path, 'bridge_meta')
        try:
            yield conn
        except BaseException:
            conn.rollback()
            raise
        finally:
            conn.close()

    cfg = json.loads((ROOT / 'config.example.json').read_text())
    cfg.update(control_catalog='analytics', staging_abfss_root='abfss://stage@acct.dfs.core.windows.net',
               loader_job_id=1, publisher_job_id=2, heartbeat_seconds=600)
    m = cfg['mappings'][0]
    m.update(target_catalog='analytics', source_schema_version='sha256:x')
    config_path = tmp_path / 'config.json'
    config_path.write_text(json.dumps(cfg))
    with db('BRIDGE_CONTROL_ODBC') as c:
        c.cursor().execute('INSERT INTO bridge.inventory_contracts VALUES (?,?)',
                           cfg['inventory_version'], br.contract_sha256(cfg))
        c.cursor().execute('INSERT INTO bridge.group_members VALUES (?,?,?,1,0,?)',
                           cfg['inventory_version'], m['group_id'], m['mapping_id'], m['strategy'])
        c.cursor().execute("INSERT INTO bridge.target_state(target_key,published_release_id,published_sequence,"
                           "high_water_sequence) VALUES (?,'NONE',-1,-1)", br.target_key(m))
        c.commit()
    with db('SYN') as c:
        c.cursor().execute("INSERT INTO bridge_meta.upstream_run VALUES "
                           "('synapse_materialised','UP1','GEN1',1,'2026-09-25','COMPLETE',1,NULL)")
        c.cursor().execute("INSERT INTO bridge_meta.upstream_object VALUES "
                           "('synapse_materialised','UP1',?,'sha256:x','COMPLETE',7,NULL,NULL)", m['mapping_id'])
        c.commit()

    log, live = [], {'customer': 'NONE'}
    def cetas(mapping, path, start, terminal):
        log.append(('cetas', path))
        start('source-1')
        terminal('source-1', 'FAILED')
        raise br.CetasRejected('test rejection')
    def copy(cfg, mapping, item, start, terminal):
        log.append(('copy', item['relative_path']))
        start('copy-run-2')
        terminal('copy-run-2', 'SUCCEEDED')
        return 'copy-run-2'
    def notebook(cfg, job_id, payload, run_id, start=None, terminal=None):
        if start:
            start('job-1')
        if 'leaf_path' in payload:
            assert payload['method'] == 'COPY_ACTIVITY'
            n = payload['source_rows']
            result = dict(source_rows=n, parquet_rows=n, delta_rows=n,
                          target=br.delta_target(payload, run_id, payload['attempt']))
        elif payload['mode'] == 'INSPECT':
            current = live['customer']
            result = dict(published_release_id=current, release_valid=current == payload['release_id'],
                          rows=payload['mapping']['source_rows'] if current == payload['release_id'] else None)
        else:
            live['customer'] = payload['release_id']
            result = dict(release_id=payload['release_id'], rows=payload['mapping']['source_rows'])
        if terminal:
            terminal('job-1', 'SUCCEEDED')
        return result
    monkeypatch.setattr(br, 'db', db)
    monkeypatch.setattr(pub, 'db', db)
    monkeypatch.setattr(br, 'validate_job_capacity', lambda *args: None)
    monkeypatch.setattr(pub, 'validate_job_capacity', lambda *args: None)
    monkeypatch.setattr(recovery, 'db', db)
    monkeypatch.setattr(upstream_audit, 'db', db)
    monkeypatch.setattr(br, 'cetas', cetas)
    monkeypatch.setattr(br, 'copy_activity', copy)
    monkeypatch.setattr(br, 'notebook_job', notebook)
    monkeypatch.setattr(pub, 'notebook_job', notebook)
    monkeypatch.setattr(br, 'require_empty_adls', lambda root, leaf: None)
    monkeypatch.setattr(source_metadata, 'schema_hash', lambda *args: 'sha256:x')

    evidence = tmp_path / 'evidence.json'
    ev = dict(bridge_run_id='BRG1', release_id='rel_BRG1', generation_id='GEN1', upstream_sequence=1)
    for gate in ('source_smoke_check', 'audit_health', 'policy_readiness',
                 'restricted_identity_tests', 'consumer_contract_tests'):
        ev[gate] = True
        ev[gate + '_evidence_uri'] = 'evidence://test/' + gate
    evidence.write_text(json.dumps(ev))
    extract = ['--config', str(config_path), '--upstream-run-id', 'UP1', '--generation-id', 'GEN1',
               '--sequence', '1', '--business-date', '2026-09-25', '--bridge-run-id', 'BRG1']
    publish = ['--config', str(config_path), '--bridge-run-id', 'BRG1', '--evidence', str(evidence)]
    def run(mod, args):
        monkeypatch.setattr(sys, 'argv', ['test', *args])
        mod.main()
    def query(sql, *params):
        with db('BRIDGE_CONTROL_ODBC') as c:
            return c.cursor().execute(sql, *params).fetchall()
    return dict(run=run, extract=extract, publish=publish, query=query, log=log,
                live=live, db=db, config_path=config_path)


def test_terminal_fallback_end_to_end(env):
    env['run'](br, env['extract'])
    assert env['query']('SELECT method,status,source_operation_state FROM bridge.object_attempts ORDER BY attempt') == [
        ('CETAS', 'FAILED', 'CETAS_REJECTED'), ('COPY_ACTIVITY', 'READY', 'SUCCEEDED')]
    assert env['log'][0][1] != env['log'][1][1]
    env['run'](pub, env['publish'])
    assert env['query']('SELECT status FROM bridge.runs') == [('PUBLISHED',)]
    assert env['query']('SELECT published_release_id FROM bridge.target_state') == [('rel_BRG1',)]


def test_failed_copy_attempt_resumes_on_copy_not_cetas(env, monkeypatch):
    original = br.copy_activity
    attempts = []
    def failing_once(cfg, mapping, item, start, terminal):
        attempts.append(item['attempt'])
        if len(attempts) == 1:
            start('copy-run-2')
            terminal('copy-run-2', 'FAILED')
            raise RuntimeError('Copy failed')
        return original(cfg, mapping, item, start, terminal)
    monkeypatch.setattr(br, 'copy_activity', failing_once)
    env['run'](br, env['extract'])
    assert env['query']('SELECT status FROM bridge.runs') == [('READY',)]
    env['run'](br, [*env['extract'], '--resume'])
    assert attempts == [2, 3]
    assert len([x for x in env['log'] if x[0] == 'cetas']) == 1
    assert env['query']('SELECT attempt,method,status FROM bridge.object_attempts ORDER BY attempt') == [
        (1, 'CETAS', 'FAILED'), (2, 'COPY_ACTIVITY', 'FAILED'), (3, 'COPY_ACTIVITY', 'READY')]


def test_crash_after_recording_rejected_cetas_resumes_on_copy(env, monkeypatch):
    # A transient local error happens after recording terminal CETAS, before Copy submission.
    original = br.copy_fallback_mapping
    with monkeypatch.context() as local:
        local.setattr(br, 'copy_fallback_mapping', lambda m: (_ for _ in ()).throw(
            RuntimeError('before Copy submission')))
        env['run'](br, env['extract'])
    assert env['query']('SELECT attempt,method,status,source_operation_state FROM bridge.object_attempts') == [
        (1, 'CETAS', 'FAILED', 'CETAS_REJECTED')]
    assert br.copy_fallback_mapping is original
    env['run'](br, [*env['extract'], '--resume'])
    assert env['query']('SELECT attempt,method,status FROM bridge.object_attempts ORDER BY attempt') == [
        (1, 'CETAS', 'FAILED'), (2, 'COPY_ACTIVITY', 'READY')]


def test_same_inventory_id_rejects_changed_column_contract(env):
    env['run'](br, env['extract'])
    config_path = Path(env['extract'][1])
    changed = json.loads(config_path.read_text())
    changed['mappings'][0]['columns'][1]['target_type'] = 'bigint'
    config_path.write_text(json.dumps(changed))
    with pytest.raises(RuntimeError, match='Inventory contract changed'):
        env['run'](pub, env['publish'])
    with pytest.raises(RuntimeError, match='Inventory contract changed'):
        env['run'](br, [*env['extract'], '--resume'])
    assert env['query']('SELECT status FROM bridge.runs') == [('READY',)]


def test_approved_empty_source_publishes_zero_row_release(env):
    path = env['config_path']
    cfg = json.loads(path.read_text())
    cfg['mappings'][0]['allow_empty'] = True
    path.write_text(json.dumps(cfg))
    with env['db']('BRIDGE_CONTROL_ODBC') as c:
        c.cursor().execute('UPDATE bridge.inventory_contracts SET contract_sha256=?', br.contract_sha256(cfg))
        c.commit()
    with env['db']('SYN') as c:
        c.cursor().execute('UPDATE bridge_meta.upstream_object SET row_count=0')
        c.commit()
    env['run'](br, env['extract'])
    assert env['query']("SELECT source_rows,parquet_rows,delta_rows FROM bridge.object_attempts "
                        "WHERE status='READY'") == [(0, 0, 0)]
    env['run'](pub, env['publish'])
    assert env['query']('SELECT status FROM bridge.runs') == [('PUBLISHED',)]


def test_copy_failure_skips_one_table_and_preserves_old_release(env, monkeypatch):
    cfg = json.loads(env['config_path'].read_text())
    other = dict(cfg['mappings'][0], mapping_id='MAP_002', group_id='independent_other',
                 source_view='v_other', target_table='other', materialised_table='other')
    cfg['mappings'].append(other)
    env['config_path'].write_text(json.dumps(cfg))
    with env['db']('BRIDGE_CONTROL_ODBC') as c:
        c.cursor().execute('UPDATE bridge.inventory_contracts SET contract_sha256=?', br.contract_sha256(cfg))
        c.cursor().execute('INSERT INTO bridge.group_members VALUES (?,?,?,1,0,?)',
                           cfg['inventory_version'], other['group_id'], other['mapping_id'], other['strategy'])
        c.cursor().execute("INSERT INTO bridge.target_state(target_key,published_release_id,published_sequence,"
                           "high_water_sequence) VALUES (?,'rel_yesterday',0,0)", br.target_key(other))
        c.commit()
    with env['db']('SYN') as c:
        c.cursor().execute("INSERT INTO bridge_meta.upstream_object VALUES "
                           "('synapse_materialised','UP1','MAP_002','sha256:x','COMPLETE',7,NULL,NULL)")
        c.commit()
    original = br.copy_activity
    def copy_one_fails(cfg, mapping, item, started, terminal):
        if mapping['mapping_id'] == 'MAP_002':
            started('copy-other')
            terminal('copy-other', 'FAILED')
            raise RuntimeError('Copy failed for MAP_002')
        return original(cfg, mapping, item, started, terminal)
    monkeypatch.setattr(br, 'copy_activity', copy_one_fails)
    env['run'](br, env['extract'])
    assert env['query']('SELECT mapping_id,status FROM bridge.object_attempts WHERE attempt=2 ORDER BY mapping_id') == [
        ('MAP_001', 'READY'), ('MAP_002', 'FAILED')]
    env['run'](pub, env['publish'])
    assert env['query']('SELECT target_key,published_release_id FROM bridge.target_state ORDER BY target_key') == [
        (br.target_key(cfg['mappings'][0]), 'rel_BRG1'), (br.target_key(other), 'rel_yesterday')]


def test_rejected_empty_audit_preserves_previous_release(env):
    with env['db']('SYN') as c:
        c.cursor().execute("UPDATE bridge_meta.upstream_object SET row_count=0,status='REJECTED'")
        c.commit()
    with env['db']('BRIDGE_CONTROL_ODBC') as c:
        c.cursor().execute("UPDATE bridge.target_state SET published_release_id='rel_yesterday',"
                           "published_sequence=0,high_water_sequence=0")
        c.commit()
    env['run'](br, env['extract'])
    assert env['query']('SELECT count(*) FROM bridge.object_attempts') == [(0,)]
    env['run'](pub, env['publish'])
    assert env['query']('SELECT published_release_id FROM bridge.target_state') == [('rel_yesterday',)]


def test_permanent_loader_rejection_is_skipped_on_resume(env, monkeypatch):
    def rejected(cfg, job_id, payload, run_id, started=None, terminal=None):
        if started:
            started('loader-1')
            terminal('loader-1', 'FAILED')
        raise br.LoaderRejected('Parquet columns/order differ: bad source')
    monkeypatch.setattr(br, 'notebook_job', rejected)
    env['run'](br, env['extract'])
    assert env['query']('SELECT method,status,loader_operation_state FROM bridge.object_attempts '
                        'ORDER BY attempt') == [
        ('CETAS', 'FAILED', None), ('COPY_ACTIVITY', 'FAILED', 'REJECTED')]
    env['run'](br, [*env['extract'], '--resume'])
    assert env['query']('SELECT count(*) FROM bridge.object_attempts') == [(2,)]


def test_recovered_terminal_cetas_failure_routes_to_copy(env, monkeypatch, tmp_path):
    def uncertain(mapping, path, started, terminal):
        started('source-1')
        raise br.Indeterminate('polling lost')
    monkeypatch.setattr(br, 'cetas', uncertain)
    env['run'](br, env['extract'])
    assert env['query']('SELECT status,source_operation_state FROM bridge.object_attempts') == [
        ('INDETERMINATE', 'UNKNOWN')]
    proof = tmp_path / 'proof.json'
    proof.write_text(json.dumps(dict(phase='SOURCE', external_terminal=True, safe_to_retry=True,
                                     external_failed=True, external_run_id='source-1',
                                     evidence_uri='evidence://source-1')))
    from types import SimpleNamespace
    recovery.resolve_attempt(SimpleNamespace(evidence=str(proof), bridge_run_id='BRG1',
                                             mapping_id='MAP_001', attempt=1, actor='operator',
                                             reason='Confirmed Synapse terminal error'))
    env['run'](br, [*env['extract'], '--resume'])
    assert env['query']('SELECT attempt,method,status FROM bridge.object_attempts ORDER BY attempt') == [
        (1, 'CETAS', 'FAILED'), (2, 'COPY_ACTIVITY', 'READY')]


def test_abandon_claim_refuses_pointer_divergence(env, tmp_path):
    env['run'](br, env['extract'])
    with env['db']('BRIDGE_CONTROL_ODBC') as c:
        c.cursor().execute("UPDATE bridge.runs SET status='PUBLISHING'")
        c.cursor().execute("UPDATE bridge.target_state SET publish_owner='BRG1',"
                           "publish_external_run_id='job-1',published_release_id='rel_yesterday'")
        c.commit()
    proof = tmp_path / 'abandon.json'
    proof.write_text(json.dumps(dict(external_terminal=True,delta_state_verified=True,safe_to_abandon=True,
                                     external_run_id='job-1',delta_published_release_id='rel_BRG1',
                                     evidence_uri='evidence://pointer')))
    from types import SimpleNamespace
    with pytest.raises(RuntimeError, match='pointer differs'):
        recovery.abandon_publication(SimpleNamespace(evidence=str(proof),bridge_run_id='BRG1',
                                                     target_key='table:analytics.gold.customer',actor='operator',
                                                     reason='11am cutoff'))
    assert env['query']('SELECT publish_owner FROM bridge.target_state') == [('BRG1',)]


def test_resolving_skipped_unknown_after_publish_allows_retention(env, monkeypatch, tmp_path):
    def uncertain(mapping, path, started, terminal):
        started('source-1')
        raise br.Indeterminate('polling lost')
    monkeypatch.setattr(br, 'cetas', uncertain)
    env['run'](br, env['extract'])
    env['run'](pub, env['publish'])
    proof = tmp_path / 'terminal.json'
    proof.write_text(json.dumps(dict(phase='SOURCE',external_terminal=True,safe_to_retry=True,
                                     external_run_id='source-1',evidence_uri='evidence://terminal')))
    from types import SimpleNamespace
    recovery.resolve_attempt(SimpleNamespace(evidence=str(proof),bridge_run_id='BRG1',
                                             mapping_id='MAP_001',attempt=1,actor='operator',
                                             reason='Terminal verified after cutoff'))
    assert env['query']('SELECT status,source_operation_state FROM bridge.object_attempts') == [
        ('FAILED', 'VERIFIED_TERMINAL')]


def test_second_run_id_cannot_duplicate_upstream_night(env):
    env['run'](br, env['extract'])
    with pytest.raises(RuntimeError, match='already belongs'):
        env['run'](br, [*env['extract'][:-1], 'BRG2'])
    assert env['query']('SELECT count(*) FROM bridge.runs') == [(1,)]


def test_unresolved_source_does_not_block_other_table_retry(env, monkeypatch):
    cfg = json.loads(env['config_path'].read_text())
    other = dict(cfg['mappings'][0], mapping_id='MAP_002', group_id='independent_other',
                 source_view='v_other', target_table='other', materialised_table='other')
    cfg['mappings'].append(other)
    env['config_path'].write_text(json.dumps(cfg))
    with env['db']('BRIDGE_CONTROL_ODBC') as c:
        c.cursor().execute('UPDATE bridge.inventory_contracts SET contract_sha256=?', br.contract_sha256(cfg))
        c.cursor().execute('INSERT INTO bridge.group_members VALUES (?,?,?,1,0,?)',
                           cfg['inventory_version'],other['group_id'],other['mapping_id'],other['strategy'])
        c.cursor().execute("INSERT INTO bridge.target_state(target_key,published_release_id,published_sequence,"
                           "high_water_sequence) VALUES (?,'NONE',-1,-1)",br.target_key(other))
        c.commit()
    with env['db']('SYN') as c:
        c.cursor().execute("INSERT INTO bridge_meta.upstream_object VALUES "
                           "('synapse_materialised','UP1','MAP_002','sha256:x','COMPLETE',7,NULL,NULL)")
        c.commit()
    original_cetas, original_copy = br.cetas, br.copy_activity
    calls = []
    def cetas(mapping, path, started, terminal):
        if mapping['mapping_id'] == 'MAP_002':
            started('uncertain-2')
            raise br.Indeterminate('source unknown')
        return original_cetas(mapping,path,started,terminal)
    def copy(cfg, mapping, item, started, terminal):
        if mapping['mapping_id'] == 'MAP_001':
            calls.append(item['attempt'])
            if len(calls) == 1:
                started('copy-fail')
                terminal('copy-fail','FAILED')
                raise RuntimeError('transient Copy failure')
        return original_copy(cfg,mapping,item,started,terminal)
    monkeypatch.setattr(br,'cetas',cetas)
    monkeypatch.setattr(br,'copy_activity',copy)
    env['run'](br, env['extract'])
    env['run'](br, [*env['extract'],'--resume'])
    assert calls == [2,3]
    assert env['query']('SELECT mapping_id,status FROM bridge.object_attempts WHERE '
                        'attempt=(SELECT MAX(x.attempt) FROM bridge.object_attempts x '
                        'WHERE x.mapping_id=bridge.object_attempts.mapping_id) ORDER BY mapping_id') == [
        ('MAP_001','READY'),('MAP_002','INDETERMINATE')]


def test_clean_publisher_failure_releases_claim(env, monkeypatch):
    original = pub.notebook_job
    def fail_publish(cfg, job, payload, run_id, started=None, terminal=None):
        if payload.get('mode') == 'PUBLISH':
            started('publisher-1')
            terminal('publisher-1','FAILED')
            raise RuntimeError('terminal failed publisher')
        return original(cfg,job,payload,run_id,started,terminal)
    monkeypatch.setattr(pub,'notebook_job',fail_publish)
    env['run'](br, env['extract'])
    env['run'](pub, env['publish'])
    assert env['query']('SELECT status FROM bridge.runs') == [('PUBLISHED',)]
    assert env['query']('SELECT published_release_id,publish_owner FROM bridge.target_state') == [('NONE',None)]


def test_loader_rejects_cetas_parquet_and_copy_succeeds(env, monkeypatch):
    original = br.notebook_job
    def loader(cfg,job,payload,run_id,started=None,terminal=None):
        if payload.get('method') == 'CETAS' and 'leaf_path' in payload:
            started('loader-cetas')
            terminal('loader-cetas','FAILED')
            raise br.LoaderRejected('Physical/logical type drift in sentinel')
        return original(cfg,job,payload,run_id,started,terminal)
    monkeypatch.setattr(br,'notebook_job',loader)
    def successful_cetas(mapping,path,started,terminal):
        started('cetas-success')
        terminal('cetas-success','SUCCEEDED')
        return 'cetas-success'
    monkeypatch.setattr(br,'cetas',successful_cetas)
    env['run'](br,env['extract'])
    assert env['query']('SELECT method,status FROM bridge.object_attempts ORDER BY attempt') == [
        ('CETAS','FAILED'),('COPY_ACTIVITY','READY')]


def test_broken_view_is_rejected_without_aborting_audit(env, monkeypatch):
    def missing(*args):
        raise ValueError('view has no columns')
    monkeypatch.setattr(upstream_audit,'schema_hash',missing)
    with env['db']('SYN') as c:
        c.cursor().execute('DELETE FROM bridge_meta.upstream_object')
        c.cursor().execute('DELETE FROM bridge_meta.upstream_run')
        c.commit()
    env['run'](upstream_audit,['--config',str(env['config_path']),'--upstream-run-id','UP1',
                                '--generation-id','GEN1','--sequence','1',
                                '--business-date','2026-09-25'])
    with env['db']('SYN') as c:
        assert c.cursor().execute('SELECT status,row_count FROM bridge_meta.upstream_object').fetchall() == [
            ('REJECTED',-1)]


def test_second_source_set_can_audit_same_upstream_id(env, tmp_path):
    cfg = json.loads(env['config_path'].read_text())
    cfg['source_set_id'] = 'other_source'
    cfg['inventory_version'] = 'wave_002_v1'
    path = tmp_path / 'other.json'
    path.write_text(json.dumps(cfg))
    with env['db']('BRIDGE_CONTROL_ODBC') as c:
        c.cursor().execute('INSERT INTO bridge.inventory_contracts VALUES (?,?)',
                           cfg['inventory_version'],br.contract_sha256(cfg))
        c.commit()
    env['run'](upstream_audit,['--config',str(path),'--upstream-run-id','UP1',
                                '--generation-id','GEN1','--sequence','1',
                                '--business-date','2026-09-25'])
    with env['db']('SYN') as c:
        assert c.cursor().execute('SELECT source_set_id FROM bridge_meta.upstream_run '
                                  'ORDER BY source_set_id').fetchall() == [
            ('other_source',),('synapse_materialised',)]


def test_orphaned_external_attempt_is_skipped_on_resume(env):
    env['run'](br,env['extract'])
    with env['db']('BRIDGE_CONTROL_ODBC') as c:
        c.cursor().execute("UPDATE bridge.runs SET status='FAILED',orchestrator_token=NULL")
        c.cursor().execute("UPDATE bridge.object_attempts SET status='EXTRACTING',"
                           "source_operation_state='RUNNING' WHERE attempt=2")
        c.commit()
    env['run'](br,[*env['extract'],'--resume'])
    assert env['query']('SELECT status FROM bridge.runs') == [('READY',)]
    assert env['query']('SELECT status,source_operation_state FROM bridge.object_attempts '
                        'WHERE attempt=2') == [('INDETERMINATE','UNKNOWN')]


def test_existing_inventory_setup_keeps_consumer_view(env, monkeypatch, tmp_path):
    out = tmp_path / 'setup'
    monkeypatch.setattr(sys,'argv',['render_setup','--config',str(env['config_path']),
                                    '--output-dir',str(out)])
    render_setup.main()
    assert 'CREATE VIEW ' in (out / 'unity_catalog_setup.sql').read_text()
    assert 'CREATE VIEW ' not in (out / 'unity_catalog_existing_targets.sql').read_text()
