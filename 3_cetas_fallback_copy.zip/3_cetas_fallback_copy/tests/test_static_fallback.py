import copy
import json
import sys
import threading
from contextlib import contextmanager
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'python'))
import bridge_run as br
import publish_run


def test_copy_deployment_rejects_wrong_sink_container():
    syn = dict(synapse_linked_service='sql_pool', adls_linked_service='storage')
    source = {'properties': {'linkedServiceName': {'referenceName': 'sql_pool'}}}
    sink = {'properties': {'linkedServiceName': {'referenceName': 'storage'},
                           'typeProperties': {'location': {'fileSystem': 'wrong',
                             'folderPath': {'value': '@dataset().folder'}}}}}
    pipeline = {'properties': {'activities': [{'name': 'CopyApprovedProjection', 'type': 'Copy',
                'typeProperties': {'source': {'type': 'SqlDWSource', 'partitionOption': 'None',
                    'sqlReaderQuery': {'value': "@concat('SELECT ',pipeline().parameters.projection,' FROM [',"
                        "pipeline().parameters.sourceSchema,'].[',pipeline().parameters.sourceView,']')"}},
                    'parallelCopies': 1},
                'inputs': [{'referenceName': 'bridge_synapse_source'}],
                'outputs': [{'referenceName': 'bridge_parquet_sink', 'parameters': {
                    'folder': {'value': '@pipeline().parameters.relativePath'}}}]}]}}
    with pytest.raises(RuntimeError, match='sink container'):
        br.validate_copy_artifacts(source, sink, pipeline, syn, 'stage')
    sink['properties']['typeProperties']['location']['fileSystem'] = 'stage'
    br.validate_copy_artifacts(source, sink, pipeline, syn, 'stage')
    pipeline['properties']['activities'][0]['typeProperties']['source']['sqlReaderQuery']['value'] = 'SELECT other'
    with pytest.raises(RuntimeError, match='source query'):
        br.validate_copy_artifacts(source, sink, pipeline, syn, 'stage')


def test_fast_table_is_sent_to_loader_before_slow_extract_finishes(monkeypatch):
    release_slow = threading.Event()
    observed = []
    def extract(cfg, ctx, lease, mapping, attempt):
        if mapping['mapping_id'] == 'slow':
            if not release_slow.wait(timeout=2):
                raise AssertionError('fast table was not dispatched during extraction')
        return {'mapping_id': mapping['mapping_id']}
    monkeypatch.setattr(br, 'extract_one', extract)
    def dispatch(item):
        observed.append(item['mapping_id'])
        if item['mapping_id'] == 'fast':
            release_slow.set()
    work = [({'mapping_id':'slow','size_class':'MEDIUM'},1),
            ({'mapping_id':'fast','size_class':'MEDIUM'},1)]
    objects, errors = br.run_extractions({'max_extraction_workers':2}, {},
                                          type('Lease',(),{'lost':False})(), work, dispatch)
    assert not errors and len(objects) == 2 and observed[0] == 'fast'


class Cursor:
    rowcount = 1
    def __init__(self, log):
        self.log = log
    def execute(self, sql, *params):
        self.log.append((sql, params))
        return self


class DB:
    def __init__(self, log):
        self.log = log
    def cursor(self):
        return Cursor(self.log)
    def commit(self):
        pass


class Lease:
    def check(self):
        pass


@pytest.fixture
def mapping():
    data = json.loads((ROOT / 'config.example.json').read_text())
    m = copy.deepcopy(data['mappings'][0])
    m['columns'].append({'source': 'as_of', 'target': 'as_of', 'source_spark_type': 'date',
                         'target_type': 'date', 'conversion': 'DIRECT'})
    return m


@pytest.fixture
def environment(monkeypatch, mapping):
    log, routes, paths = [], [], []
    @contextmanager
    def db(_):
        yield DB(log)
    monkeypatch.setattr(br, 'db', db)
    monkeypatch.setattr(br, 'require_empty_adls', lambda root, path: paths.append(path))
    cfg = {'staging_abfss_root': 'abfss://stage@account.dfs.core.windows.net',
           'inventory_version': 'wave1', 'control_catalog': 'analytics',
           'control_schema': 'bridge_control', 'max_attempts': 3}
    ctx = {'run_id': 'BRG1', 'release': 'rel_BRG1', 'generation_id': 'gen1',
           'upstream_run_id': 'up1', 'sequence': 1, 'business_date': '2026-09-25',
           'rows': {mapping['mapping_id']: 7}, 'token': 'lease1'}
    return monkeypatch, log, routes, paths, cfg, ctx


def test_terminal_cetas_rejection_switches_to_copy_with_new_path_and_date_contract(mapping, environment):
    monkeypatch, log, routes, paths, cfg, ctx = environment
    def cetas(_m, _path, start, terminal):
        start('cetas-1')
        terminal('cetas-1', 'FAILED')
        raise br.CetasRejected('confirmed rejection')
    def copy_run(_cfg, m, item, start, terminal):
        routes.append((m, item))
        start('copy-2')
        terminal('copy-2', 'SUCCEEDED')
        return 'copy-2'
    monkeypatch.setattr(br, 'cetas', cetas)
    monkeypatch.setattr(br, 'copy_activity', copy_run)
    result = br.extract_one(cfg, ctx, Lease(), mapping, 1)
    assert result['attempt'] == 2
    assert result['method'] == 'COPY_ACTIVITY'
    assert result['columns'][-1]['source_spark_type'] == 'timestamp'
    assert mapping['columns'][-1]['source_spark_type'] == 'date'
    assert paths == [br.attempt_relative_path('2026-09-25', 'BRG1', mapping['mapping_id'], n)
                     for n in (1, 2)]
    assert len(routes) == 1
    inserts = [params for sql, params in log if 'INSERT bridge.object_attempts' in sql]
    assert [params[3] for params in inserts] == ['CETAS', 'COPY_ACTIVITY']
    assert any('CETAS_REJECTED' in params for _, params in log)


def test_unknown_cetas_outcome_does_not_start_copy(mapping, environment):
    monkeypatch, log, routes, paths, cfg, ctx = environment
    def unknown(_m, _path, start, terminal):
        start('cetas-1')
        raise br.Indeterminate('outcome unknown')
    monkeypatch.setattr(br, 'cetas', unknown)
    monkeypatch.setattr(br, 'copy_activity', lambda *args: routes.append(args))
    with pytest.raises(br.Indeterminate):
        br.extract_one(cfg, ctx, Lease(), mapping, 1)
    assert len(paths) == 1 and not routes
    assert any('UNKNOWN' in params for _, params in log)


def test_resume_keeps_copy_route(mapping):
    copy_route = br.mapped_route(mapping, 'CETAS', 'CETAS_REJECTED')
    assert copy_route['method'] == 'COPY_ACTIVITY'
    assert br.mapped_route(mapping, 'COPY_ACTIVITY', 'FAILED')['method'] == 'COPY_ACTIVITY'
    assert br.mapped_route(mapping, 'CETAS', 'FAILED')['method'] == 'CETAS'
    m = dict(mapping, fallback_method=None)
    with pytest.raises(RuntimeError, match='Stored extraction route'):
        br.mapped_route(m, 'COPY_ACTIVITY', 'FAILED')


def test_resume_requires_inspected_governance_and_provenance():
    seen = {'published_release_id': 'rel_BRG1', 'rows': 7, 'release_valid': True}
    assert publish_run.replace_state_is_this_release(seen, 'rel_BRG1', 7)
    assert not publish_run.replace_state_is_this_release(dict(seen, release_valid=False), 'rel_BRG1', 7)


def test_static_control_has_no_writer_fence():
    ddl = (ROOT / 'sql/01_azure_sql_control.sql').read_text()
    assert 'CREATE TABLE bridge.source_fence' not in ddl
    assert 'CREATE OR ALTER PROCEDURE bridge.transition_fence' not in ddl
    assert 'bridge.fence_events' not in Path(publish_run.__file__).read_text()
