"""Exercise the actual publisher notebook with a small in-memory Delta SQL stand-in."""
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace as NS

import pytest

SCRIPT = Path(__file__).resolve().parents[1] / 'databricks/publish.py'
PROPS = {'delta.deletedFileRetentionDuration': 'interval 30 days',
         'delta.logRetentionDuration': 'interval 30 days',
         'delta.setTransactionRetentionDuration': 'interval 30 days'}


class NotebookExit(Exception):
    def __init__(self, value):
        self.value = json.loads(value)


class MockSpark:
    def __init__(self, body, *, empty=False, bad_properties=False):
        self.body = body
        self.pointer = NS(published_release_id='NONE', high_water_sequence=-1, control_version=0)
        self.candidate = [] if empty else [dict(source_generation_id='GEN1', bridge_run_id='BRG1',
                                                 load_attempt='1') for _ in range(7)]
        self.snapshot = []
        self.props = dict(PROPS)
        if bad_properties:
            self.props['delta.logRetentionDuration'] = 'interval 7 days'
        self.insert_count = 0
        self.update_count = 0
        self.fail_pointer_ack_once = False
        self.fail_insert_ack_once = False
        self.read = self
        self.conf = NS(set=lambda *args: None)
    def option(self, *args):
        return self
    def text(self, path):
        return NS(first=lambda: [self.body])
    def table(self, path):
        fields = [NS(name=k, dataType=NS(simpleString=lambda typ=v: typ)) for k, v in
                  [('customer_id', 'bigint'), ('release_id', 'string'), ('mapping_object_id', 'string'),
                   ('source_generation_id', 'string'), ('bridge_run_id', 'string'),
                   ('upstream_run_id', 'string'), ('upstream_sequence', 'string'),
                   ('business_date', 'string'), ('load_attempt', 'string'),
                   ('group_contract_version', 'string')]]
        return NS(schema=NS(fields=fields))
    def sql(self, sql):
        if sql.startswith('SHOW TBLPROPERTIES'):
            props = self.props if '_snapshots' in sql else PROPS
            return NS(collect=lambda: [NS(key=k, value=v) for k, v in props.items()])
        if sql.startswith('SELECT published_release_id, high_water_sequence, control_version'):
            return NS(collect=lambda: [self.pointer])
        if sql.startswith('SELECT count(*) n, count(DISTINCT'):
            rows = self.snapshot if '_snapshots' in sql else self.candidate
            row = NS(n=len(rows), g=len({r['source_generation_id'] for r in rows}),
                     b=len({r['bridge_run_id'] for r in rows}),
                     a=len({r['load_attempt'] for r in rows}),
                     gi=rows[0]['source_generation_id'] if rows else None,
                     bi=rows[0]['bridge_run_id'] if rows else None,
                     ai=rows[0]['load_attempt'] if rows else None)
            return NS(collect=lambda: [row])
        if sql.startswith('SELECT min(source_generation_id)'):
            row = self.candidate[0]
            return NS(collect=lambda: [NS(g=row['source_generation_id'], b=row['bridge_run_id'],
                                          a=row['load_attempt'])])
        if sql.startswith('SELECT count(*) n FROM'):
            return NS(collect=lambda: [NS(n=len(self.snapshot))])
        if sql.startswith('INSERT INTO'):
            self.insert_count += 1
            self.snapshot = list(self.candidate)
            if self.fail_insert_ack_once:
                self.fail_insert_ack_once = False
                raise RuntimeError('append committed; acknowledgement lost')
            return NS(collect=lambda: [])
        if sql.startswith('UPDATE'):
            assert self.pointer.published_release_id == 'NONE'
            self.pointer = NS(published_release_id='rel_BRG1', high_water_sequence=1,
                              control_version=self.pointer.control_version + 1)
            self.update_count += 1
            if self.fail_pointer_ack_once:
                self.fail_pointer_ack_once = False
                raise RuntimeError('pointer committed; acknowledgement lost')
            return NS(collect=lambda: [])
        raise AssertionError(sql)


def payload(empty=False):
    return dict(strategy='REPLACE_TABLE', mode='PUBLISH', release_id='rel_BRG1', bridge_run_id='BRG1',
                upstream_sequence=1, expected_current_release='NONE', control_catalog='analytics',
                control_schema='bridge_control', mapping=dict(mapping_id='MAP_001', generation_id='GEN1',
                source_rows=0 if empty else 7, target_catalog='analytics', target_schema='gold',
                target_table='customer', candidate_schema='bridge_candidate', candidate_table='candidate_a1',
                physical_schema='bridge_physical', attempt=1, consumer_properties=PROPS,
                columns=[dict(target='customer_id', target_type='bigint')]))


def execute(spark, p):
    body = json.dumps(p)
    spark.body = body
    digest = hashlib.sha256(body.encode()).hexdigest()
    widgets = NS(text=lambda *args: None, get=lambda key: (
        'abfss://stage@acct.dfs.core.windows.net/bridge/parquet-stage/_manifests/BRG1/' + 'a'*32 + '.json'
        if key == 'manifest_path' else digest))
    dbutils = NS(widgets=widgets, notebook=NS(exit=lambda value: (_ for _ in ()).throw(NotebookExit(value))))
    with pytest.raises(NotebookExit) as out:
        exec(compile(SCRIPT.read_text(), str(SCRIPT), 'exec'), dict(spark=spark, dbutils=dbutils))
    return out.value.value


def test_invalid_physical_properties_never_change_pointer():
    p = payload()
    spark = MockSpark('', bad_properties=True)
    with pytest.raises(ValueError, match='Governed'):
        execute(spark, p)
    assert spark.pointer.published_release_id == 'NONE'
    assert spark.insert_count == spark.update_count == 0


def test_commit_then_lost_ack_retries_without_duplicate_rows():
    p = payload()
    spark = MockSpark('')
    spark.fail_pointer_ack_once = True
    with pytest.raises(RuntimeError, match='acknowledgement lost'):
        execute(spark, p)
    assert spark.pointer.published_release_id == 'rel_BRG1'
    assert len(spark.snapshot) == 7 and spark.insert_count == 1
    p['mode'] = 'INSPECT'
    result = execute(spark, p)
    assert result['release_valid'] and result['rows'] == 7


def test_empty_release_changes_pointer_with_no_physical_rows():
    p = payload(empty=True)
    spark = MockSpark('', empty=True)
    result = execute(spark, p)
    assert result['rows'] == 0
    assert spark.pointer.published_release_id == 'rel_BRG1'
    assert not spark.snapshot and spark.insert_count == 0
    p['mode'] = 'INSPECT'
    assert execute(spark, p)['release_valid']


def test_append_committed_before_ack_reuses_exact_slice():
    p = payload()
    spark = MockSpark('')
    spark.fail_insert_ack_once = True
    with pytest.raises(RuntimeError, match='append committed'):
        execute(spark, p)
    assert spark.pointer.published_release_id == 'NONE'
    assert len(spark.snapshot) == 7
    execute(spark, p)
    assert len(spark.snapshot) == 7 and spark.insert_count == 1
    assert spark.pointer.published_release_id == 'rel_BRG1'
