# Code structure: 3_cetas_fallback_copy

## 1. Layers

The package has five layers: configuration/contract, source setup/audit, extraction orchestration, Databricks candidate/publication, and recovery/retention.

## 2. Main entry points

- `python/generate_mappings.py` and `python/source_metadata.py`: inventory creation.
- `python/render_setup.py`: one-time SQL generation from a reviewed config.
- `python/deploy_synapse_pipeline.py`: Copy fallback deployment.
- `python/upstream_audit.py`: nightly source-completion gate.
- `python/bridge_run.py`: nightly extraction and candidate load.
- `python/publish_run.py`: consumer-visible publication.
- `python/recovery.py`: exceptional evidence-based resolution.
- `python/retire_releases.py`: maintenance.

## 3. `bridge_run.py` responsibilities

`bridge_run.py` validates the config and inventory contract, claims/heartbeats the run, validates external Databricks job settings, checks Copy deployment information, builds immutable attempt paths, submits CETAS, classifies terminal versus unknown outcomes, routes eligible CETAS failures to Copy Activity, launches loader jobs, validates state transitions, writes manifests, and produces per-table READY/skipped/error results.

Important helpers include:

- `config()` and `contract_sha256()` — contract validation/hashing.
- `RunLease` / `claim_run()` / `update_run()` — single-orchestrator ownership with takeover rules.
- `cetas()` — CETAS external-table export.
- `copy_activity()` — Synapse Copy submission/inspection.
- `extract_one()` / `extract_with_limits()` — method routing and extraction attempt state.
- `load_one()` / `notebook_job()` — Databricks candidate load submission and terminal-state handling.
- `publication_selection()` — determines which successful attempt is eligible for publish.

## 4. Databricks job code

`databricks/load_candidate.py` consumes the manifest for one attempt, reads the Parquet output, applies/validates the declared schema, writes the candidate Delta table, and confirms row counts.

`databricks/publish.py` validates the candidate, the physical snapshot target, metadata, and pointer state; it appends the new release and updates `published_targets` with concurrency protection.

`databricks/retire_releases.py` performs the data-plane cleanup chosen by the Python retention planner.

## 5. Nightly call sequence

1. Upstream scheduler completes source materialisation.
2. `upstream_audit.py` writes generation/schema/count evidence.
3. `bridge_run.py` starts or resumes the bridge run.
4. Each mapping runs independently through CETAS or fallback Copy and then `load_candidate.py`.
5. Operator may resolve unknown outcomes with `recovery.py`, then rerun `bridge_run.py --resume`.
6. `publish_run.py` invokes `databricks/publish.py` for READY mappings.
7. Later, `retire_releases.py` invokes `databricks/retire_releases.py` for eligible cleanup.

## 6. Setup call sequence

1. `generate_mappings.py` calls source metadata logic and emits config/mapping review material.
2. `profile_inventory.py` may add operational profiles without changing reviewed business semantics.
3. `render_setup.py` emits `azure_sql_seed.sql`, `unity_catalog_setup.sql`, and an existing-target variant.
4. `deploy_synapse_pipeline.py` installs the three `synapse_pipeline/*.json` artifacts.

## 7. Test coverage map

- fallback/static assumptions: `test_static_fallback.py`
- orchestration simulation: `test_flow_sim.py`
- publisher: `test_publish_notebook.py`
- retention: `test_retention.py`
- retained historical regressions: `test_v6_regressions.py`
- COPY-package regressions: `test_copy_regressions.py`
