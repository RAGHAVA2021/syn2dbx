# Runbook: 3_cetas_fallback_copy

## One-time setup (in order)

1. Create a new Azure SQL control database and apply `sql/01_azure_sql_control.sql`.
2. In the Synapse dedicated pool, configure the ADLS external data source in `sql/02_synapse_setup.sql` and apply it using the reviewed identity.
3. Generate/review `config.json`. Verify every source/target, schema hash, conversion, `allow_empty`, `mandatory`, physical/candidate schema, CETAS method, and `COPY_ACTIVITY` fallback.
4. Run `python/render_setup.py --config config.json --output-dir setup` and review/apply the generated Azure SQL and Unity Catalog SQL.
5. Provision the Synapse dedicated-pool and ADLS linked services. Put their exact names in `synapse_pipeline` config.
6. Deploy the Copy artifacts with `python/deploy_synapse_pipeline.py`.
7. Configure separate Databricks loader and publisher jobs to run `databricks/load_candidate.py` and `databricks/publish.py` respectively. Use one task per job run, no automatic task retries, and adequate max-concurrent-runs/timeouts as described in `README.md`.
8. Run the local tests, then complete real Azure acceptance tests listed in `docs/RELEASE_VALIDATION.md`.

## Every night

1. Upstream completes all mapped materialisation and prevents further writes.
2. Run `python/upstream_audit.py` with the real upstream generation identifiers and completed row counts.
3. Run `python/bridge_run.py` with the same upstream/run contract. Record its JSON output.
4. CETAS runs first for each mapping. Only eligible terminal CETAS failures route to Copy Activity, using a fresh attempt path.
5. Candidate loads complete independently. Review `ready`, `skipped`, and `errors` output.
6. Retry/resume eligible same-night failures with `bridge_run.py --resume`; do not create a second upstream generation for the same source load.
7. When ready to publish, run `python/publish_run.py`. READY mappings publish independently; failed/skipped mappings remain on their prior release.
8. Send/retain one operator summary from the orchestration outputs/control state showing published, skipped, and failed tables.

## Morning recovery

For a normal terminal failure, fix the cause and use the same run with `--resume` while the operational recovery window is still open.

For an **indeterminate** Synapse or Databricks operation, do not simply retry. First gather authoritative evidence for the external run/request ID. Use `python/recovery.py` with the required evidence URI/reason/actor to record the resolution, then resume the orchestrator. This prevents duplicate external operations after a lost client response.

If publication outcome is unknown, inspect/resolve the target pointer state before allowing another publisher attempt. A table whose publication did not occur may be skipped while other targets remain published.

## Common situations

### CETAS failed

If the failure is classified as terminal and the mapping permits `COPY_ACTIVITY`, the orchestrator automatically creates a new Copy attempt. The operator should not manually write into the CETAS path.

### Copy failed

The failure is recorded for that mapping. Fix the environmental/data issue and resume; retries for that attempt route stay on Copy rather than returning to CETAS.

### Row counts disagree

Do not publish. Investigate source audit evidence, Copy/CETAS output, partial files, schema conversion, and loader count before retry/recovery.

### Source is unexpectedly empty

With `allow_empty: false`, the audited zero is rejected/skipped. Confirm whether empty is a valid business state before changing that reviewed setting.

### Existing target object already occupies the consumer name

Do not overwrite it with the generated `CREATE VIEW`. Migrate the existing table/view, permissions, masks, filters, and dependencies separately under change control.

## Maintenance

Run `python/retire_releases.py` on the approved schedule. It plans old published/unpublished candidate and staging cleanup according to configured retention and rechecks protected current/previous releases before deleting data.
