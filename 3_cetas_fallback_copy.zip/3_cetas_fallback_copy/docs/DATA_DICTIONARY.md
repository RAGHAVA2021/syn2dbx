# Data dictionary: 3_cetas_fallback_copy

## 1. How control data fits together

Three control locations are used:

- **Azure SQL `bridge` schema:** orchestration state and recovery audit.
- **Synapse `bridge_meta` schema:** upstream materialisation audit used as the trusted source gate.
- **Unity Catalog control schema:** `published_targets`, the pointer used by stable consumer views.

## 2. Azure SQL control tables

### `bridge.inventory_contracts`

Pins `inventory_version` to `contract_sha256`. A changed reviewed contract must not silently reuse the same inventory version.

### `bridge.runs`

One row per bridge run/nightly upstream generation. Key fields include `bridge_run_id`, upstream identifiers/sequence, `business_date`, `inventory_version`, `release_id`, `status`, orchestrator lease token/heartbeat, and `contract_sha256`.

Run statuses allowed by the schema are `CREATED`, `EXTRACTING`, `EXTRACTED`, `LOADING`, `READY`, `PUBLISHING`, `PUBLISHED`, `FAILED`, `PUBLICATION_ABANDONED`, and `ABANDONED_GENERATION`.

### `bridge.object_attempts`

One row per mapping attempt. Records method (`CETAS` or `COPY_ACTIVITY`), immutable `leaf_path`, source/Parquet/Delta row counts, external request/job IDs, operation-state fields, errors, candidate Delta target, consumer/target key, and retirement/staging-deletion timestamps.

Attempt statuses allowed by the schema are `EXTRACTING`, `INDETERMINATE`, `EXTRACTED`, `LOADING`, `READY`, `FAILED`, `SUPERSEDED`, and `ABANDONED_GENERATION`.

### `bridge.recovery_events`

Append-style audit of manual/evidence-based recovery actions. Stores action, run/mapping/attempt, target/external IDs, actor, evidence URI, reason, and timestamp.

### `bridge.group_members`

Pins mapping membership/policy for an inventory version: `group_id`, `mapping_id`, `enabled`, `mandatory`, and `strategy` (`REPLACE_TABLE`).

### `bridge.target_state`

Publication control/claim state per logical target. Stores current/previous release IDs, published/high-water sequences, control version, and publication claim/external-operation state.

## 3. Synapse audit tables

`sql/02_synapse_setup.sql` creates `bridge_meta.upstream_run` and `bridge_meta.upstream_object`. They are populated only after the upstream materialisation completes. `upstream_object` carries the trusted mapping-level row count and schema version used by the bridge before extraction.

Dedicated SQL pool primary/unique constraints are not treated as enforcement guarantees; the bridge precheck must reject duplicate or missing audit rows.

## 4. Unity Catalog control and data objects

`render_setup.py` creates:

- `<control_catalog>.<control_schema>.published_targets` — logical target key, current/previous release, high-water sequence, control version, publication timestamp.
- `<target_catalog>.<physical_schema>.<target_table>_snapshots` — physical Delta table containing retained published releases and bridge metadata columns.
- `<target_catalog>.<candidate_schema>...` — private candidate tables created per bridge run/attempt.
- `<target_catalog>.<target_schema>.<target_table>` — stable consumer view filtering the physical snapshot table to the release selected by `published_targets`.

## 5. Configuration identifiers

Important config fields include `inventory_version`, `source_set_id`, `staging_abfss_root`, control catalog/schema, loader/publisher job IDs and worker limits, retention settings, Synapse Copy pipeline/linked-service identifiers, and per-mapping source/target/schema/column/fallback settings.

A mapping normally uses `method: CETAS` and `fallback_method: COPY_ACTIVITY`.
