# Design: CETAS-first full refresh with Synapse Copy fallback

## 1. Problem and constraints

The source is a nightly-refreshed Azure Synapse dedicated-pool dataset that is static during bridge extraction. The objective is to refresh many Unity Catalog tables independently without one failed table cancelling the whole night. Extraction should prefer CETAS for throughput, but tables that cannot be exported successfully by CETAS need an automatic Synapse Copy Activity fallback.

Core assumptions:

- upstream materialisation is complete before extraction;
- mapped source data does not change until extraction/recovery completes;
- the load is a full refresh, not CDC;
- one mapping corresponds to one consumer target;
- failed mappings can remain on their prior published release;
- the same nightly run is resumed for recoverable failures rather than creating duplicate runs.

## 2. Architecture

Flow per mapping:

`Synapse materialised source` → `upstream audit` → `CETAS attempt` → `ADLS immutable Parquet attempt` → `Databricks private candidate` → `physical Delta snapshot table` → `stable consumer view`.

If CETAS reaches a confirmed terminal failure and `fallback_method` is `COPY_ACTIVITY`, the source leg becomes:

`Synapse materialised source` → `Synapse Copy Activity` → `fresh ADLS immutable Parquet attempt` → the same candidate/publish path.

Azure SQL stores orchestration/control state. Synapse stores the upstream audit facts. Unity Catalog stores the physical snapshot tables and the published-target pointer table used by stable consumer views.

## 3. Key decisions

### 3.1 Static-source contract

The bridge does not attempt to protect against concurrent source writers. Correctness depends on the scheduler/upstream process preventing source changes during extraction and same-day recovery. If that cannot be guaranteed, a source-fencing design is required instead.

### 3.2 CETAS is primary; Copy is fallback

CETAS is attempted first because it is the designed bulk-export path. Copy Activity is not an independent parallel extraction choice for a normal attempt; it is a fallback route after a terminal CETAS failure or a CETAS output rejection that the orchestrator explicitly classifies for fallback. A Copy retry stays on Copy.

### 3.3 Immutable attempt paths

Every extraction attempt writes to its own ADLS path. Reusing a partial path could mix files from different external operations and make count validation meaningless, so the orchestrator requires an empty attempt location before submission.

### 3.4 Three-count validation before publication

The package tracks source, Parquet, and Delta candidate row counts. A candidate is not READY unless the required counts agree and validation succeeds. `allow_empty: false` rejects audited empty source data.

### 3.5 Candidate first, publish second

Loading to a private candidate separates extraction/load errors from consumer-visible publication. `publish_run.py` validates the candidate and appends a release to the governed physical snapshot table before changing the pointer used by the stable view.

### 3.6 Per-table independence

Mappings have independent attempt state. A failed table is reported and skipped while other READY tables can publish. `mandatory` is retained as policy/alert information; it does not force unrelated target publication to roll back as one group.

### 3.7 Unknown outcomes are not guessed

If the client loses the result of an external Synapse or Databricks operation, the operation is treated as indeterminate until evidence proves terminal success/failure. `recovery.py` is the evidence-gated operator path.

### 3.8 Stable consumer object

The consumer name is a Unity Catalog view. Its underlying physical Delta table contains releases, and the control pointer chooses the published release for that mapping. This lets a failed nightly refresh continue serving the previous release.

### 3.9 Contract hashing

`render_setup.py` and `bridge_run.py` derive a reviewed inventory contract hash. A materially changed contract must use a new inventory version rather than silently changing an in-flight/existing version.

## 4. Failure behaviour

- **Terminal CETAS failure + Copy enabled:** start a fresh Copy attempt.
- **Indeterminate CETAS/Copy/Databricks operation:** stop retrying that operation until evidence-based recovery resolves it; continue unrelated tables.
- **Copy failure:** record failure; a Copy retry remains Copy.
- **Candidate validation/count mismatch:** table does not become READY.
- **Publisher terminal failure:** inspect pointer state; if publication did not occur, release the claim and skip that table.
- **Publisher unknown outcome/pointer conflict:** require recovery; do not infer success.
- **Failed/skipped table:** existing published release remains visible if one exists.

## 5. Capacity and cost

Concurrency is controlled by `max_loader_workers`, `max_publisher_workers`, and the external Synapse/Databricks service capacities. The package validates Databricks job settings but does not guarantee that 1,000 tables fit your nightly window. Benchmark real source sizes, CETAS concurrency, Copy throughput, serverless/dedicated Databricks capacity, and ADLS transaction limits.

## 6. Security

Use separate least-privilege identities for deployment, orchestration/audit, loader, publisher, and consumers where practical. Keep ODBC strings/tokens out of files and source control. The Copy linked services must be independently verified to target the correct dedicated pool and storage account. Consumers should receive the intended permissions on the stable views; test row filters/masks and inherited governance policies with real identities.

## 7. Limits and non-goals

The package is not CDC, does not create Azure infrastructure, does not provide one atomic transaction across all target tables, and does not make an existing populated target table safely become a view without a reviewed migration. Local tests do not replace Azure Synapse/ADLS/Databricks acceptance tests.
