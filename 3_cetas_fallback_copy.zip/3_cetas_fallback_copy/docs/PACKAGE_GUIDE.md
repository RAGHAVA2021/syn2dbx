# Package guide: 3_cetas_fallback_copy

## 1. What the package does

This package moves nightly-static data from Azure Synapse dedicated SQL pool to ADLS Gen2 and then to Unity Catalog Delta. CETAS is the primary extraction path. A mapping configured with `fallback_method: COPY_ACTIVITY` can switch to a packaged Synapse Copy Activity after a confirmed terminal CETAS failure. Each table is processed and published independently.

### How the folders relate

`config.example.json` defines the reviewed inventory and runtime contract. `python/` contains orchestration and setup utilities. `synapse_pipeline/` contains the Copy Activity fallback artifacts deployed by `python/deploy_synapse_pipeline.py`. `databricks/` contains the notebook code run by loader, publisher, and retirement jobs. `sql/` creates control/audit prerequisites. `tests/` exercises orchestration, fallback, publication, recovery-related regressions, and retention.

## 2. Folder and file inventory

### Root

- `FIRST_READ_ME.md` — reading map for first-time users.
- `README.md` — authoritative operational overview and setup instructions.
- `CHANGELOG.md` — package naming/documentation changes.
- `config.example.json` — example contract containing source, target, job, staging, Copy pipeline, and mapping settings.
- `requirements.txt` — runtime Python dependencies.
- `requirements-dev.txt` — development/test dependencies.

### `python/`: setup and orchestration

- `generate_mappings.py` — discovers source columns and creates mapping entries, including Copy fallback configuration.
- `source_metadata.py` — obtains ordered source-column metadata and schema hashes.
- `profile_inventory.py` — estimates operational size/capacity information for mappings.
- `render_setup.py` — validates config, pins the inventory contract, renders Azure SQL seed SQL and Unity Catalog physical/control/view setup SQL.
- `deploy_synapse_pipeline.py` — deploys the JSON artifacts in `synapse_pipeline/` to the configured Synapse workspace.
- `upstream_audit.py` — records the completed nightly source generation and row counts used as the extraction gate.
- `bridge_run.py` — main extraction/load orchestrator: CETAS first, confirmed-failure Copy fallback, candidate load, resume handling, manifests, leases, and per-table status.
- `publish_run.py` — publishes READY candidates independently and moves the target pointer only after validation.
- `recovery.py` — resolves indeterminate external operations from operator-supplied evidence and handles publication-abandonment cases.
- `retire_releases.py` — plans and orchestrates retention of old releases, candidates, manifests, and optional staging data.

### `databricks/`: job/notebook implementation

- `load_candidate.py` — reads one immutable Parquet attempt, validates counts/schema, and writes the private Delta candidate.
- `publish.py` — validates the candidate and governed physical table, appends the release to the snapshot table, and updates the Unity Catalog pointer with concurrency checks.
- `retire_releases.py` — removes eligible old release/candidate data as directed by the retention orchestrator.

### `synapse_pipeline/`: Copy fallback

- `bridge_copy_to_parquet.pipeline.json` — parameterized Synapse Copy pipeline used only for Copy-path attempts.
- `bridge_synapse_source.dataset.json` — parameterized dedicated-pool source dataset.
- `bridge_parquet_sink.dataset.json` — parameterized ADLS Parquet sink dataset.

The linked-service names are supplied by configuration and must point to the same audited dedicated pool and intended ADLS staging account.

### `sql/`: one-time and historical setup

- `01_azure_sql_control.sql` — creates fresh Azure SQL control tables for inventory contracts, bridge runs, object attempts, recovery events, group membership, and target publication state.
- `02_synapse_setup.sql` — creates dedicated-pool CETAS external objects plus upstream audit tables.
- `03_upgrade_static_v3_to_v4.sql` — historical upgrade for an existing static-v3 control database only.
- `04_upgrade_static_v4_to_v5_synapse.sql` — historical upgrade for an existing static-v4 Synapse audit schema only.

The historical upgrade filenames intentionally retain their version numbers.

### `tests/`

- `test_flow_sim.py` — orchestration flow simulation.
- `test_publish_notebook.py` — publisher notebook behaviour.
- `test_retention.py` — retention behaviour.
- `test_static_fallback.py` — CETAS-to-Copy fallback and static-source assumptions.
- `test_v6_regressions.py` — retained historical regression coverage.
- `test_copy_regressions.py` — COPY-package retry, recovery-fencing, and manifest-retirement regression coverage.

## 3. Execution order and what moves between stages

### One-time setup

1. Review/generate `config.json` from `config.example.json` and source metadata.
2. Run `sql/01_azure_sql_control.sql` in a new Azure SQL control database.
3. Configure the ADLS URL and run `sql/02_synapse_setup.sql` in the dedicated pool.
4. Run `render_setup.py`, apply the generated Azure SQL seed and Unity Catalog setup SQL.
5. Deploy the `synapse_pipeline/` artifacts with `deploy_synapse_pipeline.py`.
6. Configure Databricks loader/publisher jobs to execute the matching files in `databricks/`.

### Every automatic nightly run

1. Upstream finishes materialisation and stops writes.
2. `upstream_audit.py` records completion/schema/count evidence.
3. `bridge_run.py` creates/claims the run and processes mappings independently.
4. For each mapping: CETAS → immutable ADLS path → candidate load; if CETAS terminally fails and Copy fallback is enabled: Copy Activity → new immutable ADLS path → candidate load.
5. `bridge_run.py --resume` can retry/resume eligible failures within the permitted recovery window using the same run contract.
6. `publish_run.py` publishes only READY mappings; skipped mappings retain their prior release.
7. `retire_releases.py` performs retention separately.

### Morning investigation and same-day recovery

Use the bridge JSON output and Azure SQL control rows to identify failed/indeterminate tables. Resolve unknown external operations with `recovery.py` only when authoritative evidence is available, then run the appropriate `--resume` command. Do not invent a new source generation merely to retry the same night's table.

## 4. Boundaries and references

This package does not provision Azure resources, create linked services, create Databricks jobs, or prove that consumer row filters/masks behave correctly for your identities. Those are environment acceptance responsibilities. See `docs/RELEASE_VALIDATION.md`.
