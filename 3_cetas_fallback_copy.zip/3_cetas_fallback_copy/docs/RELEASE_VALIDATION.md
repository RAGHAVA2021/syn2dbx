# Release validation: 3_cetas_fallback_copy

Use this checklist before enabling a production schedule. Passing local tests is necessary but not sufficient.

## Package checks completed for this naming/documentation refresh

- Package root is `3_cetas_fallback_copy`.
- README/package documentation no longer identifies the current package as `synapse_databricks_bridge_static_v7`.
- Historical migration filenames remain unchanged intentionally.
- Documentation set includes first-read guide, design, package guide, code structure, data dictionary, runbook, and release validation.
- Python test suite should pass after repackaging; record the actual result in deployment evidence.

## Required target-environment acceptance

- Confirm upstream data is immutable for the extraction/recovery window.
- Validate source audit rows are unique/complete for every mapping and the correct `source_set_id`.
- Run CETAS successfully against representative small, medium, and large tables.
- Force a terminal CETAS failure and prove automatic `COPY_ACTIVITY` fallback uses a new empty ADLS attempt path.
- Validate Copy linked services target the intended dedicated pool and staging storage account.
- Test special characters, CR/LF, quotes, pipe characters, wide strings/MAX-like cases that motivated Copy fallback, decimal precision/scale, dates/timestamps including legacy/sentinel values used by your source, and empty tables.
- Prove source/Parquet/Delta row-count checks reject mismatches.
- Prove one table failure does not cancel unrelated READY tables.
- Prove `bridge_run.py --resume` reuses successful candidates and does not duplicate unknown external work.
- Simulate lost Synapse and Databricks client responses and validate evidence-based `recovery.py` handling.
- Simulate publisher terminal failure and unknown publication outcome; verify pointer/claim behaviour.
- Validate initial-load failure behaviour where no previous release exists.
- Validate consumer view permissions, masks, row filters, inherited ABAC policies, and physical-table access with real identities.
- Confirm loader/publisher jobs have the intended task count, concurrency, retry, timeout, and queue settings.
- Benchmark the complete nightly volume and recovery headroom against Synapse, ADLS, and Databricks capacity.
- Test retention against current/previous releases and verify no active release/staging path is deleted.
- Verify secrets/ODBC strings/tokens are supplied through approved secret mechanisms and are absent from the repository/config files.
- Test the operator notification/summary process so the morning team can see counts and names of failed/skipped tables and take same-day action.

Only after these checks pass in the real dev environment should the same reviewed Git commit/configuration move to production through your normal deployment process.

## Local regression result for this package

Command:

```bash
PYTHONPATH=python:tests python -m pytest -q
```

Result on the repackaged source: **43 passed**.
