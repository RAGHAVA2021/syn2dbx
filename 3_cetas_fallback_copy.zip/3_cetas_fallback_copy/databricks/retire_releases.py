# Databricks notebook source
"""Optional retention Job for attempt-specific candidate tables.

Checks the consumer view definition without scanning its data. Parameters:
manifest_path and manifest_sha256 from python/retire_releases.py --execute.
"""
import hashlib
import json
import re

NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
TOKEN = re.compile(r"[A-Za-z0-9_\-]+")
MANIFEST = re.compile(r"abfss://[^/]+/bridge/parquet-stage/_manifests/[A-Za-z0-9_\-]+/[0-9a-f]{32}\.json")

dbutils.widgets.text("manifest_path", "")
dbutils.widgets.text("manifest_sha256", "")


def read_manifest():
    path, expected = dbutils.widgets.get("manifest_path"), dbutils.widgets.get("manifest_sha256")
    if not MANIFEST.fullmatch(path) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError("Invalid manifest parameters")
    text = spark.read.option("wholetext", "true").text(path).first()[0]
    if hashlib.sha256(text.encode("utf-8")).hexdigest() != expected:
        raise ValueError("Manifest hash mismatch")
    return json.loads(text)


def q(s):
    if not isinstance(s, str) or not NAME.fullmatch(s):
        raise ValueError("Unsafe identifier")
    return f"`{s}`"


def lit(s):
    if not TOKEN.fullmatch(str(s)):
        raise ValueError("Unsafe literal")
    return f"'{s}'"


p = read_manifest()
deleted, dropped, skipped = {}, [], []

control = f"{q(p['control_catalog'])}.{q(p['control_schema'])}.`published_targets`"
for g in p["groups"]:
    key = g["target_key"]
    if not isinstance(key, str) or not re.fullmatch(r"table:[A-Za-z_][A-Za-z0-9_]*(\.[A-Za-z_][A-Za-z0-9_]*){2}", key):
        raise ValueError("Unsafe target key")
    state = spark.sql(f"SELECT published_release_id,previous_release_id,high_water_sequence "
                      f"FROM {control} WHERE target_key='{key}'").collect()
    if len(state) != 1:
        raise ValueError(f"Missing/duplicate pointer for {key}")
    keep = set(g["keep"]) | {state[0].published_release_id, state[0].previous_release_id}
    eligible = [r for r in g["releases"] if r not in keep and r != "NONE"]
    if not eligible:
        continue
    table = g["table"]
    physical = f"{q(table['catalog'])}.{q(table['schema'])}.{q(table['table'])}"
    high_water = min(int(g["high_water"]), int(state[0].high_water_sequence))
    rows = spark.sql(f"DELETE FROM {physical} WHERE mapping_object_id={lit(g['mapping_id'])} "
                     f"AND release_id IN ({', '.join(lit(r) for r in eligible)}) "
                     f"AND CAST(upstream_sequence AS BIGINT)<={high_water}").collect()
    deleted[key] = int(rows[0][0]) if rows and len(rows[0]) else None

for d in p["drop_tables"]:
    if not d["table"].startswith("candidate_"):
        raise ValueError(f"Refusing to drop a non-candidate table: {d['table']}")
    target_raw = f"{d['target']['catalog']}.{d['target']['schema']}.{d['target']['table']}"
    if spark.catalog.tableExists(target_raw):
        target = ".".join(q(d["target"][k]) for k in ("catalog", "schema", "table"))
        ddl = spark.sql(f"SHOW CREATE TABLE {target}").first()[0]
        if re.search(r"(?i)(?<![A-Za-z0-9_])`?" + re.escape(d["table"]) +
                     r"`?(?![A-Za-z0-9_])", ddl):
            skipped.append({"table": d["table"], "reason": "consumer definition references candidate"})
            continue
    spark.sql(f"DROP TABLE IF EXISTS {q(d['catalog'])}.{q(d['schema'])}.{q(d['table'])}")
    dropped.append({"run_id": d["run_id"], "mapping_id": d["mapping_id"], "attempt": d["attempt"]})

dbutils.notebook.exit(json.dumps({"deleted": deleted, "dropped": dropped, "skipped": skipped}))
