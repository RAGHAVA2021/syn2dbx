# Databricks notebook source
"""Validate an independent release in physical Delta, then atomically move its view pointer.

A failure before the pointer update leaves the old release visible. INSPECT proves
both the pointer and the release contents before Azure SQL records a lost-ack commit.
"""
import hashlib
import json
import re
import time

MANIFEST = re.compile(r"abfss://[^/]+/bridge/parquet-stage/_manifests/[A-Za-z0-9_\-]+/[0-9a-f]{32}\.json")
NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
TOKEN = re.compile(r"[A-Za-z0-9_\-]+")

dbutils.widgets.text("manifest_path", "")
dbutils.widgets.text("manifest_sha256", "")
# Serverless jobs reject Parquet rebase session configurations. Historical dates
# require a comparison with the actual Synapse writer in platform acceptance.


def read_manifest():
    path, expected = dbutils.widgets.get("manifest_path"), dbutils.widgets.get("manifest_sha256")
    if not MANIFEST.fullmatch(path) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError("Invalid manifest parameters")
    text = spark.read.option("wholetext", "true").text(path).first()[0]
    if hashlib.sha256(text.encode("utf-8")).hexdigest() != expected:
        raise ValueError("Manifest hash mismatch")
    return json.loads(text)


def q(value):
    if not isinstance(value, str) or not NAME.fullmatch(value):
        raise ValueError("Unsafe identifier")
    return f"`{value}`"


def lit(value):
    if not TOKEN.fullmatch(str(value)):
        raise ValueError("Unsafe literal")
    return f"'{value}'"


def dotted(catalog, schema, name):
    return f"{q(catalog)}.{q(schema)}.{q(name)}"


def one(sql):
    rows = spark.sql(sql).collect()
    if len(rows) != 1:
        raise ValueError(f"Expected exactly one row, found {len(rows)}")
    return rows[0]


def schema_fields(table):
    return [(f.name, f.dataType.simpleString()) for f in spark.table(table).schema.fields]


def governed(table, props):
    actual = {r.key: r.value for r in spark.sql(f"SHOW TBLPROPERTIES {table}").collect()}
    return all(actual.get(k) == v for k, v in props.items())


CONFLICT_MARKERS = ("ConcurrentAppendException", "ConcurrentDeleteReadException",
                    "ConcurrentDeleteDeleteException", "ConcurrentTransactionException",
                    "MetadataChangedException", "ProtocolChangedException", "DELTA_CONCURRENT_",
                    "ConcurrentModificationException")


def update_pointer(sql):
    wait = 2.0
    for attempt in range(6):
        try:
            spark.sql(sql)
            return
        except Exception as exc:
            if not any(marker in f"{type(exc).__name__}: {exc}" for marker in CONFLICT_MARKERS) or attempt == 5:
                raise
            time.sleep(wait)
            wait = min(wait * 2, 30.0)


p = read_manifest()
if p.get("strategy") != "REPLACE_TABLE" or p.get("mode") not in ("PUBLISH", "INSPECT"):
    raise ValueError("Unsupported publication request")
m = p["mapping"]
for k in ("mapping_id", "release_id", "generation_id", "bridge_run_id"):
    lit(m[k] if k in m else p[k])
for k in ("target_catalog", "target_schema", "target_table", "candidate_schema",
          "candidate_table", "physical_schema", "control_catalog", "control_schema"):
    q(m[k] if k in m else p[k])
release = p["release_id"]
expected_rows = int(m["source_rows"])
if expected_rows < 0:
    raise ValueError("Negative source count")
target_key = "table:" + ".".join(m[k] for k in ("target_catalog", "target_schema", "target_table"))
# Identifiers are validated above. The key contains only safe identifiers, dots and a colon.
key_sql = "'" + target_key + "'"
control = dotted(p["control_catalog"], p["control_schema"], "published_targets")
physical = dotted(m["target_catalog"], m["physical_schema"], m["target_table"] + "_snapshots")
candidate = dotted(m["target_catalog"], m["candidate_schema"], m["candidate_table"])


def pointer():
    return one(f"SELECT published_release_id, high_water_sequence, control_version FROM {control} "
               f"WHERE target_key={key_sql}")


def physical_release_valid():
    if schema_fields(candidate) != schema_fields(physical):
        return False
    if not governed(physical, m["consumer_properties"]):
        return False
    found = one(f"SELECT count(*) n, count(DISTINCT source_generation_id) g, "
                f"count(DISTINCT bridge_run_id) b, count(DISTINCT load_attempt) a, "
                f"min(source_generation_id) gi, min(bridge_run_id) bi, min(load_attempt) ai "
                f"FROM {physical} WHERE release_id={lit(release)} AND mapping_object_id={lit(m['mapping_id'])}")
    if int(found.n) != expected_rows:
        return False
    if expected_rows == 0:
        return (found.g, found.b, found.a) == (0, 0, 0)
    return (found.g, found.b, found.a, found.gi, found.bi, found.ai) == (
        1, 1, 1, m["generation_id"], p["bridge_run_id"], str(m["attempt"]))


current = pointer()
if p["mode"] == "INSPECT":
    valid = current.published_release_id == release and physical_release_valid()
    dbutils.notebook.exit(json.dumps({"published_release_id": current.published_release_id,
                                      "release_valid": bool(valid), "rows": expected_rows if valid else None}))

# The candidate must be complete and governed before any publication mutation.
if schema_fields(candidate) != schema_fields(physical):
    raise ValueError("Candidate and physical table schemas differ")
if not governed(candidate, m["consumer_properties"]) or not governed(physical, m["consumer_properties"]):
    raise ValueError("Governed candidate/physical properties differ")
source = one(f"SELECT count(*) n, count(DISTINCT source_generation_id) g, "
             f"count(DISTINCT bridge_run_id) b, count(DISTINCT load_attempt) a "
             f"FROM {candidate} WHERE release_id={lit(release)} AND mapping_object_id={lit(m['mapping_id'])}")
if (source.n, source.g, source.b, source.a) != (
    expected_rows, *(((1, 1, 1) if expected_rows else (0, 0, 0)))):
    raise ValueError("Candidate row count/provenance mismatch")
if expected_rows:
    tags = one(f"SELECT min(source_generation_id) g, min(bridge_run_id) b, min(load_attempt) a "
               f"FROM {candidate} WHERE release_id={lit(release)} AND mapping_object_id={lit(m['mapping_id'])}")
    if (tags.g, tags.b, tags.a) != (m["generation_id"], p["bridge_run_id"], str(m["attempt"])):
        raise ValueError("Candidate belongs to a different generation/run/attempt")
if current.published_release_id == release:
    if not physical_release_valid():
        raise ValueError("Visible release does not satisfy physical contract; freeze target")
    dbutils.notebook.exit(json.dumps({"release_id": release, "rows": expected_rows}))
if current.published_release_id != p["expected_current_release"] or current.high_water_sequence >= p["upstream_sequence"]:
    raise ValueError("Pointer differs from the recorded prior release or is newer")

# A Delta INSERT is an atomic commit. If its acknowledgement was lost, the next
# invocation inspects the exact slice before deciding whether to append again.
existing = one(f"SELECT count(*) n FROM {physical} WHERE release_id={lit(release)} "
               f"AND mapping_object_id={lit(m['mapping_id'])}")
if int(existing.n) == 0 and expected_rows:
    columns = ", ".join(q(c["target"]) for c in m["columns"])
    from_columns = ", ".join(q(c["target"]) for c in m["columns"])
    metadata = ", ".join(q(k) for k in ("release_id", "mapping_object_id", "source_generation_id",
                 "bridge_run_id", "upstream_run_id", "upstream_sequence", "business_date", "load_attempt",
                 "group_contract_version"))
    spark.sql(f"INSERT INTO {physical} ({columns}, {metadata}) SELECT {from_columns}, {metadata} "
              f"FROM {candidate} WHERE release_id={lit(release)} AND mapping_object_id={lit(m['mapping_id'])}")
if not physical_release_valid():
    raise ValueError("Physical release incomplete or invalid; pointer left unchanged")

# One conditional Delta UPDATE is the only consumer visibility change.
update_pointer(f"UPDATE {control} SET previous_release_id=published_release_id, "
               f"published_release_id={lit(release)},high_water_sequence={int(p['upstream_sequence'])}, "
               "control_version=control_version+1,published_at=current_timestamp() "
               f"WHERE target_key={key_sql} AND control_version={int(current.control_version)} "
               f"AND high_water_sequence={int(current.high_water_sequence)} "
               f"AND published_release_id={lit(p['expected_current_release'])} "
               f"AND high_water_sequence<{int(p['upstream_sequence'])}")
confirmed = pointer()
if confirmed.published_release_id != release or confirmed.control_version != current.control_version + 1:
    raise ValueError("Pointer update not proven; INSPECT before retry")
dbutils.notebook.exit(json.dumps({"release_id": release, "rows": expected_rows}))
