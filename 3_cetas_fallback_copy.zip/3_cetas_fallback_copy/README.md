# 3_cetas_fallback_copy — Static nightly Synapse → ADLS → Databricks bridge

Use this package only when the nightly Synapse materialisation has finished and the mapped source data stays unchanged until bridge extraction reports `READY`. Each source mapping becomes **one Unity Catalog physical Delta table plus a stable consumer view**. The view keeps its identity and points at the currently published release in a small Unity Catalog Delta control table. This supports independent per-table publication; it does not make all 1,000 tables visible as one atomic group.

CETAS is attempted first. For mappings with `fallback_method: COPY_ACTIVITY`, a **confirmed terminal CETAS error** immediately launches a Synapse Copy Activity at a fresh attempt path. An unknown outcome needs evidence-based recovery for that table; other independent tables continue. Copy retries remain on Copy. Source, Parquet and candidate Delta row counts must agree before a table publishes.

This package is the **CETAS-first with Synapse Copy Activity fallback** implementation for the static nightly bridge. It is a fresh-install redesign of the earlier static variant. Do not run its SQL against an existing v9 or static v1 control database, or against populated target tables. Moving an existing target **table** to a **view** requires a separately reviewed migration of consumers, permissions, masks, row filters and dependencies. No Azure or Databricks integration run has been performed with your services.

Existing static v3/v4/v5 installations require a separately reviewed control database and target migration. The historical `sql/03` and `sql/04` scripts only upgrade the specific objects named in those files; they **do not** constitute a complete migration to this package. Do not run this fresh-install setup against a populated control database or target. The contract hash prevents changing business and connection contracts under an existing inventory version.

## Scheduling and publication

1. The upstream Synapse pipeline finishes all writes and signals completion. The scheduler blocks any further writes to mapped source results until all extracts finish (including Copy fallback and recovery). If it cannot enforce that promise, use a source fence.
2. `python/upstream_audit.py` records source schema hashes and counts. An audited zero count with `allow_empty: false` is recorded as `REJECTED` and skipped. Use a new upstream run ID, generation ID and increasing sequence for each night.
3. `python/bridge_run.py` extracts each mapping into its own immutable ADLS attempt directory and starts its private Delta candidate load as soon as that extraction finishes. Its `READY` run status means processing completed; check its JSON `ready`, `skipped`, and `errors` lists. A failed table does not cancel other tables.
4. Before publishing, retry eligible failed tables within the window using `bridge_run.py --resume` with the same arguments. Successful candidates are kept; unknown or orphaned operations remain skipped until verified terminal. A confirmed CETAS failure goes to Copy, including a recovered failure with `external_failed: true`. A CETAS Parquet type/count rejection also tries Copy once, while a rejected Copy attempt is skipped. Once publishing starts, extraction resume is closed for that run.
5. `python/publish_run.py` verifies gate evidence and publishes **only READY tables**. Each publisher checks its candidate and governed physical table, appends a release, confirms its rows, then changes one target's pointer row. A terminal failed publisher gets a read-only pointer inspection before its claim is cleared and its table skipped; an unknown or changed pointer still requires recovery. A skipped table's view keeps its prior Delta release, regardless of its `mandatory` flag; `mandatory` is included in skipped results for alerting. On initial load with no prior release, the failed table has no historical data to serve.
6. `python/retire_releases.py` removes eligible old snapshot releases, attempt-specific candidate tables and optionally exact ADLS staging directories. It rechecks current and previous pointers at deletion time.

A view exposes the business fields and the nine bridge metadata fields. Consumers are granted the view. Review how your Unity Catalog access policies apply to its underlying physical table; validate masked/filtered reads with the actual consumer identities before publishing. The restricted publisher must be able to validate and append the physical table and update the matching pointer row. Configure a real timeout of at most 7,200 seconds and disable automatic Databricks Job task retries; the runner manages attempts. Benchmark your overnight 1,000-table window.

## Files and execution order

| File(s) | Purpose | Run |
|---|---|---|
| `python/generate_mappings.py`, `python/source_metadata.py` | Discover a source schema, all supported columns, column order and schema hash | Inventory creation |
| `python/profile_inventory.py` | Estimate size classes and source capacity | Optional inventory review |
| `sql/01_azure_sql_control.sql`, `sql/02_synapse_setup.sql` | New control tables; Synapse CETAS objects and audit tables | One-time setup |
| `python/render_setup.py` | Pin the inventory hash, seed Azure SQL target state and render UC physical tables, pointer rows and views | Fresh inventory; view creation once per new target |
| `python/deploy_synapse_pipeline.py`, `synapse_pipeline/*.json` | Install Synapse Copy source/sink datasets and pipeline | One-time setup, required for fallback |
| `python/upstream_audit.py` | Check a seeded inventory and record completed source counts | Every completed nightly source load |
| `python/bridge_run.py`, `databricks/load_candidate.py` | CETAS with terminal-error Copy fallback; load and verify private candidates | Every night, then `--resume` if necessary |
| `python/publish_run.py`, `databricks/publish.py` | Verify release and atomically move each stable view's pointer | After READY and independent gate evidence |
| `python/recovery.py` | Evidence-gated resolution for indeterminate source, loader or publisher operations | Exceptional recovery |
| `python/retire_releases.py`, `databricks/retire_releases.py` | Governed physical/candidate/staging retention | Scheduled maintenance |
| `tests/` | SQLite orchestration and publisher notebook stand-ins | Before deployment and on changes |

## One-time setup

1. Provision a **new** Azure SQL control database and run `sql/01_azure_sql_control.sql`. Set the ADLS container URL, Synapse master key and managed-identity privileges, then run `sql/02_synapse_setup.sql` in the Synapse dedicated pool. Configure `BRIDGE_CONTROL_ODBC`, `BRIDGE_SYNAPSE_AUDIT_ODBC` and `BRIDGE_CETAS_ODBC` securely, using separate least-privilege identities.
2. Generate reviewed mappings, for example:

   ```bash
   python python/generate_mappings.py --schema presentation --source-kind table \
     --target-catalog analytics --target-schema gold \
     --inventory-version wave_001_v1 --output config.json
   ```

   Use `--source-kind view` for an approved view over a nightly materialised table. Review `.exceptions.json`, every column conversion, date/decimal types, and each table's `allow_empty`. The generated config defaults to `allow_empty: false`, CETAS plus Copy fallback, and one independent `group_id` per table. It does not auto-approve MAX text or other unsupported types. Set `physical_schema` (for example `bridge_physical`) on each mapping and configure `consumer_properties` for the **physical and candidate** Delta tables; the consumer object is a view. Fill in the catalog, storage URI, Synapse pipeline details and Databricks Job IDs.
3. Run `python python/render_setup.py --config config.json --output-dir setup`. Apply `setup/azure_sql_seed.sql`, then `setup/unity_catalog_setup.sql` for a fresh target. The UC file uses `CREATE VIEW` deliberately: it **fails** if another object occupies the name. For a reviewed new inventory version over existing targets with unchanged view definitions, apply `setup/unity_catalog_existing_targets.sql` instead, which seeds physical/control objects without recreating views. Migrate any actual view/schema change separately. `profile_inventory.py` can refresh operational profiles under the same inventory version because those profiles are excluded from the contract hash; `allow_empty` and `mandatory` remain hashed reviewed policy settings.
4. Provision the source and ADLS linked services and record their exact names as `synapse_pipeline.synapse_linked_service` and `synapse_pipeline.adls_linked_service`; deploy the Synapse pipeline with `python/deploy_synapse_pipeline.py --help`. Copy checks the deployed linked services, source query, sink path/container, and Copy count before submission. Verify separately that the named linked services point to the **audited dedicated pool and correct storage account**; the package cannot infer targets from secret-based linked services. Configure each Databricks loader and publisher Job with **one notebook task**, `max_concurrent_runs` at least the worker count (8 by default), `max_retries: 0`, `disable_auto_optimization: true` for serverless retries, `retry_on_timeout: false`, queue disabled, and both job and task timeouts between 1 and 7,200 seconds. The commands check these settings before work starts. Size serverless capacity accordingly. Give the loader access to candidate schemas and ADLS, the publisher access to candidates, physical tables and pointer rows, and the consumer identity access only as intended through the views. The audit and orchestrator identities need `SELECT` on `bridge.inventory_contracts`.
5. Perform acceptance tests on the actual platform with both CETAS and Copy, especially whole-day dates, decimal precision, special characters, masks, row filters, zero rows, publisher pointer conflicts and quota/concurrency limits. `generate_mappings.py` deliberately rejects `uniqueidentifier`; if needed, design and review a manual `GUID_TEXT` mapping and test its string output. Review every external policy evidence gate.

## Nightly commands

Run these only after the existing Synapse transformations have completed:

```bash
python python/upstream_audit.py --config config.json \
  --upstream-run-id night_20260925 --generation-id gen_20260925 \
  --sequence 20260925 --business-date 2026-09-25

python python/bridge_run.py --config config.json \
  --upstream-run-id night_20260925 --generation-id gen_20260925 \
  --sequence 20260925 --business-date 2026-09-25 \
  --bridge-run-id BRG_20260925

python python/publish_run.py --config config.json \
  --bridge-run-id BRG_20260925 --evidence evidence_20260925.json
```

### Recovery by 11:00 Sydney time

Inspect the extraction JSON and the latest rows in `bridge.object_attempts` for failures. A confirmed CETAS rejection automatically tries Copy. To retry a failed Copy or loader while source data remains unchanged, rerun the **same** `bridge_run.py` command with `--resume` before starting `publish_run.py`. A completed Copy with mismatched audit counts is final for the night. Exhausted attempts and unresolved external operations stay skipped; an `INDETERMINATE` attempt needs terminal evidence through `recovery.py resolve-attempt --config config.json` before a retry. This command rejects an active run lease. By the cutoff, publish the verified `READY` tables with the recorded gate evidence. Both commands return exit code **2** if a mandatory mapping is skipped, after printing the JSON result; alert on it while allowing the publisher step to run for READY tables. A skipped table's consumer view stays on yesterday's release. Do not reuse that run the following night: the new upstream run, sequence, generation, and bridge ID are required. If a table has never published, there is no old release to serve.

If a publication starts but cannot complete by the cutoff, verify each stored external publisher has stopped and inspect the actual Delta pointer and rows. Run `recovery.py abandon-publication --config config.json` for each outstanding target claim with the required evidence, including the observed `delta_published_release_id`; abandonment is rejected if the Delta pointer differs from the Azure SQL pointer, and that target must be reconciled first. Run `recovery.py abandon-unclaimed-publication --config config.json` for a stopped `PUBLISHING` run with no claims. `resolve-publication` also requires `--config config.json`. All three check the configured takeover window and reject a live heartbeat; pass `--takeover-after-minutes` matching the configured window if it differs from 150 for the abandon commands. Resolve uncertain source/loader operations with terminal evidence even after publication, so retention can remove their staging paths. Do not release a claim while a publisher may still commit. Schedule this operator or evidence-collecting procedure at the cutoff; the package cannot safely infer terminal status merely from the clock.

For a confirmed dead orchestrator before its 150-minute heartbeat expires, use `recovery.py release-dead-orchestrator --config config.json` with evidence containing `orchestrator_stopped: true`, `external_terminal: true`, `safe_to_resume: true`, its exact `orchestrator_token`, `external_ids` listing every RUNNING/UNKNOWN source, loader and publisher ID (an empty list if none), and `evidence_uri`. Inspect the controller and **every external run** first. The command records an audit event and fences the old token. A resumed extraction still marks interrupted attempts unknown; resolve each with its own terminal evidence before retrying. Never assert the controller stopped while an old process can continue to submit work.

The evidence JSON needs exact `bridge_run_id`, `release_id`, `generation_id`, integer `upstream_sequence`, and a real `true` plus `<gate>_evidence_uri` for `source_smoke_check`, `audit_health`, `policy_readiness`, `restricted_identity_tests` and `consumer_contract_tests`. The file records **actual externally performed checks**; the package does not implement those detectors. Use the same arguments plus `--resume` for a stopped `bridge_run.py` or a PUBLISHING `publish_run.py`. Consult `python/recovery.py --help` for terminal evidence requirements. Never retry an unknown CETAS/Copy/Databricks operation by starting another untracked run.

## Known boundaries

- Each view's release pointer changes atomically; **different views change independently**. A consumer joining tables during publication can see a mix of nights. If a single atomic cross-table cutover is required, use an approved group pointer design.
- A legitimate empty source needs `allow_empty: true` on its reviewed mapping. The loader accepts a successful zero-row export with no Parquet data files by building an empty DataFrame from the reviewed column contract. With `allow_empty: false`, the audit records `REJECTED` and the old release remains live. Other missing or duplicate audit records still stop preflight. Validate the empty path with your Synapse Copy/CETAS configuration and serverless external-location privileges.
- The notebooks do not set Parquet rebasing Spark properties because serverless jobs reject unsupported session settings. Test pre-1900 timestamps and pre-1582 dates against your Synapse writer's actual calendar behavior before relying on sentinel values; a mismatched writer calendar can shift a date. Use a separately validated compute/reader configuration if those values require it.
- Synapse Copy uses one parallel copy and a two-hour timeout. Measure large-table fallback duration against the 11:00 cutoff. If it cannot finish, keep that table's previous release and investigate the capacity or partitioned-copy design for future nights.
- The nightly audit metadata carries `source_set_id` on both run and object rows, so sequences and upstream IDs are scoped to each source set. Synapse dedicated-pool constraints are not enforced; run only one audit writer for a source set/night and let bridge preflight reject duplicates.
- `retire_releases.py --execute --delete-staging` removes old job manifests for closed or superseded runs after the unpublished retention window. A READY or FAILED run becomes eligible only after every attempted target's high-water mark has advanced beyond its sequence, no run lease or publication claim is held, and no source or loader operation remains unresolved. The retention notebook checks view definitions before dropping private candidates without scanning consumer rows.
- Inspect actual consumer plans using `EXPLAIN` and measure release filtering on representative wide tables. If old releases cause excessive scanning, plan physical table clustering by `release_id` with your Databricks Runtime and data distribution. The package does not claim a performance result without that platform test.
- Benchmark 1,000 nightly CETAS runs, loader jobs, publisher jobs and sequential source audits on the actual DW2000c and Databricks capacity before committing to the cutoff. Schedule release retention outside the publish window. Restrict who can run loader/publisher Jobs and write the manifest location, because a manifest hash alone does not establish who created it.
- The immutable hash includes mapped source and target contracts, staging location and Synapse Copy endpoint. Changing any of those requires a new inventory version and a reviewed target migration when schemas change. Worker limits, profiles, retention periods and job IDs can change without rehashing the inventory.
- Mask/row-filter propagation, consumer permissions, actual Synapse pipeline artifact behavior, Copy Parquet types and UC pointer concurrency must be tested on your Azure environment. The local tests cannot establish production readiness.

## Local test command

From the package root, run:

```bash
PYTHONPATH=python:tests python -m pytest -q
```

The naming/documentation refresh on 2026-09-27 completed with **43 tests passed** using this command. This is local regression evidence only; complete the platform acceptance checks in `docs/RELEASE_VALIDATION.md` before production use.
