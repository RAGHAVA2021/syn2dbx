# Reviewer notes for 3_cetas_fallback_copy

Preserve these invariants when changing the package:

1. The source is static during extraction/recovery; if that assumption changes, redesign rather than weakening checks.
2. CETAS is primary. Copy Activity is an automatic fallback only for eligible CETAS failures/rejections, and Copy retries stay on Copy.
3. Every extraction attempt uses a fresh immutable ADLS path.
4. Unknown external outcomes require evidence-based recovery; never infer failure merely because the client call errored or timed out.
5. Source, Parquet, and candidate Delta row-count validation must succeed before READY/publication.
6. A failed mapping must not cancel unrelated mappings.
7. Publication must not expose an unvalidated candidate. A skipped target keeps its previous release when one exists.
8. Do not silently adopt/replace an existing consumer object when generated setup expects a new view.
9. Contract changes must not be hidden under an existing inventory version.
10. Keep secrets out of configuration, logs, manifests, tests, and source control.

When reviewing a change, trace both the normal CETAS path and the CETAS→Copy path, plus resume, indeterminate recovery, publication, and retention.
