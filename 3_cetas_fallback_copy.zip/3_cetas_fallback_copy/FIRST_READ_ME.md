# Read me first

## What the package does, in one paragraph

`3_cetas_fallback_copy` performs a nightly full refresh from static Azure Synapse dedicated-pool objects to ADLS Gen2 and then to Unity Catalog Delta. Each mapping tries CETAS first. If CETAS reaches a confirmed terminal failure and the mapping is configured with `fallback_method: COPY_ACTIVITY`, the orchestrator submits the packaged Synapse Copy pipeline to a fresh attempt path. Successful extracts are loaded to private Delta candidates, validated by row count, and then published independently through stable consumer views.

The package assumes the upstream nightly materialisation has finished and the mapped source data does not change during extraction. One table can fail without cancelling unrelated tables. Same-day recovery uses the same bridge run and is evidence-gated.

## Recommended reading order (first time, whole package)

1. `README.md` — operational overview, setup prerequisites, and execution sequence.
2. `docs/DESIGN.md` — architecture, invariants, failure behaviour, and boundaries.
3. `docs/PACKAGE_GUIDE.md` — every folder/file and how they connect.
4. `docs/CODE_STRUCTURE.md` — Python/Databricks call flow and module responsibilities.
5. `docs/DATA_DICTIONARY.md` — Azure SQL, Synapse audit, and Unity Catalog control state.
6. `docs/RUNBOOK.md` — installation, nightly operations, morning recovery, and maintenance.
7. `docs/RELEASE_VALIDATION.md` — checks to complete before production use.

## Shorter paths by role

- **Platform/deployment engineer:** `README.md` → `docs/PACKAGE_GUIDE.md` → `docs/RUNBOOK.md`.
- **Code reviewer:** `docs/DESIGN.md` → `docs/CODE_STRUCTURE.md` → `tests/`.
- **Support/operator:** `docs/RUNBOOK.md` → `docs/DATA_DICTIONARY.md`.
- **Security/governance reviewer:** `docs/DESIGN.md` sections on security and control boundaries, then `README.md` setup permissions.

## Where to find a specific answer

- Folder/file purpose: `docs/PACKAGE_GUIDE.md`
- Nightly sequence: `docs/CODE_STRUCTURE.md` and `docs/RUNBOOK.md`
- CETAS → Copy fallback: `docs/DESIGN.md`
- Control tables and statuses: `docs/DATA_DICTIONARY.md`
- Recovery: `docs/RUNBOOK.md`
- Production acceptance: `docs/RELEASE_VALIDATION.md`
