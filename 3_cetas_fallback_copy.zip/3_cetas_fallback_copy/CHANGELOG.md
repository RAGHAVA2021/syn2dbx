# Changelog

## 3_cetas_fallback_copy documentation/naming refresh — 2026-09-27

- Renamed the package root from the former `synapse_databricks_bridge_static_v7` name to `3_cetas_fallback_copy`.
- Updated the README title and package description to identify the CETAS-first / Synapse Copy Activity fallback design.
- Renamed the old `test_v7_regressions.py` file to `test_copy_regressions.py`; test intent is unchanged.
- Added `FIRST_READ_ME.md` and a `docs/` set covering package structure, design, code flow, data dictionary, runbook, and release validation.
- No extraction, loading, publication, recovery, SQL-control, or retention logic was intentionally changed in this naming/documentation refresh.

Historical SQL migration filenames remain unchanged because they describe the schema versions they upgrade, not the current package name.
