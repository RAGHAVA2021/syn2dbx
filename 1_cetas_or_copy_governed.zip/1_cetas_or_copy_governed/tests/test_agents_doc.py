"""AGENTS.md must stay truthful: every file it names must exist."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DOCS = ["AGENTS.md", "FIRST_READ_ME.md", "docs/PACKAGE_GUIDE.md", "docs/CODE_STRUCTURE.md"]


def test_every_referenced_path_exists():
    missing = []
    for doc in DOCS:
        text = (ROOT / doc).read_text()
        for p in set(re.findall(r"`((?:python|databricks|sql|tests|docs|synapse_pipeline)/[^`*<> …]+?)`", text)):
            if not (ROOT / p).exists():
                missing.append(f"{doc}: {p}")
    assert not missing, missing


def test_package_folder_named_in_docs():
    for doc in ("AGENTS.md", "FIRST_READ_ME.md", "docs/PACKAGE_GUIDE.md"):
        assert ROOT.name in (ROOT / doc).read_text(), doc
