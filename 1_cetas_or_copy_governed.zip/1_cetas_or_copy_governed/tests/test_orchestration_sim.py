"""Executes bridge_run.py and publish_run.py end to end against SQLite stand-ins.

Azure SQL and Synapse are emulated with SQLite (T-SQL functions translated);
CETAS, Synapse pipeline, ADLS and Databricks jobs are replaced by fakes. This checks the
control-state wiring: leases, attempts, failure, --resume and reconciliation.
It does not replace the platform acceptance tests.
"""
import json
import re
import sqlite3
import sys
from datetime import datetime, timedelta
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "python"))
import bridge_run  # noqa: E402
import publish_run  # noqa: E402
import recovery  # noqa: E402
import retire_releases as retention  # noqa: E402

CONTROL_DDL = """
CREATE TABLE bridge.source_fence(source_set_id TEXT PRIMARY KEY, state TEXT, generation_id TEXT,
  writer_owner TEXT, bridge_owner TEXT, heartbeat_utc TEXT, expires_utc TEXT, control_version INT DEFAULT 0);
CREATE TABLE bridge.runs(bridge_run_id TEXT PRIMARY KEY, upstream_run_id TEXT, generation_id TEXT,
  upstream_sequence INT, business_date TEXT, inventory_version TEXT, release_id TEXT UNIQUE, status TEXT,
  orchestrator_token TEXT, heartbeat_utc TEXT, created_utc TEXT, updated_utc TEXT, source_set_id TEXT);
CREATE TABLE bridge.object_attempts(bridge_run_id TEXT, mapping_id TEXT, attempt INT, method TEXT, status TEXT,
  leaf_path TEXT UNIQUE, source_request_id TEXT, source_rows INT, parquet_rows INT, delta_rows INT,
  error_text TEXT, delta_target TEXT, target_key TEXT, publication_strategy TEXT, consumer_target TEXT,
  source_operation_state TEXT, loader_run_id TEXT, loader_operation_state TEXT,
  updated_utc TEXT, retired_utc TEXT, staging_deleted_utc TEXT,
  PRIMARY KEY(bridge_run_id,mapping_id,attempt));
CREATE TABLE bridge.group_members(inventory_version TEXT, group_id TEXT, mapping_id TEXT, enabled INT,
  mandatory INT, strategy TEXT, PRIMARY KEY(inventory_version,mapping_id));
CREATE TABLE bridge.target_state(target_key TEXT PRIMARY KEY, published_release_id TEXT, published_sequence INT,
  high_water_sequence INT DEFAULT -1, previous_release_id TEXT, control_version INT DEFAULT 0,
  publish_owner TEXT, publish_token TEXT, publish_claimed_utc TEXT, publish_external_run_id TEXT,
  publish_operation_state TEXT);
CREATE TABLE bridge.fence_events(event_id INTEGER PRIMARY KEY, source_set_id TEXT, old_state TEXT,
  new_state TEXT, generation_id TEXT, actor TEXT, reason TEXT, at_utc TEXT);
CREATE TABLE bridge.recovery_events(recovery_event_id INTEGER PRIMARY KEY, action TEXT, bridge_run_id TEXT,
  mapping_id TEXT, attempt INT, target_key TEXT, external_run_id TEXT, actor TEXT, evidence_uri TEXT,
  reason TEXT, at_utc TEXT);
"""
SYN_DDL = """
CREATE TABLE bridge_meta.upstream_run(upstream_run_id TEXT, source_generation_id TEXT, upstream_sequence INT,
  business_date TEXT, status TEXT, write_closed INT, completed_utc TEXT);
CREATE TABLE bridge_meta.upstream_object(upstream_run_id TEXT, mapping_id TEXT, source_schema_version TEXT,
  status TEXT, row_count INT, refresh_started_utc TEXT, refresh_completed_utc TEXT);
"""
CLOCK = {"now": datetime(2026, 9, 22, 1, 0, 0)}


def ts(dt):
    return dt.strftime("%Y-%m-%d %H:%M:%S.%f")


def translate(sql):
    sql = re.sub(r"\bINSERT (bridge|bridge_meta)\.", r"INSERT INTO \1.", sql)
    sql = sql.replace(" WITH (UPDLOCK,HOLDLOCK)", "")
    sql = sql.replace("COUNT_BIG(", "count(").replace("count_big(", "count(")
    sql = sql.replace("DATEADD(minute,", "DATEADD('minute',")
    sql = sql.replace("DATEDIFF(hour,", "DATEDIFF('hour',")
    return sql


def release_fence_event(cur, generation, bridge_run_id, source_set="synapse_materialised"):
    cur.execute("INSERT INTO bridge.fence_events(source_set_id,old_state,new_state,generation_id,actor) "
                "VALUES (?,'BRIDGE_HELD','AVAILABLE',?,?)", source_set, generation, bridge_run_id)


class Cursor:
    def __init__(self, conn):
        self.c = conn.raw.cursor()
        self.rowcount = -1

    def execute(self, sql, *params):
        params = [str(p) if hasattr(p, "isoformat") else p for p in params]
        self.c.execute(translate(sql), params)
        self.rowcount = self.c.rowcount
        return self

    def fetchone(self):
        return self.c.fetchone()

    def fetchall(self):
        return self.c.fetchall()

    def __iter__(self):
        return iter(self.c.fetchall())


class Conn:
    def __init__(self, path, schema):
        self.raw = sqlite3.connect(":memory:", isolation_level="DEFERRED", check_same_thread=False)
        self.raw.execute(f"ATTACH DATABASE '{path}' AS {schema}")
        self.raw.create_function("SYSUTCDATETIME", 0, lambda: ts(CLOCK["now"]))
        self.raw.create_function("DATEADD", 3, lambda unit, n, t: ts(
            datetime.strptime(t, "%Y-%m-%d %H:%M:%S.%f") + timedelta(minutes=n)))
        self.raw.create_function("DATEDIFF", 3, lambda unit, start, end: None if start is None or end is None
                                 else int((datetime.strptime(end, "%Y-%m-%d %H:%M:%S.%f") -
                                           datetime.strptime(start, "%Y-%m-%d %H:%M:%S.%f")).total_seconds() // 3600))
        self.timeout = 0

    def cursor(self):
        return Cursor(self)

    def commit(self):
        self.raw.commit()

    def rollback(self):
        self.raw.rollback()

    def close(self):
        self.raw.close()


@pytest.fixture
def env(tmp_path, monkeypatch):
    control_db, syn_db = tmp_path / "control.db", tmp_path / "syn.db"
    for path, schema, ddl in ((control_db, "bridge", CONTROL_DDL), (syn_db, "bridge_meta", SYN_DDL)):
        c = Conn(path, schema); c.raw.executescript(ddl); c.commit(); c.close()

    from contextlib import contextmanager

    @contextmanager
    def fake_db(var, autocommit=False):
        conn = Conn(control_db, "bridge") if var == "BRIDGE_CONTROL_ODBC" else Conn(syn_db, "bridge_meta")
        try:
            yield conn
        except BaseException:
            conn.rollback(); raise
        finally:
            conn.close()

    doc = json.loads((ROOT / "config.example.json").read_text())
    doc["control_catalog"] = "cat"
    doc["staging_abfss_root"] = "abfss://landing@acct.dfs.core.windows.net"
    doc["loader_job_id"] = doc["publisher_job_id"] = doc["pointer_job_id"] = 1
    doc["heartbeat_seconds"] = 600
    for m in doc["mappings"]:
        m["target_catalog"] = "cat"
        m["source_schema_version"] = "sha256:x"
    cfg_path = tmp_path / "config.json"; cfg_path.write_text(json.dumps(doc))

    with fake_db("BRIDGE_CONTROL_ODBC") as c:
        cur = c.cursor()
        cur.execute("INSERT INTO bridge.source_fence VALUES ('synapse_materialised','BRIDGE_HELD','GEN1',NULL,'BRG1',NULL,?,3)",
                    ts(CLOCK["now"] + timedelta(hours=6)))
        for m in doc["mappings"]:
            cur.execute("INSERT INTO bridge.group_members VALUES (?,?,?,1,?,?)", doc["inventory_version"],
                        m["group_id"], m["mapping_id"], 1 if m["mandatory"] else 0, m["strategy"])
        # fence.py bridge-release records this after the detector gates; publish_run.py requires it.
        release_fence_event(cur, "GEN1", "BRG1")
        for key in {bridge_run.target_key(m) for m in doc["mappings"]}:
            cur.execute("INSERT INTO bridge.target_state(target_key,published_release_id,published_sequence,"
                        "high_water_sequence) VALUES (?,'NONE',-1,-1)", key)
        c.commit()
    with fake_db("SYN") as s:
        cur = s.cursor()
        cur.execute("INSERT INTO bridge_meta.upstream_run VALUES ('SYN1','GEN1',100,'2026-09-22','COMPLETE',1,NULL)")
        for i, m in enumerate(doc["mappings"]):
            cur.execute("INSERT INTO bridge_meta.upstream_object VALUES ('SYN1',?,'sha256:x','COMPLETE',?,NULL,NULL)",
                        m["mapping_id"], 10 + i)
        s.commit()

    state = {"fail_extract": set(), "delta": {}, "pointer": {"sales": "NONE"}, "calls": [],
             "fail_after_publish": False}

    def fake_extract(m, relative, started_callback=None, terminal_callback=None):
        state["calls"].append(("extract", m["mapping_id"], relative))
        if started_callback: started_callback("x_req")
        if m["mapping_id"] in state["fail_extract"]:
            state["fail_extract"].discard(m["mapping_id"])
            raise RuntimeError("simulated CETAS failure")
        if terminal_callback: terminal_callback("x_req", "SUCCEEDED")
        return "x_req"

    def fake_copy(cfg, m, item, started_callback=None, terminal_callback=None):
        return fake_extract(m, item["relative_path"], started_callback, terminal_callback)

    def fake_job(cfg, job_id, payload, run_id, started_callback=None, terminal_callback=None):
        external_id = "dbx_" + str(len(state["calls"]) + 1)
        if started_callback:
            started_callback(external_id)
        mode = payload.get("mode")
        if "leaf_path" in payload:                                   # loader
            n = payload["source_rows"]
            state["calls"].append(("load", payload["mapping_id"], payload["attempt"]))
            result = {"source_rows": n, "parquet_rows": n, "delta_rows": n,
                    "target": bridge_run.delta_target(payload, payload["bridge_run_id"], payload["attempt"]),
                    "release_id": payload["release_id"]}
            if terminal_callback: terminal_callback(external_id, "SUCCEEDED")
            return result
        if payload["strategy"] == "REPLACE_TABLE":
            m = payload["mapping"]
            if mode == "INSPECT":
                rel = state["delta"].get(m["target_table"])
                result = {"exists": bool(rel), "release_ids": [rel] if rel else [], "rows": m["source_rows"]}
                if terminal_callback: terminal_callback(external_id, "SUCCEEDED")
                return result
            if state.get("during_replace"):
                hook, state["during_replace"] = state["during_replace"], None
                hook()                                   # another run acts mid-replacement
            state["delta"][m["target_table"]] = payload["release_id"]
            state["calls"].append(("publish", m["target_table"], payload["release_id"]))
            result = {"release_id": payload["release_id"], "rows": m["source_rows"]}
            if terminal_callback: terminal_callback(external_id, "SUCCEEDED")
            return result
        if mode == "INSPECT":
            result = {"published_release_id": state["pointer"][payload["group_id"]]}
            if terminal_callback: terminal_callback(external_id, "SUCCEEDED")
            return result
        assert state["pointer"][payload["group_id"]] == payload["expected_current_release"]
        state["pointer"][payload["group_id"]] = payload["release_id"]
        state["calls"].append(("pointer", payload["group_id"]))
        if state["fail_after_publish"]:
            state["fail_after_publish"] = False
            raise RuntimeError("simulated lost acknowledgement after Delta commit")
        result = {"group_id": payload["group_id"], "release_id": payload["release_id"]}
        if terminal_callback: terminal_callback(external_id, "SUCCEEDED")
        return result

    import source_metadata
    monkeypatch.setattr(bridge_run, "db", fake_db)
    monkeypatch.setattr(publish_run, "db", fake_db)
    monkeypatch.setattr(bridge_run, "cetas", fake_extract)
    monkeypatch.setattr(bridge_run, "copy_activity", fake_copy)
    monkeypatch.setattr(bridge_run, "notebook_job", fake_job)
    monkeypatch.setattr(publish_run, "notebook_job", fake_job)
    monkeypatch.setattr(bridge_run, "require_empty_adls", lambda root, rel: None)
    monkeypatch.setattr(source_metadata, "schema_hash", lambda conn, s, v: "sha256:x")

    def run(module, *argv):
        monkeypatch.setattr(sys, "argv", ["x", *argv])
        module.main()

    def query(sql, *params):
        with fake_db("BRIDGE_CONTROL_ODBC") as c:
            rows = c.cursor().execute(sql, *params).fetchall()
            c.commit()
            return rows

    evidence = tmp_path / "ev.json"
    ev = {"bridge_run_id": "BRG1", "release_id": "rel_BRG1", "generation_id": "GEN1", "upstream_sequence": 100}
    for gate in ("fence_clean", "source_smoke_check", "audit_health", "policy_readiness",
                 "restricted_identity_tests", "consumer_contract_tests"):
        ev[gate] = True; ev[gate + "_evidence_uri"] = "https://evidence/" + gate
    evidence.write_text(json.dumps(ev))
    extract_args = ["--config", str(cfg_path), "--upstream-run-id", "SYN1", "--generation-id", "GEN1",
                    "--sequence", "100", "--business-date", "2026-09-22", "--bridge-run-id", "BRG1"]
    publish_args = ["--config", str(cfg_path), "--bridge-run-id", "BRG1", "--evidence", str(evidence)]
    return {"run": run, "query": query, "state": state, "extract": extract_args, "publish": publish_args}


def test_happy_path_extract_load_publish(env):
    env["run"](bridge_run, *env["extract"])
    assert env["query"]("SELECT status, orchestrator_token FROM bridge.runs") == [("READY", None)]
    env["run"](publish_run, *env["publish"])
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]
    states = dict(env["query"]("SELECT target_key, published_release_id FROM bridge.target_state"))
    assert set(states.values()) == {"rel_BRG1"}
    assert env["state"]["pointer"]["sales"] == "rel_BRG1"


def test_failed_extraction_resumes_with_new_attempt(env):
    env["state"]["fail_extract"].add("MAP_002")
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    assert env["query"]("SELECT status, orchestrator_token FROM bridge.runs") == [("FAILED", None)]
    with pytest.raises(RuntimeError, match="Run already exists"):
        env["run"](bridge_run, *env["extract"])
    env["run"](bridge_run, *env["extract"], "--resume")
    rows = env["query"]("SELECT mapping_id, attempt, status FROM bridge.object_attempts ORDER BY 1, 2")
    assert ("MAP_002", 1, "FAILED") in rows and ("MAP_002", 2, "READY") in rows
    assert [c for c in env["state"]["calls"] if c[0] == "extract" and c[1] == "MAP_001"].__len__() == 1
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]
    env["run"](publish_run, *env["publish"])
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]


def test_live_lease_blocks_takeover_until_stale(env):
    env["state"]["fail_extract"].add("MAP_001")
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    # Simulate a crashed orchestrator that still holds the lease.
    env["query"]("UPDATE bridge.runs SET status='EXTRACTING', orchestrator_token='other', heartbeat_utc=?",
                 ts(CLOCK["now"]))
    with pytest.raises(RuntimeError, match="live lease"):
        env["run"](bridge_run, *env["extract"], "--resume")
    CLOCK["now"] += timedelta(minutes=151)
    try:
        env["run"](bridge_run, *env["extract"], "--resume")
    finally:
        CLOCK["now"] -= timedelta(minutes=151)
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]


def test_expired_fence_after_extraction_fails_attempt(env, monkeypatch):
    original = bridge_run.cetas

    def slow(m, relative, *callbacks):
        CLOCK["now"] += timedelta(hours=7)                  # fence expires during the read
        return original(m, relative, *callbacks)

    monkeypatch.setattr(bridge_run, "cetas", slow)
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    CLOCK["now"] = datetime(2026, 9, 22, 1, 0, 0)
    assert "EXTRACTED" not in {r[0] for r in env["query"]("SELECT status FROM bridge.object_attempts")}


def test_publish_resume_reconciles_committed_pointer(env, monkeypatch, tmp_path_factory):
    env["run"](bridge_run, *env["extract"])
    env["state"]["fail_after_publish"] = True
    with pytest.raises(bridge_run.PhaseError):
        env["run"](publish_run, *env["publish"])
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHING",)]
    assert env["query"]("SELECT published_release_id FROM bridge.target_state WHERE target_key='group:sales'") \
        == [("NONE",)]
    # The mutating job committed but its acknowledgement was lost. v9.5 requires
    # matching terminal evidence before INSPECT may reconcile the Delta commit.
    monkeypatch.setattr(recovery, "db", bridge_run.db)
    external_id = env["query"]("SELECT publish_external_run_id FROM bridge.target_state "
                               "WHERE target_key='group:sales'")[0][0]
    evidence = tmp_path_factory.mktemp("publisher_terminal") / "terminal.json"
    evidence.write_text(json.dumps({"external_terminal": True, "safe_to_resume": True,
                                    "orchestrator_stopped": True, "external_run_id": external_id,
                                    "evidence_uri": "https://evidence/publisher-terminal"}))
    recovery.resolve_publication(type("Args", (), {
        "evidence": str(evidence), "bridge_run_id": "BRG1", "target_key": "group:sales",
        "actor": "operator", "reason": "verified committed publisher is terminal"})())
    env["run"](publish_run, *env["publish"], "--resume")
    assert env["query"]("SELECT published_release_id FROM bridge.target_state WHERE target_key='group:sales'") \
        == [("rel_BRG1",)]
    assert [c for c in env["state"]["calls"] if c[0] == "pointer"] == [("pointer", "sales")]  # not republished
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]


def _leave_in_publishing(env):
    env["run"](bridge_run, *env["extract"])
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING', orchestrator_token=NULL")


def test_publish_resume_refuses_unexpected_replace_table_state(env):
    _leave_in_publishing(env)
    env["state"]["delta"]["customer"] = "rel_SOMEONE_ELSE"       # not in Azure SQL, not this release
    with pytest.raises(bridge_run.PhaseError, match="freeze it for operator review"):
        env["run"](publish_run, *env["publish"], "--resume")
    assert not [c for c in env["state"]["calls"] if c[:2] == ("publish", "customer")]
    assert env["state"]["delta"]["customer"] == "rel_SOMEONE_ELSE"
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHING",)]


def test_publish_resume_reconciles_committed_replace_table(env):
    _leave_in_publishing(env)
    env["state"]["delta"]["customer"] = "rel_BRG1"               # committed, SQL update lost
    env["run"](publish_run, *env["publish"], "--resume")
    assert not [c for c in env["state"]["calls"] if c[:2] == ("publish", "customer")]
    assert env["query"]("SELECT published_release_id FROM bridge.target_state "
                        "WHERE target_key='table:cat.gold.customer'") == [("rel_BRG1",)]
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]


def _add_second_ready_run(env, tmp_path_factory):
    """BRG2: a newer READY run (sequence 101) over the same targets."""
    rows = env["query"]("SELECT mapping_id,attempt,method,leaf_path,source_rows,delta_target "
                        "FROM bridge.object_attempts WHERE bridge_run_id='BRG1'")
    env["query"]("INSERT INTO bridge.runs(bridge_run_id,upstream_run_id,generation_id,upstream_sequence,"
                 "business_date,inventory_version,release_id,status) SELECT 'BRG2','SYN2','GEN2',101,"
                 "business_date,inventory_version,'rel_BRG2','READY' FROM bridge.runs WHERE bridge_run_id='BRG1'")
    doc = json.loads(Path(env["extract"][1]).read_text())
    by_id = {m["mapping_id"]: m for m in doc["mappings"]}
    for mid, attempt, method, leaf, n, _ in rows:
        env["query"]("INSERT INTO bridge.object_attempts(bridge_run_id,mapping_id,attempt,method,status,leaf_path,"
                     "source_rows,parquet_rows,delta_rows,delta_target) VALUES ('BRG2',?,?,?,'READY',?,?,?,?,?)",
                     mid, attempt, method, leaf.replace("BRG1", "BRG2"), n, n, n,
                     bridge_run.delta_target(by_id[mid], "BRG2", attempt))
    env["query"]("INSERT INTO bridge.fence_events(source_set_id,old_state,new_state,generation_id,actor) "
                 "VALUES ('synapse_materialised','BRIDGE_HELD','AVAILABLE','GEN2','BRG2')")
    ev = json.loads(Path(env["publish"][-1]).read_text())
    ev.update({"bridge_run_id": "BRG2", "release_id": "rel_BRG2", "generation_id": "GEN2", "upstream_sequence": 101})
    path = tmp_path_factory.mktemp("ev2") / "ev2.json"
    path.write_text(json.dumps(ev))
    return ["--config", env["extract"][1], "--bridge-run-id", "BRG2", "--evidence", str(path)]


def _single_publisher(env):
    doc = json.loads(Path(env["extract"][1]).read_text())
    doc["max_publisher_workers"] = 1                  # deterministic group order
    Path(env["extract"][1]).write_text(json.dumps(doc))


def test_two_runs_cannot_replace_the_same_table_at_once(env, tmp_path_factory):
    _single_publisher(env)
    env["run"](bridge_run, *env["extract"])
    brg2 = _add_second_ready_run(env, tmp_path_factory)
    blocked = []

    def overlap():
        try:
            env["run"](publish_run, *brg2)
        except bridge_run.PhaseError as exc:
            blocked.append(str(exc))

    env["state"]["during_replace"] = overlap          # BRG2 starts while BRG1 is replacing 'customer'
    env["run"](publish_run, *env["publish"])
    # BRG2 published 'sales' meanwhile, so BRG1 must not roll that group back to its older release.
    assert env["state"]["pointer"]["sales"] == "rel_BRG2"
    assert env["query"]("SELECT status FROM bridge.runs WHERE bridge_run_id='BRG1'") == [("PUBLISHED",)]
    assert blocked and "being published by run BRG1" in blocked[0]
    customer = [c for c in env["state"]["calls"] if c[:2] == ("publish", "customer")]
    assert customer == [("publish", "customer", "rel_BRG1")]          # only one replacement happened
    assert env["state"]["delta"]["customer"] == "rel_BRG1"
    assert env["query"]("SELECT published_release_id, publish_owner FROM bridge.target_state "
                        "WHERE target_key='table:cat.gold.customer'") == [("rel_BRG1", None)]   # stores agree

    # BRG2 resumes, and its newer release replaces the table; both stores still agree.
    env["run"](publish_run, *brg2, "--resume")
    assert env["state"]["delta"]["customer"] == "rel_BRG2"
    assert env["query"]("SELECT published_release_id FROM bridge.target_state "
                        "WHERE target_key='table:cat.gold.customer'") == [("rel_BRG2",)]
    assert env["query"]("SELECT status FROM bridge.runs WHERE bridge_run_id='BRG2'") == [("PUBLISHED",)]


def test_older_run_never_rolls_back_a_newer_release(env, tmp_path_factory):
    _single_publisher(env)
    env["run"](bridge_run, *env["extract"])
    brg2 = _add_second_ready_run(env, tmp_path_factory)
    env["run"](publish_run, *brg2)                    # newer run publishes first
    env["run"](publish_run, *env["publish"])          # older run finishes without replacing anything
    assert env["state"]["delta"]["customer"] == "rel_BRG2"
    assert env["state"]["pointer"]["sales"] == "rel_BRG2"
    assert not [c for c in env["state"]["calls"] if c[:2] == ("publish", "customer") and c[2] == "rel_BRG1"]


def test_claim_left_by_failed_run_blocks_other_runs(env, tmp_path_factory):
    _single_publisher(env)
    env["run"](bridge_run, *env["extract"])
    brg2 = _add_second_ready_run(env, tmp_path_factory)
    # BRG1 crashed mid-replacement: it owns the claim and its outcome is unknown.
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING', orchestrator_token=NULL WHERE bridge_run_id='BRG1'")
    env["query"]("UPDATE bridge.target_state SET publish_owner='BRG1', publish_token='dead' "
                 "WHERE target_key='table:cat.gold.customer'")
    with pytest.raises(bridge_run.PhaseError, match="being published by run BRG1"):
        env["run"](publish_run, *brg2)
    assert not [c for c in env["state"]["calls"] if c[:2] == ("publish", "customer")]
    env["run"](publish_run, *env["publish"], "--resume")      # only the owner may continue
    assert env["query"]("SELECT published_release_id, publish_owner FROM bridge.target_state "
                        "WHERE target_key='table:cat.gold.customer'") == [("rel_BRG1", None)]


def test_indeterminate_extraction_remains_explicitly_blocking(env, monkeypatch):
    def unknown(m, relative, started_callback=None, terminal_callback=None):
        if started_callback: started_callback("synapse_live_123")
        raise bridge_run.Indeterminate("polling connection lost")
    monkeypatch.setattr(bridge_run, "cetas", unknown)
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    rows = env["query"]("SELECT status,source_request_id,source_operation_state FROM bridge.object_attempts "
                        "WHERE mapping_id='MAP_001'")
    assert rows == [("INDETERMINATE", "synapse_live_123", "UNKNOWN")]
    assert env["query"]("SELECT status,orchestrator_token IS NOT NULL FROM bridge.runs") == [("FAILED", 1)]
    with pytest.raises(RuntimeError, match="indeterminate external operation"):
        env["run"](bridge_run, *env["extract"], "--resume")


def test_attempt_records_cleanup_target_before_loader_finishes(env, monkeypatch):
    original = bridge_run.notebook_job
    def fail_loader(cfg, job_id, payload, run_id, *callbacks):
        if "leaf_path" in payload:
            if callbacks and callbacks[0]: callbacks[0]("dbx_failed_loader")
            raise RuntimeError("known loader failure")
        return original(cfg, job_id, payload, run_id, *callbacks)
    monkeypatch.setattr(bridge_run, "notebook_job", fail_loader)
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    rows = env["query"]("SELECT status,delta_target,target_key,consumer_target,loader_run_id "
                        "FROM bridge.object_attempts WHERE mapping_id='MAP_001'")
    assert rows[0][0] == "EXTRACTED"
    assert rows[0][1].startswith("cat.bridge_candidate.candidate_")
    assert rows[0][2:] == ("table:cat.gold.customer", "cat.gold.customer", "dbx_failed_loader")


def test_audited_recovery_resolves_indeterminate_attempt(env, monkeypatch, tmp_path_factory):
    def unknown(m, relative, started_callback=None, terminal_callback=None):
        if started_callback: started_callback("synapse_live_456")
        raise bridge_run.Indeterminate("unknown")
    monkeypatch.setattr(bridge_run, "cetas", unknown)
    monkeypatch.setattr(recovery, "db", bridge_run.db)
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    evidence = tmp_path_factory.mktemp("recovery") / "terminal.json"
    evidence.write_text(json.dumps({"external_terminal": True, "safe_to_retry": True, "phase": "SOURCE",
                                    "external_run_id": "synapse_live_456", "evidence_uri": "https://evidence/run"}))
    args = type("Args", (), {"evidence": str(evidence), "bridge_run_id": "BRG1", "mapping_id": "MAP_001",
                              "attempt": 1, "actor": "operator", "reason": "confirmed stopped"})()
    recovery.resolve_attempt(args)
    assert env["query"]("SELECT status,source_operation_state FROM bridge.object_attempts "
                        "WHERE mapping_id='MAP_001'") == [("FAILED", "VERIFIED_TERMINAL")]


def test_audited_recovery_can_abandon_publication_claim(env, monkeypatch, tmp_path_factory):
    env["run"](bridge_run, *env["extract"])
    monkeypatch.setattr(recovery, "db", bridge_run.db)
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING' WHERE bridge_run_id='BRG1'")
    env["query"]("UPDATE bridge.target_state SET publish_owner='BRG1',publish_token='dead',"
                 "publish_external_run_id='dbx_pub_1' WHERE target_key='table:cat.gold.customer'")
    evidence = tmp_path_factory.mktemp("pub_recovery") / "terminal.json"
    evidence.write_text(json.dumps({"external_terminal": True, "delta_state_verified": True,
                                    "safe_to_abandon": True, "external_run_id": "dbx_pub_1",
                                    "evidence_uri": "https://evidence/pub"}))
    args = type("Args", (), {"evidence": str(evidence), "bridge_run_id": "BRG1",
                              "target_key": "table:cat.gold.customer", "actor": "operator",
                              "reason": "generation rejected"})()
    recovery.abandon_publication(args)
    assert env["query"]("SELECT status FROM bridge.runs WHERE bridge_run_id='BRG1'") == \
        [("PUBLICATION_ABANDONED",)]
    assert env["query"]("SELECT publish_owner,publish_operation_state FROM bridge.target_state "
                        "WHERE target_key='table:cat.gold.customer'") == [(None, "ABANDONED")]


def test_retention_uses_attempt_metadata_for_removed_inventory_mapping(env, monkeypatch):
    monkeypatch.setattr(retention, "db", bridge_run.db)
    env["query"]("INSERT INTO bridge.runs(bridge_run_id,upstream_run_id,generation_id,upstream_sequence,"
                 "business_date,inventory_version,release_id,status,updated_utc) VALUES "
                 "('OLD','S','G',90,'2026-09-01','old_wave','rel_OLD','PUBLISHED',?)",
                 ts(CLOCK["now"] - timedelta(days=8)))           # published 8 days ago: past the 7-day window
    env["query"]("INSERT INTO bridge.target_state(target_key,published_release_id,published_sequence,"
                 "high_water_sequence,previous_release_id) VALUES "
                 "('table:cat.gold.old_table','rel_NEW',100,100,'rel_PREV')")
    env["query"]("INSERT INTO bridge.object_attempts(bridge_run_id,mapping_id,attempt,method,status,leaf_path,"
                 "source_rows,delta_target,target_key,publication_strategy,consumer_target) VALUES "
                 "('OLD','REMOVED_MAP',1,'CETAS','READY','bridge/parquet-stage/2026-09-01/OLD/REMOVED_MAP/attempt-001/',"
                 "1,'cat.bridge_candidate.candidate_removed','table:cat.gold.old_table','REPLACE_TABLE',"
                 "'cat.gold.old_table')")
    cfg = bridge_run.config(env["extract"][1])
    _, drops, staging = retention.plan(cfg, [])
    assert [d["table"] for d in drops] == ["candidate_removed"]
    assert [s["mapping_id"] for s in staging] == ["REMOVED_MAP"]
