# Changelog

Package `1_cetas_or_copy_governed` (formerly `bridge_v9_5_8_scripts`). Detailed
problem/fix tables for each version remain in `README.md`.

## 9.5.8 — package rename and documentation set
**No change to extraction, loading, publication or recovery logic.**

* **Renamed** the package folder from `bridge_v9_5_8_scripts` to
  `1_cetas_or_copy_governed`. Updated `PACKAGE_DIR` and the header comment in
  `databricks/generate_mappings_pyspark.py`, `WHERE_TO_ENTER_VALUES.md` and the
  `README.md` title and folder note.
* **Documentation:** added `FIRST_READ_ME.md` (reading order, question index,
  Confluence publishing guide), `AGENTS.md` (invariants, architecture map,
  rejected alternatives, safe-change rules), this `CHANGELOG.md`, and `docs/`:
  `PACKAGE_GUIDE.md`, `DESIGN.md` (summary of `DESIGN_v9.md`),
  `CODE_STRUCTURE.md`, `DATA_DICTIONARY.md`, `RUNBOOK.md`,
  `RELEASE_VALIDATION.md`.
* Added `tests/test_agents_doc.py` (paths named in the new documents exist) and
  `.gitignore`.

**Upgrade actions (from `bridge_v9_5_8_scripts`):**
* Upload the folder to `/Workspace/Shared/1_cetas_or_copy_governed` (or set
  `PACKAGE_DIR` to your location) and re-point any job, notebook or scheduler
  path that used the old folder name.
* No Azure SQL, Synapse or Unity Catalog change. No upgrade SQL.

## 9.5.8
Code review fixes. No Azure SQL schema change.
* Pointer publications of different groups run in parallel: `published_groups`
  gets deletion vectors; pointer `UPDATE` retries only Delta conflicts.
* `--business-date` must equal the upstream audit.
* Loader always runs in UTC.
* `publish_run.py` requires the recorded `BRIDGE_HELD → AVAILABLE` fence event.
* `recovery.py` accepts `idempotency_token` plus the real Databricks run ID.
* Retention applies the 7/30-day windows and retires FAILED/SUPERSEDED attempts
  of kept releases.

**Upgrade actions:** grant `SELECT` on `bridge.fence_events`; rerun
`generated/unity_catalog_setup.sql`; redeploy `load_candidate.py`,
`publish.py`, `retire_releases.py`; check timestamp conversions for UTC.

## 9.5.7
Documentation verification against Microsoft documentation.
* Dedicated-pool credential uses `IDENTITY = 'Managed Service Identity'`.
* `COPY_ACTIVITY` mappings may not declare `date`; loader narrows timestamp to
  date only when every value is midnight UTC.
* Database-scoped CETAS grants for a contained user; auto-optimization disabled
  on the loader too.

**Upgrade action:** `ALTER DATABASE SCOPED CREDENTIAL bridge_storage_mi WITH
IDENTITY = 'Managed Service Identity';`, then retest CETAS.

## 9.5.6
* `fence.py abandon` never relabels unattributed legacy runs
  (`--claim-legacy-runs`); upgrade backfills `source_set_id`.
* Rejected loader results become `FAILED`/`REJECTED`.
* Synapse deployment confirms the new definition.
* One UC name space per inventory; pre-submission interrupts are retryable.

## 9.5.5
* `resolve-attempt` evidence must match the unresolved phase.
* Pointer mappings cannot share a `_snapshots` table; views filter on
  `mapping_object_id`.
* `abandon`/`reopen` scoped to the source set (`runs.source_set_id`).
* Synapse deployment waits for asynchronous operations.

**Upgrade action:** run `sql/03_upgrade_to_v9_5.sql`; replace existing pointer
views through a governed change.

## 9.5.3
* `COPY_ACTIVITY` uses the Synapse workspace data-plane API (`2020-12-01`) with a
  persisted `source_correlation`.

## 9.5.2
* `PENDING` attempts no longer block `abandon`/`reopen`; guard locks attempt
  rows; `resolve-attempt` handles `ABANDONED_GENERATION` rows.

## 9.5.1
* Generation-level unresolved-source guards on `abandon`/`reopen`; retention
  skips live operations; control identifiers bounded to column sizes.

## 9.5
* Resume refuses unresolved mutating publishers; `resolve-publication` added;
  INSPECT never overwrites publisher IDs; Job timeout ≤ 7,200 s required.

## 9.4
* Per-invocation Databricks idempotency tokens; orphaned reads/loads become
  `INDETERMINATE`; server SQLSTATE CETAS errors are terminal;
  `fence.release_blockers()`.

## 9.3
* Per-target publication claims; resume refuses unexpected Delta state;
  `INDETERMINATE` state; `recovery.py`; retention from attempt metadata; minimum
  takeover 135 minutes.

## 9.1
* Post-read fence re-check; Copy row evidence; `--resume` and attempt numbering;
  single-member REPLACE_TABLE groups; INSPECT reconciliation; SHA-256 manifests;
  idempotent `render_setup.py`; retention job.

## 9.0
* Initial executable reference for `DESIGN_v9.md`.
