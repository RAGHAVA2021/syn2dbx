# Read me first

This page tells you **which document to read, and in what order**. Start here
if you are new to the `1_cetas_or_copy_governed` package (Synapse → Databricks
governed bridge, code version v9.5.8).

## What the package does, in one paragraph

After the upstream process rebuilds the materialised tables in an Azure Synapse
dedicated SQL pool, the bridge **freezes that source generation with a fence**,
records an authoritative row count for every mapped view, and exports each view
to ADLS Parquet with **CETAS** or, for CETAS-incompatible objects, a **Synapse
Copy Activity**. A Databricks loader job checks the Parquet against the audit
(audit = Parquet = Delta) and writes it into an unpublished candidate or snapshot
table. Only after independent evidence (fence clean, policy and consumer tests)
is recorded does a separate publication step make the release visible: either by
atomically replacing one table (`REPLACE_TABLE`) or by flipping one pointer row
for a whole group of tables (`RELEASE_POINTER`). All state lives in an Azure SQL
control database; every unknown outcome stops and waits for audited recovery.

## Recommended reading order (first time, whole package)

| # | Document | What you learn |
|---|---|---|
| 1 | `README.md` | Overview, scope limits, deployment steps, nightly command order, recovery rules, version fixes. |
| 2 | `docs/PACKAGE_GUIDE.md` | Purpose of every folder and file, how they relate, and the setup, nightly and recovery flow. **The main map.** |
| 3 | `docs/DESIGN.md` | Why it is built this way: architecture, fence, routes, publication strategies, failure handling, security. Summary of `DESIGN_v9.md`. |
| 4 | `docs/CODE_STRUCTURE.md` | How the code is wired: scripts, notebooks, jobs, shared functions, call sequences. |
| 5 | `docs/DATA_DICTIONARY.md` | What gets written: control-table columns, statuses, IDs, paths, Delta metadata columns. |
| 6 | `docs/RUNBOOK.md` | Exact setup commands, the nightly sequence, morning checks, recovery and rollback. |
| 7 | `AGENTS.md` | Rules that must never be broken, rejected alternatives, how to change code safely. |
| 8 | `docs/RELEASE_VALIDATION.md` | Go-live checklist. |
| 9 | `CHANGELOG.md` | What changed in each version. Read when upgrading. |
| 10 | `DESIGN_v9.md` | The full governing design (long). Reference when a detail is needed. |

Supporting references kept from earlier versions:

| Document | Use it for |
|---|---|
| `SCRIPT_GUIDE.md` | Every script in execution order, with what it reads and writes. |
| `WHERE_TO_ENTER_VALUES.md` | Every environment value, config field and grant. |
| `IMPLEMENTATION_STATUS.md` | What is implemented versus what still needs environment-specific work. |

## Shorter paths by role

| Reader | Read in this order |
|---|---|
| Manager or reviewer | `README.md` (first two sections) → `docs/PACKAGE_GUIDE.md` → `docs/DESIGN.md` (sections 1–3) → `IMPLEMENTATION_STATUS.md` |
| Operator (runs it daily) | `docs/PACKAGE_GUIDE.md` (section 3) → `docs/RUNBOOK.md` → `docs/DATA_DICTIONARY.md` |
| Developer (changes code) | `README.md` → `docs/PACKAGE_GUIDE.md` → `docs/DESIGN.md` → `docs/CODE_STRUCTURE.md` → `AGENTS.md` → `docs/DATA_DICTIONARY.md` |
| Platform administrator | `WHERE_TO_ENTER_VALUES.md` → `docs/RUNBOOK.md` ("One-time setup") → `docs/DESIGN.md` (section 6) |
| Go-live approver | `docs/DESIGN.md` (sections 6–8) → `IMPLEMENTATION_STATUS.md` → `docs/RELEASE_VALIDATION.md` |

## Where to find a specific answer

| Question | Go to |
|---|---|
| What is this folder or file for? | `docs/PACKAGE_GUIDE.md` section 2 |
| What happens each night, step by step? | `docs/PACKAGE_GUIDE.md` section 3, `docs/RUNBOOK.md` ("Nightly sequence") |
| Why was it designed like this? | `docs/DESIGN.md` section 3, then `DESIGN_v9.md` |
| CETAS or Copy Activity: which route for which table? | `docs/DESIGN.md` section 3.3 |
| REPLACE_TABLE or RELEASE_POINTER? | `docs/DESIGN.md` section 3.4 |
| Which script calls which job or function? | `docs/CODE_STRUCTURE.md` |
| What does a column or status mean? | `docs/DATA_DICTIONARY.md` |
| A run failed. What do I do? | `docs/RUNBOOK.md` ("Every morning", "Recovery situations") |
| An attempt is `INDETERMINATE`. What evidence is needed? | `docs/RUNBOOK.md` ("Recovery evidence"), `README.md` ("Recovery evidence files") |
| How do I roll back a table or group? | `docs/RUNBOOK.md` ("Rollback") |
| Where do I put the ADLS account, job IDs, etc.? | `WHERE_TO_ENTER_VALUES.md` |
| What is not implemented yet? | `IMPLEMENTATION_STATUS.md` |
| Is it ready for production? | `docs/RELEASE_VALIDATION.md` |

## Publishing these documents to Confluence

Upload these as Confluence pages, under one parent page, in this order:

| Page order | Source file | Audience |
|---|---|---|
| Parent page | `FIRST_READ_ME.md` | Everyone |
| 1 | `README.md` (as "Overview") | Everyone |
| 2 | `docs/PACKAGE_GUIDE.md` | Everyone |
| 3 | `docs/DESIGN.md` | Everyone |
| 4 | `docs/CODE_STRUCTURE.md` | Developers |
| 5 | `docs/DATA_DICTIONARY.md` | Operators, developers |
| 6 | `docs/RUNBOOK.md` | Operators |
| 7 | `WHERE_TO_ENTER_VALUES.md` | Administrators |
| 8 | `IMPLEMENTATION_STATUS.md` | Approvers, reviewers |
| 9 | `docs/RELEASE_VALIDATION.md` | Approvers, operators |

Keep these in the Git repository only, not in Confluence: `AGENTS.md`
(maintainer and AI-agent rules tied to the code and checked by a test),
`CHANGELOG.md` (link to the repository instead), `SCRIPT_GUIDE.md` (tied to the
script header comments) and `DESIGN_v9.md` (very long; link to it, or attach it
as a file).

Notes for uploading:

* Several documents contain Mermaid diagrams. Confluence shows them only if
  your site has a Mermaid macro or app installed. Otherwise, export each
  diagram as an image (for example from mermaid.live) and insert the image.
* Relative links between files will not work in Confluence. Replace them with
  links to the matching Confluence pages.
* The Git repository stays the source of truth. After a document changes in
  Git, update its Confluence page, and add a line at the top of each page
  saying which package version it reflects (currently
  `1_cetas_or_copy_governed` v9.5.8).
