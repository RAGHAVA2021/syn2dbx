"""Publish a READY bridge run after recorded fence, policy and consumer gates.

Step 8 of the nightly flow (see SCRIPT_GUIDE.md). A run interrupted in PUBLISHING
is continued with --resume: each target is first compared with its actual Delta
state (INSPECT mode of databricks/publish.py). A Delta commit whose Azure SQL
update was lost is reconciled instead of republished; an unexpected Delta state
freezes that target for operator review.
"""
import argparse
import json
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

from bridge_run import (Indeterminate, LATEST_ATTEMPTS, OWNED, PhaseError, RunLease, candidate_table_name,
                        claim_run, config, db, delta_target, fetchone, is_indeterminate, need,
                        notebook_job, target_key, update_run)


def read_state(key):
    with db("BRIDGE_CONTROL_ODBC") as control:
        state = fetchone(control, "SELECT published_release_id,high_water_sequence,control_version,publish_owner,"
                                  "publish_external_run_id,publish_operation_state "
                                  "FROM bridge.target_state WHERE target_key=?", key)
    need(state, f"Missing control state: {key}")
    return state


def require_resolved_publisher(ctx, key, state):
    """Do not inspect or republish while an earlier mutating job may still commit.

    A v9.4 resume overwrote the stored publisher ID with the read-only INSPECT ID.
    Preserve that evidence and require an operator to prove the mutating run terminal.
    """
    if (ctx["resume"] and state[3] == ctx["run_id"]
            and state[5] in ("RUNNING", "UNKNOWN")):
        raise RuntimeError(
            f"Target {key} still has unresolved publisher {state[4]} ({state[5]}); "
            "verify it is terminal and run recovery.py resolve-publication before --resume")


def inspect_job(cfg, job_id, payload, run_id):
    """Run a read-only inspection without replacing the mutating publisher's ID.

    An unknown INSPECT outcome is safe to retry because INSPECT cannot change Delta.
    Convert it to an ordinary failure so the orchestrator lease is released promptly.
    """
    try:
        return notebook_job(cfg, job_id, payload, run_id)
    except Indeterminate as exc:
        raise RuntimeError(f"Read-only Delta inspection did not return a result; retry is safe: {exc}") from None


def check_order(ctx, key, state):
    """Return None to proceed, or an outcome when this target needs no publication."""
    if state[0] == ctx["release"]:
        need(state[1] == ctx["sequence"], f"Inconsistent control state for {key}")
        return "already-published"
    if state[1] > ctx["sequence"] and state[3] != ctx["run_id"]:
        # A newer release is already live; publishing this older one would roll consumers back.
        return "superseded-by-newer"
    need(ctx["sequence"] > state[1], f"Stale target: {key}")
    return None


def claim_target(ctx, key, state):
    """Take the per-target publication claim before any Delta change.

    Two READY runs can overlap (one waiting for its gates while the next night's run
    finishes). CREATE OR REPLACE TABLE is unconditional, so without this claim both
    could replace the table and the loser's Azure SQL update would fail after its
    Delta commit. A claim left by a failed run is not taken over by other runs: only
    the owning run's --resume, which inspects Delta first, may continue.
    """
    with db("BRIDGE_CONTROL_ODBC") as control:
        cur = control.cursor()
        cur.execute("UPDATE bridge.target_state SET publish_owner=?,publish_token=?,"
                    "publish_claimed_utc=SYSUTCDATETIME() WHERE target_key=? AND control_version=? "
                    "AND high_water_sequence=? AND high_water_sequence<? "
                    "AND (publish_owner IS NULL OR publish_owner=?) AND " + OWNED,
                    ctx["run_id"], ctx["token"], key, state[2], state[1], ctx["sequence"], ctx["run_id"],
                    ctx["run_id"], ctx["token"])
        if cur.rowcount != 1:
            now = fetchone(control, "SELECT publish_owner,control_version FROM bridge.target_state "
                                    "WHERE target_key=?", key)
            if now and now[0] and now[0] != ctx["run_id"]:
                raise RuntimeError(f"Target {key} is being published by run {now[0]}; wait for it to finish "
                                   "or resume that run")
            raise RuntimeError(f"Target {key} changed before it could be claimed; rerun with --resume")
        control.commit()


def record_publication(ctx, key, state):
    """Advance Azure SQL state and release the claim, only from the exact version observed."""
    with db("BRIDGE_CONTROL_ODBC") as control:
        cur = control.cursor()
        cur.execute("UPDATE bridge.target_state SET previous_release_id=published_release_id, "
                    "published_release_id=?,published_sequence=?,high_water_sequence=?, "
                    "control_version=control_version+1,publish_owner=NULL,publish_token=NULL,"
                    "publish_claimed_utc=NULL,publish_external_run_id=NULL,publish_operation_state='SUCCEEDED' "
                    "WHERE target_key=? AND control_version=? "
                    "AND high_water_sequence=? AND publish_owner=? AND publish_token=? AND " + OWNED,
                    ctx["release"], ctx["sequence"], ctx["sequence"], key, state[2], state[1],
                    ctx["run_id"], ctx["token"], ctx["run_id"], ctx["token"])
        need(cur.rowcount == 1, f"Delta is published but Azure SQL state changed concurrently; freeze {key} "
                                "and rerun with --resume after review")
        control.commit()


def publication_callbacks(ctx, key):
    def started(external_id):
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            cur.execute("UPDATE bridge.target_state SET publish_external_run_id=?,publish_operation_state='RUNNING' "
                        "WHERE target_key=? AND publish_owner=? AND publish_token=? AND " + OWNED,
                        external_id, key, ctx["run_id"], ctx["token"], ctx["run_id"], ctx["token"])
            need(cur.rowcount == 1, "Could not persist publisher external run ID")
            control.commit()

    def terminal(external_id, state):
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            cur.execute("UPDATE bridge.target_state SET publish_operation_state=? WHERE target_key=? "
                        "AND publish_owner=? AND publish_token=? AND publish_external_run_id=? AND " + OWNED,
                        state, key, ctx["run_id"], ctx["token"], external_id, ctx["run_id"], ctx["token"])
            need(cur.rowcount == 1, "Could not persist terminal publisher state")
            control.commit()
    return started, terminal


def replace_state_is_this_release(seen, release, rows):
    return seen.get("exists") is True and seen.get("release_ids") == [release] and seen.get("rows") == rows


def replace_state_matches_control(seen, published):
    """True only when Delta shows exactly what Azure SQL says is published.

    Before the first bridge publication (published == 'NONE') the target may be absent,
    or a pre-existing consumer table without bridge metadata (release_ids None). Anything
    else, including a partial or foreign release, is an unexpected state.
    """
    if published == "NONE":
        return seen.get("exists") is False or seen.get("release_ids") is None
    return seen.get("exists") is True and seen.get("release_ids") == [published]


def publish_replace(cfg, ctx, lease, m, attempt_row):
    key = target_key(m)
    state = read_state(key)
    require_resolved_publisher(ctx, key, state)
    outcome = check_order(ctx, key, state)
    if outcome:
        return outcome
    lease.check()
    claim_target(ctx, key, state)
    started, terminal = publication_callbacks(ctx, key)
    mapping = {**m, "candidate_table": candidate_table_name(m["mapping_id"], ctx["run_id"], attempt_row["attempt"]),
               "attempt": attempt_row["attempt"], "source_rows": attempt_row["source_rows"],
               "generation_id": ctx["generation_id"]}
    base = {"strategy": "REPLACE_TABLE", "mapping": mapping, "release_id": ctx["release"],
            "upstream_sequence": ctx["sequence"]}
    lease.check()
    if ctx["resume"]:
        seen = inspect_job(cfg, cfg["publisher_job_id"], {**base, "mode": "INSPECT"}, ctx["run_id"])
        if replace_state_is_this_release(seen, ctx["release"], mapping["source_rows"]):
            record_publication(ctx, key, state)          # earlier attempt committed; SQL update was lost
            return "reconciled"
        need(replace_state_matches_control(seen, state[0]),
             f"Target {key} holds releases {seen.get('release_ids')} (exists={seen.get('exists')}), which match "
             f"neither Azure SQL ({state[0]}) nor a complete {ctx['release']}; freeze it for operator review")
    result = notebook_job(cfg, cfg["publisher_job_id"], {**base, "mode": "PUBLISH"}, ctx["run_id"],
                          started, terminal)
    need(result.get("release_id") == ctx["release"] and result.get("rows") == mapping["source_rows"],
         f"Publisher output mismatch: {key}")
    record_publication(ctx, key, state)
    return "published"


def publish_pointer(cfg, ctx, lease, group_id, members, attempts):
    key = "group:" + group_id
    state = read_state(key)
    require_resolved_publisher(ctx, key, state)
    need(state[0], f"Missing group control: {key}")
    outcome = check_order(ctx, key, state)
    if outcome:
        return outcome
    with db("BRIDGE_CONTROL_ODBC") as control:
        known = {r[0] for r in control.cursor().execute(
            "SELECT mapping_id FROM bridge.group_members WHERE inventory_version=? AND group_id=? "
            "AND enabled=1 AND mandatory=1 AND strategy='RELEASE_POINTER'", cfg["inventory_version"], group_id)}
    need({m["mapping_id"] for m in members} == known, f"Group membership mismatch: {group_id}")
    base = {"strategy": "RELEASE_POINTER", "group_id": group_id,
            "members": [{**m, "source_rows": attempts[m["mapping_id"]]["source_rows"],
                         "attempt": attempts[m["mapping_id"]]["attempt"]} for m in members],
            "release_id": ctx["release"], "generation_id": ctx["generation_id"], "bridge_run_id": ctx["run_id"],
            "group_contract_version": members[0]["group_contract_version"],
            "upstream_sequence": ctx["sequence"], "expected_current_release": state[0],
            "control_catalog": cfg["control_catalog"], "control_schema": cfg["control_schema"]}
    lease.check()
    # The Delta pointer update is conditional already; the claim also stops two runs
    # from invoking the pointer job for the same group at once.
    claim_target(ctx, key, state)
    started, terminal = publication_callbacks(ctx, key)
    if ctx["resume"]:
        seen = inspect_job(cfg, cfg["pointer_job_id"], {**base, "mode": "INSPECT"}, ctx["run_id"])
        if seen.get("published_release_id") == ctx["release"]:
            record_publication(ctx, key, state)
            return "reconciled"
        need(seen.get("published_release_id") == state[0],
             f"Delta pointer {seen.get('published_release_id')} matches neither Azure SQL ({state[0]}) "
             f"nor this release; freeze {key} for operator review")
    result = notebook_job(cfg, cfg["pointer_job_id"], {**base, "mode": "PUBLISH"}, ctx["run_id"],
                          started, terminal)
    need(result.get("release_id") == ctx["release"], "Pointer outcome ambiguous")
    record_publication(ctx, key, state)
    return "published"


def publish_group(cfg, ctx, lease, attempts, group_id, members):
    if members[0]["strategy"] == "REPLACE_TABLE":
        return publish_replace(cfg, ctx, lease, members[0], attempts[members[0]["mapping_id"]])
    return publish_pointer(cfg, ctx, lease, group_id, members, attempts)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--bridge-run-id", required=True)
    parser.add_argument("--evidence", required=True, help="Recorded results from independent gate jobs")
    parser.add_argument("--resume", action="store_true",
                        help="Continue a run left in PUBLISHING after reconciling each target with Delta")
    a = parser.parse_args()
    cfg = config(a.config)
    ev = json.loads(Path(a.evidence).read_text())
    need(ev.get("bridge_run_id") == a.bridge_run_id, "Evidence for different run")
    for gate in ("fence_clean", "source_smoke_check", "audit_health", "policy_readiness",
                 "restricted_identity_tests", "consumer_contract_tests"):
        need(ev.get(gate) is True and ev.get(gate + "_evidence_uri"), f"Missing evidence: {gate}")
    by_mapping = {m["mapping_id"]: m for m in cfg["mappings"]}
    with db("BRIDGE_CONTROL_ODBC") as control:
        run = fetchone(control, "SELECT upstream_run_id,generation_id,inventory_version,release_id,status,upstream_sequence "
                       "FROM bridge.runs WHERE bridge_run_id=?", a.bridge_run_id)
        need(run and run[2] == cfg["inventory_version"], "Run missing or inventory changed")
        need(run[4] == ("PUBLISHING" if a.resume else "READY"),
             f"Run status is {run and run[4]}; use --resume only for PUBLISHING runs")
        need(ev.get("release_id") == run[3] and ev.get("generation_id") == run[1], "Evidence release/generation mismatch")
        need(type(ev.get("upstream_sequence")) is int and ev["upstream_sequence"] == run[5],
             "Evidence source sequence mismatch")
        # The evidence file's fence_clean is an attestation; the control database itself records
        # whether this run returned the source to writers. Publication follows bridge-release.
        # Checked when READY -> PUBLISHING only: a PUBLISHING run already passed it, and a run left
        # PUBLISHING by v9.5.7 (which did not check) could otherwise never finish, because
        # bridge-release accepts only READY runs and abandon refuses PUBLISHING ones.
        if not a.resume:
            released = fetchone(control, "SELECT count(*) FROM bridge.fence_events WHERE source_set_id=? "
                                         "AND generation_id=? AND actor=? AND old_state='BRIDGE_HELD' "
                                         "AND new_state='AVAILABLE'", cfg["source_set_id"], run[1], a.bridge_run_id)
            need(released and released[0] >= 1,
                 f"Source fence was not released by {a.bridge_run_id} for generation {run[1]}: run "
                 "fence.py bridge-release with detector evidence before publishing")
        rows = control.cursor().execute(LATEST_ATTEMPTS, a.bridge_run_id).fetchall()
        attempts = {r[0]: {"attempt": r[1], "status": r[2], "source_rows": r[4], "parquet_rows": r[5],
                           "delta_rows": r[6], "delta_target": r[7]} for r in rows}
        need(set(attempts) == set(by_mapping), "Run has missing or unexpected mapping attempts")
        for mid, r in attempts.items():
            need(r["status"] == "READY" and r["source_rows"] == r["parquet_rows"] == r["delta_rows"],
                 f"Member not reconciled: {mid}")
            need(r["delta_target"] == delta_target(by_mapping[mid], a.bridge_run_id, r["attempt"]),
                 f"Recorded Delta target differs: {mid}")
        takeover = cfg.get("takeover_after_minutes", 150)
        token = claim_run(control, a.bridge_run_id, (run[4],), "PUBLISHING", takeover)
    ctx = {"run_id": a.bridge_run_id, "token": token, "release": run[3], "generation_id": run[1],
           "sequence": int(run[5]), "resume": a.resume}
    try:
        with RunLease(a.bridge_run_id, token, cfg.get("heartbeat_seconds", 60)) as lease:
            groups = {}
            for m in cfg["mappings"]:
                groups.setdefault(m["group_id"], []).append(m)
            failures, outcomes = [], {}
            with ThreadPoolExecutor(max_workers=cfg.get("max_publisher_workers", 1)) as pool:
                futures = {pool.submit(publish_group, cfg, ctx, lease, attempts, group_id, members): group_id
                           for group_id, members in groups.items()}
                for future in as_completed(futures):
                    try:
                        outcomes[futures[future]] = future.result()
                    except BaseException as exc:
                        failures.append(exc)
                        print(f"ERROR group {futures[future]}: {exc}")
            if failures:
                raise PhaseError(f"{len(failures)} publication group(s) failed; first: {failures[0]}", failures)
            lease.check()
            with db("BRIDGE_CONTROL_ODBC") as control:
                update_run(control, a.bridge_run_id, token, "PUBLISHING", "PUBLISHED", release_lease=True)
    except BaseException as exc:
        keep = is_indeterminate(exc)
        try:
            with db("BRIDGE_CONTROL_ODBC") as control:
                # PUBLISHING stays: other groups may be live. Release the lease so --resume can
                # reconcile, unless an external job may still be running.
                control.cursor().execute(
                    "UPDATE bridge.runs SET updated_utc=SYSUTCDATETIME(),"
                    "orchestrator_token=CASE WHEN ?=1 THEN orchestrator_token ELSE NULL END "
                    "WHERE bridge_run_id=? AND orchestrator_token=? AND status='PUBLISHING'",
                    1 if keep else 0, a.bridge_run_id, token)
                control.commit()
        except Exception as record_error:
            print(f"WARNING could not release publication lease: {record_error}")
        raise
    print(json.dumps({"bridge_run_id": a.bridge_run_id, "status": "PUBLISHED", "targets": outcomes}))


if __name__ == "__main__":
    main()
