# AGENTS.md — design intent for AI agents working on this package

This file is written for AI coding and operations agents (and the humans
reviewing their work). It says **what `1_cetas_or_copy_governed` is for, which
rules must never be broken, why each design choice was made, and how to change
things safely**.

Read it fully before editing code, generating SQL, or running commands.
`DESIGN_v9.md` is the governing design, `docs/DESIGN.md` its summary and
`docs/RUNBOOK.md` the operating procedures. If this file and `DESIGN_v9.md`
disagree, stop and ask a human.

---

## 1. Purpose in one paragraph

Copy Synapse dedicated-pool presentation views into Unity Catalog Delta, in full,
per source generation, so that consumers only ever see a complete, verified,
single-generation release. Extraction uses CETAS or a Synapse Copy Activity into
fresh ADLS paths; loading and publication are separate steps with separate
identities and gates. Azure SQL is the only source of truth for state.

## 2. Environment facts

* Control host runs `python/` with ODBC strings in `BRIDGE_CONTROL_ODBC`,
  `BRIDGE_SYNAPSE_AUDIT_ODBC`, `BRIDGE_CETAS_ODBC`.
* Databricks work runs as four serverless jobs: loader, Strategy A publisher,
  pointer publisher, retention (`databricks/`).
* The package folder name is `1_cetas_or_copy_governed`; the notebook
  `PACKAGE_DIR` must match it (`tests/test_static.py`).
* No real environment, inventory or identities are included in the package.

## 3. Invariants — never break these

1. **Never read a generation the bridge does not hold.** Check the fence before
   extraction and again (margin 0) after every read, before `EXTRACTED`.
2. **Every fence change goes through `bridge.transition_fence`.** No direct
   `UPDATE` of `bridge.source_fence`.
3. **audit = Parquet = Delta**, for every mapping, every run. No empty result
   unless `allow_empty` and an approved design exist (currently rejected).
4. **Unknown is not failure.** Post-submission uncertainty is `INDETERMINATE`
   (or `RUNNING`/`UNKNOWN`) and blocks resume, release, abandon and reopen until
   `python/recovery.py` records evidence for the stored external ID.
5. **Persist external IDs before polling**, and Databricks tokens (`token:…`)
   before `run-now`. Each invocation uses a fresh token.
6. **Every control write is conditional** on the run lease token, the fence
   version, or the publication claim.
7. **Loading never publishes.** The loader has no `MANAGE` on consumer tables.
8. **Publication requires recorded evidence and the recorded fence release**
   for this run.
9. **Never publish an older sequence over a newer one** (`high_water_sequence`);
   never roll back a newer release automatically.
10. **One publication claim per target.** Take it before changing Delta; clear
    it in the same update that records the publication.
11. **All `RELEASE_POINTER` members of an enabled group are mandatory** and share
    one `group_contract_version`; a `REPLACE_TABLE` group has one member.
12. **Retention keeps the published and previous releases** and never touches a
    run that is `PUBLISHING` or a release that could still be published.
13. **No free-form SQL in config.** Only named columns and approved conversions.
14. **Fail closed on configuration**: `bridge_run.config()` validates
    everything at start; do not weaken a check to make a config pass.
15. **Evidence is never fabricated.** Do not write evidence files with `true`
    values to unblock a run.

## 4. Architecture map (where each responsibility lives)

| Responsibility | File |
|---|---|
| Config contract, leases, job submission, extraction, loading orchestration | `python/bridge_run.py` |
| Fence transitions and release/abandon guards | `python/fence.py`, `sql/01_azure_sql_control.sql` |
| Upstream audit | `python/upstream_audit.py`, `sql/02_synapse_setup.sql` |
| Schema hash | `python/source_metadata.py` |
| Publication gates and reconciliation | `python/publish_run.py` |
| Delta publication and inspection | `databricks/publish.py` |
| Parquet verification and Delta load | `databricks/load_candidate.py` |
| Retention planning / execution | `python/retire_releases.py`, `databricks/retire_releases.py` |
| Audited recovery | `python/recovery.py` |
| Idempotent setup SQL | `python/render_setup.py` |
| Copy route artifacts | `python/deploy_synapse_pipeline.py`, `synapse_pipeline/` |
| Control schema upgrade | `sql/03_upgrade_to_v9_5.sql` |

## 5. Design decisions (with rejected alternatives)

| Decision | Rejected alternative | Why |
|---|---|---|
| Source fence in Azure SQL | Rely on schedule timing | Timing cannot prove no writer ran |
| Unique `attempt-NNN` paths, proven empty | Overwrite one path | Retries could mix files |
| Manifest file + SHA-256 | Notebook parameters | Size limit; tamper detection |
| Delta `txnAppId`/`txnVersion` | Delete-then-insert | Re-run safety without windows of missing data |
| Separate load and publish | Publish at end of load | Gates need independent evidence |
| Pointer row for groups | Replace tables one by one | Consumers would see mixed generations |
| Evidence-gated recovery | Automatic timeout-based retry | A still-running job could double-write |
| Conflict-only retry on pointer update | Serialise all pointer groups | Parallelism with the same guards |

## 6. Status vocabulary

Run statuses (`bridge.runs.status`):

| Status | Meaning |
|---|---|
| `CREATED` | Run row created |
| `EXTRACTING` | Extraction phase |
| `EXTRACTED` | All mappings extracted |
| `LOADING` | Loader phase |
| `READY` | Loaded, not published |
| `PUBLISHING` | Publication in progress |
| `PUBLISHED` | Done |
| `FAILED` | Resumable failure |
| `PUBLICATION_ABANDONED` | Publication given up with evidence |
| `ABANDONED_GENERATION` | Generation abandoned |

Attempt-only statuses: `INDETERMINATE`, `SUPERSEDED` (plus `EXTRACTING`,
`EXTRACTED`, `LOADING`, `READY`, `FAILED`, `ABANDONED_GENERATION`). Full
definitions are in `docs/DATA_DICTIONARY.md`.

## 7. How to make common changes safely

* **New config field:** validate it in `bridge_run.config()`, document it in
  `WHERE_TO_ENTER_VALUES.md`, add a failing-config test in
  `tests/test_contract.py`.
* **New control column:** add it to `sql/01_azure_sql_control.sql` **and**
  `sql/03_upgrade_to_v9_5.sql` (idempotent), update the SQLite stand-ins used by
  the tests, and `docs/DATA_DICTIONARY.md`.
* **New state transition:** update the SQL `CHECK` constraints, every guard
  query (`fence.release_blockers`, `fence.unresolved_source_operations`,
  retention `plan`), and add a regression test.
* **Notebook change:** keep notebooks free of Azure SQL writes; a changed
  notebook must be redeployed to its job — say so in `CHANGELOG.md`.
* **Every fix:** add a `tests/test_v<version>_regressions.py` test that fails on
  the previous code, and a `CHANGELOG.md` entry with upgrade actions.
* **Renaming the package folder:** update `PACKAGE_DIR` in
  `databricks/generate_mappings_pyspark.py` and `WHERE_TO_ENTER_VALUES.md`.

## 8. Things an agent must not do without explicit human approval

* Run any command against a real Azure SQL, Synapse, ADLS or Databricks
  environment.
* Run `fence.py abandon`/`reopen`, `recovery.py`, or `retire_releases.py
  --execute`.
* Create or edit evidence files.
* Change a published table, pointer, `target_state` row or grant.
* Relax a validation, a count check or a guard to make a test pass.
* Enable a mapping that needs an item listed as open in
  `IMPLEMENTATION_STATUS.md`.

## 9. Verification status

Verified locally: `pytest -q tests` with SQLite stand-ins and faked cloud calls.
Not verified: every platform behaviour listed in `docs/RELEASE_VALIDATION.md`
(row-level concurrency, conflict exception names, Synapse etag/async behaviour,
publisher privileges, midnight-UTC narrowing, credential change).

## 10. Questions to ask the human when unsure

* Which consistency strategy does the business require for this mapping?
* Which identity will run this, and what grants does it already hold?
* Is there independent evidence for this external operation's terminal state?
* Is this change allowed to alter a live consumer object?
