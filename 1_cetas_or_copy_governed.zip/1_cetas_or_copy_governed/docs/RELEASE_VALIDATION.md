# v9.5.8 release validation (1_cetas_or_copy_governed)

## Additional for the package rename

* Upload the whole folder to `/Workspace/Shared/1_cetas_or_copy_governed` and
  confirm `databricks/generate_mappings_pyspark.py` imports from it
  (`PACKAGE_DIR`).
* Update any scheduler job step, CI path or notebook path that still points to
  `bridge_v9_5_8_scripts`. Re-point the four Databricks jobs' notebook paths if
  they referenced the old folder.
* `pytest -q tests` passes, including `test_static.py` (folder name) and
  `test_agents_doc.py`.

## Completed on the packaged code

* `python -m compileall -q python databricks tests`
* `python -m json.tool config.example.json`
* `pytest -q tests` (contract, static, orchestration simulation, regressions
  v9.4–v9.5.8)

These do not replace platform tests.

## Required in the target environment before the first production run

### Platform and identities
* [ ] Control schema created or upgraded; fence seeded; runtime users have only
      `EXECUTE` on the procedure and `SELECT` on fence tables.
* [ ] Dedicated-pool credential uses `Managed Service Identity`; a CETAS write
      to the staging container succeeds with the CETAS identity.
* [ ] Each Databricks job runs as its own principal with the documented grants;
      the loader has no `MANAGE` on consumer tables.
* [ ] `MANAGE` + `CREATE TABLE` is sufficient for the Strategy A publisher's
      `CREATE OR REPLACE TABLE`.
* [ ] Job timeouts ≤ 7,200 s; serverless auto-optimization off on all four jobs;
      max concurrent runs ≥ worker limits.

### Data path
* [ ] One CETAS and one Copy mapping (if used) pass audit = Parquet = Delta.
* [ ] Data containing `|`, `"`, `\r`, `\n`, Unicode, NULLs, extreme decimals and
      dates is exported and loaded correctly.
* [ ] Copy `date` contract: midnight-UTC narrowing works; a non-midnight value
      fails.
* [ ] The largest objects are benchmarked end to end; worker limits set from it.

### Safety
* [ ] A write to a governed source while `BRIDGE_HELD` is prevented or detected.
* [ ] Fence expiry during a read fails the attempt.
* [ ] Killing the control host mid-read and mid-load produces `INDETERMINATE`;
      recovery with real evidence works.
* [ ] Two concurrent publishers for one target: the second is refused.
* [ ] Parallel pointer publications of different groups succeed (deletion
      vectors, conflict retry).
* [ ] `publish_run.py` refuses to start without the recorded fence release.
* [ ] Resume after a lost Azure SQL update reconciles instead of republishing.

### Publication and consumers
* [ ] Policy readiness, restricted-identity and consumer contract tests exist
      and produce real evidence URIs.
* [ ] Consumers cannot read candidates, `_snapshots` or `published_groups`.
* [ ] Manual rollback rehearsed for one table and one group.

### Operations
* [ ] Retention dry run reviewed, then executed; published and previous releases
      remain.
* [ ] Monitoring and on-call alerting cover `FAILED`, `INDETERMINATE`, stale
      heartbeats and open claims.
* [ ] Items listed as open in `IMPLEMENTATION_STATUS.md` are implemented or
      formally accepted for the enabled mappings.
