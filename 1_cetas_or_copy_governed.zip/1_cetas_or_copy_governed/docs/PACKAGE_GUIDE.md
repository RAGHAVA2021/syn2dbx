# Package guide: 1_cetas_or_copy_governed (v9.5.8)

This is the navigation guide for the shipped files. Read [DESIGN.md](DESIGN.md)
for the safety decisions, [CODE_STRUCTURE.md](CODE_STRUCTURE.md) for script,
job and function dependencies, [DATA_DICTIONARY.md](DATA_DICTIONARY.md) for
control-table columns and identifiers, and [RUNBOOK.md](RUNBOOK.md) for exact
setup, nightly, recovery and rollback commands. The governing long-form design
is `DESIGN_v9.md` in the package root.

## 1. What the package does

For each source generation, the upstream Synapse writer claims a **source
fence**, rebuilds its materialised tables, records one audited row count and
schema hash per mapped view, and closes the fence. The bridge then holds the
frozen generation, exports every mapping to a fresh ADLS Parquet attempt path
with **CETAS** (or a **Synapse Copy Activity**), and a Databricks loader job
writes it into an unpublished Delta candidate or snapshot table after a
three-way count check. The run ends `READY` and publishes nothing. After the
fence is released with independent evidence, a separate publication step makes
each target visible, one table (`REPLACE_TABLE`) or one group
(`RELEASE_POINTER`) at a time.

```mermaid
flowchart TD
  W["fence write-start<br/>(upstream writer)"] --> T["Existing Synapse materialisation"]
  T --> A["upstream_audit.py<br/>counts + schema hashes"]
  A --> C["fence write-close → bridge-hold"]
  C --> R["bridge_run.py"]
  R --> X["CETAS or Synapse Copy → ADLS Parquet attempt-NNN"]
  X --> L["loader Job: verify → Delta candidate / _snapshots"]
  L --> RD["run READY (nothing published)"]
  RD --> FR["fence bridge-release (evidence)"]
  FR --> P["publish_run.py (evidence)"]
  P --> PA["REPLACE_TABLE: CREATE OR REPLACE from candidate"]
  P --> PB["RELEASE_POINTER: flip published_groups row"]
  PA --> PUB["run PUBLISHED"]
  PB --> PUB
```

The control host (the orchestration machine holding the ODBC connection
strings) runs the scripts in `python/`. Those scripts start the Databricks
notebooks in `databricks/` as serverless single-task jobs and pass them a
SHA-256-checked manifest file. The Azure SQL control database is the single
source of truth for fence, run, attempt and publication state.

### How the folders relate

```mermaid
flowchart LR
  CFG["config.example.json<br/>→ config.json"] -->|input| GEN["python/generate_mappings<br/>profile_inventory<br/>source_metadata"]
  GEN -->|versioned config.json| CFG
  SQLA["sql/01 or sql/03"] -->|control schema| AZ[("Azure SQL<br/>control DB")]
  SQLS["sql/02"] -->|credential, data source,<br/>file format, audit tables| SYN[("Synapse<br/>dedicated pool")]
  CFG --> RS["python/render_setup.py"]
  RS -->|azure_sql_seed.sql| AZ
  RS -->|unity_catalog_setup.sql| UC[("Unity Catalog")]
  SP["synapse_pipeline/*.json"] -->|deploy_synapse_pipeline.py| SYN
  PY["python/ nightly scripts"] --> AZ
  PY --> SYN
  PY -->|manifest + run-now| NB["databricks/ notebooks<br/>(serverless jobs)"]
  SYN -->|CETAS / Copy| ADLS[("ADLS staging")]
  NB -->|read| ADLS
  NB --> UC
  TESTS["tests/"] -->|verify| PY
  DOCS["docs/ + README + AGENTS"] -.->|describe| PY
```

| Folder | Role | When it is used | Depends on / feeds |
|---|---|---|---|
| root `config.example.json` | The contract: which mappings, where, how, limits | Setup; read by every script | Copied to a private, versioned `config.json` |
| `sql/` | Azure SQL control schema, its upgrade, and Synapse-side objects | One-time setup, or upgrade | Creates what `python/` reads and writes |
| `python/` | Control-host scripts: inventory, setup rendering, fence, audit, run, publish, retention, recovery | Setup, every night, recovery | Reads `config.json`; uses Azure SQL, Synapse, ADLS and Databricks Jobs |
| `databricks/` | Notebooks run as Databricks jobs (loader, publisher, retention) plus optional one-time discovery/profiling notebooks | Every night (jobs); once per wave (discovery) | Started by `python/`; read the manifest from ADLS |
| `synapse_pipeline/` | Synapse datasets and Copy pipeline for the `COPY_ACTIVITY` route | One-time setup, only if Copy is used | Deployed by `python/deploy_synapse_pipeline.py` |
| `tests/` | Local verification with SQLite stand-ins and faked cloud calls | Every change | Tests `python/` and notebook static rules |
| `docs/` | Navigation and operating documentation | Reading | Describes all of the above |

## 2. Folder and file inventory

### Root

| File | Purpose |
|---|---|
| `FIRST_READ_ME.md` | Reading order by role, question index, Confluence publishing guide. |
| `README.md` | Overview, scope limits, deployment steps, nightly command order, recovery rules and per-version fixes. |
| `AGENTS.md` | Invariants, architecture ownership, status vocabulary and safe-change guidance for maintainers and AI agents. |
| `CHANGELOG.md` | Versioned changes and upgrade actions. |
| `SCRIPT_GUIDE.md` | Every script in execution order (steps 0a–9, R1–R4). |
| `WHERE_TO_ENTER_VALUES.md` | Every environment value, config field and grant. |
| `IMPLEMENTATION_STATUS.md` | Implemented versus environment-specific controls still required. |
| `DESIGN_v9.md` | The governing design. |
| `config.example.json` | Annotated example: one `REPLACE_TABLE` mapping and a two-member `RELEASE_POINTER` group (one CETAS, one Copy). |
| `requirements.txt` | Control-host Python dependencies (azure-identity, azure-storage-blob, databricks-sdk, pyodbc, requests). |
| `requirements-dev.txt` | Adds pytest for local tests. |
| `.gitignore` | Keeps generated SQL, private configs, reports and evidence files out of Git. |

### `sql/`

| File | Purpose |
|---|---|
| `01_azure_sql_control.sql` | New deployments. Creates the `bridge` schema: `source_fence`, `fence_events`, `runs`, `object_attempts`, `recovery_events`, `group_members`, `target_state`, and the `bridge.transition_fence` procedure. |
| `03_upgrade_to_v9_5.sql` | Existing v9 through v9.5.5 control databases. Idempotent in-place upgrade (adds and backfills `runs.source_set_id`, constraints, attempt metadata columns). |
| `02_synapse_setup.sql` | Once per dedicated pool: `bridge_meta` schema, `bridge_storage_mi` credential (`Managed Service Identity`), `bridge_stage` external data source, `bridge_parquet` file format, `bridge_meta.upstream_run` and `upstream_object` audit tables. |

### `python/` (control host)

| File | Step | Purpose and main input → output |
|---|---|---|
| `generate_mappings.py` | 0a | Synapse schema catalog → new pinned `config.json` plus `*.exceptions.json`. |
| `profile_inventory.py` | 0b | Config + dedicated-pool DMVs → new inventory version with `size_class` and `source_profile`, plus `.profile.csv`. |
| `source_metadata.py` | 0c | One view → canonical ordered schema hash. Also the shared drift-detection library. |
| `render_setup.py` | 2 | Config → `generated/azure_sql_seed.sql` and `generated/unity_catalog_setup.sql` (idempotent). |
| `deploy_synapse_pipeline.py` | 2b | `synapse_pipeline/*.json` → deployed and confirmed Synapse artifacts (Copy route only). |
| `fence.py` | 3, 5, 7, R3 | Fence transitions: `write-start`, `write-close`, `bridge-hold`, `bridge-release`, `abandon`, `reopen`. |
| `upstream_audit.py` | 4 | Mapped views → `bridge_meta.upstream_object` counts/hashes and one closed `upstream_run`. |
| `bridge_run.py` | 6, R1 | Held generation → extracted Parquet and loaded Delta; run `READY`. `--resume` continues. |
| `publish_run.py` | 8, R2 | `READY` run + evidence → published targets; run `PUBLISHED`. `--resume` reconciles with Delta. |
| `retire_releases.py` | 9 | Control state → dry-run plan, or with `--execute` a retention manifest for the retention job; `--delete-staging` removes exact attempt paths. |
| `recovery.py` | R4 | Evidence file → audited `resolve-attempt`, `resolve-publication`, `abandon-publication`. |

### `databricks/` (notebooks)

| File | Runs as | Purpose |
|---|---|---|
| `load_candidate.py` | Loader job (`loader_job_id`) | Reads manifest; verifies Parquet names, order, types and count; writes an idempotent Delta slice (UTC session). |
| `publish.py` | Strategy A publisher (`publisher_job_id`) and group-pointer publisher (`pointer_job_id`) | `PUBLISH` or read-only `INSPECT`. Replaces a table from its candidate, or flips a group pointer with conflict-only retry. |
| `retire_releases.py` | Retention job (`retention_job_id`) | Deletes superseded snapshot rows and drops candidates, re-reading the live pointer first. |
| `generate_mappings_pyspark.py` | Interactive cluster, once per wave | Step 0a alternative using PySpark JDBC; writes to a UC volume. Needs `PACKAGE_DIR = /Workspace/Shared/1_cetas_or_copy_governed`. |
| `profile_inventory_pyspark.py` | Classic UC cluster, once per wave | Step 0b alternative using PySpark JDBC; metadata only. |

### `synapse_pipeline/`

| File | Purpose |
|---|---|
| `bridge_synapse_source.dataset.json` | Parameterised dedicated-pool source dataset. |
| `bridge_parquet_sink.dataset.json` | Parameterised ADLS Parquet sink dataset. |
| `bridge_copy_to_parquet.pipeline.json` | One unpartitioned Copy Activity; receives the source query, path and `source_correlation`. |

### `tests/`

| File | Covers |
|---|---|
| `test_contract.py` | Fail-closed config rules, naming, paths, Copy row evidence. |
| `test_static.py` | No top-level function rebinding; `PACKAGE_DIR` equals the package folder name. |
| `test_orchestration_sim.py` | End-to-end `bridge_run.py` / `publish_run.py` against SQLite with faked cloud calls. |
| `test_v94_…` to `test_v958_regressions.py` | One file per review; each bug test fails on the preceding version. |
| `test_agents_doc.py` | Every path named in `AGENTS.md` exists. |

## 3. Execution order and what moves between stages

### One-time setup (administrator)

1. Build the inventory: `generate_mappings.py` → review → `profile_inventory.py` → review → versioned `config.json`.
2. `sql/01_azure_sql_control.sql` (or `03_upgrade_to_v9_5.sql`), seed one `bridge.source_fence` row, grant `EXECUTE` on `bridge.transition_fence`.
3. `sql/02_synapse_setup.sql` after the database master key exists.
4. `render_setup.py` → run `azure_sql_seed.sql` in Azure SQL and `unity_catalog_setup.sql` on a SQL warehouse.
5. Optional: `deploy_synapse_pipeline.py` for Copy mappings.
6. Create four serverless jobs, put their IDs in `config.json`, set timeouts, disable auto-optimization.

Repeat steps 1 and 4 for each new inventory wave (new `inventory_version`).

### Every nightly run

| Stage | Command | Hands to next stage |
|---|---|---|
| Claim | `fence.py write-start` | Fence `WRITE_ACTIVE`, generation ID |
| Materialise | existing Synapse job | Rebuilt tables |
| Audit | `upstream_audit.py` | `upstream_run` closed, per-mapping counts and hashes |
| Freeze | `fence.py write-close`, `bridge-hold` | Fence `BRIDGE_HELD` owned by the bridge run ID |
| Extract + load | `bridge_run.py` | Parquet attempt paths, Delta candidates/slices, run `READY` |
| Release source | `fence.py bridge-release --evidence` | Fence `AVAILABLE`, `fence_events` row |
| Publish | `publish_run.py --evidence` | Targets published, run `PUBLISHED` |

### Periodic and recovery

| Situation | Command |
|---|---|
| Storage growth | `retire_releases.py` (dry run), then `--execute --delete-staging` |
| Run `FAILED` | `bridge_run.py … --resume` |
| Run left `PUBLISHING` | `publish_run.py … --resume` |
| Unknown external outcome | `recovery.py resolve-attempt` / `resolve-publication` |
| Generation unusable | `fence.py abandon`, then `fence.py reopen` |

## 4. Boundaries and references

The package does **not** supply: source writer inventory and bypass-write
removal, fence-violation detectors, mask/ABAC policy tests, consumer contract
tests, business-total checks, automated rollback, or monitoring integration.
Evidence files record the results of those external tests; they do not replace
them. See `IMPLEMENTATION_STATUS.md`.
