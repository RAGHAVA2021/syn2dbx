# Runbook (v9.5.8)

Exact procedures for `1_cetas_or_copy_governed`. All IDs below are examples.
Values and grants are listed in `WHERE_TO_ENTER_VALUES.md`; the reasoning is in
[DESIGN.md](DESIGN.md).

## One-time setup (in order)

1. **Control host.** Install Microsoft ODBC Driver 18 for SQL Server, then
   `pip install -r requirements.txt`. Set, without printing them,
   `BRIDGE_CONTROL_ODBC`, `BRIDGE_SYNAPSE_AUDIT_ODBC` and `BRIDGE_CETAS_ODBC`.
   Configure Databricks unified authentication and an Azure credential usable by
   `DefaultAzureCredential`. The host identity needs list/read on the staging
   prefix, create under `bridge/parquet-stage/_manifests/`, and delete only if
   `--delete-staging` is used.
2. **Inventory.**
   ```bash
   python python/generate_mappings.py --schema presentation --source-kind view \
     --target-catalog analytics --target-schema gold --inventory-version wave_001_v1 --output wave_001_v1.json
   # review wave_001_v1.json and *.exceptions.json; set groups, strategies, materialised_* for views
   python python/profile_inventory.py --config wave_001_v1.json --inventory-version wave_001_v2 --output wave_001_v2.json
   # review the .profile.csv; keep wave_001_v2.json as the versioned config.json
   ```
   Hand-edited mappings get their hash from
   `python python/source_metadata.py --schema presentation --view v_orders`.
3. **Azure SQL.** Run `sql/01_azure_sql_control.sql` (new) or
   `sql/03_upgrade_to_v9_5.sql` (existing v9–v9.5.5). Seed once:
   `INSERT bridge.source_fence(source_set_id,state) VALUES(N'synapse_materialised','AVAILABLE');`
   Grant `EXECUTE ON bridge.transition_fence` to writer/bridge users and
   `SELECT` on `bridge.source_fence` and `bridge.fence_events` to the runtime
   user. No direct `UPDATE`.
4. **Synapse.** After the administrator creates the database master key, set
   the ADLS `LOCATION` and run `sql/02_synapse_setup.sql`.
5. **Render and apply setup SQL.**
   ```bash
   python python/render_setup.py --config config.json --output-dir generated
   ```
   Run `generated/azure_sql_seed.sql` in Azure SQL and
   `generated/unity_catalog_setup.sql` on a SQL warehouse. Both are idempotent.
6. **Copy route (only if any mapping uses `COPY_ACTIVITY`).**
   ```bash
   python python/deploy_synapse_pipeline.py --config config.json \
     --synapse-linked-service <ls> --adls-linked-service <ls> --container <container> \
     --source-dummy-schema <schema> --source-dummy-table <table>
   ```
7. **Databricks jobs.** Create four serverless single-task notebook jobs:
   loader (`databricks/load_candidate.py`), Strategy A publisher and pointer
   publisher (`databricks/publish.py`, separate Run-as identities), retention
   (`databricks/retire_releases.py`). Each takes `manifest_path` and
   `manifest_sha256`; each Run-as needs `READ FILES` on the staging external
   location. Timeout ≤ 7,200 s for loader and publishers. **Disable serverless
   auto-optimization on all four.** Max concurrent runs ≥ the matching worker
   limit. Put the IDs in `config.json`.
8. **Tune** `max_extraction_workers`, `extraction_class_limits`,
   `max_loader_workers`, `max_publisher_workers`,
   `minimum_fence_margin_minutes`, `max_attempts`, `takeover_after_minutes`
   (≥ 135) and `heartbeat_seconds` from benchmarks.

For each new inventory wave repeat steps 2 and 5 with a new `inventory_version`.

## Nightly sequence

```bash
python python/fence.py write-start --source-set synapse_materialised --generation GEN_20260922_01 \
  --actor SYN_20260922_01 --expiry-utc 2026-09-22T08:00:00
# existing Synapse materialisation job
python python/upstream_audit.py --config config.json --upstream-run-id SYN_20260922_01 \
  --generation-id GEN_20260922_01 --writer-owner SYN_20260922_01 --sequence 2026092201 --business-date 2026-09-22
python python/fence.py write-close --source-set synapse_materialised --generation GEN_20260922_01 \
  --actor SYN_20260922_01 --expiry-utc 2026-09-22T08:00:00
python python/fence.py bridge-hold --config config.json --upstream-run-id SYN_20260922_01 \
  --source-set synapse_materialised --generation GEN_20260922_01 --actor BRG_20260922_01 --expiry-utc 2026-09-22T08:00:00
python python/bridge_run.py --config config.json --upstream-run-id SYN_20260922_01 --generation-id GEN_20260922_01 \
  --sequence 2026092201 --business-date 2026-09-22 --bridge-run-id BRG_20260922_01
# external detectors produce fence_evidence.json
python python/fence.py bridge-release --source-set synapse_materialised --generation GEN_20260922_01 \
  --actor BRG_20260922_01 --evidence fence_evidence.json
# policy / restricted-identity / consumer tests produce publication_evidence.json
python python/publish_run.py --config config.json --bridge-run-id BRG_20260922_01 --evidence publication_evidence.json
```

Evidence field lists are in `README.md` ("Nightly command order"). Evidence must
be generated from real platform records; a hand-written `true` file gives no
assurance.

## Every morning

1. Check the latest run is `PUBLISHED` and the fence is `AVAILABLE`:
   ```sql
   SELECT TOP 5 bridge_run_id, status, updated_utc FROM bridge.runs ORDER BY created_utc DESC;
   SELECT * FROM bridge.source_fence;
   ```
2. List attempts in `FAILED` or `INDETERMINATE` (query in `DATA_DICTIONARY.md` §7).
3. Check for open publication claims and targets reported `superseded-by-newer`.
4. Confirm `source_rows = parquet_rows = delta_rows` for the run.

## Recovery situations

| Situation | Action |
|---|---|
| Run `FAILED` | Fix the cause; rerun `bridge_run.py` with the **same arguments plus `--resume`**. The fence must still be held if anything needs re-extraction. |
| Attempt `INDETERMINATE` | Prove the stored ID terminal independently; `python python/recovery.py resolve-attempt --bridge-run-id … --mapping-id … --attempt N --actor … --evidence terminal.json --reason "…"`; then `--resume`. |
| Run left `PUBLISHING` with publisher `RUNNING`/`UNKNOWN` | `recovery.py resolve-publication --bridge-run-id … --target-key … --actor … --evidence … --reason …`; then `publish_run.py … --resume`. |
| Run left `PUBLISHING`, no unknown publisher | `publish_run.py … --resume` (inspects Delta first, reconciles lost updates). |
| Target stopped "for review" on resume | Inspect Delta history and `target_state`; decide with the data owner; use `abandon-publication` if it must be given up. |
| "being published by run …" | Another run holds the claim; resume later. |
| Generation unusable | `fence.py abandon --source-set … --generation … --actor <current owner> --reason "…"` (add `--claim-legacy-runs` only after confirming listed legacy runs), then `fence.py reopen … --reason "…"`. |
| `max_attempts` exhausted | Abandon the generation. |
| RELEASE_POINTER loader `REJECTED` | `--resume` stops: the committed slice cannot be replaced; abandon the generation. |

### Recovery evidence

| Command | Required JSON fields |
|---|---|
| `resolve-attempt` | `phase` (`SOURCE`/`LOADER`, must be the unresolved one), `external_terminal: true`, `safe_to_retry: true`, `external_run_id`, `evidence_uri` |
| `resolve-publication` | `external_terminal`, `safe_to_resume`, `orchestrator_stopped` all `true`, `external_run_id`, `evidence_uri` |
| `abandon-publication` | `external_terminal`, `delta_state_verified`, `safe_to_abandon` all `true`, `external_run_id`, `evidence_uri` |

For a stored `token:…` add `idempotency_token` and give the real Databricks run
as `external_run_id` (repeat the token if no run exists). For `correlation:…`
give `source_correlation` and the real Synapse run ID.

## Rollback

Rollback is manual and must go through your change process.

* **REPLACE_TABLE:** the previous release's READY candidate is kept by retention.
  Replace the consumer table from it with the same governed properties, then
  update `bridge.target_state` (`published_release_id`, `previous_release_id`)
  consistently and record the reason.
* **RELEASE_POINTER:** update the group's row in `published_groups` to
  `previous_release_id` with the same guards the publisher uses, and mirror the
  change in `bridge.target_state`.

Never roll back while a claim is held or a run is `PUBLISHING`.

## Adding or changing a mapping

Create a new `inventory_version`; regenerate or edit mappings; recompute schema
hashes; run `render_setup.py` and apply both SQL files. A seeded member that
differs from the config stops the seed script by design. A column change to a
pointer view needs a governed view replacement.

## Retention (e.g. weekly)

```bash
python python/retire_releases.py --config config.json                    # dry run, review
python python/retire_releases.py --config config.json --execute --delete-staging
```

Add `--keep-release <id>` for releases pinned by a consumer contract and
`--inventory-config old_wave.json` for pre-v9.3 attempts.
