# Design: governed Synapse → Unity Catalog bridge (CETAS or Copy)

This is a summary of the design implemented by `1_cetas_or_copy_governed`
v9.5.8. The governing, detailed design is `DESIGN_v9.md` in the package root;
section references in brackets (for example [v9 §6]) point there. If this page
and `DESIGN_v9.md` disagree, `DESIGN_v9.md` wins.

## 1. Problem and constraints

* The sources are materialised tables in an Azure Synapse **dedicated SQL pool**,
  exposed to consumers through simple presentation views. An existing upstream
  job rebuilds them each business date.
* Around 1,000 mappings must reach **Unity Catalog Delta**, in full (no
  incremental logic), without consumers ever seeing a partially loaded table or
  a mix of generations inside a consistency group.
* A table must never be published from data that changed while it was being
  read, from a count that does not match the upstream audit, or from a schema
  that drifted from the reviewed contract.
* Every external call (Synapse, Synapse pipelines, Databricks Jobs) can fail with
  an **unknown outcome**. The design must never guess.
* Control state must survive a crash of the orchestrating host.

## 2. Architecture

```mermaid
flowchart LR
  subgraph Synapse
    MAT["Materialised tables + views"]
    AUD["bridge_meta.upstream_*"]
  end
  subgraph AzureSQL["Azure SQL control DB"]
    FEN["source_fence / fence_events"]
    RUN["runs / object_attempts"]
    TGT["target_state / group_members"]
    REC["recovery_events"]
  end
  subgraph Host["Control host (python/)"]
    ORC["fence · audit · bridge_run · publish_run · recovery"]
  end
  subgraph ADLS
    STG["bridge/parquet-stage/…/attempt-NNN/"]
    MAN["_manifests/"]
  end
  subgraph Databricks
    LJ["loader job"]
    PJ["publisher / pointer jobs"]
    UC["UC candidates, _snapshots,<br/>consumer tables & views, published_groups"]
  end
  ORC --> FEN & RUN & TGT & REC
  ORC -->|CETAS / Copy| MAT
  MAT --> STG
  ORC --> MAN
  ORC -->|run-now + manifest| LJ & PJ
  LJ --> STG
  LJ --> UC
  PJ --> UC
```

Three separate identities act on Synapse (audit reader, CETAS executor, storage
managed identity), and the loader, the Strategy A publisher, the pointer
publisher and the retention job each run as a different Databricks principal
[v9 §4].

### Per-mapping flow

1. **Precheck:** fence owned by this run with at least
   `minimum_fence_margin_minutes` left; upstream run closed; audited count and
   schema hash present exactly once; `--business-date` equals the audit;
   inventory seeded; sequence above the target's high-water mark.
2. **Extract:** a fresh, proven-empty `attempt-NNN` path; CETAS with a
   controlled column projection, or a Copy pipeline run with a persisted
   `source_correlation`. External IDs are stored before polling.
3. **Fence re-check** (margin 0) after the read finishes, before `EXTRACTED`.
4. **Load:** the loader verifies Parquet column names, order and Spark types,
   checks `Parquet rows = audited rows`, casts, stamps metadata columns, and
   appends with Delta `txnAppId`/`txnVersion`, then checks `Delta rows`.
5. `READY`. Publication is a different command, identity and gate.

## 3. Key decisions

### 3.1 A source fence, not a snapshot guess [v9 §6]

A state machine in Azure SQL (`AVAILABLE → WRITE_ACTIVE → CLOSED → BRIDGE_HELD
→ AVAILABLE`, plus `ABANDONED`) is changed only through
`bridge.transition_fence`, which checks state, owner, generation and a version
counter in one transaction and writes `fence_events`. Every governed writer must
use the same entry point. This makes "the bridge read one complete, unchanging
generation" a checked fact rather than a timing assumption.

### 3.2 The upstream audit is the reference count

`upstream_audit.py` counts each mapped view once, after the writer finishes and
while it still owns the fence, and refuses duplicate run IDs, drifted schemas and
non-increasing sequences. Every later stage reconciles to that number
(audit = Parquet = Delta). Dedicated-pool constraints are not enforced, so the
bridge itself rejects duplicate or missing audit rows.

### 3.3 Two extraction routes [v9 §3, §8]

| Route | Use for | Notes |
|---|---|---|
| `CETAS` (default) | Most mappings | No pipeline needed. Only direct named columns and a controlled GUID-to-text conversion are rendered. Server SQLSTATE errors are terminal `FAILED`; connection loss/timeouts are `INDETERMINATE`. |
| `COPY_ACTIVITY` | CETAS-incompatible objects | Synapse workspace data-plane API (`2020-12-01`). Requires `rowsRead == rowsCopied == source_rows`. SQL `date` must be declared as `timestamp` (Parquet INT96); the loader narrows to `date` only if every value is midnight UTC. |

Extractions are bounded by `max_extraction_workers` and
`extraction_class_limits` (SMALL/MEDIUM/LARGE from profiling); large objects start
first.

### 3.4 Two publication strategies [v9 §1, §14]

| Strategy | Unit | How it publishes | Rollback |
|---|---|---|---|
| `REPLACE_TABLE` | One table (its own `group_id`) | Atomic `CREATE OR REPLACE TABLE` from an attempt-specific candidate, then verify row count, release ID and governed properties | Replace from the previous release's retained candidate (manual) |
| `RELEASE_POINTER` | A group of mandatory tables with one `group_contract_version` | Each member appends a slice to its `_snapshots` table; one conditional `UPDATE` of the group's row in `published_groups` switches all stable views at once | Set the pointer back to `previous_release_id` (manual) |

The choice is a business consistency decision made before implementation, not a
performance setting.

### 3.5 Load is not publication

The loader has no `MANAGE` on consumer tables. Publication needs recorded
evidence (fence clean, source smoke check, audit health, policy readiness,
restricted-identity tests, consumer contract tests) **and** a `BRIDGE_HELD →
AVAILABLE` event for this run in `bridge.fence_events`.

### 3.6 Leases, claims and idempotency

* **Run lease:** `runs.orchestrator_token` plus a heartbeat; every control write
  is conditional on the token. Takeover only after `takeover_after_minutes`
  (minimum 135: 2-hour job timeout + cancellation window).
* **Publication claim:** `target_state.publish_owner` is taken before any Delta
  change and released in the same update that records the publication.
* **Databricks submissions:** a fresh idempotency token per invocation, stored as
  `token:…` before `run-now`.
* **Delta writes:** `txnAppId = bridge:<mapping>:<release>:a<attempt>` makes a
  repeated load a no-op.
* **Job payloads:** written as immutable, SHA-256-checked manifests under
  `bridge/parquet-stage/_manifests/` (notebook parameters are too small).

### 3.7 Unknown means stop

Any post-submission uncertainty makes an attempt `INDETERMINATE` (or keeps a
publisher `RUNNING`/`UNKNOWN`). It blocks `--resume`, `bridge-release`,
`abandon` and `reopen` until `recovery.py` records evidence that the **stored**
external ID is terminal. Nothing retries silently.

### 3.8 Retention is planned from immutable attempt metadata

Each attempt row records its Delta target, strategy, target key and consumer
target before loading, so retention finds candidates even after a mapping leaves
the inventory. The published and previous releases are always kept; windows are
`retention_days_published` (7) and `retention_days_unpublished` (30).

## 4. Failure behaviour

| Failure | Result |
|---|---|
| Source changed / fence expired during a read | Attempt `FAILED`; resume uses a new attempt path, or abandon the generation |
| CETAS rejected by the server | `FAILED`, retried on `--resume` up to `max_attempts` |
| Lost connection, timeout, SIGTERM after submission | `INDETERMINATE`; resolve with evidence |
| Count or type mismatch in the loader | Loader fails; attempt `FAILED` with `loader_operation_state='REJECTED'` |
| Orchestrator host stops | Lease expires; resume records in-flight work as `INDETERMINATE` |
| Delta commit whose Azure SQL update was lost | `publish_run.py --resume` inspects Delta and reconciles |
| Unexpected Delta state on resume | That target stops for review |
| Newer release already live | Target reported `superseded-by-newer`; never rolled back |

## 5. Capacity

Capacity is set from measurement, not defaults: `max_extraction_workers`,
`extraction_class_limits`, `max_loader_workers`, `max_publisher_workers`. Job
"maximum concurrent runs" must be at least the matching worker limit. Profiling
figures are planning estimates, not Parquet sizes. Benchmark the full estate
before committing to an overnight SLO [v9 §9].

## 6. Security

* No secrets in files: ODBC strings come from `BRIDGE_CONTROL_ODBC`,
  `BRIDGE_SYNAPSE_AUDIT_ODBC`, `BRIDGE_CETAS_ODBC`; Azure and Databricks use
  unified/default credential chains.
* Runtime users get `EXECUTE` on `bridge.transition_fence` and `SELECT` on fence
  tables, never direct `UPDATE`.
* Consumers see only consumer tables and stable views; never candidates,
  `_snapshots` or `published_groups`.
* The dedicated-pool credential uses `IDENTITY = 'Managed Service Identity'`;
  CETAS uses database-scoped grants for a contained Entra user [v9 §4].
* Identifiers are validated; SQL literals containing quotes are refused.

## 7. What is verified where

| Check | Where |
|---|---|
| Config contract, names, collisions | `bridge_run.config()` at every start; `tests/test_contract.py` |
| Fence ownership and margin | `bridge_run.fence()`, before and after each read |
| Counts and schema | upstream audit, loader, orchestrator result check |
| Governed properties after replace | `databricks/publish.py` |
| Orchestration, resume, races | `tests/test_orchestration_sim.py`, regression tests |
| Real platform behaviour | Only in the target environment (`docs/RELEASE_VALIDATION.md`) |

## 8. Limits and non-goals

Not implemented (fail closed, see `IMPLEMENTATION_STATUS.md`): empty-result
releases, automated rollback, chunked extraction of very large objects,
application-specific temporal/LOB profiles, detector streams, policy and
consumer test harnesses. The package is parameterised code, not a finished
deployment.
