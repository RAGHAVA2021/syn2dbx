# Data dictionary (v9.5.8)

What `1_cetas_or_copy_governed` writes and reads: Azure SQL control tables,
Synapse audit tables, Unity Catalog objects, identifiers, paths and statuses.
DDL lives in `sql/01_azure_sql_control.sql`, `sql/02_synapse_setup.sql` and the
output of `python/render_setup.py`.

## 1. How the control data fits together

```mermaid
erDiagram
  source_fence ||--o{ fence_events : "logs"
  source_fence ||--o{ runs : "generation held by"
  runs ||--o{ object_attempts : "has"
  runs ||--o{ recovery_events : "audited by"
  group_members }o--|| target_state : "target_key"
  object_attempts }o--|| target_state : "target_key"
  upstream_run ||--o{ upstream_object : "counts"
  runs }o--|| upstream_run : "upstream_run_id"
```

## 2. Azure SQL control database (`bridge` schema)

### 2.1 `bridge.source_fence`: one row per source set

| Column | Meaning |
|---|---|
| `source_set_id` | Key; equals `config.json` `source_set_id` |
| `state` | `AVAILABLE`, `WRITE_ACTIVE`, `CLOSED`, `BRIDGE_HELD`, `ABANDONED` |
| `generation_id` | Current generation; `NULL` when `AVAILABLE` |
| `writer_owner` / `bridge_owner` | Actor holding `WRITE_ACTIVE` / `BRIDGE_HELD` |
| `heartbeat_utc`, `expires_utc` | Last transition time; hard expiry of the hold |
| `control_version` | Optimistic-concurrency counter |

### 2.2 `bridge.fence_events`: append-only transition log

`event_id`, `source_set_id`, `old_state`, `new_state`, `generation_id`,
`actor`, `reason`, `at_utc`. `publish_run.py` requires a
`BRIDGE_HELD → AVAILABLE` row with this run as actor.

### 2.3 `bridge.runs`: one row per bridge run

| Column | Meaning |
|---|---|
| `bridge_run_id` | Key, 1–124 chars `[A-Za-z0-9_-]` |
| `upstream_run_id`, `generation_id`, `upstream_sequence`, `business_date` | Copied from the audited upstream run |
| `inventory_version` | Config version used |
| `release_id` | `rel_<bridge_run_id>`; unique |
| `status` | See section 5.1 |
| `orchestrator_token`, `heartbeat_utc` | Run lease |
| `created_utc`, `updated_utc` | Timestamps (retention uses `updated_utc`) |
| `source_set_id` | Source set; `NULL` only for pre-v9.5.5 rows not yet backfilled |

### 2.4 `bridge.object_attempts`: one row per mapping attempt

| Column | Meaning |
|---|---|
| `bridge_run_id`, `mapping_id`, `attempt` | Key |
| `method` | `CETAS` or `COPY_ACTIVITY` |
| `status` | See section 5.2 |
| `leaf_path` | Unique staging path (section 3) |
| `source_request_id` | CETAS request, Synapse run ID or `correlation:…` |
| `source_rows`, `parquet_rows`, `delta_rows` | Three-way count |
| `error_text` | Last error (up to 2,000 chars) |
| `delta_target` | Candidate table (REPLACE_TABLE) or `_snapshots` table (RELEASE_POINTER) |
| `target_key`, `publication_strategy`, `consumer_target` | Recorded before load, for retention |
| `source_operation_state` | `PENDING`, `RUNNING`, `SUCCEEDED`, `FAILED`, `UNKNOWN`, `NOT_STARTED`, `VERIFIED_TERMINAL` |
| `loader_run_id` | Databricks run ID or `token:…` |
| `loader_operation_state` | `RUNNING`, `SUCCEEDED`, `FAILED`, `UNKNOWN`, `REJECTED`, `VERIFIED_TERMINAL` |
| `retired_utc`, `staging_deleted_utc` | Set by retention |

### 2.5 `bridge.group_members`

`inventory_version`, `group_id`, `mapping_id`, `enabled`, `mandatory`,
`strategy`. Seeded by `azure_sql_seed.sql`; an enabled `RELEASE_POINTER` member
must be mandatory.

### 2.6 `bridge.target_state`: one row per target key

| Column | Meaning |
|---|---|
| `target_key` | `table:<catalog>.<schema>.<table>` or `group:<group_id>` |
| `published_release_id`, `published_sequence` | Live release (`NONE`, -1 initially) |
| `high_water_sequence` | Highest sequence ever published; older runs cannot publish |
| `previous_release_id` | Rollback candidate |
| `control_version` | Concurrency counter |
| `publish_owner`, `publish_token`, `publish_claimed_utc` | Publication claim |
| `publish_external_run_id`, `publish_operation_state` | Mutating publisher run and state |

### 2.7 `bridge.recovery_events`: append-only audit

`action` (`RESOLVE_ATTEMPT`, `RESOLVE_SUPERSEDED`, `RESOLVE_ABANDONED`,
`RESOLVE_PUBLICATION`, `ABANDON_PUBLICATION`), `bridge_run_id`, `mapping_id`,
`attempt`, `target_key`, `external_run_id`, `actor`, `evidence_uri`, `reason`,
`at_utc`.

## 3. Identifiers and paths

| Item | Format |
|---|---|
| Release ID | `rel_<bridge_run_id>` |
| Staging attempt path | `bridge/parquet-stage/<business_date>/<bridge_run_id>/<mapping_id>/attempt-NNN/` |
| Job manifest | `bridge/parquet-stage/_manifests/…` with its SHA-256 passed as a parameter |
| Candidate table | `<catalog>.<candidate_schema>.candidate_<mapping>_<16-hex>_a<attempt>` |
| Snapshot table | `<catalog>.<physical_schema>.<target_table>_snapshots` |
| Delta idempotency | `txnAppId = bridge:<mapping_id>:<release_id>:a<attempt>` |
| Copy correlation | `source_correlation(bridge_run_id, mapping_id, attempt)` |
| Stored placeholder IDs | `token:…` (Databricks), `correlation:…` (Synapse Copy) |

## 4. Synapse audit tables (`bridge_meta`)

| Table | Columns |
|---|---|
| `upstream_run` | `upstream_run_id`, `source_generation_id`, `upstream_sequence`, `business_date`, `status`, `write_closed`, `completed_utc` |
| `upstream_object` | `upstream_run_id`, `mapping_id`, `source_schema_version`, `status` (`COMPLETE`), `row_count`, `refresh_started_utc`, `refresh_completed_utc` |

## 5. Status values

### 5.1 `runs.status`

| Status | Meaning |
|---|---|
| `CREATED` → `EXTRACTING` → `EXTRACTED` → `LOADING` → `READY` | Normal load path |
| `PUBLISHING` → `PUBLISHED` | Publication |
| `FAILED` | Resumable with `--resume` |
| `PUBLICATION_ABANDONED` | Publication given up after evidence |
| `ABANDONED_GENERATION` | Generation abandoned through `fence.py abandon` |

### 5.2 `object_attempts.status`

| Status | Meaning |
|---|---|
| `EXTRACTING` | Read submitted or about to be |
| `INDETERMINATE` | Outcome unknown; blocks everything until `recovery.py` |
| `EXTRACTED` | Parquet written, fence re-checked |
| `LOADING` | Loader submitted |
| `READY` | Loaded and verified |
| `FAILED` | Terminal failure; a new attempt may follow |
| `SUPERSEDED` | Replaced by a newer attempt |
| `ABANDONED_GENERATION` | Generation abandoned |

## 6. Unity Catalog objects

| Object | Created by | Contents |
|---|---|---|
| `<control_catalog>.<control_schema>.published_groups` | `unity_catalog_setup.sql` | `group_id`, `published_release_id`, `published_sequence`, `high_water_sequence`, `previous_release_id`, `control_version`, `published_at`; deletion vectors on |
| `…_snapshots` tables | same | Mapping columns + metadata columns; one slice per release |
| Stable consumer views | same | Columns of one mapping for the pointer's release |
| Candidate tables | loader | Columns + metadata for one attempt |
| Consumer tables (REPLACE_TABLE) | publisher | Replaced from the candidate |

Metadata columns (all `STRING`, stamped on every row): `release_id`,
`mapping_object_id`, `source_generation_id`, `bridge_run_id`,
`upstream_run_id`, `upstream_sequence`, `business_date`, `load_attempt`,
`group_contract_version`.

## 7. Useful queries

```sql
-- Run overview
SELECT bridge_run_id, status, business_date, heartbeat_utc FROM bridge.runs ORDER BY created_utc DESC;
-- Attempts needing attention
SELECT bridge_run_id, mapping_id, attempt, status, source_operation_state, loader_operation_state, error_text
FROM bridge.object_attempts WHERE status IN ('FAILED','INDETERMINATE') ORDER BY updated_utc DESC;
-- Count reconciliation for one run
SELECT mapping_id, attempt, source_rows, parquet_rows, delta_rows FROM bridge.object_attempts
WHERE bridge_run_id = '<run>' AND status = 'READY';
-- Open publication claims
SELECT target_key, publish_owner, publish_operation_state FROM bridge.target_state WHERE publish_owner IS NOT NULL;
-- Fence history
SELECT TOP 20 * FROM bridge.fence_events ORDER BY event_id DESC;
```
