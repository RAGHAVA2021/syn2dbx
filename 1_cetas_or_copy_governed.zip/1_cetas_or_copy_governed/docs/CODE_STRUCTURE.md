# Code structure (v9.5.8)

How the code of `1_cetas_or_copy_governed` is wired: which layer does what,
which script starts which Databricks job, which functions are shared, and the
order of calls in a nightly run. For file purposes see
[PACKAGE_GUIDE.md](PACKAGE_GUIDE.md); for column meanings see
[DATA_DICTIONARY.md](DATA_DICTIONARY.md).

## 1. Layers

```mermaid
flowchart TB
  subgraph L1["Scheduler (existing upstream scheduler)"]
    S["job steps in nightly order"]
  end
  subgraph L2["Control host: python/"]
    F["fence.py"] 
    A["upstream_audit.py"]
    B["bridge_run.py"]
    P["publish_run.py"]
    R["retire_releases.py"]
    RC["recovery.py"]
  end
  subgraph L3["Databricks serverless jobs: databricks/"]
    LC["load_candidate.py"]
    PB["publish.py (×2 jobs)"]
    RT["retire_releases.py"]
  end
  subgraph L4["State and data"]
    AZ[("Azure SQL bridge.*")]
    SY[("Synapse bridge_meta.*")]
    AD[("ADLS staging + manifests")]
    UC[("Unity Catalog")]
  end
  S --> F & A & B & P & R
  B -->|run-now| LC
  P -->|run-now| PB
  R -->|run-now| RT
  F & A & B & P & R & RC --> AZ
  A & B --> SY
  B & R --> AD
  LC & PB & RT --> UC
  LC & PB & RT -->|manifest| AD
```

| Layer | Holds | Never does |
|---|---|---|
| Scheduler | Order of commands and their IDs | Decisions about state |
| `python/` | All decisions, leases, claims, gates, state transitions | Write Delta directly |
| `databricks/` | Spark reads, Delta writes, Delta inspection | Change Azure SQL state |
| Azure SQL | The single source of truth | — |

## 2. Script → job → notebook

| Script | Config key | Notebook | Mode(s) |
|---|---|---|---|
| `bridge_run.py` | `loader_job_id` | `databricks/load_candidate.py` | load |
| `publish_run.py` (REPLACE_TABLE) | `publisher_job_id` | `databricks/publish.py` | `PUBLISH`, `INSPECT` |
| `publish_run.py` (RELEASE_POINTER) | `pointer_job_id` | `databricks/publish.py` | `PUBLISH`, `INSPECT` |
| `retire_releases.py --execute` | `retention_job_id` | `databricks/retire_releases.py` | retire |

Every job receives only `manifest_path` and `manifest_sha256`. The payload is
written by `bridge_run.write_manifest()` and submitted by
`bridge_run.notebook_job()`, which stores the `token:…` placeholder before
`run-now`, polls to completion and cancels on timeout.

## 3. Shared functions (who imports what)

`bridge_run.py` is also the shared library of the control host.

```mermaid
flowchart LR
  BR["bridge_run.py"]
  SM["source_metadata.py"]
  FE["fence.py"] --> BR
  PR["publish_run.py"] --> BR
  RR["retire_releases.py"] --> BR
  RC["recovery.py"] --> BR
  RS["render_setup.py"] --> BR
  PI["profile_inventory.py"] --> BR
  UA["upstream_audit.py"] --> BR
  UA --> SM
  BR --> SM
  GM["generate_mappings.py"] --> SM
```

| Function in `bridge_run.py` | Used by | Purpose |
|---|---|---|
| `config()` | all | Load and validate the whole contract (fail closed) |
| `db()` | all with SQL | Short-lived pyodbc connection from an env var; always closed |
| `need()`, `ident()` | all | Guard and identifier validation |
| `claim_run()`, `update_run()`, `RunLease` | `bridge_run`, `publish_run` | Run lease with heartbeat; token-conditional writes |
| `notebook_job()` | `bridge_run`, `publish_run`, `retire_releases` | Databricks submission with persisted token |
| `write_manifest()` | same | Immutable SHA-256-checked job payload |
| `candidate_table_name()`, `delta_target()`, `target_key()` | `publish_run`, `render_setup`, retention | Deterministic names and keys |
| `attempt_relative_path()`, `staging_parts()`, `container_client()` | retention | Staging paths |
| `METADATA_COLUMNS`, `STAGE_PREFIX` | `render_setup`, retention | Shared constants |

| Function in other modules | Purpose |
|---|---|
| `fence.release_blockers()` | Attempts that block `bridge-release` |
| `fence.unresolved_source_operations()` | Reads that block `abandon`/`reopen` |
| `source_metadata.schema_hash()` | Canonical ordered schema hash |
| `generate_mappings.for_copy_activity()` | Re-types a mapping for the Copy route |
| `retire_releases.plan()` | Pure retention plan from control rows |
| `recovery.resolve_attempt()`, `resolve_publication()`, `abandon_publication()` | Evidence-gated recovery |

## 4. Nightly call sequence

### 4.1 `bridge_run.py`

```mermaid
sequenceDiagram
  participant H as bridge_run.py
  participant Z as Azure SQL
  participant S as Synapse
  participant A as ADLS
  participant D as Loader job
  H->>Z: config() checks; claim_run() → lease token
  H->>S: upstream_run / upstream_object; schema_hash() per mapping
  H->>Z: fence() owner + margin; seeded inventory; high-water
  loop each mapping (bounded, LARGE first)
    H->>Z: insert attempt EXTRACTING (+ target metadata)
    H->>A: require_empty_adls(attempt-NNN)
    H->>S: cetas() or copy_activity() (ID stored before polling)
    H->>Z: fence() re-check (margin 0) → EXTRACTED
    H->>A: write_manifest()
    H->>D: notebook_job() → LOADING
    D->>A: read manifest + Parquet, verify, append (txnAppId)
    D-->>H: parquet_rows, delta_rows, target
    H->>Z: verify result → READY (or FAILED/REJECTED)
  end
  H->>Z: run READY, release lease
```

Functions: `extract_one()` and `run_extractions()` for step 2–3, `load_one()` and
`run_loads()` for the loader, `build_item()` for the manifest payload,
`cetas_error_is_terminal()` / `is_indeterminate()` for classification.

### 4.2 `publish_run.py`

1. Validate evidence fields and their `_evidence_uri`s; for a `READY` run,
   require the `BRIDGE_HELD → AVAILABLE` row in `bridge.fence_events`.
2. Claim the run lease; move `READY → PUBLISHING`.
3. For each target, in parallel across groups up to `max_publisher_workers`:
   `require_resolved_publisher()` → `check_order()` (high-water) →
   `claim_target()` → on resume `inspect_job()` → `publish_replace()` or
   `publish_pointer()` → `record_publication()` (releases the claim).
4. Run `PUBLISHED`.

### 4.3 `databricks/publish.py`

* REPLACE_TABLE: `CREATE OR REPLACE TABLE … TBLPROPERTIES (…) AS SELECT` from the
  candidate; verify row count, `release_id` and properties.
* RELEASE_POINTER: verify every member slice exists with its count, then one
  guarded `UPDATE published_groups` via `run_with_conflict_retry()` (retries only
  Delta conflicts, up to six times).
* INSPECT: read-only report of the current Delta state.

## 5. Which tests cover which code

| Test | Code under test |
|---|---|
| `test_contract.py` | `bridge_run.config()`, naming, paths, Copy metrics |
| `test_static.py` | all scripts and notebooks (AST), `PACKAGE_DIR` |
| `test_orchestration_sim.py` | `bridge_run.py`, `publish_run.py` end to end |
| `test_v94_regressions.py` | tokens, INSPECT, orphaned operations, release gate, CETAS SQLSTATE |
| `test_v95_regressions.py` | publisher resolution and INSPECT |
| `test_v952_regressions.py` | `fence.py`, `recovery.py`, retention entry points |
| `test_v955_…`, `test_v956_…`, `test_v957_…`, `test_v958_regressions.py` | review fixes of each version |
| `test_agents_doc.py` | `AGENTS.md` references |
