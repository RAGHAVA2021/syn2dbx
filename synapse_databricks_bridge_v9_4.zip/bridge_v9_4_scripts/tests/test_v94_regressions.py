"""v9.4 regressions: per-invocation Databricks tokens, orphaned operations after an
orchestrator stop, the fence-release gate, CETAS error classification and legacy rows."""
import json
import sys
import types
from contextlib import contextmanager
from datetime import timedelta

import pytest

from test_orchestration_sim import CLOCK, bridge_run, env, recovery, ts  # noqa: F401
import fence

ROOT_URI = "abfss://landing@acct.dfs.core.windows.net/"


# --- Databricks idempotency ----------------------------------------------------------

class FakeDatabricks:
    """Documented run-now contract: a known idempotency token returns the EXISTING run,
    whatever its state, and launches nothing."""

    def __init__(self, outcomes):
        self.outcomes, self.by_token, self.runs, self.tokens = list(outcomes), {}, {}, []

    def client(self):
        outer = self

        class Jobs:
            def run_now(self, job_id, notebook_params, idempotency_token):
                outer.tokens.append(idempotency_token)
                if idempotency_token not in outer.by_token:
                    rid = 100 + len(outer.runs) + 1
                    outer.by_token[idempotency_token] = rid
                    outer.runs[rid] = outer.outcomes.pop(0)
                return types.SimpleNamespace(run_id=outer.by_token[idempotency_token])

            def get_run(self, run_id):
                ok = outer.runs[run_id][0]
                state = types.SimpleNamespace(
                    life_cycle_state=types.SimpleNamespace(value="TERMINATED"),
                    result_state=types.SimpleNamespace(value="SUCCESS" if ok else "FAILED"))
                return types.SimpleNamespace(state=state, tasks=[])

            def get_run_output(self, run_id):
                return types.SimpleNamespace(notebook_output=types.SimpleNamespace(result=outer.runs[run_id][1]))

        return types.SimpleNamespace(jobs=Jobs())


@pytest.fixture
def dbx(monkeypatch):
    def install(outcomes):
        fake = FakeDatabricks(outcomes)
        module = types.ModuleType("databricks.sdk")
        module.WorkspaceClient = fake.client
        monkeypatch.setitem(sys.modules, "databricks", types.ModuleType("databricks"))
        monkeypatch.setitem(sys.modules, "databricks.sdk", module)
        monkeypatch.setattr(bridge_run, "write_manifest", lambda *a: ("path", "digest"))
        return fake
    return install


def test_retry_after_failed_job_launches_a_new_run(dbx):
    fake = dbx([(False, None), (True, '{"release_id": "rel_BRG1"}')])
    payload = {"strategy": "REPLACE_TABLE", "mode": "PUBLISH", "release_id": "rel_BRG1"}
    with pytest.raises(RuntimeError, match="Job failed: 101"):
        bridge_run.notebook_job({}, 1, payload, "BRG1")
    assert bridge_run.notebook_job({}, 1, payload, "BRG1") == {"release_id": "rel_BRG1"}
    assert len(set(fake.tokens)) == 2 and all(len(t) <= 64 for t in fake.tokens)


def test_every_inspect_reads_current_state(dbx):
    dbx([(True, '{"published_release_id": "NONE"}'), (True, '{"published_release_id": "rel_BRG1"}')])
    payload = {"strategy": "RELEASE_POINTER", "mode": "INSPECT", "group_id": "sales"}
    assert bridge_run.notebook_job({}, 1, payload, "BRG1") == {"published_release_id": "NONE"}
    assert bridge_run.notebook_job({}, 1, payload, "BRG1") == {"published_release_id": "rel_BRG1"}


def test_token_is_persisted_before_submission(dbx):
    fake = dbx([(True, "{}")])
    seen = []
    bridge_run.notebook_job({}, 1, {"x": 1}, "BRG1", started_callback=seen.append)
    assert seen[0] == "token:" + fake.tokens[0] and seen[1] == "101"


# --- orphaned operations after an orchestrator stop -----------------------------------

def crashed_run(env, status, token="dead"):
    env["query"]("INSERT INTO bridge.runs VALUES ('BRG1','SYN1','GEN1',100,'2026-09-22','wave_001_v1',"
                 "'rel_BRG1',?,?,?,NULL,NULL)", status, token, ts(CLOCK["now"]))


def add_attempt(env, status, attempt=1, **cols):
    leaf = ROOT_URI + bridge_run.attempt_relative_path("2026-09-22", "BRG1", "MAP_001", attempt)
    names = ["bridge_run_id", "mapping_id", "attempt", "method", "status", "leaf_path", *cols]
    values = ["BRG1", "MAP_001", attempt, "CETAS", status, leaf, *cols.values()]
    env["query"](f"INSERT INTO bridge.object_attempts({','.join(names)}) VALUES ({','.join('?' * len(names))})",
                 *values)


def blockers(env):
    with bridge_run.db("BRIDGE_CONTROL_ODBC") as conn:
        return fence.release_blockers(conn.cursor(), "BRG1")


def resolve(env, tmp_path_factory, monkeypatch, phase, external_id):
    monkeypatch.setattr(recovery, "db", bridge_run.db)
    evidence = tmp_path_factory.mktemp("recovery") / "terminal.json"
    evidence.write_text(json.dumps({"external_terminal": True, "safe_to_retry": True, "phase": phase,
                                    "external_run_id": external_id, "evidence_uri": "https://evidence/x"}))
    recovery.resolve_attempt(type("Args", (), {
        "evidence": str(evidence), "bridge_run_id": "BRG1", "mapping_id": "MAP_001", "attempt": 1,
        "actor": "operator", "reason": "verified terminal"})())


def test_orphaned_source_read_goes_through_recovery(env, monkeypatch, tmp_path_factory):
    crashed_run(env, "EXTRACTING")
    add_attempt(env, "EXTRACTING", source_request_id="x_orphan", source_operation_state="RUNNING")
    CLOCK["now"] += timedelta(minutes=200)
    with pytest.raises(RuntimeError, match="now INDETERMINATE"):
        env["run"](bridge_run, *env["extract"], "--resume")
    assert env["query"]("SELECT status,source_operation_state FROM bridge.object_attempts") == \
        [("INDETERMINATE", "UNKNOWN")]
    assert env["query"]("SELECT status,orchestrator_token IS NOT NULL FROM bridge.runs") == [("FAILED", 1)]
    assert blockers(env)
    with pytest.raises(RuntimeError, match="indeterminate external operation"):
        env["run"](bridge_run, *env["extract"], "--resume")

    resolve(env, tmp_path_factory, monkeypatch, "SOURCE", "x_orphan")
    env["run"](bridge_run, *env["extract"], "--resume")
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]
    assert ("MAP_001", 2, "READY") in env["query"]("SELECT mapping_id,attempt,status FROM bridge.object_attempts")
    assert blockers(env) == []


def test_never_submitted_attempt_is_superseded_without_recovery(env):
    crashed_run(env, "EXTRACTING")
    add_attempt(env, "EXTRACTING", source_operation_state="PENDING")
    CLOCK["now"] += timedelta(minutes=200)
    env["run"](bridge_run, *env["extract"], "--resume")
    assert env["query"]("SELECT status,source_operation_state FROM bridge.object_attempts "
                        "WHERE mapping_id='MAP_001' AND attempt=1") == [("SUPERSEDED", "NOT_STARTED")]
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]
    assert blockers(env) == []


def test_orphaned_loader_goes_through_recovery(env, monkeypatch, tmp_path_factory):
    crashed_run(env, "LOADING")
    add_attempt(env, "LOADING", source_request_id="x_done", source_operation_state="SUCCEEDED",
                loader_run_id="dbx_9", loader_operation_state="RUNNING", source_rows=10)
    CLOCK["now"] += timedelta(minutes=200)
    with pytest.raises(RuntimeError, match="MAP_001 attempt 1 \\(LOADER\\)"):
        env["run"](bridge_run, *env["extract"], "--resume")
    assert env["query"]("SELECT status,loader_operation_state FROM bridge.object_attempts") == \
        [("INDETERMINATE", "UNKNOWN")]
    resolve(env, tmp_path_factory, monkeypatch, "LOADER", "dbx_9")
    env["run"](bridge_run, *env["extract"], "--resume")
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]
    assert env["query"]("SELECT attempt,status FROM bridge.object_attempts WHERE mapping_id='MAP_001'") == \
        [(1, "READY")]


def test_legacy_superseded_running_row_can_be_cleared(env, monkeypatch, tmp_path_factory):
    env["run"](bridge_run, *env["extract"])                          # READY run
    env["query"]("UPDATE bridge.object_attempts SET status='SUPERSEDED',source_request_id='x_old',"
                 "source_operation_state='RUNNING' WHERE mapping_id='MAP_001'")
    assert blockers(env)
    resolve(env, tmp_path_factory, monkeypatch, "SOURCE", "x_old")
    assert env["query"]("SELECT status,source_operation_state FROM bridge.object_attempts "
                        "WHERE mapping_id='MAP_001'") == [("SUPERSEDED", "VERIFIED_TERMINAL")]
    assert blockers(env) == []


# --- CETAS error classification -------------------------------------------------------

def odbc_error(state):
    cls = type("ProgrammingError", (Exception,), {"__module__": "pyodbc"})
    return cls(state, f"[{state}] simulated")


@pytest.mark.parametrize("state,terminal", [
    ("42000", True), ("42S02", True), ("22003", True), ("40001", True),
    ("08S01", False), ("HYT00", False), ("HY008", False), ("HY000", False)])
def test_cetas_sqlstate_classification(state, terminal):
    assert bridge_run.cetas_error_is_terminal(odbc_error(state)) is terminal


def test_non_odbc_errors_are_unknown():
    assert not bridge_run.cetas_error_is_terminal(RuntimeError("42000"))
    assert not bridge_run.cetas_error_is_terminal(KeyboardInterrupt())


@pytest.mark.parametrize("state,expected", [("42000", RuntimeError), ("08S01", bridge_run.Indeterminate)])
def test_cetas_raises_by_classification(monkeypatch, state, expected):
    states = []

    class Cursor:
        def execute(self, sql, *params):
            if sql.startswith("CREATE EXTERNAL TABLE"):
                raise odbc_error(state)

    class Conn:
        timeout = 0
        def cursor(self):
            return Cursor()

    @contextmanager
    def fake_db(var, autocommit=False):
        yield Conn()

    monkeypatch.setattr(bridge_run, "db", fake_db)
    mapping = {"source_schema": "presentation", "source_view": "v_customer",
               "columns": [{"source": "a", "target": "a"}]}
    with pytest.raises(expected) as caught:
        bridge_run.cetas(mapping, "bridge/parquet-stage/x/", lambda i: None, lambda i, s: states.append(s))
    assert type(caught.value) is expected
    assert states == (["FAILED"] if expected is RuntimeError else [])
