"""Step 2b, optional (SCRIPT_GUIDE.md): deploy the three reviewed ADF objects for COPY_ACTIVITY mappings.

Linked services must already exist.
"""
import argparse
import json
from pathlib import Path

import requests
from azure.identity import DefaultAzureCredential


def main():
    p=argparse.ArgumentParser()
    p.add_argument("--config",required=True)
    p.add_argument("--synapse-linked-service",required=True)
    p.add_argument("--adls-linked-service",required=True)
    p.add_argument("--container",required=True)
    p.add_argument("--source-dummy-table",required=True,
                   help="Existing Synapse table referenced by the source dataset; the query overrides it")
    p.add_argument("--source-dummy-schema",required=True,
                   help="Schema containing --source-dummy-table")
    a=p.parse_args()
    d=json.loads(Path(a.config).read_text())
    cfg=d["adf"]
    root=Path(__file__).resolve().parents[1]/"adf"
    source=json.loads((root/"bridge_synapse_source.dataset.json").read_text())
    sink=json.loads((root/"bridge_parquet_sink.dataset.json").read_text())
    pipeline=json.loads((root/"bridge_copy_to_parquet.pipeline.json").read_text())
    source["properties"]["linkedServiceName"]["referenceName"]=a.synapse_linked_service
    source["properties"]["typeProperties"]["schema"]=a.source_dummy_schema
    source["properties"]["typeProperties"]["table"]=a.source_dummy_table
    sink["properties"]["linkedServiceName"]["referenceName"]=a.adls_linked_service
    sink["properties"]["typeProperties"]["location"]["fileSystem"]=a.container
    pipeline["name"]=cfg["copy_pipeline"]
    base=(f"https://management.azure.com/subscriptions/{cfg['subscription_id']}/"
          f"resourceGroups/{cfg['resource_group']}/providers/Microsoft.DataFactory/"
          f"factories/{cfg['factory']}")
    token=DefaultAzureCredential().get_token("https://management.azure.com/.default").token
    headers={"Authorization":f"Bearer {token}","Content-Type":"application/json"}
    for kind,item in (("datasets",source),("datasets",sink),("pipelines",pipeline)):
        url=f"{base}/{kind}/{item['name']}?api-version=2018-06-01"
        resp=requests.put(url,headers=headers,json={"properties":item["properties"]},timeout=60)
        resp.raise_for_status()
        print(kind,item["name"],resp.status_code)


if __name__=="__main__": main()
