-- Step 1 (SCRIPT_GUIDE.md). New deployments: run this file. Existing v9, v9.1, v9.2 or v9.3 deployments: run 03_upgrade_to_v9_4.sql.
-- Run in a dedicated Azure SQL Database using an administrator identity.
-- Replace database roles/grants with your named deployment, orchestrator and publisher identities.
IF SCHEMA_ID(N'bridge') IS NULL EXEC(N'CREATE SCHEMA bridge');
GO
CREATE TABLE bridge.source_fence (
 source_set_id nvarchar(128) NOT NULL PRIMARY KEY,
 state varchar(20) NOT NULL CHECK (state IN ('AVAILABLE','WRITE_ACTIVE','CLOSED','BRIDGE_HELD','ABANDONED')),
 generation_id nvarchar(128) NULL, writer_owner nvarchar(128) NULL,
 bridge_owner nvarchar(128) NULL, heartbeat_utc datetime2(3) NULL,
 expires_utc datetime2(3) NULL, control_version bigint NOT NULL DEFAULT 0
);
GO
CREATE TABLE bridge.fence_events (
 event_id bigint IDENTITY PRIMARY KEY, source_set_id nvarchar(128) NOT NULL,
 old_state varchar(20) NOT NULL, new_state varchar(20) NOT NULL,
 generation_id nvarchar(128) NULL, actor nvarchar(128) NOT NULL,
 reason nvarchar(1000) NULL,
 at_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
CREATE TABLE bridge.runs (
 bridge_run_id nvarchar(128) NOT NULL PRIMARY KEY,
 upstream_run_id nvarchar(128) NOT NULL, generation_id nvarchar(128) NOT NULL,
 upstream_sequence bigint NOT NULL, business_date date NOT NULL,
 inventory_version nvarchar(128) NOT NULL, release_id nvarchar(128) NOT NULL UNIQUE,
 status varchar(24) NOT NULL CHECK(status IN ('CREATED','EXTRACTING','EXTRACTED','LOADING','READY','PUBLISHING','PUBLISHED','FAILED','PUBLICATION_ABANDONED','ABANDONED_GENERATION')),
 -- Orchestrator lease: every write by bridge_run.py/publish_run.py is conditional on the
 -- token; a process whose heartbeat is older than takeover_after_minutes can be taken over.
 orchestrator_token nvarchar(64) NULL,
 heartbeat_utc datetime2(3) NULL,
 created_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 updated_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
CREATE TABLE bridge.object_attempts (
 bridge_run_id nvarchar(128) NOT NULL REFERENCES bridge.runs(bridge_run_id),
 mapping_id nvarchar(128) NOT NULL, attempt int NOT NULL CHECK(attempt>0),
 method varchar(16) NOT NULL CHECK(method IN ('CETAS','COPY_ACTIVITY')),
 status varchar(24) NOT NULL CHECK(status IN ('EXTRACTING','INDETERMINATE','EXTRACTED','LOADING','READY','FAILED','SUPERSEDED','ABANDONED_GENERATION')),
 leaf_path nvarchar(1024) NOT NULL UNIQUE,
 source_request_id nvarchar(128) NULL, source_rows bigint NULL,
 parquet_rows bigint NULL, delta_rows bigint NULL,
 error_text nvarchar(2000) NULL,
 delta_target nvarchar(512) NULL,
 target_key nvarchar(512) NULL,
 publication_strategy varchar(16) NULL CHECK(publication_strategy IS NULL OR publication_strategy IN ('REPLACE_TABLE','RELEASE_POINTER')),
 consumer_target nvarchar(512) NULL,
 source_operation_state varchar(24) NULL,
 loader_run_id nvarchar(128) NULL,
 loader_operation_state varchar(24) NULL,
 updated_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
 retired_utc datetime2(3) NULL,
 staging_deleted_utc datetime2(3) NULL,
 PRIMARY KEY(bridge_run_id,mapping_id,attempt)
);
GO
CREATE TABLE bridge.recovery_events (
 recovery_event_id bigint IDENTITY PRIMARY KEY,
 action varchar(32) NOT NULL,
 bridge_run_id nvarchar(128) NOT NULL,
 mapping_id nvarchar(128) NULL,
 attempt int NULL,
 target_key nvarchar(512) NULL,
 external_run_id nvarchar(128) NULL,
 actor nvarchar(128) NOT NULL,
 evidence_uri nvarchar(2048) NOT NULL,
 reason nvarchar(1000) NOT NULL,
 at_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
CREATE TABLE bridge.group_members (
 inventory_version nvarchar(128) NOT NULL,
 group_id nvarchar(128) NOT NULL,
 mapping_id nvarchar(128) NOT NULL,
 enabled bit NOT NULL, mandatory bit NOT NULL,
 strategy varchar(16) NOT NULL CHECK(strategy IN ('REPLACE_TABLE','RELEASE_POINTER')),
 PRIMARY KEY(inventory_version,mapping_id),
 CONSTRAINT CK_group_member_mandatory CHECK(strategy <> 'RELEASE_POINTER' OR enabled=0 OR mandatory=1)
);
GO
CREATE TABLE bridge.target_state (
 target_key nvarchar(512) NOT NULL PRIMARY KEY,
 published_release_id nvarchar(128) NULL,
 published_sequence bigint NULL,
 high_water_sequence bigint NOT NULL DEFAULT -1,
 previous_release_id nvarchar(128) NULL,
 control_version bigint NOT NULL DEFAULT 0,
 -- Publication claim: only one bridge run may change a target's Delta state at a time.
 -- Cleared in the same update that records the publication; kept by the owning run if
 -- the outcome is unknown, so only that run's publish_run.py --resume can continue.
 publish_owner nvarchar(128) NULL,
 publish_token nvarchar(64) NULL,
 publish_claimed_utc datetime2(3) NULL,
 publish_external_run_id nvarchar(128) NULL,
 publish_operation_state varchar(24) NULL
);
GO
CREATE OR ALTER PROCEDURE bridge.transition_fence
 @source_set_id nvarchar(128), @expected_state varchar(20), @next_state varchar(20),
 @expected_version bigint, @generation_id nvarchar(128), @actor nvarchar(128),
 @expiry_utc datetime2(3) = NULL, @reason nvarchar(1000) = NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF NOT ((@expected_state='AVAILABLE' AND @next_state='WRITE_ACTIVE') OR
         (@expected_state='WRITE_ACTIVE' AND @next_state='CLOSED') OR
         (@expected_state='CLOSED' AND @next_state='BRIDGE_HELD') OR
         (@expected_state='BRIDGE_HELD' AND @next_state='AVAILABLE') OR
         (@next_state='ABANDONED' AND @expected_state IN ('WRITE_ACTIVE','CLOSED','BRIDGE_HELD')) OR
         (@expected_state='ABANDONED' AND @next_state='AVAILABLE'))
    THROW 51000, 'Illegal fence transition', 1;
 BEGIN TRANSACTION;
 UPDATE bridge.source_fence SET state=@next_state,
   generation_id=CASE WHEN @next_state='AVAILABLE' THEN NULL ELSE @generation_id END,
   writer_owner=CASE WHEN @next_state='WRITE_ACTIVE' THEN @actor WHEN @next_state IN ('AVAILABLE','ABANDONED') THEN NULL ELSE writer_owner END,
   bridge_owner=CASE WHEN @next_state='BRIDGE_HELD' THEN @actor WHEN @next_state IN ('AVAILABLE','ABANDONED') THEN NULL ELSE bridge_owner END,
   heartbeat_utc=SYSUTCDATETIME(),expires_utc=@expiry_utc,control_version=control_version+1
 WHERE source_set_id=@source_set_id AND state=@expected_state AND control_version=@expected_version
   AND ((@expected_state='AVAILABLE' AND generation_id IS NULL) OR generation_id=@generation_id)
   AND ((@expected_state<>'WRITE_ACTIVE') OR writer_owner=@actor)
   AND ((@expected_state<>'BRIDGE_HELD') OR bridge_owner=@actor);
 IF @@ROWCOUNT<>1 BEGIN ROLLBACK; THROW 51001, 'Fence owner/state/version mismatch', 1; END;
 INSERT bridge.fence_events(source_set_id,old_state,new_state,generation_id,actor,reason)
 VALUES (@source_set_id,@expected_state,@next_state,@generation_id,@actor,@reason);
 COMMIT;
END;
GO
-- Seed once, outside an active run:
-- INSERT bridge.source_fence(source_set_id,state) VALUES(N'<source-set>', 'AVAILABLE');
-- GRANT EXECUTE ON bridge.transition_fence TO [<writer-or-orchestrator-database-user>];
-- GRANT SELECT ON bridge.source_fence TO [<bridge-runtime-user>];
-- Do not give runtime users direct UPDATE on source_fence or DDL rights on bridge tables.
