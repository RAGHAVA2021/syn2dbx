/* ============================================================================
   02 · Upstream completion table (run once per pool)

   The upstream pipeline that rebuilds the source tables inserts one row here
   when, and only when, every source object for the business date is complete
   and closed to writes. The nightly job only publishes COMPLETE runs.

   upstream_sequence must strictly increase per source_set_id. The loader uses it
   as the Delta txnVersion, so it is what stops an older night overwriting a
   newer one. A good choice: yyyymmdd * 100 + revision (e.g. 2026092500, or
   2026092501 for a same-day correction).
   ============================================================================ */

-- Run 01_export_setup.sql first to create bridge_upstream.
IF OBJECT_ID('bridge_upstream.upstream_run') IS NULL
CREATE TABLE bridge_upstream.upstream_run (
    source_set_id      varchar(128)  NOT NULL,
    upstream_run_id    varchar(128)  NOT NULL,
    business_date      date          NOT NULL,
    upstream_sequence  bigint        NOT NULL,
    status             varchar(16)   NOT NULL,   -- COMPLETE | FAILED
    completed_utc      datetime2(3)  NULL
) WITH (DISTRIBUTION = REPLICATE, CLUSTERED INDEX (source_set_id, upstream_sequence));
GO

/* Upstream pipeline, final step (example):

-- The upstream scheduler must serialize completion for a source_set_id and
-- wait until the prior bridge generation and all exports finish before a correction.
DECLARE @base bigint = CONVERT(bigint, CONVERT(char(8), @business_date, 112)) * 100;
DECLARE @last bigint = (SELECT MAX(upstream_sequence) FROM bridge_upstream.upstream_run
                        WHERE source_set_id = 'synapse_nightly');
IF @last IS NOT NULL AND @last >= @base + 100
    THROW 50001, 'cannot publish an older business date', 1;
IF @last IS NOT NULL AND @last >= @base + 99
    THROW 50002, 'same-day revision limit reached', 1;
DECLARE @seq bigint = CASE WHEN @last IS NULL OR @last < @base THEN @base ELSE @last + 1 END;
INSERT INTO bridge_upstream.upstream_run
VALUES ('synapse_nightly', @pipeline_run_id, @business_date, @seq, 'COMPLETE', SYSUTCDATETIME());
*/

/* Write fence: after inserting COMPLETE, the upstream must not modify the mapped
   source tables until the nightly Databricks job has finished (its finalize task
   writes FINISHED to <control catalog>.<control schema>.run_log). Enforce this in
   the scheduler; the export has no way to detect a concurrent rewrite. This
   applies to the manifest completion mode as well: removing a previous
   _SUCCESS marker before a correction cannot stop an export already in flight.
   Do not start the correction until the prior bridge generation has finalized. */
