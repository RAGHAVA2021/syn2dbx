-- Upgrade the control tables of an existing v1.4-v2.4 deployment to v2.5 (run ONCE,
-- BEFORE deploying v2.5: the v2.5 job appends a commit_utc value to table_log).
-- From v1.0-v1.3, run the earlier upgrade scripts first.
-- Replace <catalog>.<control_schema> with control.catalog / control.schema from the inventory.
ALTER TABLE `<catalog>`.`<control_schema>`.`table_log` ADD COLUMNS (commit_utc TIMESTAMP);

-- Recreate the views so SELECT * picks up the new column.
CREATE OR REPLACE VIEW `<catalog>`.`<control_schema>`.`table_latest` AS
SELECT * EXCEPT (rn) FROM (SELECT *, row_number() OVER (
  PARTITION BY release_id, mapping_id ORDER BY event_utc DESC) AS rn
  FROM `<catalog>`.`<control_schema>`.`table_log`) WHERE rn = 1;
CREATE OR REPLACE VIEW `<catalog>`.`<control_schema>`.`table_current` AS
SELECT * EXCEPT (rn) FROM (SELECT *, row_number() OVER (
  PARTITION BY mapping_id ORDER BY event_utc DESC) AS rn
  FROM `<catalog>`.`<control_schema>`.`table_log` WHERE status IN ('PUBLISHED','ALREADY_CURRENT','ROLLED_BACK')) WHERE rn = 1;
