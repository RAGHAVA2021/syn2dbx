-- Upgrade the control tables of an existing v1.3 deployment to v1.4 (run ONCE).
-- From v1.0-v1.2, run upgrade_1.2_to_1.3.sql first.
-- Replace <catalog>.<control_schema> with control.catalog / control.schema from the inventory.
ALTER TABLE `<catalog>`.`<control_schema>`.`table_log` ADD COLUMNS (count_source STRING);
ALTER TABLE `<catalog>`.`<control_schema>`.`plan`
  ADD COLUMNS (expected_rows BIGINT, count_source STRING, source_schema_hash STRING);

-- Recreate the views so SELECT * picks up the new column.
CREATE OR REPLACE VIEW `<catalog>`.`<control_schema>`.`table_latest` AS
SELECT * EXCEPT (rn) FROM (SELECT *, row_number() OVER (
  PARTITION BY release_id, mapping_id ORDER BY event_utc DESC) AS rn
  FROM `<catalog>`.`<control_schema>`.`table_log`) WHERE rn = 1;
CREATE OR REPLACE VIEW `<catalog>`.`<control_schema>`.`table_current` AS
SELECT * EXCEPT (rn) FROM (SELECT *, row_number() OVER (
  PARTITION BY mapping_id ORDER BY event_utc DESC) AS rn
  FROM `<catalog>`.`<control_schema>`.`table_log` WHERE status IN ('PUBLISHED','ALREADY_CURRENT','ROLLED_BACK')) WHERE rn = 1;
