-- Upgrade the control log of an existing v1.0-v1.2 deployment to v1.3 (run ONCE).
-- Replace <catalog>.<control_schema> with control.catalog / control.schema from the inventory.
-- New installations do not need this: tools/render_uc_setup.py already includes the columns.
ALTER TABLE `<catalog>`.`<control_schema>`.`table_log`
  ADD COLUMNS (method STRING, error_code INT, duration_seconds DOUBLE);

-- Views are recreated so SELECT * picks up the new columns.
CREATE OR REPLACE VIEW `<catalog>`.`<control_schema>`.`table_latest` AS
SELECT * EXCEPT (rn) FROM (SELECT *, row_number() OVER (
  PARTITION BY release_id, mapping_id ORDER BY event_utc DESC) AS rn
  FROM `<catalog>`.`<control_schema>`.`table_log`) WHERE rn = 1;
CREATE OR REPLACE VIEW `<catalog>`.`<control_schema>`.`table_current` AS
SELECT * EXCEPT (rn) FROM (SELECT *, row_number() OVER (
  PARTITION BY mapping_id ORDER BY event_utc DESC) AS rn
  FROM `<catalog>`.`<control_schema>`.`table_log` WHERE status IN ('PUBLISHED','ALREADY_CURRENT','ROLLED_BACK')) WHERE rn = 1;
