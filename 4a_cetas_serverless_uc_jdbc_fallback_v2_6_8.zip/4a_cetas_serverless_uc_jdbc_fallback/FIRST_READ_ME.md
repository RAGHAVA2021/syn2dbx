# FIRST READ — 4A — serverless CETAS + serverless JDBC fallback

This ZIP is **4a_cetas_serverless_uc_jdbc_fallback.zip**.

**Nightly flow:** `Refresh complete → serverless plan/CETAS → serverless UC-JDBC fallback only when required → serverless Delta publish → final summary`

No dedicated cluster is defined in the nightly job. A UC JDBC connection is required for fallback reads.

Start with `docs/PACKAGE_GUIDE.md`, then `docs/COMPUTE_DESIGN.md`, `docs/DESIGN.md`, and `docs/RUNBOOK.md`. Keep the nightly schedule PAUSED until DEV connectivity, permissions, CETAS, fallback, publish and notification acceptance tests pass.
