# v2.2 response to the independent v2.1 review

| Review item | v2.2 result |
|---|---|
| Pre-1900 timestamps and fallback budget | Historical timestamp reroutes do not consume the CETAS-error budget. Both stages are removed on success. The double read remains; measure the number and runtime in a Synapse trial. Selecting only physical INT96 files or changing the timestamp transport requires real CETAS samples and a separate contract validation. |
| Standalone pool endpoint | Accept both `*.sql.azuresynapse.net` and `*.database.windows.net`; choose the corresponding TLS hostname pattern. |
| Default service credential on DBR 15.4 | Pin 16.4 LTS; 15.4 used the older Public Preview. Run acceptance on the actual cluster. |
| Upstream write fence | Explicit upstream scheduler contract in AGENTS, the runbook and both completion-mode descriptions. The package alone cannot stop a separate upstream writer. RCSI protects statements, not a whole night's 1,000 exports. |
| Counts exceeding the cutoff | Every Synapse recount uses the current remaining deadline. |
| Wrong history-precheck detail | Restored or changed publications now produce an investigation message. |
| Control-log file count | Weekly maintenance OPTIMIZEs control tables after retention pruning. Per-table events remain necessary for recovery. Trial the log latency and adjust maintenance if needed. |
| JDBC pool concurrency | Defaults to four export tasks and four JDBC partitions (up to sixteen simultaneous JDBC connections). Per-batch budget resets on task retries; plan workload slots for the actual DWU. |
| Spark-free test collection | The exception class lives in the pure contract module; the AGENTS consistency test loads Spark only when present. |
| Fallback event logging | Both routes use bounded logging retries; logging failure is identified as a control error. |
| Leftover CETAS stage | Both CETAS and JDBC folders are cleaned after a verified JDBC publication. |
| Partitioned overwrite | The loader sets static partition overwrite for its SQL commit and restores the previous session value; a real Spark test covers a partitioned table. |
| Retry after RESTORE | Workspace acceptance now checks that the old transaction version is still rejected, then a higher version succeeds. |
| Source names differing only by case | Inventory validation refuses ambiguous mappings before the case-insensitive catalog and manifest match. |
| Housekeeping | Module version and changelog updated; generated Derby logs excluded from the ZIP. |

Go-live still depends on the workspace acceptance job, the upstream no-overlap
protocol, effective permissions, and a Synapse trial with historical timestamps.
