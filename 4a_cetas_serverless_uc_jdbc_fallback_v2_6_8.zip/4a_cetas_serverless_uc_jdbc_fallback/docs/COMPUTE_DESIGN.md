# Compute design — 4A — serverless CETAS + serverless JDBC fallback

## Intended nightly flow

`Refresh complete → serverless plan/CETAS → serverless UC-JDBC fallback only when required → serverless Delta publish → final summary`

| Stage | Compute | Purpose |
|---|---|---|
| Plan / Synapse checks | Serverless | Uses `mssql-python` for command-capable T-SQL connection |
| CETAS | Serverless Databricks task; CETAS executes in Synapse | Issues CETAS DDL through `mssql-python` |
| JDBC fallback | Serverless | Unity Catalog JDBC connection; only `FALLBACK_REQUIRED` tables |
| Delta publish | Serverless | Publishes only `VALIDATED` stages |
| Finalize | Serverless | Final success/failure/fallback summary |

No dedicated cluster is defined in the nightly job. A UC JDBC connection is required for fallback reads.

## Why CETAS can be serverless

CETAS itself always executes inside the Synapse dedicated SQL pool. The Databricks task only submits and monitors the T-SQL command. On serverless, this package uses Microsoft's `mssql-python` DB-API driver because Spark Connect intentionally has no JVM gateway. This avoids relying on an undocumented attempt to execute DDL through a read-only remote-query pattern.

## Static-source assumption

The upstream tables refresh once per night and are immutable after the COMPLETE signal. Extraction does not start before that signal. Per-table failures do not block unrelated `VALIDATED` tables from publication.
