# 4A — serverless CETAS + serverless JDBC fallback

Production-oriented Synapse dedicated SQL pool → ADLS Gen2 → Unity Catalog managed Delta full-refresh package for static nightly source tables.

## Compute split

| Stage | Compute | Purpose |
|---|---|---|
| Plan / Synapse checks | Serverless | Uses `mssql-python` for command-capable T-SQL connection |
| CETAS | Serverless Databricks task; CETAS executes in Synapse | Issues CETAS DDL through `mssql-python` |
| JDBC fallback | Serverless | Unity Catalog JDBC connection; only `FALLBACK_REQUIRED` tables |
| Delta publish | Serverless | Publishes only `VALIDATED` stages |
| Finalize | Serverless | Final success/failure/fallback summary |

**Flow:** `Refresh complete → serverless plan/CETAS → serverless UC-JDBC fallback only when required → serverless Delta publish → final summary`

No dedicated cluster is defined in the nightly job. A UC JDBC connection is required for fallback reads.

## Important prerequisites

- Unity Catalog enabled workspace and serverless jobs available.
- Serverless network connectivity to the Synapse SQL endpoint and ADLS.
- `mssql-python==1.15.0` is installed by the job environment for serverless command/control SQL.
- The run identity has the required Synapse CETAS permissions and storage access.
- Upstream COMPLETE/manifest signal is authoritative; source tables remain static after it.
- Recovery cutoff remains 11:00 Australia/Sydney; do not rerun the previous night after the cutoff.

See `docs/PACKAGE_GUIDE.md` and `docs/COMPUTE_DESIGN.md` for file-by-file and compute details.
