"""Source-generation fence transitions (steps 3, 5, 7 and recovery in SCRIPT_GUIDE.md).

The upstream scheduler MUST call write-start before any governed table DML,
write-close after all audit rows commit, then bridge-hold. All other writer
identities must be constrained to the same entry point.

Recovery actions:
  abandon  WRITE_ACTIVE/CLOSED/BRIDGE_HELD -> ABANDONED. Marks unpublished bridge runs of the
           generation in this source set ABANDONED_GENERATION in the same transaction. Refused while
           a run publishes. Unpublished runs recorded before v9.5.5 (no source set) must be claimed
           explicitly with --claim-legacy-runs; they are never relabelled implicitly.
  reopen   ABANDONED -> AVAILABLE, so a new generation can be written.
"""
import argparse
import json
from datetime import datetime, timezone

from bridge_run import config, db, need

NEXT = {"write-start": ("AVAILABLE", "WRITE_ACTIVE"),
        "write-close": ("WRITE_ACTIVE", "CLOSED"),
        "bridge-hold": ("CLOSED", "BRIDGE_HELD"),
        "bridge-release": ("BRIDGE_HELD", "AVAILABLE"),
        "abandon": (None, "ABANDONED"),
        "reopen": ("ABANDONED", "AVAILABLE")}
NEEDS_EXPIRY = ("write-start", "write-close", "bridge-hold")
# GUARD_SCOPE selects runs for the fail-closed checks (unresolved reads, PUBLISHING). Rows from
# before v9.5.5 have no recorded source set, so they are included: they may belong to this set.
GUARD_SCOPE = "r.generation_id=? AND (r.source_set_id=? OR r.source_set_id IS NULL)"
# OWN_SCOPE selects the runs abandon may MODIFY: only runs recorded against this source set. A
# legacy NULL row may belong to another source set that reused the generation ID, so relabelling
# it implicitly could destroy that set's READY run.
OWN_SCOPE = "r.generation_id=? AND r.source_set_id=?"
OWN_RUN_SCOPE = "generation_id=? AND source_set_id=?"
ABANDONABLE_RUNS = "('CREATED','EXTRACTING','EXTRACTED','LOADING','READY','FAILED')"


def unresolved_source_operations(cur, where_sql, *values):
    """Return unresolved source reads selected by a caller-supplied run predicate.

    An EXTRACTING attempt whose source_operation_state is still PENDING never submitted a
    read: the orchestrator records RUNNING (conditional on its lease) before any CETAS or
    Synapse pipeline submission. It is not a blocker, otherwise a crash between the attempt insert and
    submission would make an expired generation impossible to abandon. A NULL state
    (pre-v9.4 row) is still treated as unknown.

    The attempt rows are read WITH (UPDLOCK,HOLDLOCK) and held until the caller commits,
    so an orchestrator cannot move a PENDING attempt to RUNNING between this check and the
    fence transition; after an abandon commits, its lease predicate fails and it never submits.
    """
    return [f"{r[0]} attempt {r[1]}: {r[2]}/{r[3]}" for r in cur.execute(
        "SELECT a.mapping_id,a.attempt,a.status,a.source_operation_state "
        "FROM bridge.object_attempts a WITH (UPDLOCK,HOLDLOCK) "
        "JOIN bridge.runs r ON r.bridge_run_id=a.bridge_run_id WHERE " + where_sql +
        " AND (a.status='INDETERMINATE' "
        "OR (a.status='EXTRACTING' AND (a.source_operation_state IS NULL OR a.source_operation_state<>'PENDING')) "
        "OR a.source_operation_state IN ('RUNNING','UNKNOWN'))", *values).fetchall()]


def release_blockers(cur, bridge_run_id):
    """Reasons the source cannot be returned to writers yet; empty when release is safe."""
    reasons = unresolved_source_operations(cur, "a.bridge_run_id=?", bridge_run_id)
    status = cur.execute("SELECT status FROM bridge.runs WITH (UPDLOCK,HOLDLOCK) "
                         "WHERE bridge_run_id=?", bridge_run_id).fetchone()
    if status is None or status[0] != "READY":
        reasons.append(f"run status {status[0] if status else 'missing'}")
    return reasons


def main():
    p = argparse.ArgumentParser()
    p.add_argument("action", choices=NEXT)
    p.add_argument("--source-set", required=True)
    p.add_argument("--generation", required=True)
    p.add_argument("--actor", required=True,
                   help="Writer run ID on start/close; bridge run ID on hold/release; current owner for abandon")
    p.add_argument("--expiry-utc", help="UTC ISO time; required for write-start, write-close and bridge-hold")
    p.add_argument("--evidence", help="JSON evidence for bridge-release; all gate checks must pass")
    p.add_argument("--reason", help="Required for abandon and reopen; stored in bridge.fence_events")
    p.add_argument("--config", help="Required for bridge-hold source-audit preflight")
    p.add_argument("--upstream-run-id", help="Required for bridge-hold source-audit preflight")
    p.add_argument("--claim-legacy-runs", action="store_true",
                   help="abandon only: record this source set on unpublished pre-v9.5.5 runs of the "
                        "generation that have none, then abandon them with the rest")
    a = p.parse_args()
    prior, nxt = NEXT[a.action]
    expiry = None
    if a.action in NEEDS_EXPIRY:
        need(a.expiry_utc, "Fence needs a bounded expiry")
        parsed = datetime.fromisoformat(a.expiry_utc.replace("Z", "+00:00"))
        need(parsed.tzinfo is None or parsed.utcoffset().total_seconds() == 0, "Expiry must be UTC")
        now_utc = datetime.now(timezone.utc).replace(tzinfo=None)
        need(parsed.replace(tzinfo=None) > now_utc, "Expiry is in the past")
        expiry = parsed.replace(tzinfo=None).isoformat(timespec="milliseconds")
    need(not a.claim_legacy_runs or a.action == "abandon", "--claim-legacy-runs applies only to abandon")
    if a.action in ("abandon", "reopen"):
        need(a.reason and len(a.reason) <= 1000, "abandon/reopen need a --reason (max 1000 characters)")
    if a.action == "bridge-release":
        need(a.evidence, "Bridge release needs independent detector evidence")
        with open(a.evidence, encoding="utf-8") as handle:
            data = json.load(handle)
        for field in ("all_source_requests_terminal", "no_source_retry_needed", "audit_healthy",
                      "no_fence_violation", "smoke_check_passed"):
            need(data.get(field) is True and data.get(field + "_evidence_uri"), f"Missing {field}")
        need(data.get("source_generation_id") == a.generation, "Wrong generation in evidence")
    if a.action == "bridge-hold":
        need(a.config and a.upstream_run_id, "Hold requires inventory and upstream run ID")
        cfg = config(a.config)
        need(cfg["source_set_id"] == a.source_set, "Wrong source set")
        with db("BRIDGE_SYNAPSE_AUDIT_ODBC") as syn:
            run = syn.cursor().execute("SELECT count_big(*) FROM bridge_meta.upstream_run WHERE "
                                       "upstream_run_id=? AND source_generation_id=? AND status='COMPLETE' "
                                       "AND write_closed=1", a.upstream_run_id, a.generation).fetchone()
            need(run and run[0] == 1, "Upstream generation not uniquely closed")
            for m in cfg["mappings"]:
                obj = syn.cursor().execute("SELECT count_big(*) FROM bridge_meta.upstream_object WHERE "
                                           "upstream_run_id=? AND mapping_id=? AND source_schema_version=? "
                                           "AND status='COMPLETE'", a.upstream_run_id, m["mapping_id"],
                                           m["source_schema_version"]).fetchone()
                need(obj and obj[0] == 1, f"Incomplete upstream member: {m['mapping_id']}")
    with db("BRIDGE_CONTROL_ODBC") as conn:
        row = conn.cursor().execute("SELECT state,generation_id,writer_owner,bridge_owner,control_version "
                                    "FROM bridge.source_fence WITH (UPDLOCK,HOLDLOCK) WHERE source_set_id=?",
                                    a.source_set).fetchone()
        need(row, "Unknown source set")
        if a.action == "abandon":
            need(row[0] in ("WRITE_ACTIVE", "CLOSED", "BRIDGE_HELD"), f"Cannot abandon from {row[0]}")
            prior = row[0]
        need(row[0] == prior, "Fence changed; stop")
        if prior != "AVAILABLE":
            need(row[1] == a.generation, "Generation changed")
        if prior == "WRITE_ACTIVE":
            need(row[2] == a.actor, "Wrong writer")
        if prior == "BRIDGE_HELD":
            need(row[3] == a.actor, "Wrong bridge owner")
        cur = conn.cursor()
        if a.action == "bridge-release":
            # Releasing lets writers modify the source; no extraction may still be reading it.
            blockers = release_blockers(cur, a.actor)
            need(not blockers, "Bridge release requires a READY run with no running or indeterminate source "
                               "operation: " + "; ".join(blockers))
        if a.action in ("abandon", "reopen"):
            # Both transitions can ultimately return the source to writers. Never allow either
            # path to bypass the same unresolved-read invariant enforced by bridge-release.
            blockers = unresolved_source_operations(cur, GUARD_SCOPE, a.generation, a.source_set)
            need(not blockers, f"{a.action} requires all source operations for the generation to be terminal: "
                               + "; ".join(blockers))
        if a.action == "abandon":
            publishing = cur.execute("SELECT count(*) FROM bridge.runs r WITH (UPDLOCK,HOLDLOCK) WHERE " + GUARD_SCOPE +
                                     " AND r.status='PUBLISHING'", a.generation, a.source_set).fetchone()[0]
            need(publishing == 0, "A run of this generation is PUBLISHING; finish or reconcile it first")
            legacy = [r[0] for r in cur.execute(
                "SELECT bridge_run_id FROM bridge.runs WITH (UPDLOCK,HOLDLOCK) WHERE generation_id=? "
                "AND source_set_id IS NULL AND status IN " + ABANDONABLE_RUNS, a.generation).fetchall()]
            if legacy:
                need(a.claim_legacy_runs,
                     "Unpublished run(s) of this generation have no recorded source set (created before "
                     "v9.5.5): " + ", ".join(sorted(legacy)) + ". Confirm they belong to source set "
                     f"{a.source_set} and rerun with --claim-legacy-runs, or record their source set first")
                cur.execute("UPDATE bridge.runs SET source_set_id=?,updated_utc=SYSUTCDATETIME() WHERE "
                            "generation_id=? AND source_set_id IS NULL AND status IN " + ABANDONABLE_RUNS,
                            a.source_set, a.generation)
        cur.execute("EXEC bridge.transition_fence @source_set_id=?,@expected_state=?,@next_state=?,"
                    "@expected_version=?,@generation_id=?,@actor=?,@expiry_utc=?,@reason=?",
                    a.source_set, prior, nxt, row[4], a.generation, a.actor, expiry, a.reason)
        abandoned = 0
        if a.action == "abandon":
            # Scope attempts using the same unpublished-run predicate *before* changing run status.
            # This prevents a reused/corrupt generation ID from relabelling attempts of PUBLISHED runs.
            cur.execute("UPDATE a SET status='ABANDONED_GENERATION',updated_utc=SYSUTCDATETIME() "
                        "FROM bridge.object_attempts a JOIN bridge.runs r ON r.bridge_run_id=a.bridge_run_id "
                        "WHERE " + OWN_SCOPE + " AND r.status IN " + ABANDONABLE_RUNS + " AND a.status IN "
                        "('EXTRACTING','INDETERMINATE','EXTRACTED','LOADING','READY','FAILED','SUPERSEDED')",
                        a.generation, a.source_set)
            cur.execute("UPDATE bridge.runs SET status='ABANDONED_GENERATION',orchestrator_token=NULL,"
                        "updated_utc=SYSUTCDATETIME() WHERE " + OWN_RUN_SCOPE + " AND status IN "
                        + ABANDONABLE_RUNS, a.generation, a.source_set)
            abandoned = cur.rowcount
            cur.execute("UPDATE ts SET publish_owner=NULL,publish_token=NULL,publish_claimed_utc=NULL,"
                        "publish_external_run_id=NULL,publish_operation_state='ABANDONED' "
                        "FROM bridge.target_state ts JOIN bridge.runs r ON r.bridge_run_id=ts.publish_owner "
                        "WHERE " + OWN_SCOPE + " AND r.status='ABANDONED_GENERATION'", a.generation, a.source_set)
        conn.commit()
    print(json.dumps({"source_set": a.source_set, "generation": a.generation, "state": nxt,
                      **({"runs_abandoned": abandoned} if a.action == "abandon" else {})}))


if __name__ == "__main__":
    main()
