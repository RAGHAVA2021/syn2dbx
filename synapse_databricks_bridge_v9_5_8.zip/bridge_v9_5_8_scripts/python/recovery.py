"""Audited recovery for indeterminate attempts and publication claims.

This command never infers that an external operation stopped. An operator or an
independent monitor must inspect the stored external run ID and supply evidence.
"""
import argparse
import json
from pathlib import Path

from bridge_run import db, need


def evidence(path, required):
    doc = json.loads(Path(path).read_text())
    for field in required:
        need(doc.get(field) is True, f"Evidence must set {field}=true")
    need(isinstance(doc.get("evidence_uri"), str) and doc["evidence_uri"], "Evidence URI is required")
    return doc



def resolve_source_external_id(stored_id, ev):
    """Validate source evidence and return the authoritative external run ID.

    Normal attempts persist the real Synapse/CETAS identifier. A Synapse Copy
    acknowledgement-loss can leave the pre-submission correlation placeholder in
    source_request_id. In that case recovery evidence must contain both the exact
    source_correlation and the actual Synapse external_run_id discovered from the
    pipeline run parameters.
    """
    need(stored_id, "Attempt has no stored source operation identifier")
    if str(stored_id).startswith("correlation:"):
        need(ev.get("source_correlation") == stored_id, "Evidence source correlation differs")
        external_id = ev.get("external_run_id")
        need(isinstance(external_id, str) and external_id and not external_id.startswith("correlation:"),
             "Evidence must provide the actual Synapse external_run_id")
        return external_id
    need(ev.get("external_run_id") == stored_id, "Evidence external run ID differs")
    return stored_id


def resolve_databricks_external_id(stored_id, ev):
    """Validate loader/publisher evidence and return the authoritative Databricks run ID.

    The orchestrator stores the job's idempotency token ("token:<token>") before run-now and the
    numeric run ID only after Databricks answers. If that answer was lost, the stored value is the
    token. Evidence may then either repeat the stored token as external_run_id (no run was found
    for it), or give the matching idempotency_token together with the actual run ID found for it,
    which is recorded in place of the token.
    """
    need(stored_id, "No stored Databricks run identifier")
    stored_id = str(stored_id)
    supplied = ev.get("external_run_id")
    if stored_id.startswith("token:"):
        if supplied == stored_id:
            return stored_id
        token = str(ev.get("idempotency_token") or "")
        need(token and "token:" + token.removeprefix("token:") == stored_id,
             "Evidence idempotency_token differs from the stored submission token")
        need(isinstance(supplied, str) and supplied.strip() and not supplied.startswith("token:"),
             "Evidence must provide the actual Databricks external_run_id found for the token")
        return supplied
    need(supplied == stored_id, "Evidence external run ID differs")
    return stored_id


def resolve_attempt(a):
    ev = evidence(a.evidence, ("external_terminal", "safe_to_retry"))
    need(ev.get("phase") in ("SOURCE", "LOADER"), "Evidence phase must be SOURCE or LOADER")
    with db("BRIDGE_CONTROL_ODBC") as conn:
        cur = conn.cursor()
        row = cur.execute(
            "SELECT a.status,a.source_request_id,a.loader_run_id,r.status,a.source_operation_state,"
            "a.loader_operation_state "
            "FROM bridge.object_attempts a WITH (UPDLOCK,HOLDLOCK) "
            "JOIN bridge.runs r ON r.bridge_run_id=a.bridge_run_id WHERE a.bridge_run_id=? AND a.mapping_id=? "
            "AND a.attempt=?", a.bridge_run_id, a.mapping_id, a.attempt).fetchone()
        need(row, "Unknown attempt")
        if row[0] == "SUPERSEDED":
            # v9.3 databases: an interrupted read could be superseded while still marked RUNNING,
            # which blocks bridge-release. Record the terminal evidence; the status stays SUPERSEDED.
            need(ev["phase"] == "SOURCE" and row[4] in ("RUNNING", "UNKNOWN"),
                 "Superseded attempt has no unresolved source operation")
            resolved_id = resolve_source_external_id(row[1], ev)
            cur.execute("UPDATE bridge.object_attempts SET source_request_id=?,source_operation_state='VERIFIED_TERMINAL',"
                        "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                        "AND status='SUPERSEDED' AND source_operation_state IN ('RUNNING','UNKNOWN')",
                        resolved_id, a.bridge_run_id, a.mapping_id, a.attempt)
            need(cur.rowcount == 1, "Attempt changed concurrently")
            cur.execute("INSERT bridge.recovery_events(action,bridge_run_id,mapping_id,attempt,external_run_id,actor,"
                        "evidence_uri,reason) VALUES ('RESOLVE_SUPERSEDED',?,?,?,?,?,?,?)",
                        a.bridge_run_id, a.mapping_id, a.attempt, resolved_id, a.actor, ev["evidence_uri"], a.reason)
            conn.commit()
            return
        if row[0] == "ABANDONED_GENERATION":
            # Databases abandoned before v9.5.2 could leave a source or loader operation marked
            # RUNNING/UNKNOWN on an abandoned attempt; that blocks fence.py reopen (source) and
            # retention (either). Record the terminal evidence; the status stays ABANDONED_GENERATION.
            source = ev["phase"] == "SOURCE"
            state, external_id = (row[4], row[1]) if source else (row[5], row[2])
            state_col = "source_operation_state" if source else "loader_operation_state"
            need(state in ("RUNNING", "UNKNOWN"),
                 f"Abandoned attempt has no unresolved {ev['phase'].lower()} operation")
            resolved_id = (resolve_source_external_id(external_id, ev) if source
                           else resolve_databricks_external_id(external_id, ev))
            id_assignment = "source_request_id=?," if source else "loader_run_id=?,"
            params = [resolved_id, a.bridge_run_id, a.mapping_id, a.attempt]
            cur.execute(f"UPDATE bridge.object_attempts SET {id_assignment}{state_col}='VERIFIED_TERMINAL',"
                        "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND mapping_id=? AND attempt=? "
                        f"AND status='ABANDONED_GENERATION' AND {state_col} IN ('RUNNING','UNKNOWN')",
                        *params)
            need(cur.rowcount == 1, "Attempt changed concurrently")
            cur.execute("INSERT bridge.recovery_events(action,bridge_run_id,mapping_id,attempt,external_run_id,actor,"
                        "evidence_uri,reason) VALUES ('RESOLVE_ABANDONED',?,?,?,?,?,?,?)",
                        a.bridge_run_id, a.mapping_id, a.attempt, resolved_id, a.actor, ev["evidence_uri"], a.reason)
            conn.commit()
            return
        need(row[0] == "INDETERMINATE" and row[3] == "FAILED", "Attempt/run is not awaiting recovery")
        source = ev["phase"] == "SOURCE"
        # The evidence must be about the operation that is actually unresolved. Proving an
        # already-terminal operation terminal would otherwise release the lease while the
        # other (source or loader) operation may still be running.
        # A NULL state is a row written before operation states existed (pre-v9.4): its phase
        # cannot be checked, so it is accepted as before rather than becoming unrecoverable.
        unresolved = ("RUNNING", "UNKNOWN")
        phase_state, other_state = (row[4], row[5]) if source else (row[5], row[4])
        other_phase = "LOADER" if source else "SOURCE"
        need(phase_state in unresolved or phase_state is None,
             f"The {ev['phase']} operation is not unresolved (state {phase_state}); "
             "supply evidence for the operation that is RUNNING/UNKNOWN")
        need(other_state not in unresolved,
             f"The {other_phase} operation is also unresolved (state {other_state}); resolve it first")
        if source and phase_state is None:
            # Legacy row: states cannot tell which operation was in flight, but a stored loader run
            # proves the source read finished and the loader was reached. SOURCE evidence would move
            # the attempt to FAILED (and on to a retry) while that loader may still be writing.
            need(not row[2], "Legacy attempt has a stored loader run; supply LOADER evidence for it")
        external_id = row[1] if source else row[2]
        resolved_id = (resolve_source_external_id(external_id, ev) if source
                       else resolve_databricks_external_id(external_id, ev))
        next_status = "FAILED" if source else "EXTRACTED"
        state_col = "source_operation_state" if source else "loader_operation_state"
        id_assignment = "source_request_id=?," if source else "loader_run_id=?,"
        params = [next_status, resolved_id, ("Recovered after terminal evidence: " + a.reason)[:2000],
                  a.bridge_run_id, a.mapping_id, a.attempt]
        cur.execute(f"UPDATE bridge.object_attempts SET status=?,{id_assignment}{state_col}='VERIFIED_TERMINAL',"
                    "error_text=?,updated_utc=SYSUTCDATETIME() "
                    "WHERE bridge_run_id=? AND mapping_id=? AND attempt=? AND status='INDETERMINATE'",
                    *params)
        need(cur.rowcount == 1, "Attempt changed concurrently")
        remaining = cur.execute("SELECT count(*) FROM bridge.object_attempts WHERE bridge_run_id=? "
                                "AND status='INDETERMINATE'", a.bridge_run_id).fetchone()[0]
        if remaining == 0:
            cur.execute("UPDATE bridge.runs SET orchestrator_token=NULL,updated_utc=SYSUTCDATETIME() "
                        "WHERE bridge_run_id=? AND status='FAILED'", a.bridge_run_id)
        cur.execute("INSERT bridge.recovery_events(action,bridge_run_id,mapping_id,attempt,external_run_id,actor,"
                    "evidence_uri,reason) VALUES ('RESOLVE_ATTEMPT',?,?,?,?,?,?,?)",
                    a.bridge_run_id, a.mapping_id, a.attempt, resolved_id, a.actor, ev["evidence_uri"], a.reason)
        conn.commit()


def abandon_publication(a):
    ev = evidence(a.evidence, ("external_terminal", "delta_state_verified", "safe_to_abandon"))
    with db("BRIDGE_CONTROL_ODBC") as conn:
        cur = conn.cursor()
        target = cur.execute("SELECT publish_owner,publish_external_run_id FROM bridge.target_state "
                             "WITH (UPDLOCK,HOLDLOCK) WHERE target_key=?", a.target_key).fetchone()
        run = cur.execute("SELECT status FROM bridge.runs WITH (UPDLOCK,HOLDLOCK) WHERE bridge_run_id=?",
                          a.bridge_run_id).fetchone()
        need(target and run and target[0] == a.bridge_run_id and run[0] == "PUBLISHING",
             "Run does not own an active publication claim")
        resolved_id = resolve_databricks_external_id(target[1], ev)
        cur.execute("UPDATE bridge.target_state SET publish_owner=NULL,publish_token=NULL,publish_claimed_utc=NULL,"
                    "publish_external_run_id=?,publish_operation_state='ABANDONED' WHERE target_key=? AND publish_owner=?",
                    resolved_id, a.target_key, a.bridge_run_id)
        need(cur.rowcount == 1, "Publication claim changed concurrently")
        remaining = cur.execute("SELECT count(*) FROM bridge.target_state WHERE publish_owner=?",
                                a.bridge_run_id).fetchone()[0]
        if remaining == 0:
            cur.execute("UPDATE bridge.runs SET status='PUBLICATION_ABANDONED',orchestrator_token=NULL,"
                        "updated_utc=SYSUTCDATETIME() WHERE bridge_run_id=? AND status='PUBLISHING'", a.bridge_run_id)
        cur.execute("INSERT bridge.recovery_events(action,bridge_run_id,target_key,external_run_id,actor,evidence_uri,"
                    "reason) VALUES ('ABANDON_PUBLICATION',?,?,?,?,?,?)", a.bridge_run_id, a.target_key,
                    resolved_id, a.actor, ev["evidence_uri"], a.reason)
        conn.commit()


def resolve_publication(a):
    """Record proof that an unknown mutating publisher is terminal, preserving its ID.

    The explicit orchestrator_stopped assertion prevents an operator from clearing the
    lease while the original publisher orchestration is still actively heartbeating.
    Once every unknown publisher owned by the run is resolved, resume may proceed
    immediately and will inspect Delta before deciding whether to reconcile or publish.
    """
    ev = evidence(a.evidence, ("external_terminal", "safe_to_resume", "orchestrator_stopped"))
    with db("BRIDGE_CONTROL_ODBC") as conn:
        cur = conn.cursor()
        target = cur.execute(
            "SELECT publish_owner,publish_external_run_id,publish_operation_state "
            "FROM bridge.target_state WITH (UPDLOCK,HOLDLOCK) WHERE target_key=?", a.target_key).fetchone()
        run = cur.execute("SELECT status FROM bridge.runs WITH (UPDLOCK,HOLDLOCK) WHERE bridge_run_id=?",
                          a.bridge_run_id).fetchone()
        need(target and run and target[0] == a.bridge_run_id and run[0] == "PUBLISHING",
             "Run does not own an unresolved publication claim")
        need(target[2] in ("RUNNING", "UNKNOWN"), "Publisher operation is not awaiting recovery")
        resolved_id = resolve_databricks_external_id(target[1], ev)
        cur.execute("UPDATE bridge.target_state SET publish_external_run_id=?,publish_operation_state='VERIFIED_TERMINAL' "
                    "WHERE target_key=? AND publish_owner=? AND publish_external_run_id=? "
                    "AND publish_operation_state IN ('RUNNING','UNKNOWN')",
                    resolved_id, a.target_key, a.bridge_run_id, target[1])
        need(cur.rowcount == 1, "Publication claim changed concurrently")
        unresolved = cur.execute(
            "SELECT count(*) FROM bridge.target_state WHERE publish_owner=? "
            "AND publish_operation_state IN ('RUNNING','UNKNOWN')", a.bridge_run_id).fetchone()[0]
        if unresolved == 0:
            cur.execute("UPDATE bridge.runs SET orchestrator_token=NULL,updated_utc=SYSUTCDATETIME() "
                        "WHERE bridge_run_id=? AND status='PUBLISHING'", a.bridge_run_id)
        cur.execute("INSERT bridge.recovery_events(action,bridge_run_id,target_key,external_run_id,actor,evidence_uri,"
                    "reason) VALUES ('RESOLVE_PUBLICATION',?,?,?,?,?,?)", a.bridge_run_id, a.target_key,
                    resolved_id, a.actor, ev["evidence_uri"], a.reason)
        conn.commit()


def main():
    p = argparse.ArgumentParser()
    sub = p.add_subparsers(dest="action", required=True)
    attempt = sub.add_parser("resolve-attempt")
    attempt.add_argument("--bridge-run-id", required=True); attempt.add_argument("--mapping-id", required=True)
    attempt.add_argument("--attempt", required=True, type=int)
    publication = sub.add_parser("abandon-publication")
    publication.add_argument("--bridge-run-id", required=True); publication.add_argument("--target-key", required=True)
    resolve_pub = sub.add_parser("resolve-publication")
    resolve_pub.add_argument("--bridge-run-id", required=True); resolve_pub.add_argument("--target-key", required=True)
    for command in (attempt, publication, resolve_pub):
        command.add_argument("--actor", required=True); command.add_argument("--evidence", required=True)
        command.add_argument("--reason", required=True)
    a = p.parse_args()
    need(len(a.reason) <= 1000, "Reason must be at most 1000 characters")
    if a.action == "resolve-attempt":
        resolve_attempt(a)
    elif a.action == "resolve-publication":
        resolve_publication(a)
    else:
        abandon_publication(a)
    print(json.dumps({"action": a.action, "bridge_run_id": a.bridge_run_id, "status": "RECORDED"}))


if __name__ == "__main__":
    main()
