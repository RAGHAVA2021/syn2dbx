"""Step 9 (SCRIPT_GUIDE.md): retire superseded releases. Dry run unless --execute.

Keeps, per target: the published release, the previous release (rollback) and any
--keep-release pinned by a consumer contract. Only releases that can never be
published again are retired: their run's sequence is at or below the target's
high-water mark, or their generation was abandoned. Runs that are PUBLISHING are
never touched.

Attempts that can never be published at all (FAILED or SUPERSEDED) are also retired,
even when their release is kept: the kept release is its READY attempt, not them.

Candidate tables and staging paths follow the DESIGN_v9.md retention windows, measured
from the time the run last changed state (publication, or closure): an attempt of a
PUBLISHED run that is its READY attempt becomes eligible retention_days_published (default 7)
days later; every other attempt retention_days_unpublished (default 30) days later.
Pointer snapshot rows are governed by the kept releases and high-water mark only.

  * RELEASE_POINTER: deletes old release rows from each *_snapshots table
    (storage is reclaimed later by VACUUM under the governed retention property).
  * REPLACE_TABLE: drops old attempt-specific candidate tables.
  * --delete-staging: deletes the exact recorded Parquet attempt paths (never a listing).
"""
import argparse
import json
import re
import sys

from bridge_run import (STAGE_PREFIX, config, container_client, db, need, notebook_job, staging_parts,
                        target_key)

RETIRABLE = ("PUBLISHED", "READY", "FAILED", "PUBLICATION_ABANDONED", "ABANDONED_GENERATION")
# Attempt states that can never be published: a later attempt (or none) replaces them.
DEAD_ATTEMPTS = ("FAILED", "SUPERSEDED")
ATTEMPT_PATH = re.compile(re.escape(STAGE_PREFIX) + r"/\d{4}-\d{2}-\d{2}/[A-Za-z0-9_\-]+/[A-Za-z0-9_\-]+/attempt-\d{3}/")


def plan(cfg, pinned, historical=(), report=None):
    inventories = [cfg, *historical]
    by_inventory = {(doc["inventory_version"], m["mapping_id"]): m
                    for doc in inventories for m in doc["mappings"]}
    with db("BRIDGE_CONTROL_ODBC") as control:
        states = {r[0]: {"published": r[1], "previous": r[2], "high_water": int(r[3])}
                  for r in control.cursor().execute("SELECT target_key,published_release_id,previous_release_id,"
                                                    "high_water_sequence FROM bridge.target_state").fetchall()}
        attempts = control.cursor().execute(
            "SELECT a.bridge_run_id,a.mapping_id,a.attempt,a.delta_target,a.leaf_path,a.retired_utc,"
            "a.staging_deleted_utc,r.release_id,r.upstream_sequence,r.status,a.target_key,"
            "a.publication_strategy,a.consumer_target,r.inventory_version,a.source_operation_state,a.loader_operation_state,"
            "a.status,DATEDIFF(hour, r.updated_utc, SYSUTCDATETIME()) "
            "FROM bridge.object_attempts a JOIN bridge.runs r ON r.bridge_run_id=a.bridge_run_id").fetchall()
    published_hours = cfg.get("retention_days_published", 7) * 24
    unpublished_hours = cfg.get("retention_days_unpublished", 30) * 24
    waiting = []

    def keep_for(key):
        s = states.get(key, {})
        return sorted({x for x in (s.get("published"), s.get("previous"), *pinned) if x and x != "NONE"})

    groups, drops, staging = {}, [], []
    for doc in inventories:
        for m in doc["mappings"]:
            if m["strategy"] == "RELEASE_POINTER":
                key = target_key(m)
                g = groups.setdefault(m["group_id"], {"group_id": m["group_id"], "keep": keep_for(key),
                                                      "high_water": states.get(key, {}).get("high_water", -1),
                                                      "tables": []})
                table = {"catalog": m["target_catalog"], "schema": m["physical_schema"],
                         "table": m["target_table"] + "_snapshots"}
                if table not in g["tables"]:
                    g["tables"].append(table)
    for (run_id, mid, attempt, dtarget, leaf, retired, deleted, release, seq, status,
         stored_key, stored_strategy, stored_consumer, inventory_version, source_state, loader_state,
         attempt_status, run_age_hours) in attempts:
        m = by_inventory.get((inventory_version, mid))
        if status not in RETIRABLE:
            continue
        # A terminal-looking parent run is not sufficient proof that its external work stopped.
        # Never drop a candidate or delete staging while a source/loader operation may still run.
        if source_state in ("RUNNING", "UNKNOWN") or loader_state in ("RUNNING", "UNKNOWN"):
            continue
        key = stored_key or (target_key(m) if m else None)
        strategy = stored_strategy or (m["strategy"] if m else None)
        consumer = stored_consumer or (".".join(m[k] for k in ("target_catalog", "target_schema", "target_table"))
                                       if m else None)
        if not key or strategy not in ("REPLACE_TABLE", "RELEASE_POINTER"):
            continue                      # legacy row lacks enough immutable metadata for safe retirement
        state = states.get(key)
        if state is None:
            continue
        dead = attempt_status in DEAD_ATTEMPTS
        releasable = release not in keep_for(key) and (
            status == "ABANDONED_GENERATION" or int(seq) <= state["high_water"])
        if not (dead or releasable):
            continue                      # kept, or could still be published
        if releasable and strategy == "RELEASE_POINTER" and dtarget and key.startswith("group:"):
            cat, sch, tab = dtarget.split(".")
            group_id = key.split(":", 1)[1]
            g = groups.setdefault(group_id, {"group_id": group_id, "keep": keep_for(key),
                                             "high_water": state["high_water"], "tables": []})
            table = {"catalog": cat, "schema": sch, "table": tab}
            if table not in g["tables"]:
                g["tables"].append(table)
        # DESIGN_v9.md windows, from the run's last state change. A missing timestamp is never old enough.
        window = published_hours if (status == "PUBLISHED" and attempt_status == "READY") else unpublished_hours
        if run_age_hours is None or int(run_age_hours) < window:
            if (retired is None and strategy == "REPLACE_TABLE" and dtarget) or (leaf and deleted is None):
                waiting.append({"run_id": run_id, "mapping_id": mid, "attempt": attempt,
                                "eligible_in_hours": window - int(run_age_hours or 0)})
            continue
        if strategy == "REPLACE_TABLE" and dtarget and consumer and retired is None:
            cat, sch, tab = dtarget.split(".")
            ccat, csch, ctab = consumer.split(".")
            drops.append({"run_id": run_id, "mapping_id": mid, "attempt": attempt, "catalog": cat,
                          "schema": sch, "table": tab, "release_id": release,
                          "target": {"catalog": ccat, "schema": csch, "table": ctab}})
        if leaf and deleted is None:
            staging.append({"run_id": run_id, "mapping_id": mid, "attempt": attempt, "leaf_path": leaf})
    if report is not None:
        report["waiting_for_retention_window"] = waiting
    return list(groups.values()), drops, staging


def delete_staging(cfg, items):
    root = cfg["staging_abfss_root"].rstrip("/") + "/"
    client = container_client(cfg["staging_abfss_root"])
    done = []
    for item in items:
        need(item["leaf_path"].startswith(root), f"Leaf path outside staging root: {item['leaf_path']}")
        relative = item["leaf_path"][len(root):]
        need(ATTEMPT_PATH.fullmatch(relative), f"Not an exact attempt path: {relative}")
        # Delete deepest names first so hierarchical-namespace directories empty cleanly.
        names = sorted((b.name for b in client.list_blobs(name_starts_with=relative)), key=len, reverse=True)
        for name in names:
            client.delete_blob(name)
        done.append(item)
    return done


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--keep-release", action="append", default=[],
                   help="Release pinned by a consumer contract; repeatable")
    p.add_argument("--inventory-config", action="append", default=[],
                   help="Older versioned config used to retire pre-v9.3 mappings; repeatable")
    p.add_argument("--delete-staging", action="store_true", help="Also delete retired Parquet attempt paths")
    p.add_argument("--execute", action="store_true", help="Apply the plan (default is a dry run)")
    a = p.parse_args()
    cfg = config(a.config)
    staging_parts(cfg["staging_abfss_root"])
    for release in a.keep_release:
        need(re.fullmatch(r"[A-Za-z0-9_\-]+", release), f"Invalid release: {release}")
    historical = [config(path) for path in a.inventory_config]
    versions = [cfg["inventory_version"], *(doc["inventory_version"] for doc in historical)]
    need(len(versions) == len(set(versions)), "Duplicate inventory versions supplied")
    report = {}
    groups, drops, staging = plan(cfg, a.keep_release, historical, report)
    summary = {"pointer_groups": groups, "candidate_tables_to_drop": drops,
               "staging_paths_to_delete": staging if a.delete_staging else [],
               "not_yet_eligible": len(report["waiting_for_retention_window"])}
    if not a.execute:
        print(json.dumps({"dry_run": True, **summary}, indent=2))
        return
    job_id = cfg.get("retention_job_id", 0)
    need(type(job_id) is int and job_id > 0, "retention_job_id is not configured")
    result = notebook_job(cfg, job_id, {"groups": groups, "drop_tables": drops,
                                        "control_catalog": cfg["control_catalog"],
                                        "control_schema": cfg["control_schema"]}, "retention")
    dropped = {(d["run_id"], d["mapping_id"], d["attempt"]) for d in result.get("dropped", [])}
    with db("BRIDGE_CONTROL_ODBC") as control:
        cur = control.cursor()
        for run_id, mid, attempt in dropped:
            cur.execute("UPDATE bridge.object_attempts SET retired_utc=SYSUTCDATETIME() WHERE bridge_run_id=? "
                        "AND mapping_id=? AND attempt=? AND retired_utc IS NULL", run_id, mid, attempt)
        control.commit()
    deleted = []
    if a.delete_staging:
        deleted = delete_staging(cfg, staging)
        with db("BRIDGE_CONTROL_ODBC") as control:
            cur = control.cursor()
            for item in deleted:
                cur.execute("UPDATE bridge.object_attempts SET staging_deleted_utc=SYSUTCDATETIME() "
                            "WHERE bridge_run_id=? AND mapping_id=? AND attempt=?",
                            item["run_id"], item["mapping_id"], item["attempt"])
            control.commit()
    print(json.dumps({"snapshot_rows_deleted": result.get("deleted", {}), "candidate_tables_dropped": len(dropped),
                      "skipped": result.get("skipped", []), "staging_paths_deleted": len(deleted)}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as exc:
        print(f"ERROR {exc}", file=sys.stderr)
        raise
