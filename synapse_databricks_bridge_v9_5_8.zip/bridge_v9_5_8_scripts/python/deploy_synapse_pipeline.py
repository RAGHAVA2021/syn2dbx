"""Step 2b, optional: deploy the reviewed Synapse datasets and Copy pipeline.

Linked services must already exist in the Azure Synapse workspace.

Synapse artifact create/update can complete asynchronously (202 Accepted). Each
artifact is confirmed before the next one is deployed, so the pipeline is never
created while a dataset it references is still being provisioned, and the script
never reports success for a deployment that has not finished.
"""
import argparse
import json
import time
from pathlib import Path

API_VERSION = "2020-12-01"
DEPLOY_TIMEOUT_SECONDS = 600
POLL_SECONDS = 5
NOT_FOUND = "<artifact did not exist>"      # previous_etag marker: any read-back proves the new one


def _retry_after(response, default):
    try:
        return max(1, int(response.headers.get("Retry-After", default)))
    except (TypeError, ValueError):
        return default


def contains(actual, expected):
    """True when every value submitted in `expected` is present, unchanged, in `actual`.

    Synapse may add defaults to a stored definition, so extra keys in `actual` are allowed.
    """
    if isinstance(expected, dict):
        return isinstance(actual, dict) and all(k in actual and contains(actual[k], v) for k, v in expected.items())
    if isinstance(expected, list):
        return (isinstance(actual, list) and len(actual) == len(expected)
                and all(contains(a, e) for a, e in zip(actual, expected)))
    return actual == expected


def current_etag(session, headers, url):
    """The etag of the artifact before it is replaced; NOT_FOUND when it does not exist yet."""
    response = session.get(url, headers=headers, timeout=60)
    if response.status_code == 404:
        return NOT_FOUND
    response.raise_for_status()
    body = response.json()
    return body.get("etag") if isinstance(body, dict) else None


def is_deployed(body, submitted, previous_etag):
    """The read-back shows the new definition, not the one it replaced."""
    if not isinstance(body, dict):
        return False
    if previous_etag == NOT_FOUND:
        return True
    if submitted is not None and contains(body.get("properties"), submitted):
        return True
    return previous_etag is not None and body.get("etag") not in (None, previous_etag)


def wait_for_artifact(session, headers, url, put_response, submitted=None, previous_etag=None,
                      timeout=DEPLOY_TIMEOUT_SECONDS, poll=POLL_SECONDS, sleep=time.sleep, clock=time.monotonic):
    """Return once the artifact PUT has finished and the NEW definition can be read back.

    `submitted` is the properties object that was PUT and `previous_etag` the artifact's etag
    before the PUT (NOT_FOUND if it did not exist). An update can otherwise be "confirmed" by reading
    back the old definition while the change is still being applied.
    Raises RuntimeError if the operation fails or does not finish within `timeout`.
    """
    put_response.raise_for_status()
    deadline = clock() + timeout
    response = put_response
    operation = response.headers.get("Location") if response.status_code == 202 else None
    if response.status_code == 202 and not operation:
        raise RuntimeError(f"Synapse accepted {url} asynchronously but returned no Location to monitor")
    while operation:
        if clock() > deadline:
            raise RuntimeError(f"Timed out waiting for Synapse operation {operation}")
        sleep(_retry_after(response, poll))
        response = session.get(operation, headers=headers, timeout=60)
        if response.status_code == 202:
            continue
        response.raise_for_status()
        try:
            body = response.json() if response.content else {}
        except ValueError:
            body = {}                      # a non-JSON completion body carries no failure status
        state = str(body.get("status", "")).lower() if isinstance(body, dict) else ""
        if state in ("failed", "canceled", "cancelled"):
            raise RuntimeError(f"Synapse operation {operation} ended {body.get('status')}: {body.get('error')}")
        if state in ("", "succeeded"):
            break
    # Read the artifact back: this is the confirmation that it exists and is usable.
    while True:
        check = session.get(url, headers=headers, timeout=60)
        if check.status_code == 200:
            body = check.json()
            if submitted is None and previous_etag is None:
                return body                    # caller supplied nothing to compare against
            if is_deployed(body, submitted, previous_etag):
                return body
        elif check.status_code not in (202, 404):
            raise RuntimeError(f"Synapse artifact {url} is not available (HTTP {check.status_code})")
        if clock() > deadline:
            raise RuntimeError(f"Synapse artifact {url} does not show the deployed definition "
                               f"(last HTTP {check.status_code})")
        sleep(poll)


def main():
    import requests
    from azure.identity import DefaultAzureCredential
    p = argparse.ArgumentParser()
    p.add_argument("--config", required=True)
    p.add_argument("--synapse-linked-service", required=True)
    p.add_argument("--adls-linked-service", required=True)
    p.add_argument("--container", required=True)
    p.add_argument("--source-dummy-table", required=True,
                   help="Existing Synapse table referenced by the source dataset; the query overrides it")
    p.add_argument("--source-dummy-schema", required=True,
                   help="Schema containing --source-dummy-table")
    a = p.parse_args()
    d = json.loads(Path(a.config).read_text())
    cfg = d["synapse_pipeline"]
    root = Path(__file__).resolve().parents[1] / "synapse_pipeline"
    source = json.loads((root / "bridge_synapse_source.dataset.json").read_text())
    sink = json.loads((root / "bridge_parquet_sink.dataset.json").read_text())
    pipeline = json.loads((root / "bridge_copy_to_parquet.pipeline.json").read_text())
    source["properties"]["linkedServiceName"]["referenceName"] = a.synapse_linked_service
    source["properties"]["typeProperties"]["schema"] = a.source_dummy_schema
    source["properties"]["typeProperties"]["table"] = a.source_dummy_table
    sink["properties"]["linkedServiceName"]["referenceName"] = a.adls_linked_service
    sink["properties"]["typeProperties"]["location"]["fileSystem"] = a.container
    pipeline["name"] = cfg["copy_pipeline"]
    endpoint = (cfg.get("endpoint") or f"https://{cfg['workspace_name']}.dev.azuresynapse.net").rstrip("/")
    token = DefaultAzureCredential().get_token("https://dev.azuresynapse.net/.default").token
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    session = requests.Session()
    # Datasets first, each confirmed, then the pipeline that references them.
    for kind, item in (("datasets", source), ("datasets", sink), ("pipelines", pipeline)):
        url = f"{endpoint}/{kind}/{item['name']}?api-version={API_VERSION}"
        previous = current_etag(session, headers, url)
        resp = session.put(url, headers=headers, json={"properties": item["properties"]}, timeout=60)
        wait_for_artifact(session, headers, url, resp, submitted=item["properties"], previous_etag=previous)
        print(kind, item["name"], "deployed")


if __name__ == "__main__":
    main()
