# Implementation status against the v9 design (package v9.5.8)

This is an execution reference, not a claim that every command in v9 has been implemented. The actual environment and mapping inventory were not supplied. No Synapse, ADLS, Synapse pipeline, Azure SQL or Databricks connection was available for an integration run.

| v9 concern | Package status |
|---|---|
| Source-generation fence | SQL state machine, CLI hooks, post-extraction re-check, guarded release and `abandon`/`reopen` recovery supplied; writer inventory, bypass permission removal and detector streams still required |
| Upstream audit | Script counts each configured presentation view and checks ordered metadata hash; integrate after actual transformation completion |
| Large inventory discovery | Generator reads all tables or views in one Synapse schema and derives supported ordered columns, types and hashes; unsupported types or names stop generation and require reviewed exceptions |
| Source-table profiling | Databricks classic-cluster PySpark JDBC notebook or control-host ODBC script; dedicated-pool DMV rows/bytes plus separate physical and mapped column counts; subset views are supported, but joined/calculated views still need separate workload measurement |
| CETAS | Controlled column projection, unique path, metadata cleanup and bounded extraction concurrency; platform test required |
| Copy Activity | Synapse dataset/pipeline and API runner; configure linked services, network, type and null behaviour, and verify route-specific capacity |
| ADLS | Fresh-path check, UC read, hash-checked job manifests and exact-path retention (`retire_releases.py --delete-staging`) with the design's 7/30-day windows; path quarantine, legal/incident holds (other than `--keep-release`) and a stored per-attempt eligibility/disposition record not implemented |
| Schema and temporal contracts | Column name/order/type checks and basic casts; application-specific TIME, timezone, ancient-date, nested, LOB and text compatibility profiles not implemented |
| Delta writes | Idempotent transaction pair and candidate/slice count; explicitly verify API support and retained transaction horizon on selected runtime |
| Independent publication | Separate publication Job, one table per REPLACE_TABLE group, per-target publication claim across runs, explicit string property contract; policy/consumer readiness must be produced and checked by independently built tests |
| Group pointer | Rejects optional member; validates enabled slices and conditional pointer update; generated consumer views assume physical-table policies |
| Empty result | Rejected until an auditable zero-row release manifest and empty-Parquet handling are implemented |
| Rollback and cleanup | Immutable attempt metadata lets retention cover failed-load candidates and mappings removed from later inventory waves; previous release is kept; rollback itself remains manual |
| Recovery and audit | External IDs/correlation tokens are persisted before polling; indeterminate work blocks release/resume; mutating publisher IDs survive read-only inspection; `recovery.py` records evidence-gated attempt/publication recovery. Configure an actual Databricks Job timeout because a stopped control host cannot cancel; source audit detectors are still required |
| Throughput/SLO | Extracts have aggregate and class caps; Databricks loads and publications across disjoint groups have bounded parallel caps. Configure the corresponding Jobs' concurrent-run limits and benchmark representative full-volume objects and the full estate |

The fail-closed omissions above are deliberate: a placeholder claiming that a policy check or source-violation detector passed would create a false production assurance. Supply actual mapping metadata and environment details before completing those controls. Never treat an evidence JSON file containing manually entered `true` values as proof.

## v9.5.1 verification fixes

The packaged implementation additionally enforces generation-level unresolved-source guards on both `abandon` and `reopen`, excludes attempts with `RUNNING`/`UNKNOWN` source or loader operations from retirement, bounds generated control identifiers to SQL column sizes, scopes abandonment consistently to unpublished runs, validates schema/contract/Spark-type fields at configuration load, and documents recovery evidence formats. The concurrent publisher recovery regression test is target-scoped so it does not depend on completion order of independent publication groups.

## v9.5.2 fixes

Never-submitted (`PENDING`) attempts no longer block `abandon`/`reopen`, so an expired generation cannot be trapped; the guard locks the attempt rows it checks. `recovery.py resolve-attempt` can record terminal evidence for legacy `ABANDONED_GENERATION` attempts. `tests/test_v952_regressions.py` exercises `fence.py`, `recovery.py` and retention through their entry points, emulating the fence stored procedure on SQLite; the row-lock behaviour itself still needs a platform test on Azure SQL.

## v9.5.3 Synapse pipeline correction

The optional `COPY_ACTIVITY` route is now Synapse-native. It calls the workspace development endpoint (`https://<workspace>.dev.azuresynapse.net`) using the Synapse `2020-12-01` data-plane API for pipeline submission, monitoring, activity metrics and cancellation. The source correlation token is also supplied to the pipeline as a parameter to support deterministic lost-acknowledgement recovery.

## v9.5.5 review fixes

`recovery.py resolve-attempt` now requires the evidence phase to be the operation that is actually unresolved. `RELEASE_POINTER` mappings can no longer share a `_snapshots` table, and generated pointer views filter on `mapping_object_id`. `fence.py abandon`/`reopen` are scoped to the source set through the new `bridge.runs.source_set_id` column (legacy rows without it stay in scope). `deploy_synapse_pipeline.py` waits for asynchronous Synapse artifact operations. Smaller fixes: lazy profile fallback, a recorded `SUCCEEDED` source state is preserved on ordinary failures (an indeterminate stop still records `UNKNOWN`), rejected loader results are recorded, and resuming a legacy run backfills its source set. Pre-v9.4 `INDETERMINATE` rows without operation states remain recoverable. `tests/test_v955_regressions.py` covers each change. Existing pointer views must be replaced through a governed view change to pick up the new filter; see README.md.

## v9.5.6 review fixes

`fence.py abandon` only modifies runs recorded against its source set; the upgrade backfills legacy runs from `bridge.fence_events`, and any still unattributed must be confirmed with `--claim-legacy-runs` (the unresolved-read guard still covers them). A rejected loader result becomes `FAILED`/`REJECTED`: REPLACE_TABLE retries as a new attempt under `max_attempts`, RELEASE_POINTER stops for review. `deploy_synapse_pipeline.py` confirms the new definition (etag or properties), not merely an existing artifact. Consumer targets, snapshot tables and the control table share one name space. An interrupt before any source submission is a retryable `FAILED`/`NOT_STARTED` attempt. Legacy recovery with a stored loader run requires LOADER evidence. `source_set_id` is validated at load. `tests/test_v956_regressions.py` covers each change; Synapse's actual etag/async behaviour still needs a platform test.

## v9.5.7 documentation verification fixes

The dedicated-pool credential now uses `IDENTITY = 'Managed Service Identity'` (existing deployments `ALTER` the credential; see README.md). `COPY_ACTIVITY` mappings may no longer declare a `date` physical type, because Synapse Copy writes SQL `date` as Parquet INT96; `generate_mappings.for_copy_activity()` produces the timestamp contract and the loader narrows to `date` only when every value is midnight UTC. `DESIGN_v9.md` §4 lists database-scoped CETAS grants for a contained user. The loader Job must also have serverless auto-optimization disabled. `tests/test_v957_regressions.py` covers each change; the midnight check and the credential change still need a platform test.

## v9.5.8 review fixes

`published_groups` has deletion vectors (row-level concurrency) and the pointer update retries only rejected Delta conflicts, so disjoint pointer groups can publish in parallel. `--business-date` must match the upstream audit. The loader always runs in UTC. Publication requires the recorded fence release (checked when a READY run starts publishing; the orchestration identity needs `SELECT` on `bridge.fence_events`). Recovery maps a stored Databricks `token:...` to the actual run ID. Retention applies the 7/30-day windows (`retention_days_published`, `retention_days_unpublished`) and retires FAILED/SUPERSEDED attempts of kept releases. No control schema change; rerun the generated Unity Catalog setup SQL once. `tests/test_v958_regressions.py` covers each change; row-level concurrency and the conflict-exception names still need a platform test.
