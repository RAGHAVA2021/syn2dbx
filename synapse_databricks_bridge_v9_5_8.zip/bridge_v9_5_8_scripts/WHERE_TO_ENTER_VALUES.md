# Entering sources, storage and Databricks tables (serverless)

For a small set, start with `cp config.example.json config.json` and edit it. For hundreds or thousands of source objects, run the generator below instead. Each entry in `mappings` is one Synapse source object and one Databricks consumer object. The legacy field name `source_view` also accepts a directly selected Synapse table; the extractor selects from `[source_schema].[source_view]`.

| Your value | Where to enter it | Example |
|---|---|---|
| Synapse source table or view | `mappings[].source_schema`, `mappings[].source_view` | `presentation`, `v_orders` |
| A stable identifier for that mapping | `mappings[].mapping_id` | `MAP_ORDERS` |
| Columns and types, in source order | `mappings[].columns[]` and `source_schema_version` | `order_id` → `order_id`, `bigint` → `bigint` |
| Extraction route | `mappings[].method` | `CETAS` (no Synapse pipeline); `COPY_ACTIVITY` uses optional Synapse pipeline in this reference package |
| ADLS account and container | `staging_abfss_root` at config top level **and** `LOCATION` in `sql/02_synapse_setup.sql` | `abfss://landing@storageacct.dfs.core.windows.net` |
| Databricks consumer name | `mappings[].target_catalog`, `target_schema`, `target_table` | `analytics.gold.orders` |
| Serverless notebook Job IDs | `loader_job_id`, `publisher_job_id`, `pointer_job_id`, `retention_job_id` at config top level | Numeric IDs returned by Databricks Jobs |
| Materialised table behind a view (profiling only) | `mappings[].materialised_schema`, `materialised_table` (both or neither) | `materialised`, `orders` |
| Retry and takeover | `max_attempts` (1–9), `takeover_after_minutes` (135–1440), `heartbeat_seconds` (10–600) | `3`, `150`, `60` |
| Staging/candidate retention windows (optional) | `retention_days_published` (0–3650, default 7), `retention_days_unpublished` (0–3650, default 30) | `7`, `30` |

For example, add a mapping to `mappings` (retaining the required retention properties shown in the example):

```json
{
  "mapping_id": "MAP_ORDERS",
  "group_id": "independent_orders",
  "strategy": "REPLACE_TABLE",
  "mandatory": false,
  "method": "CETAS",
  "source_schema": "presentation",
  "source_view": "v_orders",
  "materialised_schema": "materialised",
  "materialised_table": "orders",
  "source_schema_version": "<computed-by-source_metadata.py>",
  "group_contract_version": "independent_v1",
  "target_catalog": "analytics",
  "target_schema": "gold",
  "target_table": "orders",
  "candidate_schema": "bridge_candidate",
  "physical_schema": "bridge_physical",
  "allow_empty": false,
  "consumer_properties": {
    "delta.deletedFileRetentionDuration": "interval 30 days",
    "delta.logRetentionDuration": "interval 30 days",
    "delta.setTransactionRetentionDuration": "interval 30 days"
  },
  "columns": [
    {"source": "order_id", "target": "order_id", "conversion": "DIRECT", "source_spark_type": "bigint", "target_type": "bigint"}
  ]
}
```

Run `python python/source_metadata.py --schema presentation --view v_orders` using the configured source connection, then copy its hash into `source_schema_version`. Use the exact ordered source projection and verified Parquet Spark types in `columns`; do not infer types from the example. Add one mapping per source object. `mapping_id` is stable across runs and must be unique. A `REPLACE_TABLE` mapping must have its own `group_id`; tables that must change together belong in a `RELEASE_POINTER` group. Delta property values must be strings exactly as `SHOW TBLPROPERTIES` reports them (for example `"true"`, not `true`). Configure upstream audit records for each mapping as described in `README.md`.

## Generate mappings for 1,000 tables

If Databricks already connects to Synapse, import `databricks/generate_mappings_pyspark.py` as a notebook and run it **once** on your Databricks classic cluster, or on serverless if your Unity Catalog JDBC connection is supported there. Upload the extracted `bridge_v9_5_8_scripts` folder as Workspace files. In the notebook, set `PACKAGE_DIR`, the Synapse `SOURCE_SCHEMA` and `SOURCE_KIND`, `TARGET_CATALOG`, `TARGET_SCHEMA`, `INVENTORY_VERSION`, and `OUTPUT` (an existing writable Unity Catalog volume). Choose an existing `UC_JDBC_CONNECTION` pointing to the dedicated pool, or set `JDBC_URL` and the names of Databricks secret keys for the source read-only account. The notebook queries only Synapse catalog metadata using PySpark JDBC and writes the generated JSON plus an exceptions report to the volume. It requires the metadata identity to see source object definitions; check that the SQL Server JDBC driver is available for direct JDBC mode. After download/review, the generated config is supplied to the v9 control-host runner. The rest of the v9 bridge scripts still run on their documented control host; this notebook replaces only one-time mapping discovery.

If using a separate orchestration host with ODBC instead, use the CLI below:

On the orchestration host, supply `BRIDGE_SYNAPSE_AUDIT_ODBC` and run from the package directory:

```bash
python python/generate_mappings.py --schema presentation --source-kind table \
  --target-catalog analytics --target-schema gold \
  --inventory-version wave_001_v1 --output config.generated.json
```

For simplified views, use `--source-kind view --view-prefix v_`; that selects names beginning with `v_` and strips the prefix from the generated target table name. This reads `sys.tables` or `sys.views` plus ordered `sys.columns`. It generates **all** columns, source schema hashes, one-to-one names, CETAS routes, and independent `REPLACE_TABLE` mappings. Review `config.generated.json` and rename it to `config.json`; fill the staging root, catalog for control tables and the three serverless Job IDs. It will not overwrite an existing config. The accompanying `config.generated.exceptions.json` records unsupported objects.

The generator intentionally stops without writing a config if any selected column needs a reviewed type conversion. Its automatic type set is `varchar`/`nvarchar`/`char`/`nchar` (bounded length), `int`, `bigint`, `date`, and `decimal`/`numeric`; it does not silently drop other columns. Synapse's documented CETAS restrictions include LOBs above 1 MB and content characters that can cause Parquet export failures. Review temporal types, GUIDs, money, binaries, tinyint, floating point, text MAX, masks and policy rules individually. An explicit exception mapping or extraction route can then be added to a **new, versioned** inventory. A schema hash pins the approved source shape, and the Databricks loader checks the actual Parquet names and types; a changed source schema must be reviewed and regenerated instead of silently altering a published table.

## Profile the source tables and plan concurrency

**Recommended for your manually created Databricks cluster:** import `databricks/profile_inventory_pyspark.py` as a notebook. Use a Unity Catalog-enabled classic cluster with network access to the Synapse dedicated SQL pool. Ensure the SQL Server JDBC driver is available on the cluster. Give the notebook identity `READ VOLUME` and `WRITE VOLUME` on the existing configuration volume, and give its read-only Synapse identity visibility into `sys.tables`, `sys.columns`, distribution metadata, and the dedicated-pool partition statistics DMV. Set `INPUT_CONFIG`, `OUTPUT_CONFIG`, `NEW_INVENTORY_VERSION`, `JDBC_URL`, and the secret scope/key names in the first cell. The source config, for example `/Volumes/analytics/bridge_config/files/config.generated.json`, must already have its environment placeholders and mapping columns reviewed. Run the notebook manually for each new profile version. It uses `spark.read.format("jdbc")` to fetch only catalog and DMV rows and PySpark to aggregate physical rows and used pages across Synapse distributions; it does not read the data of the 1,000 tables.

The notebook writes `config.profiled.json` plus `config.profiled.profile.csv` to the chosen existing volume folder, and displays the full profile DataFrame. Download or transfer the approved JSON to the bridge control host before seeding and running the existing orchestration scripts. Profiling on the manually created classic cluster does **not** move the nightly serverless managed-table loading Job onto that cluster.

Alternatively, on the orchestration host with `BRIDGE_SYNAPSE_AUDIT_ODBC`, first fill the generated config's environment placeholders and review the mappings. Then run:

```bash
python python/profile_inventory.py --config config.generated.json \
  --inventory-version wave_001_v2 --output config.profiled.json
```

Review `config.profiled.profile.csv`. It gives each source table's estimated row count, `physical_column_count`, `mapped_column_count`, physical used GiB, distribution policy and size class. It does not scan the data. A subset view is allowed to have fewer mapped columns than its materialised table; joined or calculated views still need a separately reviewed workload estimate. Stored physical size is affected by compression, indexes and replication and is **not** predicted Parquet size. The profile creates a new immutable inventory version that must be reviewed and seeded before use.

`profile_thresholds` in the example config determines SMALL/MEDIUM/LARGE by rows, bytes **or** column count. The sample values are starting points for testing. `max_extraction_workers` limits all extracts together and `extraction_class_limits` limits concurrent extracts per class. `max_loader_workers` controls simultaneous serverless load jobs; `max_publisher_workers` controls publication across distinct groups. Configure each Job's Maximum concurrent runs accordingly; Databricks defaults new jobs to one. Raise limits gradually based on Synapse queueing, ADLS and serverless results. The nightly audited row count and three-way reconciliation continue to determine publication readiness, not the earlier profile estimate.

If every mapping uses `CETAS`, the sample top-level `synapse_pipeline` section is unused and can be removed. The optional `COPY_ACTIVITY` route in this version calls the Azure Synapse workspace pipeline directly.

## Staging in ADLS Gen2

The staging root in `config.json` must be the **container root**, without a trailing subdirectory. The same URI goes in the Synapse `bridge_stage` external data source in `sql/02_synapse_setup.sql`. The runner creates an attempt-specific folder under that root, for example:

```text
abfss://landing@storageacct.dfs.core.windows.net/bridge/parquet-stage/2026-09-22/BRG_20260922_01/MAP_ORDERS/attempt-001/
```

`BRG_20260922_01` is the `--bridge-run-id`: letters, digits, `_` and `-`, at most 124 characters, because the release ID `rel_<run>` must fit a 128-character column. A resumed run uses `attempt-002`, `attempt-003`, … up to `max_attempts`. Job payloads are written as immutable manifests to `bridge/parquet-stage/_manifests/<run>/<uuid>.json`; the orchestration identity needs create (not overwrite) access there.

Do not enter this generated leaf path into the config. Grant the Synapse workspace managed identity write access to the staging container and the orchestration identity read/list access to check that each attempt folder is empty. Register the staging container or a parent of the generated attempt paths as a **Unity Catalog external location** for Databricks. First create a UC storage credential backed by an Azure Databricks Access Connector managed identity with ADLS read access. Then, on a Databricks SQL warehouse, use the exact credential name created in Catalog Explorer:

```sql
CREATE EXTERNAL LOCATION bridge_parquet_stage
  URL 'abfss://landing@storageacct.dfs.core.windows.net/bridge/parquet-stage'
  WITH (STORAGE CREDENTIAL bridge_staging_credential);
GRANT READ FILES ON EXTERNAL LOCATION bridge_parquet_stage TO `bridge-loader-principal`;
-- Every job reads its manifest from this location:
GRANT READ FILES ON EXTERNAL LOCATION bridge_parquet_stage TO `bridge-publisher-principal`;
GRANT READ FILES ON EXTERNAL LOCATION bridge_parquet_stage TO `bridge-pointer-principal`;
GRANT READ FILES ON EXTERNAL LOCATION bridge_parquet_stage TO `bridge-retention-principal`;
```

The Databricks SQL warehouse identity creating the external location needs its creation privileges; the loader Job runs as `bridge-loader-principal`. Validate an actual leaf-path read using that identity on serverless compute. Configure serverless network access to the storage account if its firewall limits access. Use the external location for file access; no SAS key or `spark.conf.set` storage credential is passed to the notebook.

## Databricks destination and compute

The loader creates a **Unity Catalog managed Delta table** on first run without an explicit table storage path. Configure the catalog/schema managed storage separately in Unity Catalog if your organization requires a specific ADLS account. Keep that managed storage separate from the Parquet staging prefix. This package has no setting for a per-table external Delta `LOCATION`.

- `REPLACE_TABLE`: loader writes an attempt-specific candidate such as `analytics.bridge_candidate.candidate_MAP_ORDERS_<16-hex hash of mapping+run>_a1` (the orchestrator computes the name once and records it in `bridge.object_attempts.delta_target`); a separate publisher Job makes `analytics.gold.orders` visible after acceptance gates. The publisher must have the required `MANAGE` on the existing table and `CREATE TABLE` on its schema.
- `RELEASE_POINTER`: loader appends to `analytics.bridge_physical.orders_snapshots`, which the generated setup SQL pre-creates together with the stable `analytics.gold.orders` view. The pointer Job publishes a complete group.

Import `databricks/load_candidate.py` and `databricks/publish.py` as Databricks notebooks. Also import `databricks/retire_releases.py`. Create **four independent, single-task Notebook Jobs**: loader, Strategy A publisher, group-pointer publisher and retention. Select **Serverless** as the task's Compute, and set each Job's Run as service principal to the corresponding identity. Disable serverless auto-optimization on all four tasks (task **Retries** → **Retry Policy** → uncheck **Enable serverless auto-optimization**): publication and retention are at-most-once operations whose ambiguous outcomes require reconciliation, and a loader retry restarts the Job timeout, which the runner's takeover window does not cover. The runner creates its own new attempts. Configure the notebook parameters `manifest_path` and `manifest_sha256` with empty defaults (the runner supplies both on each invocation); put the resulting four numeric job IDs in `config.json`. The retention identity needs `MODIFY` on the `_snapshots` tables, ownership or `MANAGE` on candidate tables, and `SELECT` on the pointer control table and consumer tables. Do not put a cluster ID, VM size, storage secret, or source view name into the Databricks notebook. The same `publish.py` code supports both publisher Jobs, with separate job identities.

Set the loader Job's Maximum concurrent runs to at least `max_loader_workers`, and each publication Job's Maximum concurrent runs to at least `max_publisher_workers`; do not assume the Python thread limit changes the Job setting. Set an actual Databricks Job timeout of at most 7,200 seconds for these jobs. The control host also polls for two hours, but if that host stops it cannot submit cancellation, so the platform timeout is required defence in depth. Different target keys can publish concurrently. A failed publication can leave other groups visible; if a mutating publisher outcome is unknown, record matching terminal evidence with `recovery.py resolve-publication` before `publish_run.py --resume` reconciles the target. Validate the workspace's concurrent run quota and the identities' permissions using a representative multi-table test.

The notebooks use Unity Catalog identifiers and the staging external location. `load_candidate.py` uses reader options and the Delta writer `userMetadata` option supported on serverless; it does not set classic-only Spark session configurations. When a `COPY_ACTIVITY` mapping narrows a Parquet timestamp to a `date` target it sets the session time zone to UTC, which serverless supports. Prove the exact policy and publication DDL operations with these serverless identities before production use. Run the remaining setup and nightly commands in `README.md`; compute selection alone does not satisfy the outstanding production gates in `IMPLEMENTATION_STATUS.md`.
