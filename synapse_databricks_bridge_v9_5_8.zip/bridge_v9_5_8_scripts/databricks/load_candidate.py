# Databricks notebook source
"""Single-task loader Job (step 6 in SCRIPT_GUIDE.md), Run as the unprivileged loading principal.

Parameters: manifest_path, manifest_sha256 (the orchestrator writes the full
payload to the staging location; notebook parameters are too small for wide
tables). The job needs UC READ FILES on the staging external location.
Re-running the same attempt is idempotent; a slice already committed by a
different attempt is refused.
"""
import hashlib
import json
import re
from pyspark.sql import functions as F

NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
TOKEN = re.compile(r"[A-Za-z0-9_\-]+")
MANIFEST = re.compile(r"abfss://[^/]+/bridge/parquet-stage/_manifests/[A-Za-z0-9_\-]+/[0-9a-f]{32}\.json")

dbutils.widgets.text("manifest_path", "")
dbutils.widgets.text("manifest_sha256", "")

# Every timezone-sensitive step (timestamp casts, the timestamp-to-date narrowing check below) runs
# in UTC for every mapping, set before any DataFrame exists. Setting it only for mappings with a
# narrowed column made other conversions depend on which columns a mapping happened to contain.
spark.conf.set("spark.sql.session.timeZone", "UTC")  # session-level; supported on serverless


def read_manifest():
    path, expected = dbutils.widgets.get("manifest_path"), dbutils.widgets.get("manifest_sha256")
    if not MANIFEST.fullmatch(path) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError("Invalid manifest parameters")
    text = spark.read.option("wholetext", "true").text(path).first()[0]
    if hashlib.sha256(text.encode("utf-8")).hexdigest() != expected:
        raise ValueError("Manifest hash mismatch")
    return json.loads(text)


p = read_manifest()
for key in ("target_catalog", "target_schema", "target_table", "candidate_schema", "physical_schema"):
    assert NAME.fullmatch(p[key]), key
for key in ("mapping_id", "release_id", "bridge_run_id"):
    assert TOKEN.fullmatch(str(p[key])), key
attempt = int(p["attempt"])
assert attempt >= 1
assert p["leaf_path"].startswith("abfss://") and "/bridge/parquet-stage/" in p["leaf_path"]
assert p["leaf_path"].endswith(f"/attempt-{attempt:03d}/")


def q(s):
    if not NAME.fullmatch(s):
        raise ValueError("Unsafe identifier")
    return f"`{s}`"


def assert_count(actual, expected, what):
    if actual != expected:
        raise ValueError(f"{what}: expected {expected}, observed {actual}")


# Read only the exact immutable attempt path. A count can skip column decoding;
# the subsequent write of all projected fields is the all-column decode action.
raw = (spark.read.option("ignoreCorruptFiles", "false")
       .option("ignoreMissingFiles", "false").parquet(p["leaf_path"]))
names = [f.name for f in raw.schema.fields]
expected = [c["target"] for c in p["columns"]]
if names != expected or len({n.lower() for n in names}) != len(names):
    raise ValueError(f"Parquet columns/order differ: {names} != {expected}")
for field, contract in zip(raw.schema.fields, p["columns"]):
    if field.dataType.simpleString() != contract["source_spark_type"]:
        raise ValueError(f"Physical/logical type drift in {field.name}: {field.dataType}")
parquet_rows = raw.count()
assert_count(parquet_rows, int(p["source_rows"]), "Source-to-Parquet count")
if parquet_rows == 0 and not p["allow_empty"]:
    raise ValueError("Unapproved empty result")

metadata = {
    "release_id": p["release_id"], "mapping_object_id": p["mapping_id"],
    "source_generation_id": p["generation_id"], "bridge_run_id": p["bridge_run_id"],
    "upstream_run_id": p["upstream_run_id"], "upstream_sequence": str(p["upstream_sequence"]),
    "business_date": p["business_date"], "load_attempt": str(attempt),
    "group_contract_version": p.get("group_contract_version", "")
}

converted = raw.select(*[F.col(q(c["target"])).cast(c["target_type"]).alias(c["target"])
                         for c in p["columns"]])
# A non-null input becoming NULL is rejected even if the ambient ANSI setting differs.
bad = raw.select(*[
    F.sum(F.when(F.col(q(c["target"])).isNotNull() &
                 F.col(q(c["target"])).cast(c["target_type"]).isNull(), 1).otherwise(0)).alias(c["target"])
    for c in p["columns"]]).first()
if bad and any(x for x in bad):
    raise ValueError(f"Conversion lost non-null values: {bad}")
# Synapse Copy writes SQL date as Parquet INT96 (read as timestamp). Narrowing it back to date is
# accepted only when every value is exactly midnight UTC, so no time-of-day is silently dropped.
narrowed = [c for c in p["columns"]
            if c["source_spark_type"] == "timestamp" and c["target_type"].lower() == "date"]
if narrowed:
    # The session is already UTC (set at the top); the check relies on that.
    partial = raw.select(*[
        F.sum(F.when(F.col(q(c["target"])).isNotNull() &
                     (F.col(q(c["target"])).cast("date").cast("timestamp") != F.col(q(c["target"]))), 1)
              .otherwise(0)).alias(c["target"]) for c in narrowed]).first()
    if partial and any(x for x in partial):
        raise ValueError(f"Timestamp-to-date narrowing would drop a time of day: {partial}")
for k, v in metadata.items():
    converted = converted.withColumn(k, F.lit(v))

if p["strategy"] == "REPLACE_TABLE":
    # Name is computed once by the orchestrator (collision-free, attempt-specific).
    table_name = p["candidate_table"]
    schema_name = p["candidate_schema"]
else:
    table_name = p["target_table"] + "_snapshots"
    schema_name = p["physical_schema"]
target = f"{q(p['target_catalog'])}.{q(schema_name)}.{q(table_name)}"
target_raw = f"{p['target_catalog']}.{schema_name}.{table_name}"

columns_sql = ", ".join(f"{q(c['target'])} {c['target_type'].upper()}" for c in p["columns"])
metadata_sql = ", ".join(f"{q(k)} STRING" for k in metadata)
props = p["consumer_properties"] if p["strategy"] == "REPLACE_TABLE" else p["physical_properties"]
if any(not re.fullmatch(r"[A-Za-z][A-Za-z0-9._]*", k) or not isinstance(v, str) or "'" in v
       for k, v in props.items()):
    raise ValueError("Unsafe property contract")
properties = ", ".join(f"'{k}'='{v}'" for k, v in sorted(props.items()))
spark.sql(f"CREATE TABLE IF NOT EXISTS {target} ({columns_sql}, {metadata_sql}) USING DELTA "
          f"TBLPROPERTIES ({properties})")

where = (f"release_id = '{p['release_id']}' AND mapping_object_id = '{p['mapping_id']}' "
         f"AND bridge_run_id = '{p['bridge_run_id']}'")
existing = spark.sql(f"SELECT load_attempt, count(*) AS n FROM {target} WHERE {where} "
                     f"GROUP BY load_attempt").collect()
if existing:
    # Idempotent re-run of this attempt; a slice from another attempt must never be mixed in.
    if len(existing) != 1 or existing[0].load_attempt != str(attempt):
        raise ValueError(f"Slice already committed by attempt(s) {[r.load_attempt for r in existing]}")
    assert_count(existing[0].n, parquet_rows, "Previously committed slice")
else:
    app_id = f"bridge:{p['mapping_id']}:{p['release_id']}:a{attempt}"
    version = int(p["delta_write_sequence"])
    if version < 0:
        raise ValueError("Negative Delta transaction version")
    (converted.write.format("delta").mode("append")
        .option("txnAppId", app_id).option("txnVersion", version)
        .option("userMetadata", json.dumps(metadata, sort_keys=True)).saveAsTable(target))

delta_rows = spark.sql(f"SELECT count(*) AS n FROM {target} WHERE {where}").first().n
assert_count(delta_rows, parquet_rows, "Parquet-to-Delta count")
attempts = spark.sql(f"SELECT count(DISTINCT load_attempt) AS n FROM {target} WHERE {where}").first().n
assert_count(attempts, 1 if delta_rows else 0, "Mixed load attempts")
result = {"source_rows": int(p["source_rows"]), "parquet_rows": parquet_rows,
          "delta_rows": delta_rows, "target": target_raw, "release_id": p["release_id"]}
dbutils.notebook.exit(json.dumps(result))
