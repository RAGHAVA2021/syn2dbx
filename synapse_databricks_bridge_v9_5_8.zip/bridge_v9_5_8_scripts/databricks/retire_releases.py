# Databricks notebook source
"""Retention Job (step 9 in SCRIPT_GUIDE.md), Run as the retention principal.

Needs MODIFY on the *_snapshots tables, ownership/MANAGE on candidate tables and
SELECT on published_groups and consumer tables. Parameters: manifest_path,
manifest_sha256 (written by python/retire_releases.py --execute).
Delta state is re-read here and always wins: the currently published and previous
releases are never deleted even if the Azure SQL plan was stale.
"""
import hashlib
import json
import re

NAME = re.compile(r"[A-Za-z_][A-Za-z0-9_]*")
TOKEN = re.compile(r"[A-Za-z0-9_\-]+")
MANIFEST = re.compile(r"abfss://[^/]+/bridge/parquet-stage/_manifests/[A-Za-z0-9_\-]+/[0-9a-f]{32}\.json")

dbutils.widgets.text("manifest_path", "")
dbutils.widgets.text("manifest_sha256", "")


def read_manifest():
    path, expected = dbutils.widgets.get("manifest_path"), dbutils.widgets.get("manifest_sha256")
    if not MANIFEST.fullmatch(path) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError("Invalid manifest parameters")
    text = spark.read.option("wholetext", "true").text(path).first()[0]
    if hashlib.sha256(text.encode("utf-8")).hexdigest() != expected:
        raise ValueError("Manifest hash mismatch")
    return json.loads(text)


def q(s):
    if not isinstance(s, str) or not NAME.fullmatch(s):
        raise ValueError("Unsafe identifier")
    return f"`{s}`"


def lit(s):
    if not TOKEN.fullmatch(str(s)):
        raise ValueError("Unsafe literal")
    return f"'{s}'"


p = read_manifest()
control = f"{q(p['control_catalog'])}.{q(p['control_schema'])}.`published_groups`"
deleted, dropped, skipped = {}, [], []

for g in p["groups"]:
    rows = spark.sql(f"SELECT published_release_id, previous_release_id, high_water_sequence "
                     f"FROM {control} WHERE group_id = {lit(g['group_id'])}").collect()
    if len(rows) != 1 or rows[0].published_release_id in (None, "NONE"):
        skipped.append({"group": g["group_id"], "reason": "not published yet"})
        continue
    live = rows[0]
    keep = set(g["keep"]) | {live.published_release_id, live.previous_release_id}
    keep = sorted(x for x in keep if x and x != "NONE")
    high_water = min(int(g["high_water"]), int(live.high_water_sequence))
    for t in g["tables"]:
        name = f"{q(t['catalog'])}.{q(t['schema'])}.{q(t['table'])}"
        raw = f"{t['catalog']}.{t['schema']}.{t['table']}"
        if not spark.catalog.tableExists(raw):
            continue
        # Newer, not-yet-published releases (sequence above high-water) are kept.
        result = spark.sql(f"DELETE FROM {name} WHERE release_id NOT IN ({', '.join(lit(k) for k in keep)}) "
                           f"AND CAST(upstream_sequence AS BIGINT) <= {high_water}").collect()
        deleted[raw] = int(result[0][0]) if result and len(result[0]) else None

for d in p["drop_tables"]:
    if not d["table"].startswith("candidate_"):
        raise ValueError(f"Refusing to drop a non-candidate table: {d['table']}")
    target_raw = f"{d['target']['catalog']}.{d['target']['schema']}.{d['target']['table']}"
    if spark.catalog.tableExists(target_raw):
        target = ".".join(q(d["target"][k]) for k in ("catalog", "schema", "table"))
        columns = [c.lower() for c in spark.table(target).columns]
        if "release_id" in columns:
            # A failed or superseded attempt of the live release is not what consumers read: compare
            # the attempt too when the consumer table carries it (every bridge-published table does).
            with_attempt = "load_attempt" in columns
            fields = "release_id, load_attempt" if with_attempt else "release_id"
            live = spark.sql(f"SELECT DISTINCT {fields} FROM {target} LIMIT 5").collect()
            if any(r.release_id == d["release_id"] and
                   (not with_attempt or r.load_attempt == str(d["attempt"])) for r in live):
                skipped.append({"table": d["table"], "reason": "release is live in consumer table"})
                continue
    spark.sql(f"DROP TABLE IF EXISTS {q(d['catalog'])}.{q(d['schema'])}.{q(d['table'])}")
    dropped.append({"run_id": d["run_id"], "mapping_id": d["mapping_id"], "attempt": d["attempt"]})

dbutils.notebook.exit(json.dumps({"deleted": deleted, "dropped": dropped, "skipped": skipped}))
