# Databricks notebook source
"""Single-task publication Job (step 8 in SCRIPT_GUIDE.md).

Deployed twice with separate Run-as identities: the Strategy A publisher
(REPLACE_TABLE) and the group-pointer publisher (RELEASE_POINTER, MODIFY on the
UC control table only). Parameters: manifest_path, manifest_sha256.
mode PUBLISH performs the change; mode INSPECT only reports current Delta state
so publish_run.py --resume can reconcile a commit whose Azure SQL update was lost.
"""
import hashlib
import json
import re

MANIFEST = re.compile(r"abfss://[^/]+/bridge/parquet-stage/_manifests/[A-Za-z0-9_\-]+/[0-9a-f]{32}\.json")

dbutils.widgets.text("manifest_path", "")
dbutils.widgets.text("manifest_sha256", "")


def read_manifest():
    path, expected = dbutils.widgets.get("manifest_path"), dbutils.widgets.get("manifest_sha256")
    if not MANIFEST.fullmatch(path) or not re.fullmatch(r"[0-9a-f]{64}", expected):
        raise ValueError("Invalid manifest parameters")
    text = spark.read.option("wholetext", "true").text(path).first()[0]
    if hashlib.sha256(text.encode("utf-8")).hexdigest() != expected:
        raise ValueError("Manifest hash mismatch")
    return json.loads(text)


p = read_manifest()
mode = p.get("mode")
if mode not in ("PUBLISH", "INSPECT"):
    raise ValueError("Unsupported mode")


def quote(s):
    if not isinstance(s, str) or not re.fullmatch(r"[A-Za-z_][A-Za-z0-9_]*", s):
        raise ValueError("Unsafe identifier")
    return f"`{s}`"


def literal(s):
    if not re.fullmatch(r"[A-Za-z0-9_\-]+", str(s)):
        raise ValueError("Unsafe release, group or run ID")
    return f"'{s}'"


def table(c, s, t):
    return f"{quote(c)}.{quote(s)}.{quote(t)}"


CONFLICT_MARKERS = ("ConcurrentAppendException", "ConcurrentDeleteReadException",
                    "ConcurrentDeleteDeleteException", "ConcurrentTransactionException",
                    "MetadataChangedException", "ProtocolChangedException",
                    "DELTA_CONCURRENT_", "ConcurrentModificationException")


def is_delta_conflict(exc):
    """A Delta optimistic-concurrency conflict: the transaction was rejected, nothing committed."""
    text = f"{type(exc).__name__}: {exc}"
    return any(marker in text for marker in CONFLICT_MARKERS)


def run_with_conflict_retry(sql, attempts=6, first_wait=2.0, sleep=None):
    """Run a conditional Delta statement, retrying only rejected (uncommitted) conflict attempts.

    Parallel pointer publications of different groups all update `published_groups`. A conflict
    means the commit was refused, and the statement's own WHERE clause re-checks the expected
    pointer state, so re-running it cannot publish twice or overwrite another group's row.
    """
    import time
    sleep = sleep or time.sleep
    wait = first_wait
    for attempt in range(1, attempts + 1):
        try:
            return spark.sql(sql)
        except Exception as exc:
            if not is_delta_conflict(exc) or attempt == attempts:
                raise
            sleep(wait)
            wait = min(wait * 2, 30.0)


def single(sql):
    result = spark.sql(sql).collect()
    if len(result) != 1:
        raise ValueError(f"Expected one row, found {len(result)}")
    return result[0]


expected = int(p["upstream_sequence"])
release = literal(p["release_id"])

if p["strategy"] == "REPLACE_TABLE":
    m = p["mapping"]
    target = table(m["target_catalog"], m["target_schema"], m["target_table"])
    if mode == "INSPECT":
        raw = f"{m['target_catalog']}.{m['target_schema']}.{m['target_table']}"
        if not spark.catalog.tableExists(raw):
            dbutils.notebook.exit(json.dumps({"exists": False, "release_ids": [], "rows": 0}))
        if "release_id" not in [c.lower() for c in spark.table(target).columns]:
            dbutils.notebook.exit(json.dumps({"exists": True, "release_ids": None, "rows": None}))
        found = spark.sql(f"SELECT release_id, count(*) n FROM {target} GROUP BY release_id LIMIT 10").collect()
        dbutils.notebook.exit(json.dumps({"exists": True, "release_ids": sorted(r.release_id for r in found),
                                          "rows": sum(r.n for r in found)}))
    candidate = table(m["target_catalog"], m["candidate_schema"], m["candidate_table"])
    where = (f"release_id = {release} AND mapping_object_id = {literal(m['mapping_id'])} "
             f"AND load_attempt = {literal(m['attempt'])}")
    count = single(f"SELECT count(*) n, count(DISTINCT source_generation_id) g FROM {candidate} WHERE {where}")
    if count.n != int(m["source_rows"]) or count.g != (1 if count.n else 0):
        raise ValueError("Candidate not ready or not from one generation")
    if count.n:
        observed = single(f"SELECT DISTINCT source_generation_id FROM {candidate} WHERE {where}")
        if observed[0] != m["generation_id"]:
            raise ValueError("Wrong source generation")
    # Policy readiness is a separate mandatory gate recorded before this job runs.
    # Properties are explicit and restated on every replacement.
    props = m["consumer_properties"]
    for required in ("delta.deletedFileRetentionDuration", "delta.logRetentionDuration",
                     "delta.setTransactionRetentionDuration"):
        if required not in props:
            raise ValueError("Missing governed retention property")

    def kv(k, v):
        if not re.fullmatch(r"[A-Za-z][A-Za-z0-9._]*", k) or not isinstance(v, str) or "'" in v:
            raise ValueError("Unsafe property")
        return f"'{k}'='{v}'"

    properties = ", ".join(kv(k, v) for k, v in sorted(props.items()))
    columns = ", ".join(quote(c["target"]) for c in m["columns"])
    metadata = ", ".join(quote(x) for x in ("release_id", "mapping_object_id", "source_generation_id",
                         "bridge_run_id", "upstream_run_id", "upstream_sequence", "business_date", "load_attempt",
                         "group_contract_version"))
    spark.sql(f"CREATE OR REPLACE TABLE {target} USING DELTA TBLPROPERTIES ({properties}) "
              f"AS SELECT {columns}, {metadata} FROM {candidate} WHERE {where}")
    post = single(f"SELECT count(*) n, min(release_id) a, max(release_id) b FROM {target}")
    if post.n != count.n or post.a != p["release_id"] or post.b != p["release_id"]:
        raise ValueError("Published table validation failed; freeze target and recover")
    actual = {r.key: r.value for r in spark.sql(f"SHOW TBLPROPERTIES {target}").collect()}
    drift = {k: (v, actual.get(k)) for k, v in props.items() if actual.get(k) != v}
    if drift:
        raise ValueError(f"Governed table properties differ after REPLACE: {drift}")
    dbutils.notebook.exit(json.dumps({"target": target, "release_id": p["release_id"], "rows": post.n}))

elif p["strategy"] == "RELEASE_POINTER":
    control = table(p["control_catalog"], p["control_schema"], "published_groups")
    group = literal(p["group_id"])
    old = single(f"SELECT published_release_id,high_water_sequence,control_version "
                 f"FROM {control} WHERE group_id={group}")
    if mode == "INSPECT":
        dbutils.notebook.exit(json.dumps({"published_release_id": old.published_release_id,
                                          "high_water_sequence": old.high_water_sequence,
                                          "control_version": old.control_version}))
    members = p["members"]
    if not members or any(not m["mandatory"] for m in members):
        raise ValueError("Every enabled member must be mandatory")
    if len({m["mapping_id"] for m in members}) != len(members):
        raise ValueError("Duplicate group member")
    for m in members:
        physical = table(m["target_catalog"], m["physical_schema"], m["target_table"] + "_snapshots")
        mapping_id = literal(m["mapping_id"])
        row = single(f"SELECT count(*) n, count(DISTINCT source_generation_id) g, "
                     f"count(DISTINCT bridge_run_id) b, count(DISTINCT group_contract_version) c, "
                     f"count(DISTINCT load_attempt) l, min(load_attempt) la "
                     f"FROM {physical} WHERE release_id={release} AND mapping_object_id={mapping_id}")
        if (row.n != int(m["source_rows"]) or
                (row.g, row.b, row.c, row.l) != ((1, 1, 1, 1) if row.n else (0, 0, 0, 0))):
            raise ValueError(f"Unready group member: {m['mapping_id']}")
        if row.n:
            if row.la != str(m["attempt"]):
                raise ValueError(f"Slice for {m['mapping_id']} is not from the READY attempt")
            tags = single(f"SELECT min(source_generation_id) g, min(bridge_run_id) b, "
                          f"min(group_contract_version) c FROM {physical} "
                          f"WHERE release_id={release} AND mapping_object_id={mapping_id}")
            if (tags.g, tags.b, tags.c) != (p["generation_id"], p["bridge_run_id"], p["group_contract_version"]):
                raise ValueError("Group member from wrong generation/run/contract")
    if old.high_water_sequence >= expected:
        raise ValueError("Candidate is stale versus publication high-water")
    if old.published_release_id != p["expected_current_release"]:
        raise ValueError("Publication pointer differs from Azure SQL; reconcile with publish_run.py --resume")
    # The version is read from Delta itself: the Azure SQL control_version is a separate counter.
    run_with_conflict_retry(f"UPDATE {control} SET previous_release_id=published_release_id, "
                            f"published_release_id={release}, published_sequence={expected}, "
                            f"high_water_sequence={expected},control_version=control_version+1, "
                            f"published_at=current_timestamp() WHERE group_id={group} "
                            f"AND control_version={int(old.control_version)} "
                            f"AND published_release_id={literal(p['expected_current_release'])} "
                            f"AND high_water_sequence={int(old.high_water_sequence)}")
    new = single(f"SELECT published_release_id,control_version FROM {control} WHERE group_id={group}")
    if new.published_release_id != p["release_id"] or new.control_version != old.control_version + 1:
        raise ValueError("Pointer update not proven; inspect Delta history before retry")
    dbutils.notebook.exit(json.dumps({"group_id": p["group_id"], "release_id": p["release_id"]}))
else:
    raise ValueError("Unsupported publication strategy")
