-- Upgrade an existing v9 through v9.5.5 Azure SQL control database to v9.5.6 through v9.5.8 (v9.5.7 and
-- v9.5.8 have no control schema change; a v9.5.6 database needs nothing from this file). Run outside any active run,
-- as the control-database deployment identity. Every step checks first, so the script is safe to
-- rerun and works from either version. New deployments use 01_azure_sql_control.sql instead.
-- Existing run/attempt rows carry over. Pre-v9.3 cleanup may require the matching versioned
-- inventory passed to retire_releases.py because older rows did not store immutable target metadata.
IF COL_LENGTH('bridge.fence_events','reason') IS NULL
  ALTER TABLE bridge.fence_events ADD reason nvarchar(1000) NULL;
IF COL_LENGTH('bridge.runs','orchestrator_token') IS NULL
  ALTER TABLE bridge.runs ADD orchestrator_token nvarchar(64) NULL, heartbeat_utc datetime2(3) NULL;
IF COL_LENGTH('bridge.object_attempts','delta_target') IS NULL
  ALTER TABLE bridge.object_attempts ADD delta_target nvarchar(512) NULL,
    updated_utc datetime2(3) NOT NULL CONSTRAINT DF_object_attempts_updated DEFAULT SYSUTCDATETIME(),
    retired_utc datetime2(3) NULL, staging_deleted_utc datetime2(3) NULL;
IF COL_LENGTH('bridge.object_attempts','target_key') IS NULL
  ALTER TABLE bridge.object_attempts ADD target_key nvarchar(512) NULL;
IF COL_LENGTH('bridge.object_attempts','publication_strategy') IS NULL
  ALTER TABLE bridge.object_attempts ADD publication_strategy varchar(16) NULL;
IF COL_LENGTH('bridge.object_attempts','consumer_target') IS NULL
  ALTER TABLE bridge.object_attempts ADD consumer_target nvarchar(512) NULL;
IF COL_LENGTH('bridge.object_attempts','source_operation_state') IS NULL
  ALTER TABLE bridge.object_attempts ADD source_operation_state varchar(24) NULL;
IF COL_LENGTH('bridge.object_attempts','loader_run_id') IS NULL
  ALTER TABLE bridge.object_attempts ADD loader_run_id nvarchar(128) NULL;
IF COL_LENGTH('bridge.object_attempts','loader_operation_state') IS NULL
  ALTER TABLE bridge.object_attempts ADD loader_operation_state varchar(24) NULL;
IF COL_LENGTH('bridge.target_state','publish_owner') IS NULL
  ALTER TABLE bridge.target_state ADD publish_owner nvarchar(128) NULL,
    publish_token nvarchar(64) NULL, publish_claimed_utc datetime2(3) NULL;
IF COL_LENGTH('bridge.target_state','publish_external_run_id') IS NULL
  ALTER TABLE bridge.target_state ADD publish_external_run_id nvarchar(128) NULL;
IF COL_LENGTH('bridge.target_state','publish_operation_state') IS NULL
  ALTER TABLE bridge.target_state ADD publish_operation_state varchar(24) NULL;
-- v9.5.5: runs record their source set so fence abandon/reopen never touches another set's runs.
IF COL_LENGTH('bridge.runs','source_set_id') IS NULL
  ALTER TABLE bridge.runs ADD source_set_id nvarchar(128) NULL;
GO
-- v9.5.6: backfill the source set of pre-v9.5.5 runs wherever the fence history names exactly one
-- source set for the run's generation. Ambiguous or unknown rows stay NULL: fence.py still guards
-- them (fail-closed), and abandon refuses to modify them until claimed with --claim-legacy-runs.
UPDATE r SET source_set_id = x.source_set_id
FROM bridge.runs r
JOIN (SELECT generation_id, MIN(source_set_id) AS source_set_id FROM bridge.fence_events
      WHERE generation_id IS NOT NULL GROUP BY generation_id
      HAVING COUNT(DISTINCT source_set_id) = 1) x ON x.generation_id = r.generation_id
WHERE r.source_set_id IS NULL;
GO
-- Replace the unnamed status CHECK so SUPERSEDED is allowed.
IF OBJECT_ID('bridge.CK_object_attempts_status','C') IS NOT NULL
  ALTER TABLE bridge.object_attempts DROP CONSTRAINT CK_object_attempts_status;
DECLARE @ck sysname = (SELECT TOP (1) cc.name FROM sys.check_constraints cc
  WHERE cc.parent_object_id = OBJECT_ID('bridge.object_attempts') AND cc.definition LIKE '%status%');
IF @ck IS NOT NULL EXEC(N'ALTER TABLE bridge.object_attempts DROP CONSTRAINT ' + QUOTENAME(@ck));
ALTER TABLE bridge.object_attempts ADD CONSTRAINT CK_object_attempts_status CHECK(status IN
  ('EXTRACTING','INDETERMINATE','EXTRACTED','LOADING','READY','FAILED','SUPERSEDED','ABANDONED_GENERATION'));
GO
IF OBJECT_ID('bridge.CK_runs_status','C') IS NOT NULL
  ALTER TABLE bridge.runs DROP CONSTRAINT CK_runs_status;
DECLARE @runs_ck sysname = (SELECT TOP (1) cc.name FROM sys.check_constraints cc
  WHERE cc.parent_object_id = OBJECT_ID('bridge.runs') AND cc.definition LIKE '%status%');
IF @runs_ck IS NOT NULL EXEC(N'ALTER TABLE bridge.runs DROP CONSTRAINT ' + QUOTENAME(@runs_ck));
ALTER TABLE bridge.runs ADD CONSTRAINT CK_runs_status CHECK(status IN
 ('CREATED','EXTRACTING','EXTRACTED','LOADING','READY','PUBLISHING','PUBLISHED','FAILED',
  'PUBLICATION_ABANDONED','ABANDONED_GENERATION'));
GO
-- Replace the fence state CHECK so ABANDONED (abandon/reopen recovery) is allowed on databases
-- created before that state existed.
IF OBJECT_ID('bridge.CK_source_fence_state','C') IS NOT NULL
  ALTER TABLE bridge.source_fence DROP CONSTRAINT CK_source_fence_state;
DECLARE @fence_ck sysname = (SELECT TOP (1) cc.name FROM sys.check_constraints cc
  WHERE cc.parent_object_id = OBJECT_ID('bridge.source_fence') AND cc.definition LIKE '%state%');
IF @fence_ck IS NOT NULL EXEC(N'ALTER TABLE bridge.source_fence DROP CONSTRAINT ' + QUOTENAME(@fence_ck));
ALTER TABLE bridge.source_fence ADD CONSTRAINT CK_source_fence_state CHECK(state IN
  ('AVAILABLE','WRITE_ACTIVE','CLOSED','BRIDGE_HELD','ABANDONED'));
GO
-- Same publication_strategy rule that 01_azure_sql_control.sql creates for new deployments.
IF OBJECT_ID('bridge.CK_object_attempts_publication_strategy','C') IS NULL
  AND NOT EXISTS (SELECT 1 FROM sys.check_constraints cc
                  WHERE cc.parent_object_id = OBJECT_ID('bridge.object_attempts')
                    AND cc.definition LIKE '%publication_strategy%')
  ALTER TABLE bridge.object_attempts ADD CONSTRAINT CK_object_attempts_publication_strategy
    CHECK(publication_strategy IS NULL OR publication_strategy IN ('REPLACE_TABLE','RELEASE_POINTER'));
GO
IF OBJECT_ID('bridge.recovery_events','U') IS NULL
CREATE TABLE bridge.recovery_events (
 recovery_event_id bigint IDENTITY PRIMARY KEY, action varchar(32) NOT NULL,
 bridge_run_id nvarchar(128) NOT NULL, mapping_id nvarchar(128) NULL, attempt int NULL,
 target_key nvarchar(512) NULL, external_run_id nvarchar(128) NULL,
 actor nvarchar(128) NOT NULL, evidence_uri nvarchar(2048) NOT NULL,
 reason nvarchar(1000) NOT NULL, at_utc datetime2(3) NOT NULL DEFAULT SYSUTCDATETIME()
);
GO
-- From v9 only: v9 candidate tables were named candidate_<mapping>_<run>_a1 and v9 attempts have
-- no recorded delta_target, so publish any READY v9 run with the v9 scripts before upgrading,
-- or reload it. (v9.1 already uses the current names.)
CREATE OR ALTER PROCEDURE bridge.transition_fence
 @source_set_id nvarchar(128), @expected_state varchar(20), @next_state varchar(20),
 @expected_version bigint, @generation_id nvarchar(128), @actor nvarchar(128),
 @expiry_utc datetime2(3) = NULL, @reason nvarchar(1000) = NULL
AS
BEGIN
 SET NOCOUNT ON; SET XACT_ABORT ON;
 IF NOT ((@expected_state='AVAILABLE' AND @next_state='WRITE_ACTIVE') OR
         (@expected_state='WRITE_ACTIVE' AND @next_state='CLOSED') OR
         (@expected_state='CLOSED' AND @next_state='BRIDGE_HELD') OR
         (@expected_state='BRIDGE_HELD' AND @next_state='AVAILABLE') OR
         (@next_state='ABANDONED' AND @expected_state IN ('WRITE_ACTIVE','CLOSED','BRIDGE_HELD')) OR
         (@expected_state='ABANDONED' AND @next_state='AVAILABLE'))
    THROW 51000, 'Illegal fence transition', 1;
 BEGIN TRANSACTION;
 UPDATE bridge.source_fence SET state=@next_state,
   generation_id=CASE WHEN @next_state='AVAILABLE' THEN NULL ELSE @generation_id END,
   writer_owner=CASE WHEN @next_state='WRITE_ACTIVE' THEN @actor WHEN @next_state IN ('AVAILABLE','ABANDONED') THEN NULL ELSE writer_owner END,
   bridge_owner=CASE WHEN @next_state='BRIDGE_HELD' THEN @actor WHEN @next_state IN ('AVAILABLE','ABANDONED') THEN NULL ELSE bridge_owner END,
   heartbeat_utc=SYSUTCDATETIME(),expires_utc=@expiry_utc,control_version=control_version+1
 WHERE source_set_id=@source_set_id AND state=@expected_state AND control_version=@expected_version
   AND ((@expected_state='AVAILABLE' AND generation_id IS NULL) OR generation_id=@generation_id)
   AND ((@expected_state<>'WRITE_ACTIVE') OR writer_owner=@actor)
   AND ((@expected_state<>'BRIDGE_HELD') OR bridge_owner=@actor);
 IF @@ROWCOUNT<>1 BEGIN ROLLBACK; THROW 51001, 'Fence owner/state/version mismatch', 1; END;
 INSERT bridge.fence_events(source_set_id,old_state,new_state,generation_id,actor,reason)
 VALUES (@source_set_id,@expected_state,@next_state,@generation_id,@actor,@reason);
 COMMIT;
END;
GO
