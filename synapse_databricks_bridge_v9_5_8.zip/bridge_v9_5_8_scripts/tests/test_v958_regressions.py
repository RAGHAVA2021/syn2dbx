"""v9.5.8 review fixes.

1. Parallel pointer publications: `published_groups` gets deletion vectors (row-level
   concurrency) and the pointer UPDATE retries only rejected Delta conflicts.
2. `--business-date` must match the upstream audit row of the generation.
3. The loader sets the UTC session zone once, before any DataFrame, for every mapping.
4. publish_run.py requires the recorded BRIDGE_HELD -> AVAILABLE fence event for the run.
5. Recovery accepts the real Databricks run ID for a submission stored as its idempotency token.
6. Retention follows the DESIGN_v9.md 7/30-day windows and retires FAILED/SUPERSEDED attempts
   even when their release is kept.

The bug tests fail on v9.5.7 code; the rest confirm unchanged behaviour around each fix.
"""
import ast
import json
import re
from datetime import datetime, timedelta

import pytest

from test_orchestration_sim import CLOCK, ROOT, env, ts  # noqa: F401  (env is a fixture)
from test_v952_regressions import add_attempt, add_run, tsql  # noqa: F401  (tsql is a fixture)
import bridge_run
import publish_run
import recovery
import render_setup
import retire_releases as retention


# --- 1. parallel pointer publication ---------------------------------------------------------------

def test_control_table_enables_row_level_concurrency(env, tmp_path, monkeypatch):
    monkeypatch.setattr("sys.argv", ["x", "--config", env["extract"][1], "--output-dir", str(tmp_path)])
    render_setup.main()
    uc = (tmp_path / "unity_catalog_setup.sql").read_text()
    create = uc[uc.index("CREATE TABLE IF NOT EXISTS `cat`.`bridge_control`.published_groups"):]
    assert "'delta.enableDeletionVectors'='true'" in create[:create.index(";")]
    # Existing tables (created before v9.5.8) are upgraded in place by the same idempotent script.
    assert ("ALTER TABLE `cat`.`bridge_control`.published_groups SET TBLPROPERTIES "
            "('delta.enableDeletionVectors'='true');") in uc


def publisher_retry_helpers():
    """Load is_delta_conflict/run_with_conflict_retry from the notebook without running it."""
    tree = ast.parse((ROOT / "databricks" / "publish.py").read_text())
    wanted = {"CONFLICT_MARKERS", "is_delta_conflict", "run_with_conflict_retry"}
    nodes = [n for n in tree.body
             if (isinstance(n, ast.FunctionDef) and n.name in wanted)
             or (isinstance(n, ast.Assign) and any(getattr(t, "id", None) in wanted for t in n.targets))]
    assert len(nodes) == 3, "conflict-retry helpers missing from databricks/publish.py"
    return ast.unparse(ast.Module(body=nodes, type_ignores=[]))


class FakeSpark:
    def __init__(self, failures):
        self.failures, self.calls = list(failures), 0

    def sql(self, statement):
        self.calls += 1
        if self.failures:
            raise self.failures.pop(0)
        return "committed"


def load_retry(failures):
    spark = FakeSpark(failures)
    namespace = {"spark": spark}
    exec(publisher_retry_helpers(), namespace)
    return namespace, spark


class ConcurrentAppendException(Exception):
    pass


def test_pointer_update_retries_rejected_delta_conflicts():
    ns, spark = load_retry([ConcurrentAppendException("Files were added by a concurrent update"),
                            RuntimeError("[DELTA_CONCURRENT_APPEND] conflict")])
    waits = []
    assert ns["run_with_conflict_retry"]("UPDATE x", sleep=waits.append) == "committed"
    assert spark.calls == 3 and waits == [2.0, 4.0]


def test_pointer_update_never_retries_other_errors():
    ns, spark = load_retry([RuntimeError("PERMISSION_DENIED: MODIFY on published_groups")])
    with pytest.raises(RuntimeError, match="PERMISSION_DENIED"):
        ns["run_with_conflict_retry"]("UPDATE x", sleep=lambda s: None)
    assert spark.calls == 1


def test_pointer_update_retry_is_bounded():
    ns, spark = load_retry([ConcurrentAppendException("again")] * 10)
    with pytest.raises(ConcurrentAppendException):
        ns["run_with_conflict_retry"]("UPDATE x", attempts=4, sleep=lambda s: None)
    assert spark.calls == 4


def test_pointer_update_uses_the_retry_and_keeps_its_guards():
    text = (ROOT / "databricks" / "publish.py").read_text()
    update = text[text.index('run_with_conflict_retry(f"UPDATE {control}'):]
    update = update[:update.index('new = single(')]
    # The retried statement is still conditional on the exact pointer state it read.
    for guard in ("control_version={int(old.control_version)}", "published_release_id={literal(p['expected_current_release'])}",
                  "high_water_sequence={int(old.high_water_sequence)}"):
        assert guard in update
    assert 'spark.sql(f"UPDATE {control}' not in text


# --- 2. business date --------------------------------------------------------------------------------

def test_business_date_must_match_upstream_audit(env):
    args = list(env["extract"])
    args[args.index("--business-date") + 1] = "2026-09-21"      # audit says 2026-09-22
    with pytest.raises(RuntimeError, match="differs from the upstream audit"):
        env["run"](bridge_run, *args)
    assert env["query"]("SELECT count(*) FROM bridge.runs") == [(0,)]
    assert not [c for c in env["state"]["calls"] if c[0] == "extract"]


def test_matching_business_date_still_runs(env):
    env["run"](bridge_run, *env["extract"])
    assert env["query"]("SELECT status, business_date FROM bridge.runs") == [("READY", "2026-09-22")]


# --- 3. loader timezone ---------------------------------------------------------------------------------

def test_loader_sets_utc_once_before_any_dataframe():
    text = (ROOT / "databricks" / "load_candidate.py").read_text()
    tree = ast.parse(text)
    setters = [n for n in ast.walk(tree) if isinstance(n, ast.Call) and ast.unparse(n.func) == "spark.conf.set"
               and "spark.sql.session.timeZone" in ast.unparse(n)]
    assert len(setters) == 1, "exactly one session-timezone statement expected"
    top_level = [n for n in tree.body if isinstance(n, ast.Expr) and n.value is setters[0]]
    assert top_level, "the UTC statement must run for every mapping, not inside a condition"
    assert "'UTC'" in ast.unparse(setters[0])
    assert text.index("spark.sql.session.timeZone") < text.index("p = read_manifest()")


def test_timestamp_to_string_is_utc_whatever_the_ambient_zone():
    pytest.importorskip("pyspark")
    from pyspark.sql import SparkSession
    from pyspark.sql import functions as F
    spark = SparkSession.builder.master("local[1]").config("spark.ui.enabled", "false").getOrCreate()
    spark.conf.set("spark.sql.session.timeZone", "UTC")
    raw = spark.createDataFrame([(datetime(2026, 9, 24, 13, 5),)], "ts timestamp")
    spark.conf.set("spark.sql.session.timeZone", "Australia/Sydney")   # workspace default differs
    text = (ROOT / "databricks" / "load_candidate.py").read_text()
    statement = re.search(r'^spark\.conf\.set\("spark\.sql\.session\.timeZone", "UTC"\).*$', text, re.M).group(0)
    exec(statement, {"spark": spark})
    assert raw.select(F.col("ts").cast("string")).first()[0] == "2026-09-24 13:05:00"


# --- 4. fence release before publication -----------------------------------------------------------------

def test_publication_refused_until_fence_release_recorded(env):
    env["run"](bridge_run, *env["extract"])
    env["query"]("DELETE FROM bridge.fence_events")
    with pytest.raises(RuntimeError, match="Source fence was not released by BRG1"):
        env["run"](publish_run, *env["publish"])
    assert env["query"]("SELECT status, orchestrator_token FROM bridge.runs") == [("READY", None)]
    assert not [c for c in env["state"]["calls"] if c[0] in ("publish", "pointer")]


@pytest.mark.parametrize("generation,actor,old_state", [("GEN0", "BRG1", "BRIDGE_HELD"),
                                                        ("GEN1", "BRG9", "BRIDGE_HELD"),
                                                        ("GEN1", "BRG1", "ABANDONED")])
def test_only_this_runs_release_of_this_generation_counts(env, generation, actor, old_state):
    env["run"](bridge_run, *env["extract"])
    env["query"]("UPDATE bridge.fence_events SET generation_id=?, actor=?, old_state=?", generation, actor, old_state)
    with pytest.raises(RuntimeError, match="Source fence was not released"):
        env["run"](publish_run, *env["publish"])


def test_recorded_release_allows_publication(env):
    env["run"](bridge_run, *env["extract"])
    env["run"](publish_run, *env["publish"])
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]


# --- 5. Databricks submission token in recovery --------------------------------------------------------

TOKEN = "token:bridge_0123456789abcdef"


@pytest.mark.parametrize("evidence_token", ["bridge_0123456789abcdef", TOKEN])
def test_token_resolves_to_actual_databricks_run(evidence_token):
    ev = {"idempotency_token": evidence_token, "external_run_id": "918273645"}
    assert recovery.resolve_databricks_external_id(TOKEN, ev) == "918273645"


def test_real_run_id_needs_the_matching_token():
    with pytest.raises(RuntimeError, match="idempotency_token differs"):
        recovery.resolve_databricks_external_id(TOKEN, {"external_run_id": "918273645"})
    with pytest.raises(RuntimeError, match="idempotency_token differs"):
        recovery.resolve_databricks_external_id(TOKEN, {"idempotency_token": "bridge_other",
                                                        "external_run_id": "918273645"})


def test_repeating_the_stored_token_still_means_no_run_was_found():
    assert recovery.resolve_databricks_external_id(TOKEN, {"external_run_id": TOKEN}) == TOKEN


def test_stored_run_id_must_still_match_exactly():
    assert recovery.resolve_databricks_external_id("dbx_1", {"external_run_id": "dbx_1"}) == "dbx_1"
    with pytest.raises(RuntimeError, match="external run ID differs"):
        recovery.resolve_databricks_external_id("dbx_1", {"external_run_id": "dbx_2",
                                                          "idempotency_token": "bridge_x"})


def write_evidence(tmp_path, name, **fields):
    path = tmp_path / name
    path.write_text(json.dumps({"evidence_uri": "https://evidence/x", **fields}))
    return str(path)


def test_lost_loader_submission_records_the_actual_run(tsql, tmp_path):
    add_run(tsql, "BRG1", "FAILED")
    add_attempt(tsql, "BRG1", "INDETERMINATE", "SUCCEEDED", "UNKNOWN", loader_id=TOKEN)
    evidence = write_evidence(tmp_path, "loader.json", phase="LOADER", external_terminal=True, safe_to_retry=True,
                              idempotency_token=TOKEN, external_run_id="918273645")
    recovery.resolve_attempt(type("Args", (), {"evidence": evidence, "bridge_run_id": "BRG1", "mapping_id": "MAP_001",
                                               "attempt": 1, "actor": "operator", "reason": "run list checked"})())
    assert tsql["query"]("SELECT status,loader_run_id,loader_operation_state FROM bridge.object_attempts") == \
        [("EXTRACTED", "918273645", "VERIFIED_TERMINAL")]
    assert tsql["query"]("SELECT external_run_id FROM bridge.recovery_events") == [("918273645",)]


def test_lost_publisher_submission_records_the_actual_run(env, monkeypatch, tmp_path):
    env["run"](bridge_run, *env["extract"])
    monkeypatch.setattr(recovery, "db", bridge_run.db)
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING'")
    env["query"]("UPDATE bridge.target_state SET publish_owner='BRG1',publish_token='dead',"
                 "publish_external_run_id=?,publish_operation_state='RUNNING' WHERE target_key='group:sales'", TOKEN)
    evidence = write_evidence(tmp_path, "pub.json", external_terminal=True, safe_to_resume=True,
                              orchestrator_stopped=True, idempotency_token=TOKEN, external_run_id="55501")
    recovery.resolve_publication(type("Args", (), {"evidence": evidence, "bridge_run_id": "BRG1",
                                                   "target_key": "group:sales", "actor": "operator",
                                                   "reason": "run list checked"})())
    assert env["query"]("SELECT publish_external_run_id,publish_operation_state FROM bridge.target_state "
                        "WHERE target_key='group:sales'") == [("55501", "VERIFIED_TERMINAL")]


# --- 6. retention windows and dead attempts -----------------------------------------------------------------

def published_old_release(env, days_ago, attempt_status="READY", attempt=1):
    env["query"]("INSERT OR IGNORE INTO bridge.runs(bridge_run_id,upstream_run_id,generation_id,upstream_sequence,"
                 "business_date,inventory_version,release_id,status,updated_utc) VALUES "
                 "('OLD','S','G',90,'2026-09-01','wave_001_v1','rel_OLD','PUBLISHED',?)",
                 ts(CLOCK["now"] - timedelta(days=days_ago)))
    env["query"]("INSERT INTO bridge.object_attempts(bridge_run_id,mapping_id,attempt,method,status,leaf_path,"
                 "source_rows,delta_target,target_key,publication_strategy,consumer_target) VALUES "
                 "('OLD','MAP_001',?,'CETAS',?,?,1,?,'table:cat.gold.customer','REPLACE_TABLE','cat.gold.customer')",
                 attempt, attempt_status, f"bridge/parquet-stage/2026-09-01/OLD/MAP_001/attempt-{attempt:03d}/",
                 f"cat.bridge_candidate.candidate_old_a{attempt}")


def set_target(env, published, previous=None, high_water=100):
    env["query"]("UPDATE bridge.target_state SET published_release_id=?,previous_release_id=?,high_water_sequence=? "
                 "WHERE target_key='table:cat.gold.customer'", published, previous, high_water)


def retention_plan(env):
    report = {}
    _, drops, staging = retention.plan(bridge_run.config(env["extract"][1]), [], report=report)
    return drops, staging, report["waiting_for_retention_window"]


@pytest.mark.parametrize("days_ago,eligible", [(3, False), (8, True)])
def test_published_attempt_waits_seven_days(env, monkeypatch, days_ago, eligible):
    monkeypatch.setattr(retention, "db", bridge_run.db)
    published_old_release(env, days_ago)
    set_target(env, "rel_NEW", "rel_PREV")
    drops, staging, waiting = retention_plan(env)
    assert (len(drops), len(staging), len(waiting)) == ((1, 1, 0) if eligible else (0, 0, 1))


@pytest.mark.parametrize("days_ago,eligible", [(20, False), (31, True)])
def test_unpublished_attempt_waits_thirty_days(env, monkeypatch, days_ago, eligible):
    monkeypatch.setattr(retention, "db", bridge_run.db)
    published_old_release(env, days_ago)
    env["query"]("UPDATE bridge.runs SET status='FAILED' WHERE bridge_run_id='OLD'")
    set_target(env, "rel_NEW", "rel_PREV")
    drops, staging, _ = retention_plan(env)
    assert (len(drops), len(staging)) == ((1, 1) if eligible else (0, 0))


def test_windows_are_configurable(env, monkeypatch):
    monkeypatch.setattr(retention, "db", bridge_run.db)
    doc = json.loads(open(env["extract"][1]).read())
    doc["retention_days_published"] = 2
    open(env["extract"][1], "w").write(json.dumps(doc))
    published_old_release(env, 3)
    set_target(env, "rel_NEW", "rel_PREV")
    drops, staging, _ = retention_plan(env)
    assert (len(drops), len(staging)) == (1, 1)


@pytest.mark.parametrize("value", [-1, 3651, "7", 7.0])
def test_retention_window_config_is_validated(env, value):
    doc = json.loads(open(env["extract"][1]).read())
    doc["retention_days_unpublished"] = value
    open(env["extract"][1], "w").write(json.dumps(doc))
    with pytest.raises(RuntimeError, match="retention_days_unpublished"):
        bridge_run.config(env["extract"][1])


def test_missing_state_change_time_is_never_old_enough(env, monkeypatch):
    monkeypatch.setattr(retention, "db", bridge_run.db)
    published_old_release(env, 100)
    env["query"]("UPDATE bridge.runs SET updated_utc=NULL WHERE bridge_run_id='OLD'")
    set_target(env, "rel_NEW", "rel_PREV")
    drops, staging, _ = retention_plan(env)
    assert (drops, staging) == ([], [])


def test_failed_attempt_of_live_release_is_retired_but_ready_attempt_kept(env, monkeypatch):
    monkeypatch.setattr(retention, "db", bridge_run.db)
    published_old_release(env, 40, attempt_status="FAILED", attempt=1)      # e.g. a rejected loader result
    published_old_release(env, 40, attempt_status="READY", attempt=2)       # what consumers read
    set_target(env, "rel_OLD", None, high_water=90)                          # rel_OLD is live
    drops, staging, _ = retention_plan(env)
    assert [(d["attempt"], d["table"]) for d in drops] == [(1, "candidate_old_a1")]
    assert [s["attempt"] for s in staging] == [1]


def test_superseded_attempt_of_unpublished_run_is_retired_after_window(env, monkeypatch):
    monkeypatch.setattr(retention, "db", bridge_run.db)
    published_old_release(env, 40, attempt_status="SUPERSEDED", attempt=1)
    env["query"]("UPDATE bridge.runs SET status='READY', upstream_sequence=500 WHERE bridge_run_id='OLD'")
    set_target(env, "rel_NEW", None, high_water=100)                         # OLD could still publish
    drops, staging, _ = retention_plan(env)
    assert [d["attempt"] for d in drops] == [1] and [s["attempt"] for s in staging] == [1]


def test_ready_attempt_of_publishable_run_is_still_kept(env, monkeypatch):
    monkeypatch.setattr(retention, "db", bridge_run.db)
    published_old_release(env, 40, attempt_status="READY")
    env["query"]("UPDATE bridge.runs SET status='READY', upstream_sequence=500 WHERE bridge_run_id='OLD'")
    set_target(env, "rel_NEW", None, high_water=100)
    drops, staging, _ = retention_plan(env)
    assert (drops, staging) == ([], [])


def test_retention_job_compares_attempt_before_skipping_a_live_release():
    text = (ROOT / "databricks" / "retire_releases.py").read_text()
    check = text[text.index('for d in p["drop_tables"]:'):text.index("DROP TABLE IF EXISTS")]
    assert "load_attempt" in check and 'str(d["attempt"])' in check


def test_run_left_publishing_by_v957_can_still_resume(env):
    """v9.5.7 never checked the release; such a run cannot be released later (it is not READY)."""
    env["run"](bridge_run, *env["extract"])
    env["query"]("UPDATE bridge.runs SET status='PUBLISHING', orchestrator_token=NULL")
    env["query"]("DELETE FROM bridge.fence_events")
    env["run"](publish_run, *env["publish"], "--resume")
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]
