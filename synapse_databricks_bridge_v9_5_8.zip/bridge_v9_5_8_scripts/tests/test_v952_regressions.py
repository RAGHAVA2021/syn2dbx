"""v9.5.2 regressions: fence abandon/reopen guards, abandon scoping, legacy recovery and retention.

These drive python/fence.py, python/recovery.py and python/retire_releases.py through their
real entry points. SQLite cannot run the T-SQL stored procedure or the aliased UPDATE ... FROM
form, so the fixture below emulates bridge.transition_fence and rewrites those two statements.
"""
import json
import re
from datetime import timedelta

import pytest

import test_orchestration_sim as sim
from test_orchestration_sim import CLOCK, env, ts  # noqa: F401  (env is a fixture)
import bridge_run
import fence
import recovery
import retire_releases as retention

FENCE = "synapse_materialised"
LEAF = "abfss://landing@acct.dfs.core.windows.net/bridge/parquet-stage/2026-09-22/{run}/MAP_001/attempt-001/"
ALIASED_UPDATE = re.compile(r"^UPDATE (\w+) SET (.*?) FROM (\S+) \1 JOIN (\S+ \w+) ON (.*?) WHERE ", re.S)


@pytest.fixture
def tsql(env, monkeypatch):
    """Emulate bridge.transition_fence and T-SQL aliased UPDATE ... FROM on SQLite."""
    original = sim.Cursor.execute

    def execute(self, sql, *params):
        if sql.startswith("EXEC bridge.transition_fence"):
            sid, expected, nxt, version, generation, actor, expiry, _reason = params
            original(self, "UPDATE bridge.source_fence SET state=?, "
                           "generation_id=CASE WHEN ?='AVAILABLE' THEN NULL ELSE ? END, "
                           "bridge_owner=CASE WHEN ? IN ('AVAILABLE','ABANDONED') THEN NULL ELSE bridge_owner END, "
                           "expires_utc=?, control_version=control_version+1 "
                           "WHERE source_set_id=? AND state=? AND control_version=?",
                     nxt, nxt, generation, nxt, expiry, sid, expected, version)
            if self.rowcount != 1:
                raise RuntimeError("Fence owner/state/version mismatch")
            return self
        sql = ALIASED_UPDATE.sub(r"UPDATE \3 AS \1 SET \2 FROM \4 WHERE \5 AND ", sql)
        return original(self, sql, *params)

    monkeypatch.setattr(sim.Cursor, "execute", execute)
    for module in (fence, recovery, retention):
        monkeypatch.setattr(module, "db", bridge_run.db)
    return env


def add_run(env, run_id, status, seq=100, generation="GEN1", source_set=FENCE):
    # updated_utc: the run last changed state 31 days ago, past every v9.5.8 retention window.
    env["query"]("INSERT INTO bridge.runs VALUES (?,'SYN1',?,?,'2026-09-22','wave_001_v1',?,?,NULL,NULL,NULL,?,?)",
                 run_id, generation, seq, "rel_" + run_id, status, ts(CLOCK["now"] - timedelta(days=31)), source_set)


def add_attempt(env, run_id, status, source_state, loader_state=None, source_id="x_req", loader_id=None):
    env["query"]("INSERT INTO bridge.object_attempts(bridge_run_id,mapping_id,attempt,method,status,leaf_path,"
                 "source_request_id,source_operation_state,loader_run_id,loader_operation_state,delta_target,"
                 "target_key,publication_strategy,consumer_target) VALUES (?,'MAP_001',1,'CETAS',?,?,?,?,?,?,"
                 "'cat.bridge_candidate.candidate_x','table:cat.gold.customer','REPLACE_TABLE','cat.gold.customer')",
                 run_id, status, LEAF.format(run=run_id), source_id, source_state, loader_id, loader_state)


def fence_cmd(env, action, actor="BRG1", generation="GEN1"):
    env["run"](fence, action, "--source-set", FENCE, "--generation", generation, "--actor", actor, "--reason", "test")


def fence_state(env):
    return env["query"]("SELECT state,generation_id FROM bridge.source_fence WHERE source_set_id=?", FENCE)[0]


def expire_fence(env):
    env["query"]("UPDATE bridge.source_fence SET expires_utc=?", ts(CLOCK["now"] - timedelta(minutes=1)))


def resolve(env, tmp_path, run_id, phase, external_id, **overrides):
    path = tmp_path / f"terminal_{phase}.json"
    path.write_text(json.dumps({"phase": phase, "external_terminal": True, "safe_to_retry": True,
                                "external_run_id": external_id, "evidence_uri": "https://evidence/x",
                                **overrides}))
    args = type("Args", (), {"evidence": str(path), "bridge_run_id": run_id, "mapping_id": "MAP_001",
                              "attempt": 1, "actor": "operator", "reason": "verified terminal"})()
    recovery.resolve_attempt(args)


# --- abandon / reopen guard -------------------------------------------------------------------

@pytest.mark.parametrize("status,source_state", [("INDETERMINATE", "UNKNOWN"), ("FAILED", "RUNNING"),
                                                 ("EXTRACTING", "RUNNING"), ("EXTRACTING", None)])
def test_abandon_refused_while_source_may_be_reading(tsql, status, source_state):
    add_run(tsql, "BRG1", "FAILED")
    add_attempt(tsql, "BRG1", status, source_state)
    with pytest.raises(RuntimeError, match="abandon requires all source operations"):
        fence_cmd(tsql, "abandon")
    assert tsql["query"]("SELECT status FROM bridge.runs") == [("FAILED",)]
    assert fence_state(tsql) == ("BRIDGE_HELD", "GEN1")


def test_never_submitted_attempt_does_not_trap_expired_generation(tsql):
    """Crash between the attempt insert and submission, then the fence expires."""
    add_run(tsql, "BRG1", "EXTRACTING")
    add_attempt(tsql, "BRG1", "EXTRACTING", "PENDING", source_id=None)
    expire_fence(tsql)
    with pytest.raises(RuntimeError, match="fence"):
        tsql["run"](bridge_run, *tsql["extract"], "--resume")      # resume cannot clear it ...
    fence_cmd(tsql, "abandon")                                       # ... but abandon now can
    assert fence_state(tsql) == ("ABANDONED", "GEN1")
    assert tsql["query"]("SELECT status,orchestrator_token FROM bridge.runs") == [("ABANDONED_GENERATION", None)]
    assert tsql["query"]("SELECT status,source_operation_state FROM bridge.object_attempts") == \
        [("ABANDONED_GENERATION", "PENDING")]
    fence_cmd(tsql, "reopen", actor="operator")
    assert fence_state(tsql) == ("AVAILABLE", None)


def test_abandon_does_not_relabel_published_runs(tsql):
    add_run(tsql, "BRG0", "PUBLISHED", seq=90)
    add_attempt(tsql, "BRG0", "READY", "SUCCEEDED", "SUCCEEDED")
    add_run(tsql, "BRG1", "FAILED")
    add_attempt(tsql, "BRG1", "FAILED", "FAILED")
    fence_cmd(tsql, "abandon")
    rows = dict(tsql["query"]("SELECT bridge_run_id,status FROM bridge.object_attempts"))
    assert rows == {"BRG0": "READY", "BRG1": "ABANDONED_GENERATION"}
    assert dict(tsql["query"]("SELECT bridge_run_id,status FROM bridge.runs")) == \
        {"BRG0": "PUBLISHED", "BRG1": "ABANDONED_GENERATION"}


# --- legacy abandoned rows --------------------------------------------------------------------

def test_legacy_abandoned_source_read_is_recoverable_then_reopens(tsql, tmp_path):
    add_run(tsql, "BRG1", "ABANDONED_GENERATION")
    add_attempt(tsql, "BRG1", "ABANDONED_GENERATION", "RUNNING")
    tsql["query"]("UPDATE bridge.source_fence SET state='ABANDONED',bridge_owner=NULL")
    with pytest.raises(RuntimeError, match="reopen requires"):
        fence_cmd(tsql, "reopen", actor="operator")
    with pytest.raises(RuntimeError, match="external run ID differs"):
        resolve(tsql, tmp_path, "BRG1", "SOURCE", "some_other_id")
    resolve(tsql, tmp_path, "BRG1", "SOURCE", "x_req")
    assert tsql["query"]("SELECT status,source_operation_state FROM bridge.object_attempts") == \
        [("ABANDONED_GENERATION", "VERIFIED_TERMINAL")]
    assert tsql["query"]("SELECT action,external_run_id FROM bridge.recovery_events") == \
        [("RESOLVE_ABANDONED", "x_req")]
    fence_cmd(tsql, "reopen", actor="operator")
    assert fence_state(tsql) == ("AVAILABLE", None)


def test_legacy_abandoned_loader_is_recoverable_then_retired(tsql, tmp_path):
    add_run(tsql, "BRG1", "ABANDONED_GENERATION")
    add_attempt(tsql, "BRG1", "ABANDONED_GENERATION", "SUCCEEDED", "RUNNING", loader_id="dbx_9")
    cfg = bridge_run.config(tsql["extract"][1])
    _, drops, staging = retention.plan(cfg, [])
    assert drops == [] and staging == []
    with pytest.raises(RuntimeError, match="no unresolved source operation"):
        resolve(tsql, tmp_path, "BRG1", "SOURCE", "x_req")
    resolve(tsql, tmp_path, "BRG1", "LOADER", "dbx_9")
    _, drops, staging = retention.plan(cfg, [])
    assert len(drops) == 1 and len(staging) == 1


# --- retention --------------------------------------------------------------------------------

@pytest.mark.parametrize("source_state,loader_state,retired", [
    ("UNKNOWN", None, False), ("SUCCEEDED", "RUNNING", False), ("SUCCEEDED", "UNKNOWN", False),
    ("VERIFIED_TERMINAL", "FAILED", True)])
def test_retention_skips_attempts_with_live_operations(tsql, source_state, loader_state, retired):
    add_run(tsql, "BRG1", "FAILED", seq=100)
    add_attempt(tsql, "BRG1", "FAILED", source_state, loader_state)
    tsql["query"]("UPDATE bridge.target_state SET high_water_sequence=200,published_release_id='rel_NEW' "
                  "WHERE target_key='table:cat.gold.customer'")
    _, drops, staging = retention.plan(bridge_run.config(tsql["extract"][1]), [])
    assert (len(drops), len(staging)) == ((1, 1) if retired else (0, 0))


def test_bridge_run_id_limit_enforced(tsql):
    args = list(tsql["extract"])
    args[args.index("--bridge-run-id") + 1] = "r" * 125
    with pytest.raises(RuntimeError, match="1..124"):
        tsql["run"](bridge_run, *args)


def test_synapse_lost_ack_correlation_resolves_to_actual_run_id():
    stored = bridge_run.source_correlation("BRG1", "MAP_001", 1)
    ev = {"source_correlation": stored, "external_run_id": "synapse-run-123"}
    assert recovery.resolve_source_external_id(stored, ev) == "synapse-run-123"


def test_synapse_lost_ack_recovery_rejects_wrong_correlation():
    stored = bridge_run.source_correlation("BRG1", "MAP_001", 1)
    ev = {"source_correlation": "correlation:wrong", "external_run_id": "synapse-run-123"}
    with pytest.raises(RuntimeError, match="source correlation differs"):
        recovery.resolve_source_external_id(stored, ev)
