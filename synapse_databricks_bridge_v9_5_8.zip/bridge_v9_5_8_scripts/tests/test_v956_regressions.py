"""v9.5.6 review fixes. Each test fails on v9.5.5 code.

1. fence.py abandon never relabels legacy (NULL source set) runs implicitly.
2. A rejected loader result can no longer loop forever on --resume.
3. deploy_synapse_pipeline.py cannot confirm a stale artifact.
4. Every Unity Catalog object a config creates has a distinct name.
5. An interrupt before any source submission leaves a retryable attempt, not a dead end.
6. Legacy recovery cannot resolve a loader-phase attempt with SOURCE evidence.
7. source_set_id is validated at configuration load.
"""
import copy
import json

import pytest

from test_orchestration_sim import env  # noqa: F401  (fixture)
from test_v952_regressions import FENCE, add_attempt, add_run, fence, fence_state, resolve, tsql  # noqa: F401
from test_contract import ORIGINAL, write
import bridge_run


# --- 1. abandon scope -------------------------------------------------------------------------------

def abandon(env, *extra):
    env["run"](fence, "abandon", "--source-set", FENCE, "--generation", "GEN1", "--actor", "BRG1",
               "--reason", "test", *extra)


def statuses(env):
    return dict(env["query"]("SELECT bridge_run_id,status FROM bridge.runs"))


def test_abandon_refuses_to_relabel_unclaimed_legacy_run(tsql):
    add_run(tsql, "BRG1", "FAILED")
    add_run(tsql, "LEGACY", "READY", source_set=None)        # may belong to another source set
    with pytest.raises(RuntimeError, match="no recorded source set.*LEGACY.*--claim-legacy-runs"):
        abandon(tsql)
    assert statuses(tsql) == {"BRG1": "FAILED", "LEGACY": "READY"}   # whole transaction rolled back
    assert fence_state(tsql)[0] != "ABANDONED"


def test_abandon_with_claim_records_source_set_and_abandons(tsql):
    add_run(tsql, "BRG1", "FAILED")
    add_run(tsql, "LEGACY", "READY", source_set=None)
    abandon(tsql, "--claim-legacy-runs")
    assert statuses(tsql) == {"BRG1": "ABANDONED_GENERATION", "LEGACY": "ABANDONED_GENERATION"}
    assert tsql["query"]("SELECT source_set_id FROM bridge.runs WHERE bridge_run_id='LEGACY'") == [(FENCE,)]


def test_terminal_legacy_runs_do_not_block_abandon(tsql):
    add_run(tsql, "BRG1", "FAILED")
    add_run(tsql, "OLD", "PUBLISHED", source_set=None)       # nothing abandon would change
    abandon(tsql)
    assert statuses(tsql) == {"BRG1": "ABANDONED_GENERATION", "OLD": "PUBLISHED"}


def test_upgrade_script_backfills_unambiguous_source_sets():
    from pathlib import Path
    sql = (Path(__file__).resolve().parents[1] / "sql" / "03_upgrade_to_v9_5.sql").read_text()
    assert "HAVING COUNT(DISTINCT source_set_id) = 1" in sql
    assert sql.index("ADD source_set_id") < sql.index("UPDATE r SET source_set_id")


# --- 2. rejected loader result ----------------------------------------------------------------------

def reject_loads(monkeypatch, which, times=1):
    """Make the loader report a wrong delta count for mappings in `which`, `times` times each."""
    real_job = bridge_run.notebook_job
    left = {mid: times for mid in which}
    calls = []

    def job(cfg, job_id, payload, run_id, started=None, terminal=None):
        calls.append(payload["mapping_id"])
        result = real_job(cfg, job_id, payload, run_id, started, terminal)
        if left.get(payload["mapping_id"], 0) > 0:
            left[payload["mapping_id"]] -= 1
            return {**result, "delta_rows": result["delta_rows"] + 1}
        return result

    monkeypatch.setattr(bridge_run, "notebook_job", job)
    return calls


def resume(env):
    env["query"]("UPDATE bridge.runs SET orchestrator_token=NULL")
    env["run"](bridge_run, *env["extract"], "--resume")


def test_rejected_replace_table_result_is_reextracted_as_a_new_attempt(env, monkeypatch):
    reject_loads(monkeypatch, {"MAP_001"})
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    assert env["query"]("SELECT status,loader_operation_state FROM bridge.object_attempts "
                        "WHERE mapping_id='MAP_001'") == [("FAILED", "REJECTED")]
    resume(env)
    assert env["query"]("SELECT attempt,status FROM bridge.object_attempts WHERE mapping_id='MAP_001' "
                        "ORDER BY attempt") == [(1, "FAILED"), (2, "READY")]
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]


def test_persistent_rejection_reaches_max_attempts_instead_of_looping(env, monkeypatch):
    calls = reject_loads(monkeypatch, {"MAP_001"}, times=99)
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    for _ in range(2):                                          # attempts 2 and 3
        with pytest.raises(bridge_run.PhaseError):
            resume(env)
    with pytest.raises(RuntimeError, match="reached max_attempts"):
        resume(env)
    assert calls.count("MAP_001") == 3


def test_rejected_pointer_result_stops_resume_for_review(env, monkeypatch):
    calls = reject_loads(monkeypatch, {"MAP_002"})
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    before = len(calls)
    with pytest.raises(RuntimeError, match="MAP_002 attempt 1: the loader result was rejected"):
        resume(env)
    assert len(calls) == before                                 # no silent reload


# --- 3. Synapse deploy confirms the NEW definition -------------------------------------------------

import deploy_synapse_pipeline as deploy  # noqa: E402
from test_v955_regressions import Resp, Session  # noqa: E402


def confirm(session, put, submitted, previous):
    ticks = iter(range(0, 10_000, 5))
    return deploy.wait_for_artifact(session, {}, "https://w/datasets/d", put, submitted=submitted,
                                    previous_etag=previous, sleep=lambda s: None, clock=lambda: next(ticks))


NEW = {"type": "Parquet", "location": "new"}


def test_accepted_without_location_is_refused():
    with pytest.raises(RuntimeError, match="no Location"):
        confirm(Session([]), Resp(202), NEW, "e1")


def test_stale_definition_is_not_confirmed():
    old = Resp(200, {"name": "d", "etag": "e1", "properties": {"type": "Parquet", "location": "old"}})
    with pytest.raises(RuntimeError, match="does not show the deployed definition"):
        confirm(Session([old] * 1000), Resp(200, {}), NEW, "e1")


def test_update_confirmed_by_changed_etag_or_matching_properties():
    stale = Resp(200, {"etag": "e1", "properties": {"location": "old"}})
    changed = Resp(200, {"etag": "e2", "properties": {"normalised": True}})
    assert confirm(Session([stale, changed]), Resp(200, {}), NEW, "e1")["etag"] == "e2"
    same_etag = Resp(200, {"etag": "e1", "properties": {**NEW, "annotations": []}})   # defaults added
    assert confirm(Session([same_etag]), Resp(200, {}), NEW, "e1")["etag"] == "e1"


def test_new_artifact_confirmed_by_existence():
    session = Session([Resp(404), Resp(200, {"etag": "e9", "properties": {"normalised": True}})])
    assert confirm(session, Resp(201, {}), NEW, deploy.NOT_FOUND)["etag"] == "e9"


def test_main_captures_previous_etag_before_put(monkeypatch, tmp_path):
    order = []

    class S:
        def get(self, url, **_):
            order.append("get")
            return Resp(404) if len(order) == 1 else Resp(200, {"etag": "x", "properties": {}})

        def put(self, url, **_):
            order.append("put")
            return Resp(200, {})

    monkeypatch.setattr(deploy, "current_etag", lambda s, h, u: order.append("etag") or deploy.NOT_FOUND)
    monkeypatch.setattr(deploy, "wait_for_artifact",
                        lambda *a, **k: order.append(("wait", k["previous_etag"])))
    import types, sys as _sys
    fake_req = types.SimpleNamespace(Session=S)
    fake_id = types.SimpleNamespace(DefaultAzureCredential=lambda: types.SimpleNamespace(
        get_token=lambda scope: types.SimpleNamespace(token="t")))
    monkeypatch.setitem(_sys.modules, "requests", fake_req)
    monkeypatch.setitem(_sys.modules, "azure.identity", fake_id)
    monkeypatch.setitem(_sys.modules, "azure", types.SimpleNamespace(identity=fake_id))
    src = deploy.Path(deploy.__file__).resolve().parents[1]
    cfg = json.loads((src / "config.example.json").read_text())
    cfg_path = tmp_path / "c.json"; cfg_path.write_text(json.dumps(cfg))
    monkeypatch.setattr(_sys, "argv", ["deploy", "--config", str(cfg_path), "--synapse-linked-service", "ls",
                                       "--adls-linked-service", "adls", "--container", "c",
                                       "--source-dummy-table", "t", "--source-dummy-schema", "s"])
    deploy.main()
    assert order[:3] == ["etag", "put", ("wait", deploy.NOT_FOUND)]


# --- 4. one Unity Catalog name space ---------------------------------------------------------------

def mapping(doc, mid):
    return next(m for m in doc["mappings"] if m["mapping_id"] == mid)


def test_replace_target_cannot_be_a_pointer_snapshot_table(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    replace, pointer = mapping(doc, "MAP_001"), mapping(doc, "MAP_002")
    replace.update(target_catalog=pointer["target_catalog"], target_schema=pointer["physical_schema"],
                   target_table=pointer["target_table"] + "_snapshots")
    with pytest.raises(RuntimeError, match="Unity Catalog name collision.*snapshot table of MAP_002"):
        bridge_run.config(write(tmp_path, doc))


def test_pointer_view_cannot_be_another_pointers_snapshot_table(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    a, b = mapping(doc, "MAP_002"), mapping(doc, "MAP_003")
    b.update(target_schema=a["physical_schema"], target_table=a["target_table"] + "_SNAPSHOTS")  # case-insensitive
    with pytest.raises(RuntimeError, match="Unity Catalog name collision"):
        bridge_run.config(write(tmp_path, doc))


def test_target_cannot_be_the_control_table(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    m = mapping(doc, "MAP_001")
    m.update(target_catalog=doc["control_catalog"], target_schema=doc["control_schema"], target_table="published_groups")
    with pytest.raises(RuntimeError, match="control table"):
        bridge_run.config(write(tmp_path, doc))


def test_target_cannot_use_generated_candidate_names(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    m = mapping(doc, "MAP_001")
    m.update(target_schema=m["candidate_schema"], target_table="candidate_customer")
    with pytest.raises(RuntimeError, match="reserved for generated candidate tables"):
        bridge_run.config(write(tmp_path, doc))


def test_original_inventory_still_valid(tmp_path):
    bridge_run.config(write(tmp_path, copy.deepcopy(ORIGINAL)))


# --- 5. interrupt before submission -----------------------------------------------------------------

def interrupt_before_submission(monkeypatch):
    real = {"cetas": bridge_run.cetas, "copy_activity": bridge_run.copy_activity}

    def never_submits(*args, **kwargs):
        raise KeyboardInterrupt()                                  # before started_callback runs
    monkeypatch.setattr(bridge_run, "cetas", never_submits)
    monkeypatch.setattr(bridge_run, "copy_activity", never_submits)
    return lambda: [monkeypatch.setattr(bridge_run, k, v) for k, v in real.items()]


def test_interrupt_before_submission_is_retryable_not_indeterminate(env, monkeypatch):
    restore = interrupt_before_submission(monkeypatch)
    with pytest.raises(bridge_run.PhaseError) as caught:
        env["run"](bridge_run, *env["extract"])
    assert bridge_run.is_indeterminate(caught.value)                # the run still keeps its lease
    assert set(env["query"]("SELECT status,source_operation_state FROM bridge.object_attempts")) == \
        {("FAILED", "NOT_STARTED")}
    restore()
    env["query"]("UPDATE bridge.runs SET orchestrator_token=NULL")  # as after the lease expires
    env["run"](bridge_run, *env["extract"], "--resume")
    assert env["query"]("SELECT status FROM bridge.runs") == [("READY",)]


def test_not_started_attempt_does_not_block_fence_abandon(tsql, monkeypatch):
    env = tsql
    interrupt_before_submission(monkeypatch)
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    env["run"](fence, "abandon", "--source-set", FENCE, "--generation", "GEN1", "--actor", "BRG1",
               "--reason", "test")
    assert fence_state(env)[0] == "ABANDONED"


def test_interrupt_after_submission_still_records_unknown(env, monkeypatch):
    def submits_then_interrupted(m, rel, started=None, terminal=None):
        started("x_submitted")
        raise KeyboardInterrupt()
    monkeypatch.setattr(bridge_run, "cetas", submits_then_interrupted)
    monkeypatch.setattr(bridge_run, "copy_activity",
                        lambda cfg, m, item, started=None, terminal=None: submits_then_interrupted(m, None, started))
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    assert set(env["query"]("SELECT status,source_operation_state FROM bridge.object_attempts")) == \
        {("INDETERMINATE", "UNKNOWN")}


# --- 6. legacy recovery phase ------------------------------------------------------------------------

def test_legacy_attempt_with_loader_run_needs_loader_evidence(tsql, tmp_path):
    add_run(tsql, "BRG1", "FAILED", source_set=None)
    add_attempt(tsql, "BRG1", "INDETERMINATE", None, loader_id="dbx_7")     # pre-v9.4: no states
    with pytest.raises(RuntimeError, match="supply LOADER evidence"):
        resolve(tsql, tmp_path, "BRG1", "SOURCE", "x_req")
    resolve(tsql, tmp_path, "BRG1", "LOADER", "dbx_7")
    assert tsql["query"]("SELECT status,loader_operation_state FROM bridge.object_attempts") == \
        [("EXTRACTED", "VERIFIED_TERMINAL")]


# --- 7. source_set_id validation --------------------------------------------------------------------

@pytest.mark.parametrize("value", ["x" * 129, 42, " padded ", ["set"]])
def test_invalid_source_set_id_is_rejected_at_load(tmp_path, value):
    doc = copy.deepcopy(ORIGINAL)
    doc["source_set_id"] = value
    with pytest.raises(RuntimeError, match="source_set_id must be a string"):
        bridge_run.config(write(tmp_path, doc))


def test_claim_legacy_runs_is_refused_outside_abandon(tsql):
    with pytest.raises(RuntimeError, match="applies only to abandon"):
        tsql["run"](fence, "reopen", "--source-set", FENCE, "--generation", "GEN1", "--actor", "BRG1",
                    "--reason", "test", "--claim-legacy-runs")


def test_shipped_example_config_passes_the_new_name_checks(tmp_path):
    """The example uses <placeholders>; fill them with safe identifiers, then it must load."""
    import re
    from pathlib import Path
    text = (Path(__file__).resolve().parents[1] / "config.example.json").read_text()
    filled = re.sub(r"<([^>]*)>", lambda g: re.sub(r"[^A-Za-z0-9_]", "_", g.group(1)) or "x", text)
    path = tmp_path / "example.json"; path.write_text(filled)
    bridge_run.config(str(path))
