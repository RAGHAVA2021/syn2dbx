"""v9.5.7 documentation verification fixes. Each test fails on v9.5.6.

1. The dedicated-pool credential uses 'Managed Service Identity' (PolyBase/CETAS, TYPE=HADOOP).
2. A COPY_ACTIVITY mapping cannot declare a `date` physical type (Synapse Copy writes INT96),
   generate_mappings.for_copy_activity() produces the timestamp contract, and the loader
   narrows timestamp -> date only when every value is midnight UTC.
3. The design's CETAS grants are database-scoped (no server-login grants).
4. Serverless auto-optimization is disabled on the loader too.
"""
import copy
import re
from datetime import datetime
from pathlib import Path

import pytest

from test_contract import ORIGINAL, write
from bridge_run import config
from generate_mappings import for_copy_activity

ROOT = Path(__file__).resolve().parents[1]


# --- 1. credential identity -----------------------------------------------------------------------

def test_dedicated_pool_credential_uses_managed_service_identity():
    sql = (ROOT / "sql" / "02_synapse_setup.sql").read_text()
    statements = [line for line in sql.splitlines()
                  if line.startswith("CREATE DATABASE SCOPED CREDENTIAL")]
    assert statements == ["CREATE DATABASE SCOPED CREDENTIAL bridge_storage_mi "
                          "WITH IDENTITY = 'Managed Service Identity';"]
    assert "ALTER DATABASE SCOPED CREDENTIAL bridge_storage_mi WITH IDENTITY = 'Managed Service Identity'" in sql
    assert "IDENTITY = 'Managed Identity'`, this is" not in (ROOT / "DESIGN_v9.md").read_text()


# --- 2. Copy-route date contract ------------------------------------------------------------------

def copy_mapping_with_date(source_type):
    doc = copy.deepcopy(ORIGINAL)
    m = doc["mappings"][2]
    assert m["method"] == "COPY_ACTIVITY"
    m["columns"].append({"source": "valid_from", "target": "valid_from", "conversion": "DIRECT",
                         "source_spark_type": source_type, "target_type": "date"})
    return doc


def test_copy_activity_rejects_date_physical_type(tmp_path):
    with pytest.raises(RuntimeError, match="COPY_ACTIVITY writes SQL date as Parquet INT96"):
        config(write(tmp_path, copy_mapping_with_date("date")))


def test_copy_activity_accepts_timestamp_physical_type_for_date_target(tmp_path):
    config(write(tmp_path, copy_mapping_with_date("timestamp")))


def test_cetas_keeps_date_physical_type(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][0]["columns"].append({"source": "d", "target": "d", "conversion": "DIRECT",
                                          "source_spark_type": "date", "target_type": "date"})
    config(write(tmp_path, doc))


def test_for_copy_activity_rewrites_only_date_columns(tmp_path):
    cetas = copy.deepcopy(ORIGINAL["mappings"][0])
    cetas["columns"].append({"source": "d", "target": "d", "conversion": "DIRECT",
                             "source_spark_type": "date", "target_type": "date"})
    routed = for_copy_activity(cetas)
    assert routed["method"] == "COPY_ACTIVITY"
    assert [c["source_spark_type"] for c in routed["columns"]] == ["bigint", "string", "timestamp"]
    assert [c["target_type"] for c in routed["columns"]] == ["bigint", "string", "date"]
    assert cetas["method"] == "CETAS" and cetas["columns"][2]["source_spark_type"] == "date"  # input untouched
    doc = copy.deepcopy(ORIGINAL)
    doc["mappings"][0] = routed
    config(write(tmp_path, doc))


def loader_narrowing_block():
    """The exact narrowing code from the loader notebook, from `narrowed =` to its raise."""
    text = (ROOT / "databricks" / "load_candidate.py").read_text()
    match = re.search(r"^narrowed = .*?^        raise ValueError\(f\"Timestamp-to-date.*?\n", text, re.S | re.M)
    assert match, "narrowing check missing from load_candidate.py"
    return match.group(0)


def loader_timezone_statement():
    text = (ROOT / "databricks" / "load_candidate.py").read_text()
    match = re.search(r'^spark\.conf\.set\("spark\.sql\.session\.timeZone", "UTC"\).*$', text, re.M)
    assert match, "UTC session timezone statement missing from load_candidate.py"
    return match.group(0)


@pytest.fixture(scope="module")
def spark():
    pyspark = pytest.importorskip("pyspark")
    from pyspark.sql import SparkSession
    session = (SparkSession.builder.master("local[1]").appName("v957")
               .config("spark.ui.enabled", "false").getOrCreate())
    yield session
    session.stop()


def run_narrowing(spark, values):
    from pyspark.sql import functions as F
    # Synapse Copy writes the SQL date as a UTC-midnight INT96 instant: build the values in UTC ...
    spark.conf.set("spark.sql.session.timeZone", "UTC")
    raw = spark.createDataFrame([(v,) for v in values], "valid_from timestamp")
    # ... then evaluate under a different ambient zone: the loader must not depend on it.
    spark.conf.set("spark.sql.session.timeZone", "America/New_York")
    p = {"columns": [{"target": "valid_from", "source_spark_type": "timestamp", "target_type": "date"}]}
    namespace = {"p": p, "raw": raw, "F": F, "spark": spark, "q": lambda s: f"`{s}`"}
    # v9.5.8: the loader sets the UTC session zone once, at the top, for every mapping; the
    # narrowing block relies on it. Run that statement exactly as the notebook does.
    exec(loader_timezone_statement(), namespace)
    exec(loader_narrowing_block(), namespace)


def test_loader_accepts_midnight_utc_timestamps(spark):
    run_narrowing(spark, [datetime(2026, 9, 24), datetime(1999, 1, 1), None])


def test_loader_rejects_time_of_day(spark):
    with pytest.raises(ValueError, match="Timestamp-to-date narrowing would drop a time of day"):
        run_narrowing(spark, [datetime(2026, 9, 24), datetime(2026, 9, 24, 13, 5)])


# --- 3. database-scoped CETAS grants --------------------------------------------------------------

def test_design_cetas_grants_are_database_scoped():
    design = (ROOT / "DESIGN_v9.md").read_text()
    section = design[design.index("### CETAS SQL execution identity"):design.index("### Bridge orchestration/control identity")]
    assert "GRANT ADMINISTER DATABASE BULK OPERATIONS TO" in section
    assert "GRANT ALTER ANY EXTERNAL DATA SOURCE TO" in section
    assert "GRANT ALTER ANY EXTERNAL FILE FORMAT TO" in section
    assert "server login" not in section.lower()
    assert "contained-only user" not in section


# --- 4. loader retries ----------------------------------------------------------------------------

def test_auto_optimization_disabled_on_all_four_jobs():
    assert "including the loader" in (ROOT / "README.md").read_text()
    assert "Disable serverless auto-optimization on all four tasks" in (ROOT / "WHERE_TO_ENTER_VALUES.md").read_text()
