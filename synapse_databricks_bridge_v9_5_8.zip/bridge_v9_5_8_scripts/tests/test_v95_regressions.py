"""v9.5 regressions for evidence-gated publisher recovery."""
import json

import pytest

from test_orchestration_sim import bridge_run, env, publish_run, recovery  # noqa: F401


def leave_publishers_unknown(env, monkeypatch):
    env["run"](bridge_run, *env["extract"])
    normal_job = publish_run.notebook_job

    def unknown_job(cfg, job_id, payload, run_id, started_callback=None, terminal_callback=None):
        if started_callback:
            started_callback("token:unknown_submission")
            started_callback("dbx_unknown_publisher")
        raise bridge_run.Indeterminate("publisher polling failed")

    monkeypatch.setattr(publish_run, "notebook_job", unknown_job)
    with pytest.raises(bridge_run.PhaseError):
        env["run"](publish_run, *env["publish"])
    monkeypatch.setattr(publish_run, "notebook_job", normal_job)
    return normal_job


def resolve_publishers(env, monkeypatch, tmp_path_factory):
    monkeypatch.setattr(recovery, "db", bridge_run.db)
    keys = [r[0] for r in env["query"](
        "SELECT target_key FROM bridge.target_state WHERE publish_owner='BRG1' ORDER BY target_key")]
    for index, key in enumerate(keys):
        evidence = tmp_path_factory.mktemp(f"publisher_recovery_{index}") / "terminal.json"
        evidence.write_text(json.dumps({
            "external_terminal": True,
            "safe_to_resume": True,
            "orchestrator_stopped": True,
            "external_run_id": "dbx_unknown_publisher",
            "evidence_uri": "https://evidence/publisher-terminal",
        }))
        recovery.resolve_publication(type("Args", (), {
            "evidence": str(evidence), "bridge_run_id": "BRG1", "target_key": key,
            "actor": "operator", "reason": "verified terminal publisher",
        })())
    return keys


def test_unknown_publisher_requires_evidence_and_inspect_preserves_its_id(
        env, monkeypatch, tmp_path_factory):
    normal_job = leave_publishers_unknown(env, monkeypatch)
    before = env["query"](
        "SELECT target_key,publish_external_run_id,publish_operation_state FROM bridge.target_state "
        "WHERE publish_owner='BRG1' ORDER BY target_key")
    assert before and all(r[1:] == ("dbx_unknown_publisher", "RUNNING") for r in before)

    # Make the retained publication lease claimable, then prove resume still refuses
    # to overwrite the unknown mutating run ID with an INSPECT ID.
    from test_orchestration_sim import CLOCK, timedelta
    CLOCK["now"] += timedelta(minutes=151)
    with pytest.raises(bridge_run.PhaseError, match="resolve-publication"):
        env["run"](publish_run, *env["publish"], "--resume")
    assert env["query"](
        "SELECT publish_external_run_id,publish_operation_state FROM bridge.target_state "
        "WHERE publish_owner='BRG1' ORDER BY target_key") == \
        [("dbx_unknown_publisher", "RUNNING"), ("dbx_unknown_publisher", "RUNNING")]

    keys = resolve_publishers(env, monkeypatch, tmp_path_factory)
    assert env["query"]("SELECT orchestrator_token FROM bridge.runs") == [(None,)]
    observed = []

    def observe_job(cfg, job_id, payload, run_id, started_callback=None, terminal_callback=None):
        if payload.get("mode") == "INSPECT":
            # Publication groups execute concurrently. Another group may already have reconciled
            # and cleared its claim; assert preservation only for the target being inspected.
            key = ("group:" + payload["group_id"] if payload.get("strategy") == "RELEASE_POINTER"
                   else bridge_run.target_key(payload["mapping"]))
            rows = env["query"](
                "SELECT publish_external_run_id,publish_operation_state FROM bridge.target_state "
                "WHERE target_key=? AND publish_owner='BRG1'", key)
            assert rows == [("dbx_unknown_publisher", "VERIFIED_TERMINAL")]
            observed.append(payload.get("strategy"))
        return normal_job(cfg, job_id, payload, run_id, started_callback, terminal_callback)

    monkeypatch.setattr(publish_run, "notebook_job", observe_job)
    env["run"](publish_run, *env["publish"], "--resume")
    assert set(observed) == {"REPLACE_TABLE", "RELEASE_POINTER"}
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]
    assert len(keys) == 2


def test_unknown_read_only_inspect_is_immediately_retryable(env, monkeypatch, tmp_path_factory):
    normal_job = leave_publishers_unknown(env, monkeypatch)
    resolve_publishers(env, monkeypatch, tmp_path_factory)

    def unknown_inspect(cfg, job_id, payload, run_id, started_callback=None, terminal_callback=None):
        if payload.get("mode") == "INSPECT":
            raise bridge_run.Indeterminate("inspection polling failed")
        return normal_job(cfg, job_id, payload, run_id, started_callback, terminal_callback)

    monkeypatch.setattr(publish_run, "notebook_job", unknown_inspect)
    with pytest.raises(bridge_run.PhaseError, match="Read-only Delta inspection"):
        env["run"](publish_run, *env["publish"], "--resume")
    assert env["query"]("SELECT orchestrator_token FROM bridge.runs") == [(None,)]
    assert env["query"](
        "SELECT publish_external_run_id,publish_operation_state FROM bridge.target_state "
        "WHERE publish_owner='BRG1' ORDER BY target_key") == \
        [("dbx_unknown_publisher", "VERIFIED_TERMINAL"),
         ("dbx_unknown_publisher", "VERIFIED_TERMINAL")]

    monkeypatch.setattr(publish_run, "notebook_job", normal_job)
    env["run"](publish_run, *env["publish"], "--resume")
    assert env["query"]("SELECT status FROM bridge.runs") == [("PUBLISHED",)]


def test_generation_unresolved_source_guard(env):
    # A generation-level guard is used by both abandon and reopen, preventing a second
    # route around bridge-release while a CETAS/Synapse Copy source read may still be active.
    env["query"]("INSERT INTO bridge.runs VALUES ('BRG1','SYN1','GEN1',100,'2026-09-22','wave_001_v1',"
                 "'rel_BRG1','FAILED',NULL,NULL,NULL,NULL,NULL)")
    env["query"]("INSERT INTO bridge.object_attempts(bridge_run_id,mapping_id,attempt,method,status,"
                 "source_operation_state) VALUES ('BRG1','MAP_001',1,'CETAS','INDETERMINATE','UNKNOWN')")
    with bridge_run.db("BRIDGE_CONTROL_ODBC") as conn:
        rows = __import__('fence').unresolved_source_operations(conn.cursor(), "r.generation_id=?", "GEN1")
    assert rows and "INDETERMINATE/UNKNOWN" in rows[0]


def test_generated_ids_fit_control_columns():
    run_id = "r" * 124
    release_id = "rel_" + run_id
    correlation = bridge_run.source_correlation(run_id, "m" * 128, 999)
    assert len(release_id) == 128
    assert len(correlation) <= 128
    assert correlation == bridge_run.source_correlation(run_id, "m" * 128, 999)
