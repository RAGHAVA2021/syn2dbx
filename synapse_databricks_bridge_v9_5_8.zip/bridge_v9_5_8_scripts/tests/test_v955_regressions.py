"""v9.5.5 review fixes.

1. recovery.py resolve-attempt only accepts evidence for the operation that is actually unresolved.
2. RELEASE_POINTER mappings cannot share a *_snapshots table; generated views filter by mapping.
3. fence.py abandon/reopen are scoped to the source set, not only the generation ID.
4. deploy_synapse_pipeline.py waits for asynchronous (202) Synapse artifact operations.
5. Smaller: profiles without legacy column_count, a successful read keeps SUCCEEDED when the
   attempt later fails, and a rejected loader result is recorded in error_text.
"""
import copy
import json
import sys

import pytest

from test_orchestration_sim import env  # noqa: F401  (fixture)
from test_v952_regressions import FENCE, add_attempt, add_run, fence_cmd, fence_state, resolve, tsql  # noqa: F401
from test_contract import ORIGINAL, write
import bridge_run
import deploy_synapse_pipeline as deploy
import render_setup


# --- 1. recovery phase must match the unresolved operation --------------------------------------

def loader_indeterminate(env):
    add_run(env, "BRG1", "FAILED")
    env["query"]("UPDATE bridge.runs SET orchestrator_token='tok'")
    add_attempt(env, "BRG1", "INDETERMINATE", "SUCCEEDED", loader_state="UNKNOWN", loader_id="dbx_7")


def test_source_evidence_cannot_resolve_an_unresolved_loader(tsql, tmp_path):
    loader_indeterminate(tsql)
    with pytest.raises(RuntimeError, match="SOURCE operation is not unresolved"):
        resolve(tsql, tmp_path, "BRG1", "SOURCE", "x_req")
    assert tsql["query"]("SELECT status,source_operation_state,loader_operation_state "
                         "FROM bridge.object_attempts") == [("INDETERMINATE", "SUCCEEDED", "UNKNOWN")]
    assert tsql["query"]("SELECT orchestrator_token FROM bridge.runs") == [("tok",)]   # lease kept


def test_loader_evidence_resolves_loader(tsql, tmp_path):
    loader_indeterminate(tsql)
    resolve(tsql, tmp_path, "BRG1", "LOADER", "dbx_7")
    assert tsql["query"]("SELECT status,loader_operation_state FROM bridge.object_attempts") == \
        [("EXTRACTED", "VERIFIED_TERMINAL")]
    assert tsql["query"]("SELECT orchestrator_token FROM bridge.runs") == [(None,)]


def test_loader_evidence_cannot_resolve_an_unresolved_source(tsql, tmp_path):
    add_run(tsql, "BRG1", "FAILED")
    add_attempt(tsql, "BRG1", "INDETERMINATE", "UNKNOWN", loader_state="FAILED", loader_id="dbx_old")
    with pytest.raises(RuntimeError, match="LOADER operation is not unresolved"):
        resolve(tsql, tmp_path, "BRG1", "LOADER", "dbx_old")


# --- 2. pointer snapshot tables are per mapping --------------------------------------------------

def test_pointer_mappings_cannot_share_a_snapshot_table(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    extra = copy.deepcopy(doc["mappings"][1])
    extra.update({"mapping_id": "MAP_009", "source_view": "v_sales_eu", "target_schema": "gold_eu"})
    doc["mappings"].append(extra)
    with pytest.raises(RuntimeError, match="Snapshot table shared"):
        bridge_run.config(write(tmp_path, doc))
    extra["target_table"] = "sales_eu"                  # its own physical table is fine
    bridge_run.config(write(tmp_path, doc))


def test_generated_pointer_view_filters_by_mapping(tmp_path, monkeypatch):
    out = tmp_path / "out"
    monkeypatch.setattr(sys, "argv", ["x", "--config", str(write(tmp_path, ORIGINAL)), "--output-dir", str(out)])
    render_setup.main()
    views = [line for line in (out / "unity_catalog_setup.sql").read_text().splitlines()
             if line.startswith("CREATE VIEW")]
    assert views and all("mapping_object_id = 'MAP_" in v for v in views)


# --- 3. fence recovery is scoped to the source set -----------------------------------------------

def test_abandon_leaves_other_source_sets_alone(tsql):
    add_run(tsql, "BRG1", "FAILED")                                    # this source set
    add_run(tsql, "OTHER", "READY", source_set="another_set")         # same generation ID, other set
    add_attempt(tsql, "OTHER", "INDETERMINATE", "UNKNOWN")            # would block if in scope
    fence_cmd(tsql, "abandon")
    assert fence_state(tsql) == ("ABANDONED", "GEN1")
    assert dict(tsql["query"]("SELECT bridge_run_id,status FROM bridge.runs")) == \
        {"BRG1": "ABANDONED_GENERATION", "OTHER": "READY"}
    assert tsql["query"]("SELECT status FROM bridge.object_attempts") == [("INDETERMINATE",)]


def test_legacy_run_without_source_set_is_still_guarded(tsql):
    add_run(tsql, "BRG1", "FAILED", source_set=None)
    add_attempt(tsql, "BRG1", "INDETERMINATE", "UNKNOWN")
    with pytest.raises(RuntimeError, match="abandon requires all source operations"):
        fence_cmd(tsql, "abandon")


def test_new_run_records_its_source_set(env):
    env["run"](bridge_run, *env["extract"])
    assert env["query"]("SELECT source_set_id FROM bridge.runs") == [(FENCE,)]


# --- 4. Synapse deployment waits for asynchronous operations -------------------------------------

class Resp:
    def __init__(self, code, body=None, headers=None):
        self.status_code, self._body, self.headers = code, body, headers or {}
        self.content = b"x" if body is not None else b""

    def json(self):
        return self._body

    def raise_for_status(self):
        if self.status_code >= 400:
            raise RuntimeError(f"HTTP {self.status_code}")


class Session:
    def __init__(self, responses):
        self.responses, self.urls = list(responses), []

    def get(self, url, **_):
        self.urls.append(url)
        return self.responses.pop(0)


def wait(session, put, clock=None):
    ticks = iter(range(0, 10_000, 5))
    return deploy.wait_for_artifact(session, {}, "https://w/datasets/d", put, sleep=lambda s: None,
                                    clock=clock or (lambda: next(ticks)))


def test_deploy_polls_accepted_operation_then_confirms_artifact():
    session = Session([Resp(202), Resp(200, {"status": "Succeeded"}), Resp(404), Resp(200, {"name": "d"})])
    assert wait(session, Resp(202, headers={"Location": "https://w/op/1"})) == {"name": "d"}
    assert session.urls == ["https://w/op/1", "https://w/op/1", "https://w/datasets/d", "https://w/datasets/d"]


def test_deploy_reports_failed_operation():
    session = Session([Resp(200, {"status": "Failed", "error": "bad reference"})])
    with pytest.raises(RuntimeError, match="ended Failed"):
        wait(session, Resp(202, headers={"Location": "https://w/op/1"}))


def test_deploy_times_out():
    session = Session([Resp(202)] * 1000)
    with pytest.raises(RuntimeError, match="Timed out"):
        wait(session, Resp(202, headers={"Location": "https://w/op/1"}))


def test_deploy_synchronous_success_still_reads_back():
    session = Session([Resp(200, {"name": "d"})])
    assert wait(session, Resp(200, {"name": "d"})) == {"name": "d"}


# --- 5. smaller fixes -----------------------------------------------------------------------------

def test_profile_without_legacy_column_count(tmp_path):
    doc = copy.deepcopy(ORIGINAL)
    doc["require_profiles"] = True
    doc["profile_thresholds"] = {"medium_rows": 100, "large_rows": 1000, "medium_bytes": 10000,
                                 "large_bytes": 100000, "medium_columns": 10, "large_columns": 50}
    for m in doc["mappings"]:
        m["size_class"] = "SMALL"
        m["source_profile"] = {"profiled_at_utc": "2026-09-22T00:00:00Z", "estimated_rows": 1,
                               "physical_used_bytes": 128, "mapped_column_count": len(m["columns"]),
                               "physical_column_count": 7, "source_schema_version": m["source_schema_version"]}
    bridge_run.config(write(tmp_path, doc))


def test_successful_read_keeps_succeeded_when_fence_lapses_afterwards(env, monkeypatch):
    real_fence = bridge_run.fence

    def fence(conn, doc, generation, run_id, margin_minutes=None):
        if margin_minutes == 0:                                       # the post-read re-check
            raise RuntimeError("Source fence not held by this run/generation")
        return real_fence(conn, doc, generation, run_id, margin_minutes)

    monkeypatch.setattr(bridge_run, "fence", fence)
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    assert set(env["query"]("SELECT status,source_operation_state FROM bridge.object_attempts")) == \
        {("FAILED", "SUCCEEDED")}


def test_rejected_loader_result_is_recorded(env, monkeypatch):
    real_job = bridge_run.notebook_job

    def job(cfg, job_id, payload, run_id, started=None, terminal=None):
        result = real_job(cfg, job_id, payload, run_id, started, terminal)
        return {**result, "delta_rows": result["delta_rows"] + 1}

    monkeypatch.setattr(bridge_run, "notebook_job", job)
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    rows = env["query"]("SELECT status,loader_operation_state,error_text FROM bridge.object_attempts")
    # v9.5.6: a rejected result is FAILED/REJECTED rather than left LOADING (see test_v956_regressions.py).
    assert rows and all(s == "FAILED" and o == "REJECTED" and e.startswith("Loader result rejected: Three-way count mismatch")
                        for s, o, e in rows)


# --- second review pass ----------------------------------------------------------------------------

def test_interrupt_after_successful_read_is_recoverable(env, monkeypatch, tmp_path):
    """An indeterminate stop after a SUCCEEDED read must record UNKNOWN, not keep SUCCEEDED,
    otherwise neither SOURCE nor LOADER evidence could ever resolve the attempt."""
    real_fence = bridge_run.fence

    def fence(conn, doc, generation, run_id, margin_minutes=None):
        if margin_minutes == 0:
            raise KeyboardInterrupt()
        return real_fence(conn, doc, generation, run_id, margin_minutes)

    monkeypatch.setattr(bridge_run, "fence", fence)
    with pytest.raises(bridge_run.PhaseError) as caught:           # worker errors are collected
        env["run"](bridge_run, *env["extract"])
    assert bridge_run.is_indeterminate(caught.value)
    assert env["query"]("SELECT orchestrator_token IS NOT NULL FROM bridge.runs") == [(1,)]   # lease kept
    rows = env["query"]("SELECT mapping_id,status,source_operation_state FROM bridge.object_attempts")
    assert {(s, o) for _, s, o in rows} == {("INDETERMINATE", "UNKNOWN")}
    env["query"]("UPDATE bridge.runs SET status='FAILED'")        # as after the orchestrator exits
    import recovery
    monkeypatch.setattr(recovery, "db", bridge_run.db)            # the env fixture's SQLite stand-in
    for mid, _, _ in rows:
        path = tmp_path / f"{mid}.json"
        path.write_text(json.dumps({"phase": "SOURCE", "external_terminal": True, "safe_to_retry": True,
                                    "external_run_id": "x_req", "evidence_uri": "https://evidence/x"}))
        recovery.resolve_attempt(type("A", (), {"evidence": str(path), "bridge_run_id": "BRG1", "mapping_id": mid,
                                                "attempt": 1, "actor": "op", "reason": "verified"})())
    assert {r[0] for r in env["query"]("SELECT status FROM bridge.object_attempts")} == {"FAILED"}


def test_legacy_indeterminate_without_operation_state_is_recoverable(tsql, tmp_path):
    add_run(tsql, "BRG1", "FAILED", source_set=None)
    add_attempt(tsql, "BRG1", "INDETERMINATE", None)              # pre-v9.4 row: no states recorded
    resolve(tsql, tmp_path, "BRG1", "SOURCE", "x_req")
    assert tsql["query"]("SELECT status,source_operation_state FROM bridge.object_attempts") == \
        [("FAILED", "VERIFIED_TERMINAL")]


def test_resume_backfills_legacy_source_set(env):
    env["state"]["fail_extract"].add("MAP_002")
    with pytest.raises(bridge_run.PhaseError):
        env["run"](bridge_run, *env["extract"])
    env["query"]("UPDATE bridge.runs SET source_set_id=NULL")      # as if created before v9.5.5
    env["run"](bridge_run, *env["extract"], "--resume")
    assert env["query"]("SELECT status,source_set_id FROM bridge.runs") == [("READY", FENCE)]


def test_deploy_accepts_non_json_completion_body():
    done = Resp(200, None)
    done.content = b"<html>ok</html>"
    done.json = lambda: (_ for _ in ()).throw(ValueError("not json"))
    session = Session([done, Resp(200, {"name": "d"})])
    assert wait(session, Resp(202, headers={"Location": "https://w/op/1"})) == {"name": "d"}


def test_deploy_rejects_http_error_on_put():
    with pytest.raises(RuntimeError, match="HTTP 400"):
        wait(Session([]), Resp(400))
