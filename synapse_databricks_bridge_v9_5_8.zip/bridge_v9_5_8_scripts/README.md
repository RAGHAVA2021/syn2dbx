# Synapse to Databricks bridge: v9.5.8 executable reference

> **Start with [`SCRIPT_GUIDE.md`](SCRIPT_GUIDE.md)** — it lists every script in execution order with its purpose, who runs it, and what it reads and writes.

This package implements the governing design in `DESIGN_v9.md`. It is parameterised code, **not a completed deployment for the actual estate**. It cannot be run unchanged: the sample has fictitious names and the real mappings, identities, network, table contracts, security policies, Synapse linked services and Databricks jobs have not been supplied.

## Scope and current limits

The supplied code implements the core full-load path: a governed source fence, upstream view audit, CETAS or Synapse Copy to unique ADLS attempt paths, a three-way row count, Delta candidate or multi-release physical writes, independent table replacement and an atomic group pointer. It refuses unsafe identifiers, duplicate mappings, optional pointer members, schema drift, stale publication and blind reruns. Failed runs are continued explicitly with `--resume` under an orchestrator lease; nothing retries silently, and an operation whose outcome is unknown keeps the lease until matching terminal evidence is recorded or the lease expires.

Several v9 production controls need environment-specific implementations before any production run: source writer inventory and removal of bypass writes; audit-stream/fence-violation detectors; table-level mask/ABAC inventory and restricted-identity policy tests; consumer contracts and streaming/CDF tests; source/Delta business-total checks; rollback automation; case-specific `time`/timestamp/ancient-date conversion; large-object chunking; and monitoring/on-call integration. The evidence file is a record of those external tests, not a way to bypass them. For any mapping requiring those features, extend and validate the code before enabling it. **Do not use this package alone to declare v9 fully implemented.**

Only direct named source columns and a controlled GUID-to-text conversion are rendered for CETAS/Copy. There is no unrestricted SQL expression field. The basic Spark type conversion should be extended for specific source timestamp/decimal contracts after full-volume testing. The Synapse Copy route uses one unpartitioned Copy Activity; set additional source parallelism only after capacity testing. The Python bridge runs bounded concurrent extracts, serverless loads, and publications across disjoint target keys. Members within one publication group remain ordered. Benchmark the full 1,000-table path before declaring an overnight SLO.

## Files

See [`SCRIPT_GUIDE.md`](SCRIPT_GUIDE.md) for the full, ordered explanation. Summary:

| File | Execution context |
|---|---|
| `sql/01_azure_sql_control.sql` | Azure SQL control database administrator (new deployments) |
| `sql/03_upgrade_to_v9_5.sql` | Azure SQL control database administrator (existing v9 through v9.5.5 deployments) |
| `sql/02_synapse_setup.sql` | Existing Synapse dedicated SQL pool database administrator |
| `python/generate_mappings.py` / `databricks/generate_mappings_pyspark.py` | Discover a Synapse schema and generate a pinned mapping inventory |
| `python/profile_inventory.py` / `databricks/profile_inventory_pyspark.py` | Non-scanning dedicated-pool profile, CSV report and a new versioned config |
| `python/source_metadata.py` | Reproducible source schema hash (also a shared library) |
| `python/render_setup.py` | Idempotent control seeds and Unity Catalog setup SQL for each wave |
| `python/deploy_synapse_pipeline.py` | Optional Copy route; deploy reviewed Synapse pipeline objects |
| `python/fence.py` | Source fence transitions, including `abandon`/`reopen` recovery |
| `python/recovery.py` | Evidence-gated resolution of indeterminate attempts and publication claims |
| `python/upstream_audit.py` | After Synapse materialisation, while upstream owns WRITE_ACTIVE |
| `python/bridge_run.py` | Control host: extraction and Databricks loading; `--resume` |
| `databricks/load_candidate.py` | Loader Job |
| `python/publish_run.py` | Control host: gated publication; `--resume` reconciles with Delta |
| `databricks/publish.py` | Strategy A publisher Job and group-pointer Job (PUBLISH / INSPECT) |
| `python/retire_releases.py` / `databricks/retire_releases.py` | Retention of superseded releases, candidates and staging paths |
| `requirements-dev.txt` / `tests/` | Test dependencies, contract tests and SQLite-backed orchestration simulations |

## Before the first run

1. Copy `config.example.json` to a private `config.json`, or use `python/generate_mappings.py` or `databricks/generate_mappings_pyspark.py` as documented in `WHERE_TO_ENTER_VALUES.md` to discover a large source schema. For physical source tables, run `databricks/profile_inventory_pyspark.py` on a manually created, Unity Catalog-enabled Databricks classic cluster. Set its input/output UC volume paths, dedicated-pool JDBC connection and new inventory version. Review the accompanying `.profile.csv` report and configured class thresholds. The orchestration-host `python/profile_inventory.py` remains an alternative, not a prerequisite. Seed **the new profile inventory version**, not the input version. Replace every `<...>` marker; review all mappings, source hashes, ordered column types and exceptions. Choose `REPLACE_TABLE` or `RELEASE_POINTER` by the v9 consistency review. All enabled pointer members must be mandatory and have the same `group_contract_version`. The example count and types are illustrations only.
2. Install Microsoft ODBC Driver 18 for SQL Server and `pip install -r requirements.txt`; test hosts additionally use `pip install -r requirements-dev.txt`. Supply the secure ODBC connection strings via `BRIDGE_CONTROL_ODBC`, `BRIDGE_SYNAPSE_AUDIT_ODBC`, `BRIDGE_CETAS_ODBC`, and optionally the identity used for source writer procedures. Do not print them. The CETAS SQL login and source storage credential are different principals. The host identity also needs read/list access to the ADLS staging prefix to prove an attempt path is empty, and write access (create only) under `bridge/parquet-stage/_manifests/` for job manifests; delete access is needed only if you use `retire_releases.py --delete-staging`; the Databricks job reads through its UC external location. Configure Databricks unified authentication for the three job invocations. Synapse workspace data-plane API access uses `DefaultAzureCredential`.
3. Create Azure SQL tables and stored procedure (`01_azure_sql_control.sql`, or `03_upgrade_to_v9_5.sql` for an existing v9 through v9.5.5 database — from v9, publish any READY v9 run with the v9 scripts first); seed `bridge.source_fence` once. Create Synapse audit, credential, external data source and Parquet file format after the administrator provisions its database master key. Fill the ADLS account/container in the SQL script, then run it once. Grant stored-procedure execution to registered writer/bridge identities but no direct fence-table write privileges. Ensure all governed Synapse writers, including replays and support, acquire the same fence before modification.
4. For each source view, run `python python/source_metadata.py --schema presentation --view v_customer` and record the hash in the config. Recompute on any schema change. Keep a versioned, immutable copy of `config.json` per run. Precreate UC catalogs, schemas, staging external location, service principals and policy functions. Verify runtime and warehouse support for every write and policy inspection command. Grant the Strategy A publisher `MANAGE` on existing consumer tables, `CREATE TABLE` on their schema, plus `SELECT` on candidate tables. Grant the loader no `MANAGE` on consumer tables.
5. Run `python python/render_setup.py --config config.json --output-dir generated`. Review and execute `generated/azure_sql_seed.sql` in the control database and `generated/unity_catalog_setup.sql` on a Databricks SQL warehouse. Both are idempotent: rerun them for every new inventory wave; existing target state and pointers are never reset, and a seeded member that differs from the config stops the script. The UC script creates the physical snapshot tables with the loader's exact DDL, inserts the `NONE` pointer and creates the stable views, so no load has to run first. Do not grant users access to physical snapshot tables, unpublished candidates or the pointer control table. Apply and test either governed policies on physical tables or approved dynamic view SQL; the generated views assume `PHYSICAL_TABLE_POLICY` and must not be used for groups requiring the other mode.
6. Follow `WHERE_TO_ENTER_VALUES.md` for the UC staging external location and four **Serverless** single-task notebook Jobs: loader (`databricks/load_candidate.py`), Strategy A publisher and group-pointer publisher (`databricks/publish.py`, separate identities), and retention (`databricks/retire_releases.py`). Each takes the notebook parameters `manifest_path` and `manifest_sha256`, and each Run-as identity needs `READ FILES` on the staging external location to read its manifest. Set an actual Databricks Job timeout of at most 7,200 seconds for loader and publisher jobs; the runner's polling timeout cannot cancel a job after the runner itself stops. Disable serverless auto-optimization (automatic retries) on all four tasks, including the loader: it is on by default, the Job timeout applies to each retry, so a retried loader could outlive the runner's 7,200-second poll plus cancel window that `takeover_after_minutes` is sized for, and the runner already creates its own attempts. Set the four job IDs in config. If using Copy, deploy the reviewed datasets and pipeline with `python python/deploy_synapse_pipeline.py --config config.json --synapse-linked-service ... --adls-linked-service ... --container ... --source-dummy-schema ... --source-dummy-table ...`. The linked services must exist already, with correct network and secret access. Inspect pipeline metrics for skipped/truncated rows during the acceptance run.
7. Test the exact privilege, policy and staging access paths with the intended service principals. Benchmark the full-sized largest objects, CETAS/Copy mixture, Parquet scan, Delta write, publication and rollback. Set `max_extraction_workers`, `extraction_class_limits`, `max_loader_workers`, `max_publisher_workers` and `minimum_fence_margin_minutes` to measured values. Set the loader and publisher Jobs' **Maximum concurrent runs** to at least their respective worker limits; verify workspace/serverless quotas separately. Set `max_attempts`, `takeover_after_minutes` and `heartbeat_seconds` (see *Failure and recovery*). Optionally set `retention_days_published` (default 7) and `retention_days_unpublished` (default 30), the staging and candidate retention windows from `DESIGN_v9.md`.

### Profiling and workload classes

Both profilers use dedicated-pool distribution metadata. Their `estimated_rows` and `physical_used_bytes` are planning measurements, not a point-in-time source audit and **not predicted Parquet output bytes**. The report keeps `physical_column_count` for workload classification and `mapped_column_count` for the view contract, so a reviewed view may project a subset of its materialised table. Replicated tables are counted once for estimated logical rows, but physical bytes include replicated copies. Index maintenance affects the accuracy of DMV counts. Limits are initial examples; calibrate them from measured execution time and source queue pressure. A view that adds joins or calculated expansion still needs a separately approved workload estimate because base-table DMVs cannot measure that execution plan.

## Nightly command order

All identifiers below are examples. The **same generation** is used from upstream materialisation through the source read. An existing upstream scheduler invokes these as job steps; no secret or manual GUI action is required once the identities and external gates are implemented.

```bash
python python/fence.py write-start --source-set synapse_materialised --generation GEN_20260922_01 --actor SYN_20260922_01 --expiry-utc 2026-09-22T08:00:00
# Run the existing Synapse transformation/materialisation job here.
python python/upstream_audit.py --config config.json --upstream-run-id SYN_20260922_01 --generation-id GEN_20260922_01 --writer-owner SYN_20260922_01 --sequence 2026092201 --business-date 2026-09-22
python python/fence.py write-close --source-set synapse_materialised --generation GEN_20260922_01 --actor SYN_20260922_01 --expiry-utc 2026-09-22T08:00:00
python python/fence.py bridge-hold --config config.json --upstream-run-id SYN_20260922_01 --source-set synapse_materialised --generation GEN_20260922_01 --actor BRG_20260922_01 --expiry-utc 2026-09-22T08:00:00
python python/bridge_run.py --config config.json --upstream-run-id SYN_20260922_01 --generation-id GEN_20260922_01 --sequence 2026092201 --business-date 2026-09-22 --bridge-run-id BRG_20260922_01
# Produce real audit/monitoring/source-smoke evidence and inspect every source request.
python python/fence.py bridge-release --source-set synapse_materialised --generation GEN_20260922_01 --actor BRG_20260922_01 --evidence fence_evidence.json
# Run policy/consumer/readiness tests with the correct restricted identities.
# publish_run.py refuses to start until bridge.fence_events records this bridge-release.
python python/publish_run.py --config config.json --bridge-run-id BRG_20260922_01 --evidence publication_evidence.json
# Optional, e.g. weekly: review the dry run, then apply.
python python/retire_releases.py --config config.json
python python/retire_releases.py --config config.json --execute --delete-staging
```

`bridge_meta.upstream_run.write_closed=1` means the writer has completed and committed its audit while it still owns `WRITE_ACTIVE`; the authoritative physical interlock is the subsequent fence transition to `CLOSED`, followed by `BRIDGE_HELD`.

The `fence_evidence.json` must contain `source_generation_id`, and each of `all_source_requests_terminal`, `no_source_retry_needed`, `audit_healthy`, `no_fence_violation`, `smoke_check_passed` set to `true`, with a separate `<field>_evidence_uri` for each. The publication evidence must contain `bridge_run_id`, `release_id`, `generation_id`, integer `upstream_sequence`, and `fence_clean`, `source_smoke_check`, `audit_health`, `policy_readiness`, `restricted_identity_tests`, `consumer_contract_tests`, each with a `<field>_evidence_uri`. An external evidence producer must generate them from actual platform records; a hand-written `true` file provides no assurance.

## Failure and recovery

Every run carries an orchestrator lease (`bridge.runs.orchestrator_token` plus a heartbeat every `heartbeat_seconds`). All control writes are conditional on the token, so a superseded process cannot change state. `takeover_after_minutes` must cover the two-hour external-job timeout plus the cancellation window (minimum 135; example 150 minutes).

- **Extraction or load failed** (`bridge.runs.status = FAILED`): fix the cause, then rerun `bridge_run.py` with the **same arguments plus `--resume`**. READY mappings are kept; EXTRACTED/LOADING mappings are reloaded idempotently from their retained Parquet; FAILED or interrupted extractions get a new `attempt-NNN` path, up to `max_attempts`. The fence must still be held if anything needs re-extraction.
- **Unknown external outcome**: the attempt becomes `INDETERMINATE`, keeps its correlation/run ID and blocks both `--resume` and `bridge-release`. After an independent monitor proves the stored operation terminal, run `python/recovery.py resolve-attempt ... --evidence terminal.json`; the evidence must match that ID. Each Databricks submission uses a fresh idempotency token that is stored (`token:…`) before `run-now`, so a retry always launches a new run while an unknown submission can still be looked up by calling `run-now` with the stored token.
- **Orchestrator stopped mid-operation**: on `--resume`, an attempt still `EXTRACTING` with a submitted source operation, or `LOADING` with a running loader, is recorded as `INDETERMINATE` and the resume stops. Resolve it with `recovery.py resolve-attempt`, then resume again. An attempt whose operation was never submitted (`PENDING`) is superseded automatically.
- **CETAS errors**: a SQLSTATE the server returns for a rejected or rolled-back statement (for example `42xxx` syntax/permission, `22xxx` data, `40xxx` rollback) is a normal `FAILED` attempt and is retried on `--resume`. Connection loss, query timeout, cancellation, generic driver errors and interrupts are `INDETERMINATE`.
- **Publication interrupted** (`PUBLISHING`): if a stored mutating publisher is `RUNNING` or `UNKNOWN`, first prove that exact external ID terminal and run `python/recovery.py resolve-publication ... --evidence publisher_terminal.json`. The evidence must also affirm that the old orchestrator stopped and that resume is safe. Then rerun `publish_run.py` with `--resume`. Read-only INSPECT runs never overwrite the mutating publisher ID. Each target is compared with its actual Delta state first: a commit whose Azure SQL update was lost is reconciled, not republished; an unexpected Delta state stops that target for review.
- **Generation unusable** (source changed, fence expired, too many attempts): `python python/fence.py abandon --source-set ... --generation ... --actor <current owner> --reason "..."` locks the fence/run rows, marks attempts and unpublished runs of that generation in that source set `ABANDONED_GENERATION`, and clears their claims. Unpublished runs created before v9.5.5 that the upgrade could not attribute to a source set are never relabelled implicitly: abandon lists them and stops, and you confirm they belong to this source set by adding `--claim-legacy-runs`; then `fence.py reopen` returns the fence to AVAILABLE. Abandon remains refused while a run is actively `PUBLISHING`. Both `abandon` and `reopen` are also refused while any attempt of the generation may still be reading the source; resolve those with `recovery.py resolve-attempt` first. Attempts that never submitted a read (`PENDING`) do not block.
- **Publication must be abandoned**: first prove the stored publisher operation terminal and inspect Delta, then run `python/recovery.py abandon-publication ... --evidence publication_terminal.json`. It records an immutable recovery event and clears only the verified claim.
- **Fence release** requires the bridge run to be `READY` and rejects `EXTRACTING`, `INDETERMINATE`, `RUNNING` or `UNKNOWN` source operations.
- **Two runs publishing the same target**: each target has a publication claim in `bridge.target_state` (`publish_owner`). A run takes it before changing Delta and releases it in the same update that records the publication, so a second run is refused with "being published by run …" and can simply be resumed later. If the owning run fails with an unknown outcome, the claim stays with it; only that run's `publish_run.py --resume`, which inspects Delta first, can continue. A run that finds a *newer* release already live reports that target as `superseded-by-newer` and never rolls it back.

For attempts created before v9.3, retain the approved versioned configuration files and pass each older one to retention with `--inventory-config old_wave.json`. v9.3 attempts store their cleanup metadata directly, so later removal from the current mapping inventory does not hide them.

Do not publish a pointer group until all its physical slices, control row, policies and consumer views exist.

## Validation performed locally

Run `python -m compileall -q python databricks tests`, `python -m json.tool config.example.json`, and `pytest -q tests`. The suite covers fail-closed configuration, extraction/load recovery, indeterminate operations, persisted external IDs, per-invocation Databricks tokens, orphaned operations after an orchestrator stop, CETAS error classification, audited recovery, candidate cleanup metadata, publication races and reconciliation. It does not replace Azure SQL, Synapse, Synapse pipeline, ADLS or Databricks acceptance tests with the deployment identities.

## Product references

- [Synapse CETAS syntax and permissions](https://learn.microsoft.com/en-us/sql/t-sql/statements/create-external-table-as-select-transact-sql)
- [Synapse pipeline createRun](https://learn.microsoft.com/en-us/rest/api/synapse/data-plane/pipeline/create-pipeline-run)
- [Synapse Copy from Synapse dedicated SQL pool](https://learn.microsoft.com/en-us/azure/data-factory/connector-azure-sql-data-warehouse)
- [Databricks SDK for Python](https://learn.microsoft.com/en-us/azure/databricks/dev-tools/sdk-python)
- [Databricks table replacement privileges](https://learn.microsoft.com/en-us/azure/databricks/tables/tables-concepts)
- [Synapse dedicated pool: load external data using a managed identity](https://learn.microsoft.com/en-us/azure/synapse-analytics/sql/tutorial-external-tables-using-managed-identity)
- [Parquet format type mapping for Copy](https://learn.microsoft.com/en-us/azure/data-factory/format-parquet)
- [Serverless jobs auto-optimization](https://learn.microsoft.com/en-us/azure/databricks/jobs/run-serverless-jobs)
- [Unity Catalog JDBC connection](https://learn.microsoft.com/en-us/azure/databricks/connect/jdbc-connection)
- [Delta idempotent writes](https://learn.microsoft.com/en-us/azure/databricks/structured-streaming/delta-lake)

## v9.1 fixes

| # | Problem in v9 | Fix |
|---|---|---|
| 1 | Fence checked only before extraction; a read could finish after the fence expired | `extract_one` re-checks the fence (margin 0) before marking EXTRACTED; expiry is compared in SQL |
| 2 | Synapse Copy row check passed when metrics were missing (`None == None`) and ignored the audited count | Requires integer `rowsRead == rowsCopied == source_rows`, filtered to the copy activity |
| 3 | No retry path: fixed `attempt-001`, rerun refused, fence could not be reassigned | `--resume`, attempt numbering, `max_attempts`, `SUPERSEDED` state; `fence.py abandon/reopen` |
| 4 | Multi-member REPLACE_TABLE groups published partially with no resume | REPLACE_TABLE groups must have exactly one member; `publish_run.py --resume` |
| 5 | Delta pointer and Azure SQL could diverge with no recovery | INSPECT mode + reconciliation on resume; pointer version read from Delta, not the SQL counter |
| 6 | Job payload in a notebook parameter exceeded the size limit for wide tables/groups | Payload written as an immutable, SHA-256-checked manifest under the staging location |
| 7 | Profilers could not size view-based mappings | Optional `materialised_schema`/`materialised_table`; generator sets them for tables |
| 8 | `render_setup.py` failed or duplicated rows on later waves | Fully idempotent SQL (`IF NOT EXISTS`, `MERGE`, drift check); physical tables pre-created |
| 9 | Candidate names collided for IDs differing only by `-`/`_` | Hash-based, attempt-specific candidate names computed once by the orchestrator |
| 10 | Property check failed for non-string values | Config requires string values; loader, publisher and check use them unchanged |
| 11 | CETAS metadata cleanup failure could hide the real error | Cleanup errors are reported separately and never replace the original error |
| — | ARM token fetched once, expired during two-hour Synapse pipeline polls | Token fetched per request from a cached credential |
| — | Timed-out Databricks/Synapse pipeline runs kept running while state moved on | Cancelled on timeout; unconfirmed cancellation keeps the lease |
| — | pyodbc `with` never closed connections; long-held idle connections | `db()` always closes; short-lived connections around long operations; CETAS statement timeout |
| — | Unknown `size_class` crashed the scheduler; profiler crashed on missing thresholds | Validated up front |
| — | Upstream sequence regressions caught only after a full extraction | `upstream_audit.py` enforces increasing sequences |
| — | `_snapshots`, candidates and staging grew without limit | `retire_releases.py` + retention Job |
| — | Unused imports, unused `LOADING` state, `CREATED` missing from the failure handler | Cleaned up; `LOADING` is now used |

## v9.3 changes

Upgrade the control database with `sql/03_upgrade_to_v9_5.sql`.

| Problem in v9.1 | Fix |
|---|---|
| PySpark profiler rebound its `physical` lookup function as a DataFrame, so profiling failed | Function renamed `physical_source`, DataFrame `physical_df`; static test added |
| `publish_run.py --resume` could replace a REPLACE_TABLE target holding an unexpected release | Resume publishes only if Delta matches Azure SQL's published release (or no bridge release yet); otherwise the target is frozen |
| Two different runs could both replace a REPLACE_TABLE target; the loser's Azure SQL update failed after its Delta commit, and an older run could land last | Per-target publication claim in Azure SQL, taken before any Delta change; older runs skip targets that already hold a newer release; race test added |
| Notebook `PACKAGE_DIR` and docs used the old `bridge_v9_scripts` folder name | Updated to `bridge_v9_3_scripts`; test checks they match |
| Indeterminate source reads became FAILED and no longer blocked fence release | Dedicated `INDETERMINATE` state; release now requires a READY run and no running/unknown operation |
| Polling failures after Synapse pipeline/Databricks submission were treated as ordinary failures | All post-submission uncertainty raises `Indeterminate`; IDs/correlation tokens are persisted before polling |
| Takeover could occur before the two-hour job and cancellation windows elapsed | Minimum takeover is 135 minutes; example/default is 150 minutes |
| Failed publication claims had no governed escape path | `recovery.py` provides evidence-gated attempt and publication recovery with `bridge.recovery_events` |
| Failed-load candidates and older inventory waves escaped retention | Attempt rows record Delta target, strategy, target key and consumer target before load; retention plans from immutable attempt metadata |
| Profilers required view and materialised-table column counts to match | Physical and mapped column counts are recorded separately; subset views are supported |
| Manual config accepted invalid decimals | Precision is limited to 1–38 and scale to 0–precision |
| Synapse pipeline deployment left the dummy dataset schema hard-coded | `--source-dummy-schema` is required |

## v9.4 changes

Found in an independent review of v9.3. These fixes remain included in v9.5 through `sql/03_upgrade_to_v9_5.sql`.

| Problem in v9.3 | Fix |
|---|---|
| The Databricks idempotency token was a hash of the payload. Databricks returns the existing run for a known token whatever its state, so a retry after a failed loader/publisher job re-adopted the failed run forever | Token includes a per-invocation nonce; it is still persisted before `run-now` |
| For the same reason every `publish_run.py --resume` INSPECT returned the first inspection's output instead of current Delta state | Fixed by the same change; each INSPECT is a new run |
| A read in flight when the orchestrator stopped was marked `SUPERSEDED` on takeover but kept `source_operation_state='RUNNING'`, blocking `bridge-release` with no tool to clear it | Submitted in-flight reads and running loaders become `INDETERMINATE` on resume and go through `recovery.py`; never-submitted (`PENDING`) attempts are superseded as `NOT_STARTED`. `resolve-attempt` also clears such legacy v9.3 `SUPERSEDED` rows |
| Every CETAS error, including permission or syntax errors, became `INDETERMINATE` and needed manual recovery | Server-returned SQLSTATE classes are terminal (`FAILED`); only unknown outcomes are `INDETERMINATE` |
| The upgrade script did not replace the `source_fence` state constraint and omitted the `publication_strategy` check | Both included in `03_upgrade_to_v9_5.sql` |
| The release gate was an inline query | `fence.release_blockers()` returns the blocking attempts, used by `bridge-release` and the tests |

## v9.5 changes

Found in an independent review of v9.4. Upgrade existing v9 through v9.4 control databases with `sql/03_upgrade_to_v9_5.sql`. The package folder is now `bridge_v9_5_8_scripts`; set `PACKAGE_DIR` accordingly.

| Problem in v9.4 | Fix |
|---|---|
| `publish_run.py --resume` could overwrite an unresolved mutating publisher ID with an INSPECT ID, then start a second publisher without terminal evidence | Resume refuses `RUNNING`/`UNKNOWN` publishers; `recovery.py resolve-publication` requires matching terminal evidence; INSPECT never writes publisher tracking fields |
| An unknown read-only INSPECT retained the run lease even though retrying it cannot change Delta | INSPECT uncertainty becomes an ordinary retryable failure and releases the lease |
| Documentation omitted v9.3 from some upgrade paths and treated the runner's polling timeout as sufficient | All v9 through v9.4 upgrade paths are explicit; deployment now requires a Databricks Job timeout of at most 7,200 seconds as defence in depth |

## Recovery evidence files (v9.5.1)

Recovery is deliberately evidence-gated. The external operation identified by the ID stored in the control tables must be checked independently before running `python/recovery.py`. A stored ID can be the actual external run ID or, when submission acknowledgement was lost, a `token:...` / `correlation:...` placeholder. Evidence must refer to that exact stored ID, with two placeholder forms:

- `correlation:...` (Synapse Copy): give `source_correlation` equal to the stored value and the actual Synapse run as `external_run_id`.
- `token:...` (Databricks loader or publisher, v9.5.8): give `idempotency_token` equal to the stored value (with or without the `token:` prefix) and the actual Databricks run found for that token as `external_run_id`; the real run ID then replaces the token in the control row and the recovery event. If the job's run list shows no run for the token, repeat the stored `token:...` value as `external_run_id` instead.

### `resolve-attempt`

Required JSON fields: `phase` (`SOURCE` or `LOADER`), `external_terminal: true`, `safe_to_retry: true`, `external_run_id`, and non-empty `evidence_uri`.

Accepted attempts: `INDETERMINATE` (moves to a retryable state; `phase` must be the operation that is `RUNNING`/`UNKNOWN`, and the other phase must not also be unresolved), legacy `SUPERSEDED` with a running source read, and `ABANDONED_GENERATION` with a `RUNNING`/`UNKNOWN` operation for the given phase. For the last two, status is unchanged and only the operation is marked `VERIFIED_TERMINAL`, which unblocks `bridge-release`, `reopen` and retention respectively.

Example:
```json
{"phase":"SOURCE","external_terminal":true,"safe_to_retry":true,"external_run_id":"<stored-source-request-id>","evidence_uri":"<independent-evidence-uri>"}
```

### `resolve-publication`

Required JSON fields: `external_terminal: true`, `safe_to_resume: true`, `orchestrator_stopped: true`, `external_run_id`, and non-empty `evidence_uri`.

Example:
```json
{"external_terminal":true,"safe_to_resume":true,"orchestrator_stopped":true,"external_run_id":"<stored-publisher-run-id>","evidence_uri":"<independent-evidence-uri>"}
```

When the stored publisher (or loader) ID is a `token:...` placeholder:
```json
{"external_terminal":true,"safe_to_resume":true,"orchestrator_stopped":true,"idempotency_token":"<stored token:... value>","external_run_id":"<Databricks run ID found for that token>","evidence_uri":"<independent-evidence-uri>"}
```

### `abandon-publication`

Required JSON fields: `external_terminal: true`, `delta_state_verified: true`, `safe_to_abandon: true`, `external_run_id`, and non-empty `evidence_uri`.

Example:
```json
{"external_terminal":true,"delta_state_verified":true,"safe_to_abandon":true,"external_run_id":"<stored-publisher-run-id>","evidence_uri":"<independent-evidence-uri>"}
```

Do not manufacture evidence merely to satisfy the schema. `evidence_uri` should point to the independently retained operational evidence used for the decision.

## v9.5.2 fixes

| Problem found in v9.5.1 | Fix |
|---|---|
| The abandon/reopen guard treated never-submitted (`PENDING`) attempts as live reads; with an expired fence, neither `abandon` nor `--resume` could clear them | `PENDING` no longer blocks. The guard now reads attempt rows `WITH (UPDLOCK,HOLDLOCK)`, so an orchestrator cannot submit between the check and the abandon; afterwards its lease check fails before submission |
| Rows abandoned before the guard existed could keep `RUNNING`/`UNKNOWN` operations, permanently blocking `reopen` and retention | `recovery.py resolve-attempt` accepts `ABANDONED_GENERATION` attempts and records `RESOLVE_ABANDONED` |
| The abandon, reopen and retention fixes were only tested through a helper | `tests/test_v952_regressions.py` drives the real entry points and fails on v9.5 and v9.5.1 code |

## v9.5.5 review fixes

| Problem | Fix |
|---|---|
| `resolve-attempt` accepted evidence for whichever phase the operator named. Proving an already-finished source read terminal moved a loader-`UNKNOWN` attempt to `FAILED` and cleared the lease, so a retry could start while the loader was still writing; for `RELEASE_POINTER` a committed first slice then made every later attempt fail with "Slice already committed" | The named phase must be `RUNNING`/`UNKNOWN`, and the other phase must not be unresolved. Pre-v9.4 rows with no recorded operation state are still accepted, as before |
| Two `RELEASE_POINTER` mappings with the same catalog, `physical_schema` and `target_table` (for example in different target schemas) shared one `_snapshots` table, and the generated views filtered only on `release_id`, so each view showed the other mapping's rows | `config()` rejects a shared snapshot table; generated views also filter on `mapping_object_id` |
| `fence.py abandon`/`reopen` selected runs by generation ID only, so another source set using the same generation ID was relabelled or blocked | `bridge.runs.source_set_id` is recorded for new runs, backfilled when a legacy run is resumed, and both commands filter on it (legacy rows with no source set remain in scope) |
| `deploy_synapse_pipeline.py` treated `202 Accepted` as done, so the pipeline could race its datasets and success could be reported for a deployment that later failed | Each artifact's operation is polled (honouring `Location`/`Retry-After`), failures are reported, a non-JSON completion body is tolerated, and the artifact is read back before the next one is deployed |
| A profile without the legacy `column_count` key crashed `config()` with `KeyError` | Fallback is evaluated lazily |
| When the fence re-check after a successful read failed, the attempt's `source_operation_state` was overwritten from `SUCCEEDED` to `FAILED` | On an ordinary failure a recorded `SUCCEEDED` state is kept; the attempt is still `FAILED` and retried. An indeterminate stop (for example SIGTERM) still records `UNKNOWN`, so the attempt remains resolvable with SOURCE evidence |
| A loader result that failed the orchestrator's count/target check was never recorded | The reason is written to `error_text`; the attempt stays `LOADING` for idempotent re-verification |

**Upgrading an existing deployment:** run `sql/03_upgrade_to_v9_5.sql` (adds `bridge.runs.source_set_id`). The generated consumer views use `CREATE VIEW IF NOT EXISTS`, so existing pointer views keep their old definition; after confirming no two mappings share a snapshot table (the new `config()` check), replace each existing pointer view through your governed view-change process with the definition in the regenerated `unity_catalog_setup.sql`.

## v9.5.3 Synapse pipeline correction

- `COPY_ACTIVITY` is implemented through the Azure Synapse workspace data-plane API, not Azure Data Factory ARM endpoints.
- Configuration uses `synapse_pipeline.workspace_name`, optional `synapse_pipeline.endpoint`, and `synapse_pipeline.copy_pipeline`.
- Pipeline create-run, run-status, activity-run metrics, and cancellation use Synapse API version `2020-12-01`.
- A deterministic `source_correlation` is persisted before submission and passed as a Synapse pipeline parameter. If the external run starts but its `runId` cannot be persisted, operators can correlate the stored value with the actual Synapse pipeline run before audited recovery.
- `COPY_ACTIVITY` config is validated fail-closed.
- The optional deployment helper is `python/deploy_synapse_pipeline.py`, with artifacts under `synapse_pipeline/`.

## v9.5.6 review fixes

Upgrade existing v9 through v9.5.5 control databases with `sql/03_upgrade_to_v9_5.sql` (it now also backfills `bridge.runs.source_set_id`). Pointer views created before v9.5.5 still need the governed view replacement described above.

| Finding in v9.5.5 | Change |
|---|---|
| `fence.py abandon` modified legacy runs with no recorded source set, so abandoning one set could relabel another set's READY run that reused the generation ID | The upgrade backfills the source set wherever `bridge.fence_events` names exactly one set for the generation. Abandon modifies only runs recorded against its source set; remaining unattributed unpublished runs make it stop and list them until confirmed with `--claim-legacy-runs`. They still block abandon/reopen while unresolved (fail-closed guard unchanged) |
| A rejected loader result stayed `LOADING`, so every `--resume` reran the loader and `max_attempts` never applied | The attempt becomes `FAILED` with `loader_operation_state='REJECTED'`. REPLACE_TABLE re-extracts as a new attempt under `max_attempts`; RELEASE_POINTER stops `--resume` with instructions, because its committed slice cannot be replaced by another attempt. A v9.5.5 row left `LOADING` is reloaded once and then converted |
| `deploy_synapse_pipeline.py` could confirm an update by reading back the previous definition | The etag is captured before each PUT; a 202 without `Location` is refused; the read-back must show the artifact is new, its etag changed, or its properties contain what was submitted |
| Only pointer-vs-pointer snapshot collisions were rejected | All consumer targets, snapshot tables and the control `published_groups` table share one case-insensitive name space; `candidate_*` names in a candidate schema are reserved |
| An interrupt before any source submission left `INDETERMINATE` with no external ID, blocking recovery, resume and abandon | A stored `PENDING` state proves nothing was submitted; the attempt is recorded `FAILED`/`NOT_STARTED` and retried |
| Pre-v9.4 attempts without operation states accepted SOURCE evidence even when a loader run was stored | Such attempts require LOADER evidence |
| `source_set_id` was only checked for presence | Must be a string of 1–128 characters without surrounding spaces |
| README, SCRIPT_GUIDE and `01_azure_sql_control.sql` still described the upgrade script as v9–v9.4 only | Corrected to v9 through v9.5.5 |

`tests/test_v956_regressions.py` covers each change.

## v9.5.7 documentation verification fixes

Found by checking every platform call against Microsoft Synapse and Azure Databricks documentation. No control-database schema change: v9.5.6 databases need no upgrade script run.

| Problem in v9.5.6 | Fix |
|---|---|
| `02_synapse_setup.sql` created the dedicated-pool credential with `IDENTITY = 'Managed Identity'`; Microsoft documents `'Managed Service Identity'` for dedicated-pool PolyBase/CETAS with a `TYPE = HADOOP` data source (and requires it for VNet-secured storage) | Script uses `'Managed Service Identity'`. **Existing deployments:** run `ALTER DATABASE SCOPED CREDENTIAL bridge_storage_mi WITH IDENTITY = 'Managed Service Identity';` in the dedicated pool, then retest a CETAS write |
| A `COPY_ACTIVITY` mapping with a SQL `date` column could never load: Synapse Copy maps `date` to interim DateTime, the Parquet sink writes INT96, and Spark reads timestamp, so the loader's `date` physical-type check always failed | `config()` rejects `source_spark_type: date` on `COPY_ACTIVITY` with an explanatory message; `generate_mappings.for_copy_activity()` re-routes a mapping with `timestamp` physical types; the loader narrows timestamp→date only after proving every value is midnight UTC |
| `DESIGN_v9.md` §4 required server-login grants and forbade contained users for CETAS | Rewritten with database-scoped dedicated-pool grants (`ADMINISTER DATABASE BULK OPERATIONS`, `ALTER ANY EXTERNAL DATA SOURCE/FILE FORMAT`, `ALTER ON SCHEMA::bridge_meta`) for a contained Entra user |
| Serverless auto-optimization retries were disabled only on publication and retention | Disable on the loader as well (timeout applies per retry) |
| The idempotency-token comment implied re-calling run-now is a read-only probe | Comment states that run-now with an unused token starts the run |

Also noted: `notebook_params` is deprecated in favour of `job_parameters` (still supported; keep manifest parameters as notebook widgets, not job-level parameters); the Unity Catalog JDBC connection option used by `generate_mappings_pyspark.py` is a preview feature and its connection must allow the `query` option; CETAS-to-Parquet can reject data containing `|`, `"`, `\r` or `\n`, so include such values in acceptance tests. Still to prove on the platform: that `MANAGE` + `CREATE TABLE` suffices for the Strategy A publisher's `CREATE OR REPLACE TABLE`, the replicated-table row estimate in the profiler, and Synapse artifact etag/async behaviour.

## v9.5.8 review fixes

Found in a code review of v9.5.7. No Azure SQL control schema change: v9.5.6/v9.5.7 databases need no upgrade script. Before upgrading:

- If the orchestration identity has table-scoped rights, grant it `SELECT` on `bridge.fence_events`; `publish_run.py` now reads it.
- **Rerun `generated/unity_catalog_setup.sql`** (from `render_setup.py`) once so the existing `published_groups` table gets deletion vectors. This upgrades the table's Delta protocol: any reader of it, or of the pointer views, outside Databricks must support deletion vectors.
- Redeploy the three changed notebooks: `load_candidate.py` (loader Job), `publish.py` (both publisher Jobs) and `retire_releases.py` (retention Job).
- The loader now always runs in UTC. If your workspace sets a different default session time zone, `timestamp` to `timestamp_ntz` or `string` conversions now follow UTC instead; check such mappings once.
- A run already `PUBLISHING` when you upgrade is resumed normally: the fence-release check applies when a `READY` run starts publishing.

| Problem in v9.5.7 | Fix |
|---|---|
| Every RELEASE_POINTER group updates the one `published_groups` Delta table, so with `max_publisher_workers` above 1 concurrent pointer publications could fail with Delta concurrent-modification conflicts (safe, but it defeated the parallelism) | `render_setup.py` creates the table with `delta.enableDeletionVectors` and `ALTER`s an existing one, enabling Databricks row-level concurrency. `publish.py` also retries the pointer `UPDATE` up to six times with backoff, only on a Delta conflict (which commits nothing); the statement keeps its version, expected-release and high-water guards, so a retry cannot publish twice |
| `--business-date` was not compared with the upstream audit, although it names the staging paths and is stamped on every Delta row | `bridge_run.py` requires it to equal `bridge_meta.upstream_run.business_date` for the generation, before any run row is created |
| The loader set the UTC session zone only when a mapping narrowed timestamp to date, after the null-loss check, so other timestamp conversions depended on which columns a mapping had | `load_candidate.py` sets UTC once, before reading the manifest, for every mapping |
| `publish_run.py` trusted the evidence file's `fence_clean` for the fence release | It also requires the `BRIDGE_HELD → AVAILABLE` event in `bridge.fence_events` for this source set, generation and bridge run before a `READY` run starts publishing (`--resume` of a `PUBLISHING` run does not repeat it, so runs left `PUBLISHING` by v9.5.7 can still finish) |
| After a lost Databricks submission the stored loader/publisher ID is `token:...`, and recovery demanded that literal string as `external_run_id`, rejecting the real run ID | `recovery.py` accepts `idempotency_token` plus the actual run ID and records the real ID (see *Recovery evidence files*); repeating the token still means no run was found |
| Retention ignored the `DESIGN_v9.md` 7/30-day windows, and never retired FAILED/SUPERSEDED attempts of a kept release, leaking their candidate tables and staging | Candidate drops and staging deletion wait `retention_days_published` (7) days after publication for a published run's READY attempt and `retention_days_unpublished` (30) days after the run's last state change otherwise; a missing timestamp is never old enough. FAILED/SUPERSEDED attempts are retired even when their release is kept, and the retention job skips a candidate only when its own attempt is live in the consumer table. The dry run reports `not_yet_eligible`. The published and previous releases' READY candidates are still kept for rollback, and pointer snapshot rows are unchanged |

`tests/test_v958_regressions.py` covers each change; its bug tests fail on v9.5.7 code. The SQLite simulation now models `bridge.fence_events` and `DATEDIFF`. Still to prove on the platform: row-level concurrency on the chosen runtime, and that the Delta conflict exception names match `publish.py`'s list.
